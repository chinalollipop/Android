//
// 更多 - 主页
//

#import "CFCSettingCoreModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCAppMoreInfoMainModel : CFCSettingCoreModel

+ (NSMutableArray *) buildingDataModles;

@end

NS_ASSUME_NONNULL_END
