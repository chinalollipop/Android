//
// 更多 - 联系我们
//

#import "CFCSettingCoreModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCContactUSModel : CFCSettingCoreModel

@property (nonatomic, copy) NSString *markImageUrl; // 图标

+ (NSMutableArray *) buildingDataModles;

@end

NS_ASSUME_NONNULL_END
