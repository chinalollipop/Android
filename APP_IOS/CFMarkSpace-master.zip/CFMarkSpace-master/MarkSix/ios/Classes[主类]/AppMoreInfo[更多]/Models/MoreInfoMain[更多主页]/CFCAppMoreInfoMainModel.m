//
// 更多 - 主页
//

#import "CFCAppMoreInfoMainModel.h"

@implementation CFCAppMoreInfoMainModel

+ (NSMutableArray *) buildingDataModles
{
  NSMutableArray<NSMutableArray *> *modelGroups = [NSMutableArray array];
  {
    NSArray *titles = @[
                        @[ @"关于应用" ],
                        @[ @"免费声明", @"意见反馈" ],
                        @[ @"联系我们", @"短信分享", @"软件分享" ]
                        ];
    NSArray *contents = @[
                          @[ @"" ],
                          @[ @"", @"" ],
                          @[ @"", @"", @"" ]
                          ];
    NSArray *markIds = @[
                         @[ STR_MARKID_MOREINFO_SETTING_ABOUT_SOFTWARE ],
                         @[ STR_MARKID_MOREINFO_SETTING_FREE_DECLARATION, STR_MARKID_MOREINFO_SETTING_SUGGESTION ],
                         @[ STR_MARKID_MOREINFO_SETTING_CONTACT_US, STR_MARKID_MOREINFO_SETTING_SHARE_SMSC, STR_MARKID_MOREINFO_SETTING_SHARE_SOFTWARE ]
                         ];
    NSArray *isEdits = @[
                         @[ [NSNumber numberWithBool:YES] ],
                         @[ [NSNumber numberWithBool:YES], [NSNumber numberWithBool:YES] ],
                         @[ [NSNumber numberWithBool:YES], [NSNumber numberWithBool:YES], [NSNumber numberWithBool:YES] ]
                         ];
    NSArray *isSwitchs = @[ @[ [NSNumber numberWithBool:NO] ],
                            @[ [NSNumber numberWithBool:NO], [NSNumber numberWithBool:NO] ],
                            @[ [NSNumber numberWithBool:NO], [NSNumber numberWithBool:NO], [NSNumber numberWithBool:NO] ]
                            ];
    for (int index = 0; index < titles.count; index ++) {
      NSMutableArray<CFCSettingCoreModel *> *models = [NSMutableArray array];
      NSArray *groupTitles = titles[index];
      NSArray *groupContents = contents[index];
      NSArray *groupMarkIds = markIds[index];
      NSArray *groupEdits = isEdits[index];
      NSArray *groupSwitchs = isSwitchs[index];
      for (int k = 0; k < groupTitles.count; k ++) {
        CFCSettingCoreModel *model = [[CFCSettingCoreModel alloc] init];
        [model setMarkId:groupMarkIds[k]];
        [model setTitle:groupTitles[k]];
        [model setContent:groupContents[k]];
        [model setIsEdit:[groupEdits[k] boolValue]];
        [model setIsSwitch:[groupSwitchs[k] boolValue]];
        [models addObject:model];
      }
      [modelGroups addObject:models];
    }
  }
  
  return modelGroups;
}

@end
