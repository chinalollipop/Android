//
// 更多 - 关于应用
//

#import "CFCSettingCoreModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCAboutAppModel : CFCSettingCoreModel

+ (NSMutableArray *) buildingDataModles;

@end

NS_ASSUME_NONNULL_END
