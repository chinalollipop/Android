//
// 更多 - 关于应用
//

#import "CFCAboutAppModel.h"


@implementation CFCAboutAppModel


+ (NSMutableArray *) buildingDataModles
{
  NSMutableArray<NSMutableArray *> *modelGroups = [NSMutableArray array];
  {
    NSArray *titles = @[
                        @[ [NSString stringWithFormat:@"V %@" , [CFCAppUtil getAppVersion]] ],
                        @[ @"应用简介", @"关于我们" ]
                        ];
    NSArray *contents = @[
                          @[ @"如有任何疑问，记得联系我们" ],
                          @[ @"", @"" ]
                          ];
    NSArray *markIds = @[
                         @[ @"" ],
                         @[ STR_MARKID_MOREINFO_SETTING_SOFTWARE_INTRO, STR_MARKID_MOREINFO_SETTING_ABOUT_US ]
                         ];
    NSArray *isEdits = @[
                         @[ [NSNumber numberWithBool:NO] ],
                         @[ [NSNumber numberWithBool:YES], [NSNumber numberWithBool:YES] ]
                         ];
    NSArray *isSwitchs = @[ @[ [NSNumber numberWithBool:NO] ],
                            @[ [NSNumber numberWithBool:NO], [NSNumber numberWithBool:NO] ]
                            ];
    for (int index = 0; index < titles.count; index ++) {
      NSMutableArray<CFCAboutAppModel *> *models = [NSMutableArray array];
      NSArray *groupTitles = titles[index];
      NSArray *groupContents = contents[index];
      NSArray *groupMarkIds = markIds[index];
      NSArray *groupEdits = isEdits[index];
      NSArray *groupSwitchs = isSwitchs[index];
      for (int k = 0; k < groupTitles.count; k ++) {
        CFCAboutAppModel *model = [[CFCAboutAppModel alloc] init];
        [model setMarkId:groupMarkIds[k]];
        [model setTitle:groupTitles[k]];
        [model setContent:groupContents[k]];
        [model setIsEdit:[groupEdits[k] boolValue]];
        [model setIsSwitch:[groupSwitchs[k] boolValue]];
        [models addObject:model];
      }
      [modelGroups addObject:models];
    }
  }
  
  return modelGroups;
}


@end

