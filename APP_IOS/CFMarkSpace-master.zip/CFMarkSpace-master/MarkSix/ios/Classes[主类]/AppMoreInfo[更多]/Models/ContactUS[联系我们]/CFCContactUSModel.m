//
// 更多 - 联系我们
//

#import "CFCContactUSModel.h"

@implementation CFCContactUSModel


+ (NSMutableArray *) buildingDataModles
{
  NSMutableArray<NSMutableArray *> *modelGroups = [NSMutableArray array];
  {
    NSArray *titles = @[
                        @[ @"" ],
                        @[ @"QQ：", @"微信：", @"网站：" ]
                        ];
    NSArray *contents = @[
                          @[ @"如有任何疑问，记得联系我们" ],
                          @[ @"扣扣号码", @"微信号码", @"网站地址" ]
                          ];
    NSArray *markIds = @[
                         @[ @"" ],
                         @[ @"", @"", @"" ]
                         ];
    NSArray *markImages = @[
                            @[ ICON_APP_LOGO ],
                            @[
                              @"icon_contact_qq",
                              @"icon_contact_weixin",
                              @"icon_contact_link"
                              ]
                            ];
    NSArray *isEdits = @[
                         @[ [NSNumber numberWithBool:NO] ],
                         @[ [NSNumber numberWithBool:YES], [NSNumber numberWithBool:YES], [NSNumber numberWithBool:YES] ]
                         ];
    NSArray *isSwitchs = @[ @[ [NSNumber numberWithBool:NO] ],
                            @[ [NSNumber numberWithBool:NO], [NSNumber numberWithBool:NO], [NSNumber numberWithBool:NO] ]
                            ];
    for (int index = 0; index < titles.count; index ++) {
      NSMutableArray<CFCContactUSModel *> *models = [NSMutableArray array];
      NSArray *groupTitles = titles[index];
      NSArray *groupContents = contents[index];
      NSArray *groupMarkIds = markIds[index];
      NSArray *groupMarkImages = markImages[index];
      NSArray *groupEdits = isEdits[index];
      NSArray *groupSwitchs = isSwitchs[index];
      for (int k = 0; k < groupTitles.count; k ++) {
        CFCContactUSModel *model = [[CFCContactUSModel alloc] init];
        [model setMarkId:groupMarkIds[k]];
        [model setTitle:groupTitles[k]];
        [model setContent:groupContents[k]];
        [model setMarkImageUrl:groupMarkImages[k]];
        [model setIsEdit:[groupEdits[k] boolValue]];
        [model setIsSwitch:[groupSwitchs[k] boolValue]];
        [models addObject:model];
      }
      [modelGroups addObject:models];
    }
  }
  
  return modelGroups;
}


@end
