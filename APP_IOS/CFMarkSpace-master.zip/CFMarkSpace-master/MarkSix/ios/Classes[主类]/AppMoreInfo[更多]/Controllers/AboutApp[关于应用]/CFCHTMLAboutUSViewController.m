//
// 更多 - 关于应用 - 关于我们
//

#import "CFCHTMLAboutUSViewController.h"


@interface CFCHTMLAboutUSViewController ()

@end


@implementation CFCHTMLAboutUSViewController

#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_ABOUT_US;
}


@end

