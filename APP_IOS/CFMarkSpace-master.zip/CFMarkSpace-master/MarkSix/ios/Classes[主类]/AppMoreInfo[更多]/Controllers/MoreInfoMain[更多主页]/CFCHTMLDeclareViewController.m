//
// 更多 - 免费声明
//


#import "CFCHTMLDeclareViewController.h"

@interface CFCHTMLDeclareViewController ()

@end

@implementation CFCHTMLDeclareViewController


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_DECLAREATION;
}


@end
