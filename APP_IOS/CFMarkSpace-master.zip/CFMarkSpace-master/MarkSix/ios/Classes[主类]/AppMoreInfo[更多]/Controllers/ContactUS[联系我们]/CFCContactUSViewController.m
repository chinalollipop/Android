//
// 更多 - 联系我们
//

#import "CFCContactUSViewController.h"
#import "CFCContactUSLogoTableViewCell.h"
#import "CFCContactUSTableViewCell.h"
#import "CFCContactUSModel.h"


@interface CFCContactUSViewController () <CFCContactUSTableViewCellDelegate>

@end


@implementation CFCContactUSViewController



#pragma mark -
#pragma mark 事件处理 - 点击联系方式
- (void)didSelectRowAtContactUSModel:(CFCContactUSModel *)model
{
  if (!model.isEdit) {
    return;
  }
  
  CFCLog(@"%@", model.title);
  
  UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
  pasteboard.string = model.content;
  [CFCProgressAlertUtil showMessage:@"已复制" toView:self.view];
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    self.hasRefreshHeader = NO;
    self.hasRefreshFooter = NO;
  }
  return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
}


#pragma mark -
#pragma mark 请求地址
- (NSString *)getRequestURLString
{
  return URL_API_MORE_INFO_CONTACT_US;
}

#pragma mark 请求参数
- (NSMutableDictionary *)getRequestParamerter
{
  return [CFCNetworkParamsUtil getMoreInfoContactUSParameters];
}

#pragma mark 请求网络数据或加载缓存
- (NSMutableArray *)loadNetworkDataOrCacheDataSingle:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData
{
  WEAKSELF(weakSelf);
  
  NSDictionary *responseData = (NSDictionary *)responseDataOrCacheData;
  CFCLog(@"[联系我们][%@] => %@\n", CFC_DATA_TYPE(isCacheData), responseData);
  
  // 请求成功，解析数据
  NSDictionary *data = [responseData objectForKey:CFC_REQUEST_KEY_DATA];
  NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
  if (![CFCSysUtil validateResultCodeIsSuccess:status] || [CFCSysUtil validateObjectIsNull:data]) {
    return [NSMutableArray array];
  }
  
  /////////////////////////////////////////////////////////////////
  // A、组装数据 -> 开始
  /////////////////////////////////////////////////////////////////
  NSMutableArray *allItemModels = [CFCContactUSModel buildingDataModles];
  NSMutableArray<CFCContactUSModel *> *allContactModels = allItemModels.lastObject;
  for (NSInteger idx = 0; idx < allContactModels.count; idx ++) {
    CFCContactUSModel *itemModel = [allContactModels objectAtIndex:idx];
    if (0 == idx) {
      NSString *content = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:[data stringForKey:@"qq"]];
      [itemModel setContent:content];
    } else if (1 == idx) {
      NSString *content = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:[data stringForKey:@"WeChat"]];
      [itemModel setContent:content];
    } else if (2 == idx) {
      NSString *content = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:[data stringForKey:@"link"]];
      [itemModel setContent:content];
    }
  }
  /////////////////////////////////////////////////////////////////
  // A、组装数据 -> 结束
  /////////////////////////////////////////////////////////////////
  
  
  /////////////////////////////////////////////////////////////////
  // B、配置数据源  -> 开始
  /////////////////////////////////////////////////////////////////
  weakSelf.tableDataRefresh = [NSMutableArray array];
  if (allItemModels && 0 < allItemModels.count) {
    [weakSelf.tableDataRefresh addObjectsFromArray:allItemModels.mutableCopy];
  }
  /////////////////////////////////////////////////////////////////
  // B、配置数据源  -> 结束
  /////////////////////////////////////////////////////////////////
  
  return weakSelf.tableDataRefresh;
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_CONTACT_US;
}


#pragma mark -
#pragma mark 注册 UITableViewCell
- (void)tableViewRefreshRegisterClass:(UITableView *)tableView
{
  [self.tableViewRefresh registerClass:[CFCContactUSLogoTableViewCell class]
                forCellReuseIdentifier:CELL_IDENTIFIER_CONTACT_US_LOGO_TABLE_CELL];
  
  [self.tableViewRefresh registerClass:[CFCContactUSTableViewCell class]
                forCellReuseIdentifier:CELL_IDENTIFIER_APP_CONTACT_US];
}


#pragma mark -
#pragma mark UITableViewDelegate UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0) {
    return self.tableDataRefresh.count;
  }
  return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0 && self.tableDataRefresh.count > section) {
    if ([self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
      NSMutableArray *group = self.tableDataRefresh[section];
      if ([group isKindOfClass:[NSArray class]]) {
        return group.count;
      }
    }
  }
  return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  if (0 == indexPath.section) {
    CFCContactUSLogoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_CONTACT_US_LOGO_TABLE_CELL];
    if (!cell) {
      cell = [[CFCContactUSLogoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_CONTACT_US_LOGO_TABLE_CELL];
    }
    cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
  } else {
    CFCContactUSTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_APP_CONTACT_US];
    if (!cell) {
      cell = [[CFCContactUSTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_APP_CONTACT_US];
    }
    cell.delegate = self;
    cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
  }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  if (0 == indexPath.section) {
    return [self.tableViewRefresh fd_heightForCellWithIdentifier:CELL_IDENTIFIER_CONTACT_US_LOGO_TABLE_CELL cacheByIndexPath:indexPath configuration:^(CFCContactUSLogoTableViewCell *cell) {
      cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
    }];
  } else {
    return [self.tableViewRefresh fd_heightForCellWithIdentifier:CELL_IDENTIFIER_APP_CONTACT_US cacheByIndexPath:indexPath configuration:^(CFCContactUSTableViewCell *cell) {
      cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
    }];
  }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableViewRefresh.frame.size.width, CFC_AUTOSIZING_MARGIN(MARGIN))];
  [headerView setBackgroundColor:COLOR_TABLEVIEW_HEADER_VIEW_BACKGROUND_DEFAULT];
  return headerView;
}


- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableViewRefresh.frame.size.width, CFC_AUTOSIZING_MARGIN(MARGIN))];
  [footerView setBackgroundColor:COLOR_TABLEVIEW_FOOTER_VIEW_BACKGROUND_DEFAULT];
  return footerView;
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return FLOAT_MIN;
}


- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return CFC_AUTOSIZING_MARGIN(MARGIN);
}


@end

