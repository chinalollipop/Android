//
// 更多 - 主页
//

#import <MessageUI/MessageUI.h>
#import "CFCAppMoreInfoMainViewController.h"
#import "CFCAppMoreInfoMainTableViewCell.h"
#import "CFCAppMoreInfoMainModel.h"

// 跳转页面
#import "CFCAboutAppViewController.h"
#import "CFCContactUSViewController.h"
#import "CFCAppSuggestViewController.h"
#import "CFCHTMLDeclareViewController.h"


@interface CFCAppMoreInfoMainViewController () <CFCAppMoreInfoMainTableViewCellDelegate, MFMessageComposeViewControllerDelegate>

@end


@implementation CFCAppMoreInfoMainViewController


#pragma mark -
#pragma mark 事件处理 - 根据标识处理相应事件
- (void)didSelectRowAtAppMoreInfoMainModel:(CFCAppMoreInfoMainModel *)model
{
  if (!model.isEdit) {
    return;
  }
  
  // 关于应用
  if ([STR_MARKID_MOREINFO_SETTING_ABOUT_SOFTWARE isEqualToString:model.markId]) {
    CFCAboutAppViewController *viewController = [[CFCAboutAppViewController alloc] init];
    [self.navigationController pushViewController:viewController animated:YES];
  }
  // 免费声明
  else if ([STR_MARKID_MOREINFO_SETTING_FREE_DECLARATION isEqualToString:model.markId]) {
    CFCHTMLDeclareViewController *viewController = [[CFCHTMLDeclareViewController alloc] initWithLocalHTMLString:@"html_declaration"];
    [self.navigationController pushViewController:viewController animated:YES];
  }
  // 意见反馈
  else if ([STR_MARKID_MOREINFO_SETTING_SUGGESTION isEqualToString:model.markId]) {
    CFCAppSuggestViewController *viewController = [[CFCAppSuggestViewController alloc] init];
    [self.navigationController pushViewController:viewController animated:YES];
  }
  // 联系我们
  else if ([STR_MARKID_MOREINFO_SETTING_CONTACT_US isEqualToString:model.markId]) {
    CFCContactUSViewController *viewController = [[CFCContactUSViewController alloc] init];
    [self.navigationController pushViewController:viewController animated:YES];
  }
  // 短信分享
  else if ([STR_MARKID_MOREINFO_SETTING_SHARE_SMSC isEqualToString:model.markId]) {
    [self showShareMessageViewController];
  }
  // 软件分享
  else if ([STR_MARKID_MOREINFO_SETTING_SHARE_SOFTWARE isEqualToString:model.markId]) {
    [self alertPromptInfoMessage:@"开发中"];
  }

}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    self.isRequestNetwork = NO;
    self.hasRefreshHeader = NO;
    self.hasRefreshFooter = NO;
  }
  return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  // 创建静态数据模型
  self.tableDataRefresh = [NSMutableArray array];
  NSMutableArray<CFCAppMoreInfoMainModel *> *allAppMoreInfoMainModels = [CFCAppMoreInfoMainModel buildingDataModles];
  if (allAppMoreInfoMainModels && 0 < allAppMoreInfoMainModels.count) {
    [self.tableDataRefresh addObjectsFromArray:allAppMoreInfoMainModels];
  }
  [self.tableViewRefresh reloadData];
}


#pragma mark -
#pragma mark 注册 UITableViewCell
- (void)tableViewRefreshRegisterClass:(UITableView *)tableView
{
  [self.tableViewRefresh registerClass:[CFCAppMoreInfoMainTableViewCell class]
                forCellReuseIdentifier:CELL_IDENTIFIER_APP_MORE_INFO_MAIN];
}


#pragma mark -
#pragma mark UITableViewDelegate UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0) {
    return self.tableDataRefresh.count;
  }
  return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0 && self.tableDataRefresh.count > section) {
    if ([self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
      NSMutableArray *group = self.tableDataRefresh[section];
      if ([group isKindOfClass:[NSArray class]]) {
        return group.count;
      }
    }
  }
  return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  CFCAppMoreInfoMainTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_APP_MORE_INFO_MAIN];
  if (!cell) {
    cell = [[CFCAppMoreInfoMainTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_APP_MORE_INFO_MAIN];
  }
  cell.delegate = self;
  cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
  cell.selectionStyle = UITableViewCellSelectionStyleNone;
  return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return [self.tableViewRefresh fd_heightForCellWithIdentifier:CELL_IDENTIFIER_APP_MORE_INFO_MAIN cacheByIndexPath:indexPath configuration:^(CFCAppMoreInfoMainTableViewCell *cell) {
    cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
  }];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableViewRefresh.frame.size.width, CFC_AUTOSIZING_MARGIN(MARGIN))];
  [headerView setBackgroundColor:COLOR_TABLEVIEW_HEADER_VIEW_BACKGROUND_DEFAULT];
  return headerView;
}


- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableViewRefresh.frame.size.width, CFC_AUTOSIZING_MARGIN(MARGIN))];
  [footerView setBackgroundColor:COLOR_TABLEVIEW_FOOTER_VIEW_BACKGROUND_DEFAULT];
  return footerView;
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return FLOAT_MIN;
}


- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return CFC_AUTOSIZING_MARGIN(MARGIN);
}




#pragma mark -
#pragma mark 短信分享
- (void)showShareMessageViewController
{
  if([MFMessageComposeViewController canSendText])  {
    MFMessageComposeViewController * controller = [[MFMessageComposeViewController alloc]init];
    controller.body = @"六合社区，我们更专业";
    controller.messageComposeDelegate = self;
    [self presentViewController:controller animated:YES completion:nil];
    [[[[controller viewControllers] lastObject] navigationItem] setTitle:@"短信分享"];
  } else {
    [self alertPromptMessage:@"短信功能不可用！" okActionBlock:^(NSString *content) {
      
    }];
  }
}


#pragma mark 短信发送成功后的回调
- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
  [controller dismissViewControllerAnimated:YES completion:nil];
  
  switch (result) {
    case MessageComposeResultCancelled: {
      // 用户取消发送
      
      break;
    }
    case MessageComposeResultFailed: {
      [self alertPromptMessage:@"短信发送失败!" okActionBlock:^(NSString *content) {
        
      }];
      break;
    }
    case MessageComposeResultSent: {
      [self alertPromptMessage:@"短信发送成功!" okActionBlock:^(NSString *content) {
        
      }];
      break;
    }
    default: {
      break;
    }
  }
}


@end






