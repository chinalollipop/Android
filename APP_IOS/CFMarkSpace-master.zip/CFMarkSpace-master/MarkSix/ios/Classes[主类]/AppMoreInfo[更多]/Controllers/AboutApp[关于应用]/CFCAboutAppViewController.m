//
// 更多 - 关于应用
//

#import "CFCAboutAppViewController.h"
#import "CFCAboutAppLogoTableViewCell.h"
#import "CFCAboutAppTableViewCell.h"
#import "CFCAboutAppModel.h"

#import "CFCHTMLAppIntroViewController.h"
#import "CFCHTMLAboutUSViewController.h"




@interface CFCAboutAppViewController () <CFCAboutAppTableViewCellDelegate>


@end


@implementation CFCAboutAppViewController


#pragma mark -
#pragma mark 事件处理 - 根据标识处理相应事件
- (void)didSelectRowAtAboutAppModel:(CFCAboutAppModel *)model
{
  if (!model.isEdit) {
    return;
  }
  
  // 应用简介
  if ([STR_MARKID_MOREINFO_SETTING_SOFTWARE_INTRO isEqualToString:model.markId]) {
    CFCHTMLAppIntroViewController *viewController = [[CFCHTMLAppIntroViewController alloc] initWithLocalHTMLString:@"html_appintro"];
    [self.navigationController pushViewController:viewController animated:YES];
  }
  // 关于我们
  else if ([STR_MARKID_MOREINFO_SETTING_ABOUT_US isEqualToString:model.markId]) {
    CFCHTMLAboutUSViewController *viewController = [[CFCHTMLAboutUSViewController alloc] initWithLocalHTMLString:@"html_aboutus"];
    [self.navigationController pushViewController:viewController animated:YES];
  }

}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    self.isRequestNetwork = NO;
    self.hasRefreshHeader = NO;
    self.hasRefreshFooter = NO;
  }
  return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  // 创建静态数据模型
  self.tableDataRefresh = [NSMutableArray array];
  NSMutableArray<CFCAboutAppModel *> *allAboutAppModels = [CFCAboutAppModel buildingDataModles];
  if (allAboutAppModels && 0 < allAboutAppModels.count) {
    [self.tableDataRefresh addObjectsFromArray:allAboutAppModels];
  }
  [self.tableViewRefresh reloadData];
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_ME_CENTER_USERINFO;
}


#pragma mark -
#pragma mark 注册 UITableViewCell
- (void)tableViewRefreshRegisterClass:(UITableView *)tableView
{
  [self.tableViewRefresh registerClass:[CFCAboutAppLogoTableViewCell class]
                forCellReuseIdentifier:CELL_IDENTIFIER_ABOUT_APP_LOGO_TABLE_CELL];
  
  [self.tableViewRefresh registerClass:[CFCAboutAppTableViewCell class]
                forCellReuseIdentifier:CELL_IDENTIFIER_ABOUT_APP_TABLE_CELL];
}


#pragma mark -
#pragma mark UITableViewDelegate UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0) {
    return self.tableDataRefresh.count;
  }
  return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0 && self.tableDataRefresh.count > section) {
    if ([self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
      NSMutableArray *group = self.tableDataRefresh[section];
      if ([group isKindOfClass:[NSArray class]]) {
        return group.count;
      }
    }
  }
  return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  if (0 == indexPath.section) {
    CFCAboutAppLogoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_ABOUT_APP_LOGO_TABLE_CELL];
    if (!cell) {
      cell = [[CFCAboutAppLogoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_ABOUT_APP_LOGO_TABLE_CELL];
    }
    cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
  } else {
    CFCAboutAppTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_ABOUT_APP_TABLE_CELL];
    if (!cell) {
      cell = [[CFCAboutAppTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_ABOUT_APP_TABLE_CELL];
    }
    cell.delegate = self;
    cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
  }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  if (0 == indexPath.section) {
    return [self.tableViewRefresh fd_heightForCellWithIdentifier:CELL_IDENTIFIER_ABOUT_APP_LOGO_TABLE_CELL cacheByIndexPath:indexPath configuration:^(CFCAboutAppLogoTableViewCell *cell) {
      cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
    }];
  } else {
    return [self.tableViewRefresh fd_heightForCellWithIdentifier:CELL_IDENTIFIER_ABOUT_APP_TABLE_CELL cacheByIndexPath:indexPath configuration:^(CFCAboutAppTableViewCell *cell) {
      cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
    }];
  }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableViewRefresh.frame.size.width, CFC_AUTOSIZING_MARGIN(MARGIN))];
  [headerView setBackgroundColor:COLOR_TABLEVIEW_HEADER_VIEW_BACKGROUND_DEFAULT];
  return headerView;
}


- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableViewRefresh.frame.size.width, CFC_AUTOSIZING_MARGIN(MARGIN))];
  [footerView setBackgroundColor:COLOR_TABLEVIEW_FOOTER_VIEW_BACKGROUND_DEFAULT];
  return footerView;
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return FLOAT_MIN;
}


- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return CFC_AUTOSIZING_MARGIN(MARGIN);
}


@end

