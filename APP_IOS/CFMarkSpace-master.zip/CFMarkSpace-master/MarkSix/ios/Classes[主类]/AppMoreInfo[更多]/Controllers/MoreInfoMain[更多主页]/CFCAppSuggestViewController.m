//
// 更多 - 意见反馈
//

#import "CFCAppSuggestViewController.h"
#import "CFCTextView.h"


@interface CFCAppSuggestViewController () <UITextViewDelegate>

@property (nonatomic, strong) UIView *suggestNormalContainerView;
@property (nonatomic, strong) CFCTextView *suggestTextView;
@property (nonatomic, strong) UITextField *telephoneTextField;
@property (nonatomic, strong) UIButton *confirmButton;

@end


@implementation CFCAppSuggestViewController


#pragma mark -
#pragma mark 事件处理 - 提交问题
- (void)doConfirmAction:(UIButton *)button
{
  [self resignFirstResponderOfTextField];
  
  // 问题描述
  NSString *suggest = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.suggestTextView.text];
  if ([CFCSysUtil validateStringEmpty:suggest]) {
    [self alertPromptInfoMessage:@"问题描述不能为空！"];
    return;
  }
  
  // 手机号码
  NSString *telephone = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.telephoneTextField.text];
  
  // 提交操作
  [self doConfirmActionSuggest:suggest telephone:telephone];
}


#pragma mark 事件处理 - 提交问题 - 逻辑操作
- (void)doConfirmActionSuggest:(NSString *)suggest telephone:(NSString *)telephone
{
  NSString *url = URL_API_MORE_INFO_SUGGESTION;
  NSMutableDictionary *params = [CFCNetworkParamsUtil getMoreInfoContactUSParameters:suggest telephone:telephone];
  CFCLog(@"\n请求地址：%@ \n请求参数：%@", url, params);
  [CFCNetworkHTTPSessionUtil POST:url parameters:params success:^(id responseObject) {
    NSDictionary *responseData = (NSDictionary *)responseObject;
    CFCLog(@"[提交成功] => %@\n", responseData);
    NSString *message = [responseObject objectForKey:CFC_REQUEST_KEY_MESS];
    NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
    if ([CFCSysUtil validateResultCodeIsSuccess:status]) {
      [self alertPromptMessage:message okActionBlock:^(NSString *content) {
        [self.navigationController popViewControllerAnimated:YES];
      }];
    } else {
      NSString *message = [responseObject objectForKey:CFC_REQUEST_KEY_MESS];
      [self alertPromptErrorMessage:message];
    }
  } failure:^(NSError *error) {
    CFCLog(@"提交失败 = %@", error);
    [self alertPromptErrorMessage:@"反馈失败！"];
  } showMessage:nil showProgressHUD:YES showProgressView:self.view isHideErrorMessage:YES];
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    
  }
  return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  [self createMainUIView];
}

#pragma mark 创建主要界面
- (void)createMainUIView
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat margin_top = margin * 2.25f;
  CGFloat margin_left = margin * 1.50f;
  CGFloat margin_right = margin * 1.50f;
  CGFloat margin_bottom = margin * 2.00f;
  CGFloat text_view_height = SCREEN_WIDTH * 0.48f;
  
  CGFloat buttonHeight = CFC_AUTOSIZING_WIDTH(SYSTEM_GLOBAL_BUTTON_HEIGHT); // 登录、快速注册按钮高度
  CGFloat textFieldHeight = CFC_AUTOSIZING_WIDTH(45.0f); // 用户名、密码输入框高度

  UIFont *titleFont = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(14.0f)]; // 输入框字体
  UIColor *titleColor = [UIColor colorWithRed:0.20 green:0.20 blue:0.20 alpha:1.00]; // 输入框文字颜色
  
  UIFont *textFieldFont = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]; // 输入框字体
  UIColor *textFieldColor = [UIColor colorWithRed:0.20 green:0.20 blue:0.20 alpha:1.00]; // 输入框文字颜色
  UIColor *textFieldPlaceholderColor = COLOR_HEXSTRING(@"#9B9B9B"); // 输入框暂位符颜色
  UIColor *textBackgroundColor = COLOR_HEXSTRING(@"#F0F1F2"); // 输入框背景颜色
  
  
  // 根容器
  UIScrollView *rootScrollView = ({
    TPKeyboardAvoidingScrollView *scrollView = [[TPKeyboardAvoidingScrollView alloc] init];
    [scrollView setShowsVerticalScrollIndicator:NO];
    [self.view addSubview:scrollView];
    
    [scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(self.view).with.offset(0.0);
      make.right.equalTo(self.view).with.offset(0.0);
      make.top.equalTo(self.view.mas_top).with.offset(0.0f);
      make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0f);
    }];
    
    scrollView;
  });
  
  
  // 主容器
  UIView *containerView = ({
    UIView *view = [[UIView alloc] init];
    [rootScrollView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.edges.equalTo(rootScrollView);
      make.width.equalTo(rootScrollView);
      make.height.mas_equalTo(SCREEN_HEIGHT-STATUS_NAVIGATION_BAR_HEIGHT+1.0f);
    }];
    view;
  });
  
  
  // 主要区域
  {
    // 容器视图
    UIView *suggestNormalContainerView = ({
      UIView *view = [[UIView alloc] init];
      [containerView addSubview:view];

      [view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(@0);
        make.right.equalTo(@0);
        make.top.equalTo(containerView.mas_top);
      }];
      
      view;
    });
    self.suggestNormalContainerView = suggestNormalContainerView;
    
    // 问题描述
    UILabel *titleLabel = [UILabel new];
    [suggestNormalContainerView addSubview:titleLabel];
    [titleLabel setText:@"问题描述"];
    [titleLabel setFont:titleFont];
    [titleLabel setTextColor:titleColor];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(suggestNormalContainerView.mas_top).offset(margin_top);
      make.left.equalTo(suggestNormalContainerView.mas_left).offset(margin_left);
    }];
    
    // 输入控件
    CFCTextView *suggestTextView = ({
      CFCTextView *textView = [CFCTextView textView];
      [textView setDelegate:self];
      [textView setFont:textFieldFont];
      [textView setBorderWidth:0.5f];
      [textView setCornerRadius:5.0f];
      [textView setTextColor:textFieldColor];
      [textView setBorderColor:UIColor.lightGrayColor];
      [textView setBackgroundColor:textBackgroundColor];
      [textView setTranslatesAutoresizingMaskIntoConstraints:NO];
      [textView setPlaceholderFont:[UIFont fontWithName:@"NotoMono" size:CFC_AUTOSIZING_FONT(15)]];
      [textView setPlaceholderColor:textFieldPlaceholderColor];
      [textView setPlaceholder:@"请输入问题描述"];
      [suggestNormalContainerView addSubview:textView];
      
      [suggestNormalContainerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"H:|-%f-[textView]-%f-|", margin_left, margin_right]
                                                                                       options:kNilOptions
                                                                                       metrics:nil
                                                                                         views:NSDictionaryOfVariableBindings(textView)]];
      [suggestNormalContainerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"V:|-[titleLabel]-%f-[textView(==%f)]", margin, text_view_height]
                                                                                       options:kNilOptions
                                                                                       metrics:nil
                                                                                         views:NSDictionaryOfVariableBindings(textView,titleLabel)]];
      
      textView;
    });
    self.suggestTextView = suggestTextView;
    self.suggestTextView.mas_key = @"suggestTextView";
    
    
    // 联系手机
    UILabel *phoneLabel = [UILabel new];
    [suggestNormalContainerView addSubview:phoneLabel];
    [phoneLabel setText:@"联系手机"];
    [phoneLabel setFont:titleFont];
    [phoneLabel setTextColor:titleColor];
    [phoneLabel mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(suggestTextView.mas_bottom).offset(margin_top);
      make.left.equalTo(suggestNormalContainerView.mas_left).offset(margin_left);
    }];
    
    
    // 手机号码
    UITextField *telephoneTextField = [UITextField new];
    [suggestNormalContainerView addSubview:telephoneTextField];
    [telephoneTextField setFont:textFieldFont];
    [telephoneTextField setTextColor:textFieldColor];
    [telephoneTextField setBorderStyle:UITextBorderStyleRoundedRect];
    [telephoneTextField setBackgroundColor:textBackgroundColor];
    [telephoneTextField setClearButtonMode:UITextFieldViewModeWhileEditing];
    [telephoneTextField setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
    [telephoneTextField setAttributedPlaceholder:[[NSAttributedString alloc] initWithString:@"请输入联系手机" attributes:@{ NSForegroundColorAttributeName : textFieldPlaceholderColor }]];
    [telephoneTextField mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(phoneLabel.mas_bottom).offset(margin);
      make.left.equalTo(suggestNormalContainerView.mas_left).offset(margin_left);
      make.right.equalTo(suggestNormalContainerView.mas_right).with.offset(-margin_right);
      make.height.equalTo(@(textFieldHeight));
    }];
    self.telephoneTextField = telephoneTextField;
    self.telephoneTextField.mas_key = @"telephoneTextField";
    
    
    // 提交问题
    UIButton *confirmButton = ({
      UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
      [button loginStyleButton];
      [button setTitle:@"提交问题" forState:UIControlStateNormal];
      [button addTarget:self action:@selector(doConfirmAction:) forControlEvents:UIControlEventTouchUpInside];
      [suggestNormalContainerView addSubview:button];
      
      [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(telephoneTextField.mas_bottom).offset(margin*2.5f);
        make.left.equalTo(suggestNormalContainerView.mas_left).offset(margin_left);
        make.right.equalTo(suggestNormalContainerView.mas_right).with.offset(-margin_right);
        make.height.equalTo(@(buttonHeight));
      }];
      
      button;
    });
    self.confirmButton = confirmButton;
    
    
    // 约束的完整性
    [suggestNormalContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.bottom.equalTo(confirmButton.mas_bottom).offset(margin_bottom);
    }];
    
  } // 登录区域
  
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_SUGGESTION;
}


#pragma mark -
#pragma mark 注销输入框响应事件
- (void)resignFirstResponderOfTextField
{
  [self.view endEditing:YES];
  [self.suggestTextView resignFirstResponder];
  [self.telephoneTextField resignFirstResponder];
}


#pragma mark 响应点击事件
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
  [self resignFirstResponderOfTextField];
}




@end
