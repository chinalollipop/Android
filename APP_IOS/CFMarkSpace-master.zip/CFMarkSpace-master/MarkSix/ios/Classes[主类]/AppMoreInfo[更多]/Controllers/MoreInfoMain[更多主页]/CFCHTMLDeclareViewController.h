//
// 更多 - 免费声明
//

#import "CFCHTMLWebViewViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCHTMLDeclareViewController : CFCHTMLWebViewViewController

@end

NS_ASSUME_NONNULL_END
