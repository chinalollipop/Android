//
// 更多 - 关于应用 - 应用简介
//

#import "CFCHTMLAppIntroViewController.h"

@implementation CFCHTMLAppIntroViewController


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_APP_INTRO;
}


@end
