//
// 更多 - 关于应用（LOGO）
//

#import "CFCAboutAppLogoTableViewCell.h"
#import "CFCAboutAppModel.h"

// Cell Identifier
NSString * const CELL_IDENTIFIER_ABOUT_APP_LOGO_TABLE_CELL = @"CFCAboutAppLogoTableViewCellIdentifier";


@interface CFCAboutAppLogoTableViewCell ()
/**
 * 根容器组件
 */
@property (nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonatomic, strong) UIView *publicContainerView;
/**
 * 应用LOGO
 */
@property (nonnull, nonatomic, strong) UIImageView *logoImageView;
/**
 * 应用版本
 */
@property (nonatomic, strong) UILabel *titleLabel;
/**
 * 联系我们
 */
@property (nonatomic, strong) UILabel *contentLabel;

@end


@implementation CFCAboutAppLogoTableViewCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
  if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
    [self createViewAtuoLayout];
  }
  return self;
}


#pragma mark - 创建子控件
- (void)createViewAtuoLayout
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  
  // 根容器
  UIView *rootContainerView = ({
    UIView *view = [[UIView alloc] init];
    [self.contentView insertSubview:view atIndex:0];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
    }];
    
    view;
  });
  self.rootContainerView = rootContainerView;
  self.rootContainerView.mas_key = @"rootContainerView";
  
  // 公共容器
  UIView *publicContainerView = ({
    UIView *view = [[UIView alloc] init];
    [view.layer setMasksToBounds:YES];
    [rootContainerView addSubview:view];
    [rootContainerView setBackgroundColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(rootContainerView.mas_left).offset(0.0f);
      make.top.equalTo(rootContainerView.mas_top).offset(0.0f);
      make.right.equalTo(rootContainerView.mas_right).offset(0.0f);
      make.bottom.equalTo(rootContainerView.mas_bottom).offset(0.0f);
    }];
    
    view;
  });
  self.publicContainerView = publicContainerView;
  self.publicContainerView.mas_key = @"publicContainerView";
  
  // 应用LOGO
  UIImageView *logoImageView = ({
    CGFloat size = CFC_AUTOSIZING_WIDTH(60.0f);
    UIImageView *imageView = [UIImageView new];
    [self.publicContainerView addSubview:imageView];
    [imageView.layer setMasksToBounds:YES];
    [imageView setContentMode:UIViewContentModeScaleAspectFit];
    
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(self.publicContainerView.mas_top).offset(margin * 2.5f);
      make.centerX.equalTo(self.publicContainerView.mas_centerX);
      make.size.mas_equalTo(CGSizeMake(size, size));
    }];
    
    imageView;
  });
  self.logoImageView = logoImageView;
  self.logoImageView.mas_key = @"logoImageView";
  
  // 应用版本
  UILabel *titleLabel = ({
    UILabel *label = [UILabel new];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)]];
    [label setTextColor:COLOR_HEXSTRING(@"#101010")];
    [label setTextAlignment:NSTextAlignmentCenter];
    [publicContainerView addSubview:label];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(logoImageView.mas_bottom).offset(margin * 1.5f);
      make.centerX.equalTo(logoImageView.mas_centerX);
    }];
    
    label;
  });
  self.titleLabel = titleLabel;
  self.titleLabel.mas_key = @"titleLabel";
  
  // 联系我们
  UILabel *contentLabel = ({
    UILabel *label = [UILabel new];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
    [label setTextColor:COLOR_HEXSTRING(@"#101010")];
    [label setTextAlignment:NSTextAlignmentCenter];
    [publicContainerView addSubview:label];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(titleLabel.mas_bottom).offset(margin * 1.0f);
      make.centerX.equalTo(logoImageView.mas_centerX);
    }];
    
    label;
  });
  self.contentLabel = contentLabel;
  self.contentLabel.mas_key = @"contentLabel";
  
  // 约束的完整性
  [publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
    make.bottom.equalTo(contentLabel.mas_bottom).offset(margin * 1.0f).priority(749);
  }];
  
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCAboutAppModel *)model
{
  // 类型安全检查
  if (![model isKindOfClass:[CFCAboutAppModel class]]) {
    return;
  }
  
  // 数据赋值
  _model = model;
  
  // 应用LOGO
  [self.logoImageView setImage:[UIImage imageNamed:ICON_APP_LOGO]];
  
  // 应用版本
  [self.titleLabel setText:[NSString stringWithFormat:@"版本 %@", _model.title]];

  // 联系我们
  [self.contentLabel setText:_model.content];

}

@end



