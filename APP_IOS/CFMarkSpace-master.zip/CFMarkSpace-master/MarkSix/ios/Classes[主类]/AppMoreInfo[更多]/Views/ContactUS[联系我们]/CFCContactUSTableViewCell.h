//
// 更多 - 联系我们
//

#import "CFCSettingCoreTableViewCell.h"
@class CFCContactUSModel;


NS_ASSUME_NONNULL_BEGIN


UIKIT_EXTERN NSString * const CELL_IDENTIFIER_APP_CONTACT_US;


@protocol CFCContactUSTableViewCellDelegate <CFCSettingCoreTableViewCellDelegate>
@optional
- (void)didSelectRowAtContactUSModel:(CFCContactUSModel *)model;
@end


@interface CFCContactUSTableViewCell : CFCSettingCoreTableViewCell

@end


NS_ASSUME_NONNULL_END

