//
// 更多 - 主页
//

#import "CFCSettingCoreTableViewCell.h"
@class CFCAppMoreInfoMainModel;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_APP_MORE_INFO_MAIN;

@protocol CFCAppMoreInfoMainTableViewCellDelegate <CFCSettingCoreTableViewCellDelegate>
@optional
- (void)didSelectRowAtAppMoreInfoMainModel:(CFCAppMoreInfoMainModel *)model;
@end

@interface CFCAppMoreInfoMainTableViewCell : CFCSettingCoreTableViewCell

@end

NS_ASSUME_NONNULL_END
