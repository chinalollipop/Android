//
// 更多 - 关于应用（LOGO）
//

#import <UIKit/UIKit.h>
@class CFCAboutAppModel;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_ABOUT_APP_LOGO_TABLE_CELL;

@interface CFCAboutAppLogoTableViewCell : UITableViewCell

/**
 * 数据模型
 */
@property (nonatomic, strong) CFCAboutAppModel *model;

@end

NS_ASSUME_NONNULL_END
