//
// 更多 - 关于应用
//

#import "CFCAboutAppTableViewCell.h"
#import "CFCAboutAppModel.h"

// Cell Identifier
NSString * const CELL_IDENTIFIER_ABOUT_APP_TABLE_CELL = @"CFCAboutAppTableViewCellIdentifier";


@implementation CFCAboutAppTableViewCell

#pragma mark - 触发操作事件
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture
{
  [super pressPublicItemView:gesture];
  
  // 强击类型转换
  CFCAboutAppModel *model_original = (CFCAboutAppModel *)self.model;
  id<CFCAboutAppTableViewCellDelegate> delegate_original = (id<CFCAboutAppTableViewCellDelegate>)self.delegate;
  
  if (delegate_original && [delegate_original respondsToSelector:@selector(didSelectRowAtAboutAppModel:)]) {
    [delegate_original didSelectRowAtAboutAppModel:model_original];
  }

}


@end
