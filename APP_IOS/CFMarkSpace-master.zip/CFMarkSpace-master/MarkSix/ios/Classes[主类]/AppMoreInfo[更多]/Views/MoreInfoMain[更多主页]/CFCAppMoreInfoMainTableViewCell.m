//
// 更多 - 主页
//

#import "CFCAppMoreInfoMainTableViewCell.h"
#import "CFCAppMoreInfoMainModel.h"

// Cell Identifier
NSString * const CELL_IDENTIFIER_APP_MORE_INFO_MAIN = @"CFCAppMoreInfoMainTableViewCellIdentifier";


@implementation CFCAppMoreInfoMainTableViewCell

#pragma mark - 触发操作事件
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture
{
  [super pressPublicItemView:gesture];
  
  // 强击类型转换
  CFCAppMoreInfoMainModel *model_original = (CFCAppMoreInfoMainModel *)self.model;
  id<CFCAppMoreInfoMainTableViewCellDelegate> delegate_original = (id<CFCAppMoreInfoMainTableViewCellDelegate>)self.delegate;
  
  if (delegate_original && [delegate_original respondsToSelector:@selector(didSelectRowAtAppMoreInfoMainModel:)]) {
    [delegate_original didSelectRowAtAppMoreInfoMainModel:model_original];
  }
  
}


@end
