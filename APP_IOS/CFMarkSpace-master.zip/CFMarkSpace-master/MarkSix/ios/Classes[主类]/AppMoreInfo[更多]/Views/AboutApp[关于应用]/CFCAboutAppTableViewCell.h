//
// 更多 - 关于应用
//

#import "CFCSettingCoreTableViewCell.h"
@class CFCAboutAppModel;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_ABOUT_APP_TABLE_CELL;

@protocol CFCAboutAppTableViewCellDelegate <CFCSettingCoreTableViewCellDelegate>
@optional
- (void)didSelectRowAtAboutAppModel:(CFCAboutAppModel *)model;
@end

@interface CFCAboutAppTableViewCell : CFCSettingCoreTableViewCell

@end

NS_ASSUME_NONNULL_END
