//
// 更多 - 关于应用（LOGO）
//

#import <UIKit/UIKit.h>
@class CFCContactUSModel;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_CONTACT_US_LOGO_TABLE_CELL;

@interface CFCContactUSLogoTableViewCell : UITableViewCell

/**
 * 数据模型
 */
@property (nonatomic, strong) CFCContactUSModel *model;

@end

NS_ASSUME_NONNULL_END
