//
// 更多 - 联系我们
//

#import "CFCContactUSTableViewCell.h"
#import "CFCContactUSModel.h"


// Cell Identifier
NSString * const CELL_IDENTIFIER_APP_CONTACT_US = @"CFCContactUSTableViewCellIdentifier";

@interface CFCContactUSTableViewCell ()

@property (nonnull, nonatomic, strong) UIImageView *markImageView;  // 标识图片

@end


@implementation CFCContactUSTableViewCell


#pragma mark - 创建子控件
- (void)createViewAtuoLayout
{
  [super createViewAtuoLayout];
  
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  
  // 图片
  UIImageView *markImageView = ({
    UIImageView *imageView = [UIImageView new];
    [self.publicContainerView addSubview:imageView];
    [imageView.layer setMasksToBounds:YES];
    [imageView setUserInteractionEnabled:YES];
    [imageView setContentMode:UIViewContentModeScaleAspectFit];
    
    CGSize imageSize = CGSizeMake(CFC_AUTOSIZING_WIDTH(25.0f), CFC_AUTOSIZING_WIDTH(25.0f));
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      //            make.top.equalTo(self.publicContainerView.mas_top).offset(margin*0.5);
      make.centerY.equalTo(self.publicContainerView.mas_centerY).offset(0.0f);
      make.left.equalTo(self.publicContainerView.mas_left).offset(margin * 1.5);
      make.size.mas_equalTo(imageSize);
    }];
    
    imageView;
  });
  self.markImageView = markImageView;
  self.markImageView.mas_key = [NSString stringWithFormat:@"markImageView"];
  
  // 标题
  [self.titleLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
    make.centerY.equalTo(markImageView.mas_centerY).offset(0.0);
    make.left.equalTo(markImageView.mas_right).offset(margin * 1.5);
  }];
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCContactUSModel *)model
{
  [super setModel:model];
  
  // 类型安全检查
  if (![model isKindOfClass:[CFCContactUSModel class]]) {
    return;
  }
  
  // 强击类型转换
  CFCContactUSModel *model_original = (CFCContactUSModel *)self.model;
  
  // 内容控件
  [self.contentLabel setHidden:YES];
  
  // 标题控件
  NSString *titleValue = [NSString stringWithFormat:@"%@%@", model_original.title, model_original.content];
  [self.titleLabel setText:titleValue];
  
  // 标识图片
  CGSize imageSize = CGSizeMake(CFC_AUTOSIZING_WIDTH(35.0f), CFC_AUTOSIZING_WIDTH(35.0f));
  [self.markImageView setImage:[[UIImage imageNamed:model_original.markImageUrl] imageByScalingProportionallyToSize:imageSize]];
  
}


#pragma mark - 触发操作事件
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture
{
  [super pressPublicItemView:gesture];
  
  // 强击类型转换
  CFCContactUSModel *model_original = (CFCContactUSModel *)self.model;
  id<CFCContactUSTableViewCellDelegate> delegate_original = (id<CFCContactUSTableViewCellDelegate>)self.delegate;
  
  if (delegate_original && [delegate_original respondsToSelector:@selector(didSelectRowAtContactUSModel:)]) {
    [delegate_original didSelectRowAtContactUSModel:model_original];
  }
  
}


@end
