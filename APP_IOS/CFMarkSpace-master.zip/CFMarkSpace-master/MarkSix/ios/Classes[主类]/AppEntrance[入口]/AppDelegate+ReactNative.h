
#import "AppDelegate.h"
#import <React/RCTBridgeDelegate.h>

NS_ASSUME_NONNULL_BEGIN

@interface AppDelegate (ReactNative) <RCTBridgeDelegate>

- (BOOL)application:(UIApplication *)application didLaunchWithOptionsOfReactNative:(NSDictionary *)launchOptions;

@end

NS_ASSUME_NONNULL_END
