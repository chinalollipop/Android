//
//  AppRNViewController.h
//  MarkSix
//
//  Created by david on 2019/4/12.
//  Copyright © 2019年 Facebook. All rights reserved.
//

#import "CFCBaseCommonViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface AppRNViewController : CFCBaseCommonViewController

@end

NS_ASSUME_NONNULL_END
