
#import "AppDelegate+ReactNative.h"
#import "AppRNViewController.h"

#import <React/RCTBridge.h>
#import <React/RCTRootView.h>
#import <React/RCTBundleURLProvider.h>

@implementation AppDelegate (ReactNative)

- (BOOL)application:(UIApplication *)application didLaunchWithOptionsOfReactNative:(NSDictionary *)launchOptions
{
  // 不显示RN加载进度
  [RCTDevLoadingView setEnabled:NO];
  
  // 设置根部窗口容器
  [self setWindow:[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]]];
  [self.window setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_DEFAULT];
  [self.window makeKeyAndVisible];
  
  // 设置根视图控制器
  AppRNViewController *rootViewController = [[AppRNViewController alloc] init];
  RCTBridge *bridge = [[RCTBridge alloc] initWithDelegate:self launchOptions:launchOptions];
  RCTRootView *rootView = [[RCTRootView alloc] initWithBridge:bridge
                                                   moduleName:@"MarkSix"
                                            initialProperties:nil];
  rootView.backgroundColor = [[UIColor alloc] initWithRed:1.0f green:1.0f blue:1.0f alpha:1];
  rootViewController.view = rootView;
  [self.window setRootViewController:rootViewController];
  
  return YES;
}

- (NSURL *)sourceURLForBridge:(RCTBridge *)bridge
{
#if DEBUG
  return [[RCTBundleURLProvider sharedSettings] jsBundleURLForBundleRoot:@"index" fallbackResource:nil];
#else
  return [[NSBundle mainBundle] URLForResource:@"main" withExtension:@"jsbundle"];
#endif
}

@end
