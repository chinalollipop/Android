

#import "AppDelegate.h"
#import "AppDelegate+Options.h"
#import "AppDelegate+ReactNative.h"


@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
  // 设置离散网络架构
  [CFCAppUtil applicationNetworkManagerSetting];

  // 刷新用户的令牌
  [CFCAppUtil applicationAuthorizationCurrentRefresh];
  
  // 配置Bugly日志
  [Bugly startWithAppId:APP_BUGLY_PROJECT_UUID];
  
#if NATIVE
  return [self application:application didLaunchWithOptions:launchOptions];
#else
  return [self application:application didLaunchWithOptionsOfReactNative:launchOptions];
#endif
}


@end

