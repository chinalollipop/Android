//
//  AppRNViewController.m
//  MarkSix
//
//  Created by david on 2019/4/12.
//  Copyright © 2019年 Facebook. All rights reserved.
//

#import "AppRNViewController.h"


@interface AppRNViewController ()

@end


@implementation AppRNViewController


#pragma mark -
#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
    [super viewDidLoad];
  
}


#pragma mark -
#pragma mark 设置状态栏样式类型
- (UIStatusBarStyle)preferredStatusBarStyle
{
  return UIStatusBarStyleDefault;
}


@end

