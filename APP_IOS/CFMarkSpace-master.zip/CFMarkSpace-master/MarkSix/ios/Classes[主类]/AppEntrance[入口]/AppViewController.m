

#import "AppViewController.h"
#import "CFCAppHomeMainViewController.h"
#import "CFCAppDiscoverMainViewController.h"
#import "CFCAppMoreInfoMainViewController.h"
#import "CFCAppMeCenterMainViewController.h"
#import "CFCAppLoginViewController.h"

@interface AppViewController ()

@end

@implementation AppViewController

#pragma mark 添加子控制器
- (void)addChildControllers
{
  // 首页
  [self addChildNavigationController:[CFCNavigationController class]
                  rootViewController:[CFCAppHomeMainViewController class]
                     navigationTitle:STR_NAVIGATION_BAR_TITLE_HOME
                     tabBarItemTitle:STR_TAB_BAR_ITEM_NAME_HOME
               tabBarNormalImageName:ICON_TAB_BAR_ITEM_HOME_NORMAL
               tabBarSelectImageName:ICON_TAB_BAR_ITEM_HOME_SELECT
                   tabBarItemEnabled:YES];

  // 寻宝
  [self addChildNavigationController:[CFCNavigationController class]
                  rootViewController:[CFCAppDiscoverMainViewController class]
                     navigationTitle:STR_NAVIGATION_BAR_TITLE_DISCOVER
                     tabBarItemTitle:STR_TAB_BAR_ITEM_NAME_DISCOVER
               tabBarNormalImageName:ICON_TAB_BAR_ITEM_DISCOVER_NORMAL
               tabBarSelectImageName:ICON_TAB_BAR_ITEM_DISCOVER_SELECT
                   tabBarItemEnabled:YES];
  
  // 用户
  if (APPINFORMATION.loginStatus) {
    // 我的
    [self addChildNavigationController:[CFCNavigationController class]
                    rootViewController:[CFCAppMeCenterMainViewController class]
                       navigationTitle:STR_NAVIGATION_BAR_TITLE_ME_CENTER
                       tabBarItemTitle:STR_TAB_BAR_ITEM_NAME_ME_CENTER
                 tabBarNormalImageName:ICON_TAB_BAR_ITEM_ME_CENTER_NORMAL
                 tabBarSelectImageName:ICON_TAB_BAR_ITEM_ME_CENTER_SELECT
                     tabBarItemEnabled:YES];
  } else {
    // 登录
    [self addChildNavigationController:[CFCNavigationController class]
                    rootViewController:[CFCAppLoginViewController class]
                       navigationTitle:STR_NAVIGATION_BAR_TITLE_USER_LOGIN
                       tabBarItemTitle:STR_TAB_BAR_ITEM_NAME_ME_CENTER
                 tabBarNormalImageName:ICON_TAB_BAR_ITEM_ME_CENTER_NORMAL
                 tabBarSelectImageName:ICON_TAB_BAR_ITEM_ME_CENTER_SELECT
                     tabBarItemEnabled:YES];
  }
  
  // 更多
  [self addChildNavigationController:[CFCNavigationController class]
                  rootViewController:[CFCAppMoreInfoMainViewController class]
                     navigationTitle:STR_NAVIGATION_BAR_TITLE_MORE_INFO
                     tabBarItemTitle:STR_TAB_BAR_ITEM_NAME_MORE_INFO
               tabBarNormalImageName:ICON_TAB_BAR_ITEM_MOREINFO_NORMAL
               tabBarSelectImageName:ICON_TAB_BAR_ITEM_MOREINFO_SELECT
                   tabBarItemEnabled:YES];
}

@end
