

#import "AppDelegate+Options.h"
#import "AppViewController.h"


@implementation AppDelegate (Options)


- (BOOL)application:(UIApplication *)application didLaunchWithOptions:(NSDictionary *)launchOptions
{
  // 不显示RN加载进度
  [RCTDevLoadingView setEnabled:NO];
  
  // 设置根部窗口容器
  [self setWindow:[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]]];
  [self.window setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_DEFAULT];
  [self.window makeKeyAndVisible];
  
  // 设置根视图控制器
  AppViewController *rootViewController = [[AppViewController alloc] init];
  [self.window setRootViewController:rootViewController];
  
  return YES;
}


@end

