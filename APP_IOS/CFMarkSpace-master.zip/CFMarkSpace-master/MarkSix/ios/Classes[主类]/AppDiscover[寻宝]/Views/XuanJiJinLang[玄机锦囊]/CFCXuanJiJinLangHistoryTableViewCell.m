//
// 寻宝 - 玄机锦囊 - 历史记录
//

#import "CFCXuanJiJinLangHistoryTableViewCell.h"
#import "CFCXuanJiJinLangHistoryModel.h"


// Cell Identifier
NSString * const CELL_IDENTIFIER_DISCOVER_XUANJIJINLANG_IDENTIFIER = @"CFCXuanJiJinLangHistoryTableViewCellIdentifier";


@interface CFCXuanJiJinLangHistoryTableViewCell ()
/**
 * 根容器组件
 */
@property (nonnull, nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonnull, nonatomic, strong) UIView *publicContainerView;
/**
 * 头部容器
 */
@property (nonnull, nonatomic, strong) UIView *titleContainerView;
/**
 * 标题控件
 */
@property (nonnull, nonatomic, strong) UILabel *titleIssueLabel;
/**
 * 箭头控件
 */
@property (nonnull, nonatomic, strong) UIImageView *arrowImageView;
/**
 * 内容控件1
 */
@property (nonnull, nonatomic, strong) UILabel *content1Label;
/**
 * 内容控件2
 */
@property (nonnull, nonatomic, strong) UILabel *content2Label;
/**
 * 分割控件
 */
@property (nonnull, nonatomic, strong) UIView *separatorLineView;


@end

@implementation CFCXuanJiJinLangHistoryTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
  if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
    [self createViewAtuoLayout];
  }
  return self;
}

#pragma mark 创建子控件
- (void)createViewAtuoLayout
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat heightOfTitle = CFC_AUTOSIZING_HEIGTH(45.0f);
  CGFloat arrowImageWidth = heightOfTitle*0.4f;
  CGFloat arrowImageHeight = heightOfTitle*0.4f;
  
  
  // 根容器
  UIView *rootContainerView = ({
    UIView *view = [[UIView alloc] init];
    [self.contentView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
    }];
    
    view;
  });
  self.rootContainerView = rootContainerView;
  self.rootContainerView.mas_key = @"rootContainerView";
  
  // 公共容器
  UIView *publicContainerView = ({
    UIView *view = [[UIView alloc] init];
    [view.layer setMasksToBounds:YES];
    [view setBackgroundColor:COLOR_HEXSTRING(@"#F0F1EC")];
    [rootContainerView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.bottom.equalTo(rootContainerView.mas_bottom);
    }];
    
    view;
  });
  self.publicContainerView = publicContainerView;
  self.publicContainerView.mas_key = @"publicContainerView";
  
  // 标题控件
  UIView *titleContainerView = ({
    UIView *view = [[UIView alloc] init];
    [view.layer setMasksToBounds:YES];
    [view setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_DEFAULT];
    [publicContainerView addSubview:view];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressTitleContainerView:)];
    [view addGestureRecognizer:tapGesture];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.height.mas_equalTo(heightOfTitle);
    }];
    
    view;
  });
  self.titleContainerView = titleContainerView;
  self.titleContainerView.mas_key = @"titleContainerView";
  
  
  // 标题控件
  UILabel *titleIssueLabel = ({
    UILabel *label = [UILabel new];
    [label setText:STR_APP_TEXT_PLACEHOLDER];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    [label setTextAlignment:NSTextAlignmentLeft];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)]];
    [titleContainerView addSubview:label];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(titleContainerView.mas_centerY).offset(margin*0.1f);
      make.left.equalTo(titleContainerView.mas_left).offset(margin*1.5f);
    }];
    
    label;
  });
  self.titleIssueLabel = titleIssueLabel;
  self.titleIssueLabel.mas_key = @"titleIssueLabel";
  
  
  // 箭头控件
  UIImageView *arrowImageView = ({
    UIImageView *imageView = [UIImageView new];
    [titleContainerView addSubview:imageView];
    [imageView setUserInteractionEnabled:YES];
    [imageView setImage:[UIImage imageNamed:@"icon_arrow_down"]];
    [imageView setContentMode:UIViewContentModeScaleAspectFit];
    
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(titleContainerView.mas_centerY);
      make.right.equalTo(titleContainerView.mas_right).offset(-margin*1.5f);
      make.size.mas_equalTo(CGSizeMake(arrowImageWidth, arrowImageHeight));
    }];
    
    imageView;
  });
  self.arrowImageView = arrowImageView;
  self.arrowImageView.mas_key = @"arrowImageView";
  
  
  // 内容控件1
  UILabel *content1Label = ({
    UILabel *label = [UILabel new];
    [label setText:STR_APP_TEXT_PLACEHOLDER];
    [label setTextColor:COLOR_HEXSTRING(@"#B78B59")];
    [label setTextAlignment:NSTextAlignmentCenter];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)]];
    [publicContainerView addSubview:label];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerX.equalTo(publicContainerView.mas_centerX);
      make.top.equalTo(titleContainerView.mas_bottom).offset(margin*1.5f);
    }];
    
    label;
  });
  self.content1Label = content1Label;
  self.content1Label.mas_key = @"content1Label";
  
  
  // 内容控件2
  UILabel *content2Label = ({
    UILabel *label = [UILabel new];
    [label setText:STR_APP_TEXT_PLACEHOLDER];
    [label setTextColor:COLOR_HEXSTRING(@"#B78B59")];
    [label setTextAlignment:NSTextAlignmentCenter];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)]];
    [publicContainerView addSubview:label];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerX.equalTo(publicContainerView.mas_centerX);
      make.top.equalTo(content1Label.mas_bottom).offset(margin*1.0f);
    }];
    
    label;
  });
  self.content2Label = content2Label;
  self.content2Label.mas_key = @"content2Label";
  
  
  // 分割线
  UIView *separatorLineView = ({
    UIView *view = [[UIView alloc] init];
    [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
    [publicContainerView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(titleContainerView.mas_bottom);
      make.left.equalTo(publicContainerView.mas_left);
      make.right.equalTo(publicContainerView.mas_right);
      make.height.mas_equalTo(SEPARATOR_LINE_HEIGHT*0.5f);
    }];
    
    view;
  });
  self.separatorLineView = separatorLineView;
  self.separatorLineView.mas_key = @"separatorLineView";
  
  // 约束完整性
  [self.publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
    make.bottom.equalTo(separatorLineView.mas_bottom).priority(749);
  }];
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCXuanJiJinLangHistoryModel *)model
{
  // 类型安全检查
  if (![model isKindOfClass:[CFCXuanJiJinLangHistoryModel class]]) {
    return;
  }
  
  _model = model;
  
  // 标题控件
  [self.titleIssueLabel setText:[NSString stringWithFormat:@"%@年%03ld期六合锦囊", _model.year.stringValue, _model.period.integerValue]];

  // 内容控件
  NSCharacterSet *character = [NSCharacterSet characterSetWithCharactersInString:@"\r\n"];
  NSArray<NSString *> *splitConents = [_model.content componentsSeparatedByCharactersInSet:character];
  if (splitConents.count > 0) {
    [self.content1Label setText:splitConents.firstObject];
  }
  if (splitConents.count > 1) {
    [self.content2Label setText:splitConents.lastObject];
  }
  
  // 是否显示
  if (_model.isShowContent) {
    CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
    [self.arrowImageView setImage:[UIImage imageNamed:@"icon_arrow_up"]];
    [self.separatorLineView mas_remakeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(self.content2Label.mas_bottom).offset(margin*1.5f);
      make.left.equalTo(self.publicContainerView.mas_left);
      make.right.equalTo(self.publicContainerView.mas_right);
      make.height.mas_equalTo(SEPARATOR_LINE_HEIGHT*0.5f);
    }];
  } else {
    [self.arrowImageView setImage:[UIImage imageNamed:@"icon_arrow_down"]];
    [self.separatorLineView mas_remakeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(self.titleContainerView.mas_bottom);
      make.left.equalTo(self.publicContainerView.mas_left);
      make.right.equalTo(self.publicContainerView.mas_right);
      make.height.mas_equalTo(SEPARATOR_LINE_HEIGHT*0.5f);
    }];
  }
  
}


#pragma mark - 操作事件 - 点击事件
- (void)pressTitleContainerView:(UITapGestureRecognizer *)gesture
{
  if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectRowAtXuanJiJinLangHistoryModel:indexPath:)]) {
    [self.delegate didSelectRowAtXuanJiJinLangHistoryModel:self.model indexPath:self.indexPath];
  }
}


@end





