//
// 寻宝 - 搅珠日期
//

#import <UIKit/UIKit.h>
@class CFCJiaoZhuRiQiModel;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_RESULT_JIAOZHURIQI_COLLECTION_SECTION_FOOTER;

@interface CFCJiaoZhuRiQiCollectionFooterView : UICollectionReusableView

@property (nonatomic, strong) CFCJiaoZhuRiQiModel *selectedDateTime;

@end

NS_ASSUME_NONNULL_END
