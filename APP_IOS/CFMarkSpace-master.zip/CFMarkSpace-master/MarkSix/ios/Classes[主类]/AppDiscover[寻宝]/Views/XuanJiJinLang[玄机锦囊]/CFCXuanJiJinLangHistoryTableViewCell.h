//
// 寻宝 - 玄机锦囊 - 历史记录
//

#import <UIKit/UIKit.h>
@class CFCXuanJiJinLangHistoryModel;


NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_DISCOVER_XUANJIJINLANG_IDENTIFIER;


@protocol CFCXuanJiJinLangHistoryTableViewCellDelegate <NSObject>
@optional
- (void)didSelectRowAtXuanJiJinLangHistoryModel:(CFCXuanJiJinLangHistoryModel *)model indexPath:(NSIndexPath *)indexPath;
@end


@interface CFCXuanJiJinLangHistoryTableViewCell : UITableViewCell
/**
 * 数据下标
 */
@property (nonatomic, strong) NSIndexPath *indexPath;
/**
 * 数据模型
 */
@property (nonatomic, strong) CFCXuanJiJinLangHistoryModel *model;
/**
 * 表格代理
 */
@property (nonatomic, weak) id<CFCXuanJiJinLangHistoryTableViewCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
