//
// 寻宝 - 搅珠日期
//

#import <UIKit/UIKit.h>
@class CFCJiaoZhuRiQiModel;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_RESULT_JIAOZHURIQI_COLLECTION_VIEW_CELL;

@interface CFCJiaoZhuRiQiCollectionViewCell : UICollectionViewCell

@property (nonatomic, strong) CFCJiaoZhuRiQiModel *model;

@end

NS_ASSUME_NONNULL_END
