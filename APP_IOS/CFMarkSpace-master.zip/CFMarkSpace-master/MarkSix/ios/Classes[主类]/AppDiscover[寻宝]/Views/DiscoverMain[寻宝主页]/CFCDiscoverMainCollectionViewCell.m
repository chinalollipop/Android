//
// 寻宝 - 寻宝数据
//

#import "CFCDiscoverMainCollectionViewCell.h"
#import "CFCDiscoverMainModel.h"


// Cell Identifier
NSString * const CELL_IDENTIFIER_DISCOVER_MAIN_COLLECTION_VIEW_CELL = @"CFCDiscoverMainCollectionViewCellIdentifier";


@interface CFCDiscoverMainCollectionViewCell ()
/**
 * 根容器组件
 */
@property (nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonatomic, strong) UIView *publicContainerView;
/**
 * 标题控件
 */
@property (nonnull, nonatomic, strong) UILabel *titleLabel;
/**
 * 图标控件
 */
@property (nonnull, nonatomic, strong) UIImageView *iconImageView;

@end


@implementation CFCDiscoverMainCollectionViewCell

-(instancetype)initWithFrame:(CGRect)frame
{
  self = [super initWithFrame:frame];
  if(self) {
    [self createViewAtuoLayout];
  }
  return self;
}

#pragma mark 创建子控件
- (void) createViewAtuoLayout
{
  // 定义变量
  CGFloat imageSize = self.width*0.57f;
  
  // 根容器
  UIView *rootContainerView = ({
    UIView *view = [[UIView alloc] init];
    [self.contentView insertSubview:view atIndex:0];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
    }];
    
    view;
  });
  self.rootContainerView = rootContainerView;
  self.rootContainerView.mas_key = @"rootContainerView";
  
  // 公共容器
  UIView *publicContainerView = ({
    UIView *view = [[UIView alloc] init];
    [rootContainerView addSubview:view];
    [view setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_DEFAULT];

    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressPublicItemView:)];
    [view addGestureRecognizer:tapGesture];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(rootContainerView.mas_left).offset(0.0f);
      make.top.equalTo(rootContainerView.mas_top).offset(0.0f);
      make.right.equalTo(rootContainerView.mas_right).offset(0.0f);
      make.bottom.equalTo(rootContainerView.mas_bottom).offset(0.0f);
    }];
    
    view;
  });
  self.publicContainerView = publicContainerView;
  self.publicContainerView.mas_key = @"publicContainerView";
  
  // 图标控件
  UIImageView *iconImageView = ({
    UIImageView *imageView = [UIImageView new];
    [publicContainerView addSubview:imageView];
    [imageView setUserInteractionEnabled:YES];
    [imageView setContentMode:UIViewContentModeScaleAspectFit];
    
    
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerX.equalTo(publicContainerView.mas_centerX);
      make.centerY.equalTo(publicContainerView.mas_centerY).offset(-imageSize*0.20f);
      make.size.mas_equalTo(CGSizeMake(imageSize, imageSize));
    }];
    
    imageView;
  });
  self.iconImageView = iconImageView;
  self.iconImageView.mas_key = [NSString stringWithFormat:@"iconImageView"];
  
  // 标题控件
  UILabel *titleLabel = ({
    UILabel *label = [UILabel new];
    [label setText:STR_APP_TEXT_PLACEHOLDER];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    [label setTextAlignment:NSTextAlignmentCenter];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
    [publicContainerView addSubview:label];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerX.equalTo(publicContainerView.mas_centerX);
      make.top.equalTo(iconImageView.mas_bottom).offset(imageSize*0.05f);
    }];
    
    label;
  });
  self.titleLabel = titleLabel;
  self.titleLabel.mas_key = @"titleLabel";
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCDiscoverMainModel *)model
{
  // 类型安全检查
  if (![model isKindOfClass:[CFCDiscoverMainModel class]]) {
    return;
  }
  
  // 数据赋值
  _model = (CFCDiscoverMainModel *)model;
  
  // 图标控件
  [self.iconImageView setImage:[UIImage imageNamed:_model.imageUrl]];
  
  // 标题
  NSString *title = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:_model.title];
  [self.titleLabel setText:title];
}


#pragma mark - 操作事件 - 操作按钮
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture
{
  // 执行代理
  if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectRowAtDiscoverMainModel:)]) {
    [self.delegate didSelectRowAtDiscoverMainModel:self.model];
  }
}


@end

