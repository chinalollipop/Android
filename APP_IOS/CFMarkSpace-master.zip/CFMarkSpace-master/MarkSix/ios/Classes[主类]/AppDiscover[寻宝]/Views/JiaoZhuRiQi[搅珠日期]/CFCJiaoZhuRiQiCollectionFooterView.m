//
// 寻宝 - 搅珠日期
//

#import "CFCJiaoZhuRiQiCollectionFooterView.h"
#import "CFCJiaoZhuRiQiModel.h"

// Section Header Identifier
NSString * const CELL_IDENTIFIER_RESULT_JIAOZHURIQI_COLLECTION_SECTION_FOOTER = @"CFCJiaoZhuRiQiCollectionFooterViewIdentifier";

@interface CFCJiaoZhuRiQiCollectionFooterView ()

@property (nonatomic, strong) UILabel *contentLabel;

@end

@implementation CFCJiaoZhuRiQiCollectionFooterView

- (instancetype)initWithFrame:(CGRect)frame
{
  self = [super initWithFrame:frame];
  if (self) {
    CGFloat magin = CFC_AUTOSIZING_MARGIN(MARGIN);
    self.contentLabel = [[UILabel alloc] init];
    [self addSubview:self.contentLabel];
    [self.contentLabel setNumberOfLines:0];
    [self.contentLabel setTextAlignment:NSTextAlignmentCenter];
    [self.contentLabel setFont:[UIFont fontWithName:@"NotoMono" size:CFC_AUTOSIZING_FONT(15)]];
    [self.contentLabel setTextColor:COLOR_HEXSTRING(@"#BB9265")];
    [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerX.equalTo(self.mas_centerX);
      make.width.equalTo(self.mas_width);
      make.bottom.equalTo(self.mas_bottom).offset(-magin*0.5f);
    }];
  }
  return self;
}

- (void)setSelectedDateTime:(CFCJiaoZhuRiQiModel *)selectedDateTime
{
  _selectedDateTime = selectedDateTime;

  NSString *content = @"";
  if ([_selectedDateTime.dateValue.yyyyMMddByLineWithDate isEqualToString:[NSDate date].yyyyMMddByLineWithDate]) {
    if (selectedDateTime.isOpenResultDay) {
      content = [NSString stringWithFormat:@"今天 %@ 第%@期", _selectedDateTime.dateValue.yyyyMMddByLineWithDate, _selectedDateTime.issue.stringValue];
    } else {
      content = [NSString stringWithFormat:@"今天 %@ 非开奖日期", _selectedDateTime.dateValue.yyyyMMddByLineWithDate];
    }
  } else {
    if (selectedDateTime.isOpenResultDay) {
      content = [NSString stringWithFormat:@"%@ 第%@期", _selectedDateTime.dateValue.yyyyMMddByLineWithDate, _selectedDateTime.issue.stringValue];
    } else {
      content = [NSString stringWithFormat:@"%@ 非开奖日期", _selectedDateTime.dateValue.yyyyMMddByLineWithDate];
    }
  }
  
  [_contentLabel setText:content];
}


@end



