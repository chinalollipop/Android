//
// 寻宝 - 寻宝数据
//

#import <UIKit/UIKit.h>
@class CFCDiscoverMainModel;


NS_ASSUME_NONNULL_BEGIN


UIKIT_EXTERN NSString * const CELL_IDENTIFIER_DISCOVER_MAIN_COLLECTION_VIEW_CELL;


@protocol CFCDiscoverMainCollectionViewCellDelegate <NSObject>
@optional
- (void)didSelectRowAtDiscoverMainModel:(CFCDiscoverMainModel *)model;
@end


@interface CFCDiscoverMainCollectionViewCell : UICollectionViewCell
/**
 * 数据模型
 */
@property (nonatomic, strong) CFCDiscoverMainModel *model;
/**
 * 表格代理
 */
@property (nonatomic, weak) id<CFCDiscoverMainCollectionViewCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
