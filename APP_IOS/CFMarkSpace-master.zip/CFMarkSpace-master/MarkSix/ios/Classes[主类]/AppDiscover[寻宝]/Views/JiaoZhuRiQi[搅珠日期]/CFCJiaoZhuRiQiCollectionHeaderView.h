//
// 寻宝 - 搅珠日期
//

#import <UIKit/UIKit.h>
@class CFCJiaoZhuRiQiModel;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN CGFloat const HEIGHT_DRAW_RESULT_JIAOZHURIQI_COLLECTION_SECTION_HEADER;

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_RESULT_JIAOZHURIQI_COLLECTION_SECTION_HEADER;

@protocol CFCJiaoZhuRiQiCollectionHeaderViewDelegate <NSObject>
@optional
- (void)doLogicPressButtonLastMounthAction;
- (void)doLogicPressButtonNextMounthAction;
@end

@interface CFCJiaoZhuRiQiCollectionHeaderView : UICollectionReusableView
@property (nonatomic, assign) BOOL isMondayOfWeekFirst;
@property (nonatomic, strong) CFCJiaoZhuRiQiModel *selectedDateTime;
@property (nonatomic, weak) id<CFCJiaoZhuRiQiCollectionHeaderViewDelegate> delegate;
@end

NS_ASSUME_NONNULL_END
