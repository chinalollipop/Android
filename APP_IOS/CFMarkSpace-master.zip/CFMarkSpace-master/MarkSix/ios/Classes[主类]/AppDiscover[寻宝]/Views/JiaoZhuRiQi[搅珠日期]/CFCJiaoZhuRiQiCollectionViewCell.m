//
// 寻宝 - 搅珠日期
//

#import "CFCJiaoZhuRiQiCollectionViewCell.h"
#import "CFCJiaoZhuRiQiModel.h"

// Cell Identifier
NSString * const CELL_IDENTIFIER_RESULT_JIAOZHURIQI_COLLECTION_VIEW_CELL = @"CFCJiaoZhuRiQiCollectionViewCellIdentifier";

@interface CFCJiaoZhuRiQiCollectionViewCell ()

@property (nonnull, nonatomic, strong) UIView *container;

@property (nonnull, nonatomic, strong) UILabel *contentLabel;

@end


@implementation CFCJiaoZhuRiQiCollectionViewCell

-(instancetype)initWithFrame:(CGRect)frame
{
  self = [super initWithFrame:frame];
  if(self) {
    [self createViewAtuoLayout];
  }
  return self;
}

#pragma mark 创建子控件
- (void) createViewAtuoLayout
{
  CGFloat container_size = self.contentView.frame.size.width*0.65;
  CGRect container_frame = CGRectMake(self.contentView.frame.size.width*0.5-container_size*0.5, self.contentView.frame.size.height*0.5-container_size*0.5, container_size, container_size);
  UIView *container = [[UIView alloc] initWithFrame:container_frame];
  [container.layer setMasksToBounds:YES];
  [container.layer setCornerRadius:container_size*0.5f];
  [container.layer setBorderWidth:1.0f];
  [self setContainer:container];
  [self.contentView addSubview:container];
  [self.contentView setBackgroundColor:[UIColor whiteColor]];
  
  CGFloat width = self.contentView.frame.size.width*0.55;
  CGFloat height = self.contentView.frame.size.height*0.55;
  CGRect frame = CGRectMake(self.contentView.frame.size.width*0.5-width*0.5, self.contentView.frame.size.height*0.5-height*0.5, width, height);
  UILabel *contentLabel = [[UILabel alloc] initWithFrame:frame];
  [contentLabel setTextAlignment:NSTextAlignmentCenter];
  [contentLabel setTextColor:[UIColor blackColor]];
  [contentLabel setBackgroundColor:[UIColor whiteColor]];
  [contentLabel setFont:[UIFont fontWithName:@"NotoMono" size:CFC_AUTOSIZING_FONT(16)]];
  [contentLabel.layer setMasksToBounds:YES];
  [contentLabel.layer setCornerRadius:height*0.5f];
  [self setContentLabel:contentLabel];
  [self.contentView addSubview:contentLabel];
  [self.contentView setBackgroundColor:[UIColor whiteColor]];
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCJiaoZhuRiQiModel *)model
{
  // 类型安全检查
  if (![model isKindOfClass:[CFCJiaoZhuRiQiModel class]]) {
    return;
  }
  
  // 数据赋值
  _model = (CFCJiaoZhuRiQiModel *)model;
  
  // 日期天数
  if (_model.dayValue) {
    [self.contentLabel setText:[NSString stringWithFormat:@"%ld", _model.dayValue]];
  } else {
    [self.contentLabel setText:@""];
  }
  
  // 开奖日期
  if (_model.isOpenResultDay) {
    [self.contentLabel setBackgroundColor:COLOR_HEXSTRING(@"#E89135")];
  } else {
    [self.contentLabel setBackgroundColor:COLOR_HEXSTRING(@"#FFFFFF")];
  }

  // 是否选中
  if (_model.isSelectedDay) {
    [self.container.layer setBorderColor:COLOR_HEXSTRING(@"#000000").CGColor];
  } else {
    // 当前日期
    if (_model.isCurrentDay) {
      [self.container.layer setBorderColor:COLOR_HEXSTRING(@"#B53339").CGColor];
    } else {
      [self.container.layer setBorderColor:COLOR_HEXSTRING(@"#FFFFFF").CGColor];
    }
  }
  
}


@end





