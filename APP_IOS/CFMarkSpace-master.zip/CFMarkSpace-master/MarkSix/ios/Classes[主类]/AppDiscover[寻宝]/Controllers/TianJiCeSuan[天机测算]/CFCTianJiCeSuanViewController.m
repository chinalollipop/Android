//
// 寻宝 - 天机测算
//

#import "CFCTianJiCeSuanViewController.h"


@interface CFCTianJiCeSuanViewController ()

@property (nonatomic, strong) UIButton *buttonShengXiao;
@property (nonatomic, strong) UIButton *buttonWeiShu;

@property (nonatomic, copy) NSString *currentIssue;

@end


@implementation CFCTianJiCeSuanViewController


#pragma mark -
#pragma mark 事件处理 - 生成生肖
- (void)doLogicShengXiaoAction:(UIButton *)button
{
  [self doLogicTianJiCeSuan];
}

#pragma mark 事件处理 - 生成尾数
- (void)doLogicWeiShuAction:(UIButton *)button
{
  [self doLogicTianJiCeSuan];
}

#pragma mark 事件处理 - 天机测算
- (void)doLogicTianJiCeSuan
{
  // 随机开奖号码
  NSArray<NSString *> *randNumber = [CFCAppGameUtil getRandNumberWeiShu:3];
  NSArray<NSString *> *randShengXiao = [CFCAppGameUtil getRandShengXiaoNames:randNumber.count];
  NSString *rangNumberValue = [randNumber componentsJoinedByString:@","];
  NSString *randShengXiaoValue = [randShengXiao componentsJoinedByString:@","];
  //
  NSString *rangNumberString = [randNumber componentsJoinedByString:@" "];
  NSString *rangShengXiaoString = [randShengXiao componentsJoinedByString:@" "];
  [self.buttonShengXiao setTitle:rangShengXiaoString forState:UIControlStateNormal];
  [self.buttonWeiShu setTitle:rangNumberString forState:UIControlStateNormal];
  
  // 保存当前期结果
  APPINFORMATION.tianJiCeSuanIssue = self.currentIssue;
  APPINFORMATION.tianJiCeSuanResult = [NSString stringWithFormat:@"%@|%@", rangNumberValue, randShengXiaoValue];
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    
  }
  return self;
}


#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  WEAKSELF(weakSelf);
  
  // 设置背景颜色
  [self.view setBackgroundColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT];
  
  // 创建主要界面
  [self createMainUIView];
  
  // 是否重围结果
  [CFCAppGameUtil getCurrentIssueNumber:self.view then:^(NSString * _Nonnull year, NSString * _Nonnull issue, NSString * _Nonnull datetime) {

    weakSelf.currentIssue = issue;
    
    if (APPINFORMATION.tianJiCeSuanIssue.integerValue > 0
        && APPINFORMATION.tianJiCeSuanIssue.integerValue >= issue.integerValue) {
      
      NSString *tianJiCeSuanResult = APPINFORMATION.tianJiCeSuanResult;
      NSCharacterSet *character = [NSCharacterSet characterSetWithCharactersInString:@"||"];
      NSArray<NSString *> *split = [tianJiCeSuanResult componentsSeparatedByCharactersInSet:character];
      NSArray<NSString *> *randNumbers = split.count > 0 ? [split[0] split:@","] : @[@""];
      NSArray<NSString *> *randShengXiao = split.count > 1 ? [split[1] split:@","] : @[@""];;
      NSString *rangNumberString = [randNumbers componentsJoinedByString:@" "];
      NSString *rangShengXiaoString = [randShengXiao componentsJoinedByString:@" "];
      [weakSelf.buttonShengXiao setEnabled:NO];
      [weakSelf.buttonWeiShu setEnabled:NO];
      [weakSelf.buttonShengXiao setTitle:rangShengXiaoString forState:UIControlStateNormal];
      [weakSelf.buttonWeiShu setTitle:rangNumberString forState:UIControlStateNormal];
      
    } else {
      
      APPINFORMATION.tianJiCeSuanIssue = @"0";
      APPINFORMATION.tianJiCeSuanResult = @"";
      [weakSelf.buttonShengXiao setTitle:@"开 始" forState:UIControlStateNormal];
      [weakSelf.buttonWeiShu setTitle:@"开 始" forState:UIControlStateNormal];
      
    }
    
  }];
}


#pragma mark 创建主要界面
- (void)createMainUIView
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat buttonWidth = SCREEN_WIDTH * 0.25f;
  CGFloat buttonHeight = buttonWidth * 0.35f;
  CGFloat heightOfHeader = CFC_AUTOSIZING_WIDTH(DISCOVER_INTRODUCE_HEADER_HEIGHT);
  CGFloat left_right_margin = margin * 1.5f;
  
  NSString *tianJiCeSuanResult = APPINFORMATION.tianJiCeSuanResult;
  NSCharacterSet *character = [NSCharacterSet characterSetWithCharactersInString:@"||"];
  NSArray<NSString *> *split = [tianJiCeSuanResult componentsSeparatedByCharactersInSet:character];
  NSArray<NSString *> *randNumbers = split.count > 0 ? [split[0] split:@","] : @[@""];
  NSArray<NSString *> *randShengXiao = split.count > 1 ? [split[1] split:@","] : @[@""];;
  NSString *rangNumberString = APPINFORMATION.tianJiCeSuanResult.length > 0 ? [randNumbers componentsJoinedByString:@" "] : @"开 始";
  NSString *rangShengXiaoString = APPINFORMATION.tianJiCeSuanResult.length > 0 ? [randShengXiao componentsJoinedByString:@" "] : @"开 始";
  
  // 根容器
  UIScrollView *rootScrollView = ({
    UIScrollView *scrollView = [[UIScrollView alloc] init];
    [scrollView setShowsVerticalScrollIndicator:NO];
    [self.view addSubview:scrollView];

    [scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(self.view).with.offset(0.0);
      make.right.equalTo(self.view).with.offset(0.0);
      make.top.equalTo(self.view.mas_top).with.offset(0.0f);
      make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0f);
    }];
    
    scrollView;
  });
  
  // 主容器
  UIView *containerView = ({
    UIView *view = [[UIView alloc] init];
    [rootScrollView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.edges.equalTo(rootScrollView);
      make.width.equalTo(rootScrollView);
      make.height.mas_greaterThanOrEqualTo(SCREEN_HEIGHT-STATUS_NAVIGATION_BAR_HEIGHT+1.0);
    }];
    
    view;
  });
  
  // 头部介绍
  UIImageView *headerImageView = ({
    // 背景
    UIImageView *imageView = [UIImageView new];
    [containerView addSubview:imageView];
    [imageView setImage:[UIImage imageNamed:ICON_OPEN_BACKGROUND_HEADER]];
    [imageView setContentMode:UIViewContentModeScaleToFill];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(containerView.mas_top).offset(margin*1.5f);
      make.left.equalTo(containerView.mas_left).offset(left_right_margin);
      make.right.equalTo(containerView.mas_right).offset(-left_right_margin);
      make.height.mas_equalTo(heightOfHeader);
    }];
    
    // 标题
    UILabel *titleLabel = ({
      UILabel *label = [UILabel new];
      [imageView addSubview:label];
      [label setText:@"简介"];
      [label setTextAlignment:NSTextAlignmentCenter];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(imageView.mas_centerY).offset(-margin*1.0f);
        make.left.equalTo(imageView.mas_left).offset(margin*2.0f);
        make.right.equalTo(imageView.mas_right).offset(-margin*2.0f);
      }];
      
      label;
    });
    titleLabel.mas_key = @"titleLabel";
    
    // 内容
    UILabel *contentLabel = ({
      UILabel *label = [UILabel new];
      [imageView addSubview:label];
      [label setText:@"天机泄露啦！所求何事，让诸葛丞相为您卜一卦，祝您六合彩顺风顺水。"];
      [label setNumberOfLines:0];
      [label setTextAlignment:NSTextAlignmentLeft];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(12.0f)]];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(imageView.mas_centerY).offset(margin*0.50f);
        make.left.equalTo(imageView.mas_left).offset(margin*2.5f);
        make.right.equalTo(imageView.mas_right).offset(-margin*2.5f);
      }];
      
      label;
    });
    contentLabel.mas_key = @"contentLabel";
    
    imageView;
  });
  headerImageView.mas_key = @"headerImageView";
  
  
  // 天机测算
  UIView *tianJiCeSuanView = ({
    UIView *view = [[UIView alloc] init];
    [containerView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(headerImageView.mas_bottom).offset(margin*1.0f);
      make.left.equalTo(containerView.mas_left);
      make.right.equalTo(containerView.mas_right);
      make.height.mas_equalTo(containerView.mas_width).multipliedBy(0.55f);
    }];
    
    view;
  });
  
  
  // 天机测算
  {
    // 求生肖
    UILabel *shengXiaoLabel = ({
      UILabel *label = [UILabel new];
      [tianJiCeSuanView addSubview:label];
      [label setText:@"求生肖"];
      [label setTextAlignment:NSTextAlignmentCenter];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setFont:[UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(tianJiCeSuanView.mas_right).multipliedBy(0.25f);
        make.centerY.equalTo(tianJiCeSuanView.mas_bottom).multipliedBy(0.25f);
      }];
      
      label;
    });
    shengXiaoLabel.mas_key = @"shengXiaoLabel";
    
    // 求尾数
    UILabel *weiShuLabel = ({
      UILabel *label = [UILabel new];
      [tianJiCeSuanView addSubview:label];
      [label setText:@"求尾数"];
      [label setTextAlignment:NSTextAlignmentCenter];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setFont:[UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(shengXiaoLabel.mas_centerY);
        make.centerX.equalTo(tianJiCeSuanView.mas_right).multipliedBy(0.75f);
      }];
      
      label;
    });
    weiShuLabel.mas_key = @"weiShuLabel";
    
    // 求生肖
    UIButton *buttonShengXiao = ({
      UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
      [button defaultStyleButton];
      [button.layer setBorderWidth:0.0f];
      [button setTitle:rangShengXiaoString forState:UIControlStateNormal];
      [button addTarget:self action:@selector(doLogicShengXiaoAction:) forControlEvents:UIControlEventTouchUpInside];
      [tianJiCeSuanView addSubview:button];
      
      [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(tianJiCeSuanView.mas_right).multipliedBy(0.25f);
        make.centerY.equalTo(tianJiCeSuanView.mas_bottom).multipliedBy(0.55f);
        make.width.mas_equalTo(buttonWidth);
        make.height.mas_equalTo(buttonHeight);
      }];
      
      button;
    });
    self.buttonShengXiao = buttonShengXiao;
    self.buttonShengXiao.mas_key = @"buttonShengXiao";
    
    // 求尾数
    UIButton *buttonWeiShu = ({
      UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
      [button defaultStyleButton];
      [button.layer setBorderWidth:0.0f];
      [button setTitle:rangNumberString forState:UIControlStateNormal];
      [button addTarget:self action:@selector(doLogicWeiShuAction:) forControlEvents:UIControlEventTouchUpInside];
      [tianJiCeSuanView addSubview:button];
      
      [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(tianJiCeSuanView.mas_right).multipliedBy(0.75f);
        make.centerY.equalTo(buttonShengXiao.mas_centerY);
        make.width.mas_equalTo(buttonWidth);
        make.height.mas_equalTo(buttonHeight);
      }];
      
      button;
    });
    self.buttonWeiShu = buttonWeiShu;
    self.buttonWeiShu.mas_key = @"buttonWeiShu";
  }

  
  // 装饰图片1
  UIImageView *pictureImageView1 = ({
    CGFloat width = SCREEN_WIDTH*0.34f;
    CGFloat height = width * 1.458f;
    UIImageView *imageView = [UIImageView new];
    [containerView addSubview:imageView];
    [imageView setImage:[UIImage imageNamed:@"icon_discover_tianjicesuan1"]];
    [imageView setContentMode:UIViewContentModeScaleToFill];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(tianJiCeSuanView.mas_bottom);
      make.right.equalTo(containerView.mas_centerX).offset(-margin*2.0f);
      make.size.mas_equalTo(CGSizeMake(width, height));
    }];
    
    imageView;
  });
  pictureImageView1.mas_key = @"pictureImageView1";
  
  
  // 装饰图片2
  UIImageView *pictureImageView2 = ({
    CGFloat width = SCREEN_WIDTH*0.45f;
    CGFloat height = width * 1.297f;
    UIImageView *imageView = [UIImageView new];
    [containerView addSubview:imageView];
    [imageView setImage:[UIImage imageNamed:@"icon_discover_tianjicesuan2"]];
    [imageView setContentMode:UIViewContentModeScaleToFill];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.bottom.equalTo(pictureImageView1.mas_bottom).offset(margin*0.5f);
      make.left.equalTo(containerView.mas_centerX).offset(margin*0.5f);
      make.size.mas_equalTo(CGSizeMake(width, height));
    }];
    
    imageView;
  });
  pictureImageView2.mas_key = @"pictureImageView2";
  
  
  // 约束完整
  [containerView mas_makeConstraints:^(MASConstraintMaker *make) {
    make.bottom.mas_greaterThanOrEqualTo(pictureImageView1.mas_bottom).offset(margin*1.0f);
  }];
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_DISCOVER_TIANJICESUAN;
}


@end

