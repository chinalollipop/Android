

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCBoXiaoZhuanPanTimer : NSObject

#pragma mark -
#pragma mark 定时回调，注意释放定时器
- (void)countDownInterval:(float)interval callBackBlock:(void (^)(void))callBackBlock;

#pragma mark 销毁定时器
- (void)destoryTimer;

@end

NS_ASSUME_NONNULL_END
