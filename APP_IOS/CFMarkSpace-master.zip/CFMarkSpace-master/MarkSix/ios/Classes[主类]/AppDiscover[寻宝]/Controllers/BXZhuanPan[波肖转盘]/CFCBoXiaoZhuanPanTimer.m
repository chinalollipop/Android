

#import "CFCBoXiaoZhuanPanTimer.h"


@interface CFCBoXiaoZhuanPanTimer ()
@property(nonatomic, retain) dispatch_source_t timer;
@end


@implementation CFCBoXiaoZhuanPanTimer

#pragma mark -
#pragma mark 定时回调，注意释放定时器
- (void)countDownInterval:(float)interval callBackBlock:(void (^)(void))callBackBlock
{
  if (_timer == nil) {
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
    dispatch_source_set_timer(_timer, dispatch_walltime(NULL, 0), interval*NSEC_PER_SEC, 0);
    dispatch_source_set_event_handler(_timer, ^{
      dispatch_async(dispatch_get_main_queue(), ^{
        callBackBlock();
      });
    });
    dispatch_resume(_timer);
  }
}


#pragma mark 销毁定时器
- (void)destoryTimer
{
  if (_timer) {
    dispatch_source_cancel(_timer);
    _timer = nil;
  }
}


@end
