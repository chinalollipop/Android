//
// 寻宝 - 玄机锦囊
//

#import "CFCBaseCommonViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCXuanJiJinLangViewController : CFCBaseCommonViewController

@end

NS_ASSUME_NONNULL_END
