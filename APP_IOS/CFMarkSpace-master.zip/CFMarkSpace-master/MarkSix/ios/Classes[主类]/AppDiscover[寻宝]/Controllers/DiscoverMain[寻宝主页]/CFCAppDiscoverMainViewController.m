//
// 寻宝 - 寻宝数据
//

#import "CFCAppDiscoverMainViewController.h"
#import "CFCDiscoverMainCollectionViewCell.h"
#import "CFCDiscoverMainModel.h"

// 跳转
#import "CFCYaoYiYaoViewController.h"
#import "CFCJiaoZhuRiQiViewController.h"
#import "CFCLianRenTeMaViewController.h"
#import "CFCShengXiaoKaViewController.h"
#import "CFCTianJiCeSuanViewController.h"
#import "CFCBoXiaoZhuanPanViewController.h"
#import "CFCXingYunYaoJiangViewController.h"
#import "CFCXuanJiJinLangViewController.h"
#import "CFCTiaoMaZhuSouViewController.h"


@interface CFCAppDiscoverMainViewController () <CFCDiscoverMainCollectionViewCellDelegate>

@end

@implementation CFCAppDiscoverMainViewController


#pragma mark -
#pragma mark 事件处理 - 工具宝箱
- (void)didSelectRowAtDiscoverMainModel:(CFCDiscoverMainModel *)model
{
  CFCBaseCommonViewController *viewController = nil;
  NSString *MARKID = model.markId.uppercaseString;
  
  // 恋人特码
  if ([STR_MARKID_DISCOVER_MAIN_LIAN_REN isEqualToString:MARKID.uppercaseString]) {
    viewController = [[CFCLianRenTeMaViewController alloc] init];
  }
  // 生肖卡牌
  else if ([STR_MARKID_DISCOVER_MAIN_SHENG_XIAO isEqualToString:MARKID.uppercaseString]) {
    viewController = [[CFCShengXiaoKaViewController alloc] init];
  }
  // 摇一摇
  else if ([STR_MARKID_DISCOVER_MAIN_YAO_YI_YAO isEqualToString:MARKID.uppercaseString]) {
    viewController = [[CFCYaoYiYaoViewController alloc] init];
  }
  // 玄机锦囊
  else if ([STR_MARKID_DISCOVER_MAIN_XUANJIJINNANG isEqualToString:MARKID.uppercaseString]) {
    viewController = [[CFCXuanJiJinLangViewController alloc] init];
  }
  // 幸运摇奖
  else if ([STR_MARKID_DISCOVER_MAIN_XINGYUNYAOJIANG isEqualToString:MARKID.uppercaseString]) {
    viewController = [[CFCXingYunYaoJiangViewController alloc] init];
  }
  // 波肖转盘
  else if ([STR_MARKID_DISCOVER_MAIN_BOXIAOZHUANPAN isEqualToString:MARKID.uppercaseString]) {
    viewController = [[CFCBoXiaoZhuanPanViewController alloc] init];
  }
  // 搅珠日期
  else if ([STR_MARKID_DISCOVER_MAIN_JIAOZHURIQI isEqualToString:MARKID.uppercaseString]) {
    viewController = [[CFCJiaoZhuRiQiViewController alloc] init];
  }
  // 天机测算
  else if ([STR_MARKID_DISCOVER_MAIN_TIANJICESUAN isEqualToString:MARKID.uppercaseString]) {
    viewController = [[CFCTianJiCeSuanViewController alloc] init];
  }
  // 挑码助手
  else if ([STR_MARKID_DISCOVER_MAIN_TIAOMAZHUSHOU isEqualToString:MARKID.uppercaseString]) {
    viewController = [[CFCTiaoMaZhuSouViewController alloc] init];
  }
  
  // 跳转页面
  if (viewController) {
    [self.navigationController pushViewController:viewController animated:YES];
  } else {
    [self alertPromptMessage:[NSString stringWithFormat:@"[%@]", model.title]];
  }
  
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    self.isRequestNetwork = NO;
    self.hasRefreshHeader = NO;
    self.hasRefreshFooter = NO;
  }
  return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  // 创建静态数据模型
  self.collectionViewDataRefresh = [NSMutableArray array];
  NSMutableArray<CFCDiscoverMainModel *> *allDiscoverMainModels = [CFCDiscoverMainModel buildingDataModles];
  if (allDiscoverMainModels && 0 < allDiscoverMainModels.count) {
    [self.collectionViewDataRefresh addObject:allDiscoverMainModels.mutableCopy];
  }
  [self.collectionViewRefresh reloadData];
}


#pragma mark -
#pragma mark 注册 UICollectionView
- (void)collectionViewRefreshRegisterClass:(UICollectionView *)collectionView
{
  [super collectionViewRefreshRegisterClass:collectionView];
  
  // 注册 CFCDiscoverMainCollectionViewCell（必须）
  [self.collectionViewRefresh registerClass:[CFCDiscoverMainCollectionViewCell class]
                 forCellWithReuseIdentifier:CELL_IDENTIFIER_DISCOVER_MAIN_COLLECTION_VIEW_CELL];
  
}

#pragma mark 设置 CFCCollectionViewLayoutType 布局
- (UICollectionViewLayout *)collectionViewLayout
{
  CFCCollectionRefreshViewWaterFallLayout *flowLayout = [[CFCCollectionRefreshViewWaterFallLayout alloc] init];
  flowLayout.delegate = self;
  flowLayout.margin = CFC_AUTOSIZING_WIDTH(2.0f);
  return flowLayout;
}


#pragma mark -
#pragma mark UICollectionViewDataSource UICollectionViewDelegate
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
  if (self.collectionViewDataRefresh && self.collectionViewDataRefresh.count > 0) {
    return self.collectionViewDataRefresh.count;
  }
  return 0;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
  if (self.collectionViewDataRefresh && self.collectionViewDataRefresh.count > 0 && self.collectionViewDataRefresh.count > section) {
    if ([self.collectionViewDataRefresh[section] isKindOfClass:[NSArray class]]) {
      NSMutableArray *group = self.collectionViewDataRefresh[section];
      if ([group isKindOfClass:[NSArray class]]) {
        return group.count;
      }
    }
  }
  return 0;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.collectionViewDataRefresh
      || self.collectionViewDataRefresh.count <= 0
      || self.collectionViewDataRefresh.count <= indexPath.section
      || ![self.collectionViewDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  CFCDiscoverMainCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:CELL_IDENTIFIER_DISCOVER_MAIN_COLLECTION_VIEW_CELL forIndexPath:indexPath];
  if (!cell) {
    cell = [[CFCDiscoverMainCollectionViewCell alloc] init];
  }
  cell.delegate = self;
  cell.model = self.collectionViewDataRefresh[indexPath.section][indexPath.row];
  return cell;
}


#pragma mark -
#pragma mark CFCCollectionRefreshViewWaterFallLayoutDelegate

#pragma mark 自定义表格每一个分组的列数
- (NSInteger)numberOfColumnsInSectionForIndexPath:(NSIndexPath *)indexPath
{
  return 3;
}

#pragma mark 自定义表格每一行的高度
- (CGFloat)heightOfCellItemForCollectionViewAtIndexPath:(NSIndexPath *)indexPath
{
  NSInteger column = [self numberOfColumnsInSectionForIndexPath:indexPath];
  CFCCollectionRefreshViewWaterFallLayout *layout = (CFCCollectionRefreshViewWaterFallLayout *)self.collectionViewLayout;
  return ((self.collectionViewRefresh.width-layout.margin*(column-1))/column);
}



@end

