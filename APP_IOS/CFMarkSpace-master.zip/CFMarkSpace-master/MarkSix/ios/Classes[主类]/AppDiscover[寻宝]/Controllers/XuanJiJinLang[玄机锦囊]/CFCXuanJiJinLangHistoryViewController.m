//
// 寻宝 - 玄机锦囊 - 历史记录
//

#import "CFCXuanJiJinLangHistoryViewController.h"
#import "CFCXuanJiJinLangHistoryTableViewCell.h"
#import "CFCXuanJiJinLangHistoryModel.h"
#import "CFCDrawResultRecordYearsModel.h"
#import "CFCDrawRecordYearPickerView.h"


@interface CFCXuanJiJinLangHistoryViewController () <CFCXuanJiJinLangHistoryTableViewCellDelegate>

@property(nonatomic, copy) NSString *currentYear;
@property(nonatomic, strong) NSMutableArray<CFCDrawResultRecordYearsModel *> *drawResultRecordYears;

@end


@implementation CFCXuanJiJinLangHistoryViewController


#pragma mark -
#pragma mark 事件处理 - 选择年份事件
- (void)pressNavigationBarRightButtonItem:(id)sender
{
  WEAKSELF(weakSelf);
  NSString *year = [NSString stringWithFormat:@"%ld", [NSDate new].year];
  if (![CFCSysUtil validateStringEmpty:self.currentYear]) {
    year = self.currentYear;
  }
  UIWindow *window = [UIApplication sharedApplication].keyWindow;
  CFCDrawRecordYearPickerView *pickerView = [[CFCDrawRecordYearPickerView alloc] initWithFrame:window.frame
                                                                                    dataSource:self.drawResultRecordYears
                                                                                 selectedValue:year];
  [pickerView setSelectedBlock:^(CFCDrawResultRecordYearsModel *selectedValue) {
    [weakSelf doRefreshTableViewByYear:selectedValue.year.stringValue animated:YES];
  }];
  [window addSubview:pickerView];
}

#pragma mark 事件处理 - 点击表格
- (void)didSelectRowAtXuanJiJinLangHistoryModel:(CFCXuanJiJinLangHistoryModel *)model indexPath:(NSIndexPath *)indexPath
{
  model.isShowContent = !model.isShowContent;
  [self.tableViewRefresh reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
}


#pragma mark -
#pragma mark 逻辑处理 - 刷新表格
- (void)doRefreshTableViewByYear:(NSString *)year animated:(BOOL)animated
{
  if (self.currentYear.integerValue == year.integerValue) {
    return;
  }
  
  [self setCurrentYear:year];
  if (animated) {
    [self.tableViewRefresh.mj_header beginRefreshing];
  } else {
    [self loadData];
  }
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    self.hasPage = NO;
    self.hasCacheData = NO;
  }
  return self;
}

#pragma mark 视图生命周期
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  WEAKSELF(weakSelf);
  [self viewDidLoadNetworkDataSourceOfYearThen:^(BOOL success, NSUInteger count) {
    [weakSelf viewDidLoadNetworkDataSourceOfYearThenAfterSuccess];
  }];
}


#pragma mark -
#pragma mark 请求地址
- (NSString *)getRequestURLString
{
  return URL_API_DISCOER_MAIN_XUANJIJINLANG_HISTORY;
}

#pragma mark 请求参数
- (NSMutableDictionary *)getRequestParamerter
{
  NSString *year = [NSString stringWithFormat:@"%ld", [NSDate new].year];
  if (![CFCSysUtil validateStringEmpty:self.currentYear]) {
    year = self.currentYear;
  }
  return [CFCNetworkParamsUtil getDiscoerMainXuanJiJinLangParameters:year];
}

#pragma mark 请求网络数据或加载缓存
- (NSMutableArray *)loadNetworkDataOrCacheDataSingle:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData
{
  WEAKSELF(weakSelf);
  
  NSDictionary *responseData = (NSDictionary *)responseDataOrCacheData;
  CFCLog(@"[往期历史][%@] => %@\n", CFC_DATA_TYPE(isCacheData), responseData);
  
  // 请求成功，解析数据
  NSArray *data = [responseData objectForKey:CFC_REQUEST_KEY_DATA];
  NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
  if (![CFCSysUtil validateResultCodeIsSuccess:status] || [CFCSysUtil validateObjectIsNull:data]) {
    return [NSMutableArray array];
  }
  
  /////////////////////////////////////////////////////////////////
  // A、组装数据 -> 开始
  /////////////////////////////////////////////////////////////////
  
  // 开奖历史
  NSMutableArray<CFCXuanJiJinLangHistoryModel *> *allItemModels = [NSMutableArray<CFCXuanJiJinLangHistoryModel *> array];
  [data enumerateObjectsUsingBlock:^(NSDictionary *  _Nonnull dict, NSUInteger idx, BOOL * _Nonnull stop) {
    CFCXuanJiJinLangHistoryModel *model = [CFCXuanJiJinLangHistoryModel mj_objectWithKeyValues:dict];
    [allItemModels addObject:model];
  }];
  
  /////////////////////////////////////////////////////////////////
  // A、组装数据 -> 结束
  /////////////////////////////////////////////////////////////////
  
  
  /////////////////////////////////////////////////////////////////
  // B、配置数据源  -> 开始
  /////////////////////////////////////////////////////////////////
  
  // 初始化数据源
  weakSelf.tableDataRefresh = [NSMutableArray array];
  
  // 开奖结果
  if (allItemModels && 0 < allItemModels.count) {
    [weakSelf.tableDataRefresh addObject:allItemModels.mutableCopy];
  } else {
    [weakSelf.tableDataRefresh addObject:@[].mutableCopy];
  }
  
  /////////////////////////////////////////////////////////////////
  // B、配置数据源  -> 结束
  /////////////////////////////////////////////////////////////////
  
  return weakSelf.tableDataRefresh.firstObject;
}


#pragma mark -
#pragma mark 注册 UITableViewCell
- (void)tableViewRefreshRegisterClass:(UITableView *)tableView
{
  [self.tableViewRefresh registerClass:[CFCXuanJiJinLangHistoryTableViewCell class]
                forCellReuseIdentifier:CELL_IDENTIFIER_DISCOVER_XUANJIJINLANG_IDENTIFIER];
}



#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_DISCOVER_XUANJIJINLANG_HISTORY;
}

#pragma mark 导航栏右边按钮类型
- (CFCNavBarButtonItemType)prefersNavigationBarRightButtonItemType
{
  return CFCNavBarButtonItemTypeCustom;
}

#pragma mark 导航栏右边按钮标题
- (NSString *)prefersNavigationBarRightButtonItemTitle
{
  return @"选择年份";
}


#pragma mark -
#pragma mark 年份选择 - 加载请求网络数据成功
- (void)viewDidLoadNetworkDataSourceOfYearThen:(void (^)(BOOL success, NSUInteger count))then
{
  WEAKSELF(weakSelf);
  
  // 请求数据是否成功
  __block BOOL isSuccess = NO;
  __block NSUInteger listCount = 0;
  
  // 请求地址与参数
  NSString *url = URL_API_DRAW_RESULT_RECORD_YEARS;
  NSMutableDictionary *params = [CFCNetworkParamsUtil getDrawResultRecordYearsParameters];
  CFCLog(@"\n请求地址：%@ \n请求参数：%@", url, params);
  
  // 请求网络数据
  [CFCNetworkHTTPSessionUtil GET:url parameters:params success:^(id responseObject) {
    
    // 加载解析网络数据
    NSMutableArray *responseTableData = [weakSelf loadDrawRecordYearsNetworkDataOrCacheData:responseObject isCacheData:NO];
    
    // 更新请求数据状态
    listCount = responseTableData.count;
    if (listCount > 0) {
      isSuccess = YES;
      CFCLog(@"加载请求网络数据成功");
    } else {
      isSuccess = YES;
      CFCLog(@"没有更多网络数据");
    }
    
    // 刷新界面
    then(isSuccess,listCount);
    
  } failure:^(NSError *error) {
    
    CFCLog(@"加载请求网络数据异常：%@", error);
    
    // 刷新界面
    then(isSuccess,listCount);
    
  } showProgressHUD:YES showProgressView:self.view];
}

#pragma mark 年份选择 - 请求网络数据或加载缓存
- (NSMutableArray *)loadDrawRecordYearsNetworkDataOrCacheData:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData
{
  WEAKSELF(weakSelf);
  
  NSDictionary *responseData = (NSDictionary *)responseDataOrCacheData;
  CFCLog(@"[开奖记录年份][%@] => %@\n", CFC_DATA_TYPE(isCacheData), responseData);
  
  // 请求成功，解析数据
  NSDictionary *data = [responseData objectForKey:CFC_REQUEST_KEY_DATA];
  NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
  if (![CFCSysUtil validateResultCodeIsSuccess:status] || [CFCSysUtil validateObjectIsNull:data]) {
    return [NSMutableArray array];
  }
  
  NSMutableArray<CFCDrawResultRecordYearsModel *> *allDrawResultYearsModels = [NSMutableArray<CFCDrawResultRecordYearsModel *> array];
  [data[@"list"] enumerateObjectsUsingBlock:^(NSDictionary *  _Nonnull dict, NSUInteger idx, BOOL * _Nonnull stop) {
    CFCDrawResultRecordYearsModel *itemModel = [CFCDrawResultRecordYearsModel mj_objectWithKeyValues:dict];
    [allDrawResultYearsModels addObject:itemModel];
  }];
  
  weakSelf.drawResultRecordYears = [NSMutableArray array];
  if (allDrawResultYearsModels && 0 < allDrawResultYearsModels.count) {
    [weakSelf.drawResultRecordYears addObjectsFromArray:allDrawResultYearsModels];
  }
  
  return weakSelf.drawResultRecordYears;
}

#pragma mark 年份选择 - 加载请求网络数据成功
- (void)viewDidLoadNetworkDataSourceOfYearThenAfterSuccess
{
  CFCDrawResultRecordYearsModel *model = self.drawResultRecordYears.firstObject;
  [self setCurrentYear:model.year.stringValue];

  
}


#pragma mark -
#pragma mark UITableViewDelegate UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0) {
    return self.tableDataRefresh.count;
  }
  return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0 && self.tableDataRefresh.count > section) {
    if ([self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
      NSMutableArray *group = self.tableDataRefresh[section];
      if ([group isKindOfClass:[NSArray class]]) {
        return group.count;
      }
    }
  }
  return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  CFCXuanJiJinLangHistoryTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_DISCOVER_XUANJIJINLANG_IDENTIFIER];
  if (!cell) {
    cell = [[CFCXuanJiJinLangHistoryTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_DISCOVER_XUANJIJINLANG_IDENTIFIER];
  }
  cell.delegate = self;
  cell.indexPath = indexPath;
  cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
  cell.selectionStyle = UITableViewCellSelectionStyleNone;
  return cell;
  
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return [self.tableViewRefresh fd_heightForCellWithIdentifier:CELL_IDENTIFIER_DISCOVER_XUANJIJINLANG_IDENTIFIER cacheByIndexPath:indexPath configuration:^(CFCXuanJiJinLangHistoryTableViewCell *cell) {
    cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
  }];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableViewRefresh.frame.size.width, CFC_AUTOSIZING_MARGIN(MARGIN))];
  [headerView setBackgroundColor:COLOR_TABLEVIEW_HEADER_VIEW_BACKGROUND_DEFAULT];
  return headerView;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableViewRefresh.frame.size.width, CFC_AUTOSIZING_MARGIN(MARGIN))];
  [footerView setBackgroundColor:COLOR_TABLEVIEW_FOOTER_VIEW_BACKGROUND_DEFAULT];
  return footerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return FLOAT_MIN;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return FLOAT_MIN;
}


@end

