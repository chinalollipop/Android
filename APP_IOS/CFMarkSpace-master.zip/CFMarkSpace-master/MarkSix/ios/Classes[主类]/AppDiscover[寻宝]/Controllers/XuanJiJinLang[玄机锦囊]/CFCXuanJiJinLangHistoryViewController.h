//
// 寻宝 - 玄机锦囊 - 历史记录
//

#import "CFCTableRefreshViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCXuanJiJinLangHistoryViewController : CFCTableRefreshViewController

@end

NS_ASSUME_NONNULL_END
