//
// 寻宝 - 玄机锦囊
//

#import "CFCXuanJiJinLangViewController.h"
#import "CFCXuanJiJinLangHistoryViewController.h"


@interface CFCXuanJiJinLangViewController ()

@property (nonnull, nonatomic, strong) UIView *containerView;
@property (nonnull, nonatomic, strong) UIButton *buttonJinLang;
@property (nonnull, nonatomic, strong) UIButton *buttonHistory;
@property (nonnull, nonatomic, strong) UILabel *jinLangTitleLabel;
@property (nonnull, nonatomic, strong) UILabel *jinLangContent1Label;
@property (nonnull, nonatomic, strong) UILabel *jinLangContent2Label;
@property (nonnull, nonatomic, strong) UIImageView *jinLangImageView;

@end


@implementation CFCXuanJiJinLangViewController


#pragma mark -
#pragma mark 事件处理 - 打开锦囊
- (void)doLogicJingLangAction:(UIButton *)button
{
  CGFloat widthOfImage = SCREEN_WIDTH * 0.56f;
  CGFloat heightOfImage = widthOfImage * 1.0f;
  [self.buttonJinLang setHidden:YES];
  [self.jinLangContent1Label setHidden:NO];
  [self.jinLangContent2Label setHidden:NO];
  [self.jinLangImageView setImage:[UIImage imageNamed:@"icon_discover_jinglang_open"]];
  [self.jinLangImageView setSize:CGSizeMake(widthOfImage, heightOfImage)];
  [self.jinLangImageView mas_remakeConstraints:^(MASConstraintMaker *make) {
    make.centerX.equalTo(self.containerView.mas_centerX);
    make.top.equalTo(self.jinLangTitleLabel.mas_bottom);
    make.size.mas_equalTo(CGSizeMake(widthOfImage, heightOfImage));
  }];
}

#pragma mark 事件处理 - 往期历史
- (void)doLogicHistoryAction:(UIButton *)button
{
  CFCXuanJiJinLangHistoryViewController *viewController = [[CFCXuanJiJinLangHistoryViewController alloc] init];
  [self.navigationController pushViewController:viewController animated:YES];
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    
  }
  return self;
}


#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  // 设置背景颜色
  [self.view setBackgroundColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT];
  
  // 创建主要界面
  [self createMainUIView];
  
  // 玄机锦囊内容
  WEAKSELF(weakSelf);
  [CFCAppGameUtil getXuanJiJinLang:self.view then:^(NSString * _Nonnull year, NSString * _Nonnull issue, NSString * _Nonnull content) {
    // 标题
    [weakSelf.jinLangTitleLabel setText:[NSString stringWithFormat:@"%@第%@期六合锦囊", year, issue]];
    // 内容
    NSCharacterSet *character = [NSCharacterSet characterSetWithCharactersInString:@"\r\n"];
    NSArray<NSString *> *splitConents = [content componentsSeparatedByCharactersInSet:character];
    if (splitConents.count > 0) {
      [weakSelf.jinLangContent1Label setText:splitConents.firstObject];
    }
    if (splitConents.count > 1) {
      [weakSelf.jinLangContent2Label setText:splitConents.lastObject];
    }
  }];
}


#pragma mark 创建主要界面
- (void)createMainUIView
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat heightOfHeader = CFC_AUTOSIZING_WIDTH(DISCOVER_INTRODUCE_HEADER_HEIGHT);
  CGFloat left_right_margin = margin * 1.5f;
  
  // 根容器
  UIScrollView *rootScrollView = ({
    UIScrollView *scrollView = [[UIScrollView alloc] init];
    [scrollView setShowsVerticalScrollIndicator:NO];
    [self.view addSubview:scrollView];
    
    [scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(self.view).with.offset(0.0);
      make.right.equalTo(self.view).with.offset(0.0);
      make.top.equalTo(self.view.mas_top).with.offset(0.0f);
      make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0f);
    }];
    
    scrollView;
  });
  
  
  // 主容器
  UIView *containerView = ({
    UIView *view = [[UIView alloc] init];
    [rootScrollView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.edges.equalTo(rootScrollView);
      make.width.equalTo(rootScrollView);
      make.height.mas_greaterThanOrEqualTo(SCREEN_HEIGHT-STATUS_NAVIGATION_BAR_HEIGHT+1.0);
    }];
    
    view;
  });
  self.containerView = containerView;
  self.containerView.mas_key = @"containerView";
  
  
  // 头部介绍
  UIImageView *headerImageView = ({
    // 背景
    UIImageView *imageView = [UIImageView new];
    [containerView addSubview:imageView];
    [imageView setImage:[UIImage imageNamed:ICON_OPEN_BACKGROUND_HEADER]];
    [imageView setContentMode:UIViewContentModeScaleToFill];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(containerView.mas_top).offset(margin*1.5f);
      make.left.equalTo(containerView.mas_left).offset(left_right_margin);
      make.right.equalTo(containerView.mas_right).offset(-left_right_margin);
      make.height.mas_equalTo(heightOfHeader);
    }];
    
    // 标题
    UILabel *titleLabel = ({
      UILabel *label = [UILabel new];
      [imageView addSubview:label];
      [label setText:@"简介"];
      [label setTextAlignment:NSTextAlignmentCenter];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(imageView.mas_centerY).offset(-margin*1.0f);
        make.left.equalTo(imageView.mas_left).offset(margin*2.0f);
        make.right.equalTo(imageView.mas_right).offset(-margin*2.0f);
      }];
      
      label;
    });
    titleLabel.mas_key = @"titleLabel";
    
    // 内容
    UILabel *contentLabel = ({
      UILabel *label = [UILabel new];
      [imageView addSubview:label];
      [label setText:@"10万六合彩用户都说准的谜题，这一期，你猜出了什么玄机？"];
      [label setNumberOfLines:0];
      [label setTextAlignment:NSTextAlignmentLeft];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(12.0f)]];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(imageView.mas_centerY).offset(margin*0.50f);
        make.left.equalTo(imageView.mas_left).offset(margin*2.5f);
        make.right.equalTo(imageView.mas_right).offset(-margin*2.5f);
      }];
      
      label;
    });
    contentLabel.mas_key = @"contentLabel";
    
    imageView;
  });
  headerImageView.mas_key = @"headerImageView";
  

  // 第N期标题
  UILabel *jinLangTitleLabel = ({
    UILabel *label = [UILabel new];
    [containerView addSubview:label];
    [label setText:@"0000年第000期六合锦囊"];
    [label setTextAlignment:NSTextAlignmentCenter];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)]];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(containerView.mas_bottom).multipliedBy(0.28f);
      make.left.equalTo(containerView.mas_left).offset(margin*2.0f);
      make.right.equalTo(containerView.mas_right).offset(-margin*2.0f);
    }];
    
    label;
  });
  self.jinLangTitleLabel = jinLangTitleLabel;
  self.jinLangTitleLabel.mas_key = @"jinLangTitleLabel";
  

  // 玄机锦囊
  UIImageView *jinLangImageView = ({
    CGFloat widthOfImage = SCREEN_WIDTH * 0.40f;
    CGFloat heightOfImage = widthOfImage * 1.10f;
    UIImageView *imageView = [UIImageView new];
    [containerView addSubview:imageView];
    [imageView setUserInteractionEnabled:YES];
    [imageView setImage:[UIImage imageNamed:@"icon_discover_jinglang_close"]];
    [imageView setContentMode:UIViewContentModeScaleToFill];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerX.equalTo(containerView.mas_centerX);
      make.top.equalTo(jinLangTitleLabel.mas_bottom).offset(margin*5.0f);
      make.size.mas_equalTo(CGSizeMake(widthOfImage, heightOfImage));
    }];
    
    imageView;
  });
  self.jinLangImageView = jinLangImageView;
  self.jinLangImageView.mas_key = @"jinLangImageView";
  
  
  // 提示信息
  UILabel *tipInfoLabel = ({
    UILabel *label = [UILabel new];
    [containerView addSubview:label];
    [label setText:@"小提示：打开锦囊将获得本期一道六合谜题，参透谜题将获得本期中奖号码，快来打开您的玄机之旅吧！"];
    [label setNumberOfLines:0];
    [label setTextAlignment:NSTextAlignmentCenter];
    [label setTextColor:COLOR_HEXSTRING(@"#D58447")];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(13.0f)]];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerX.equalTo(containerView.mas_centerX);
      make.left.equalTo(containerView.mas_left).offset(margin * 1.5f);
      make.right.equalTo(containerView.mas_right).offset(-margin * 1.5f);
    }];
    
    label;
  });
  tipInfoLabel.mas_key = @"tipInfoLabel";
  
  
  // 往期历史
  UIButton *buttonHistory = ({
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button discoerXuanJiJinLang];
    [button setTitle:@"往期历史" forState:UIControlStateNormal];
    [button setTitleColor:COLOR_HEXSTRING(@"#A28C40") forState:UIControlStateNormal];
    [button setBackgroundColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT];
    [button addTarget:self action:@selector(doLogicHistoryAction:) forControlEvents:UIControlEventTouchUpInside];
    [containerView addSubview:button];
    
    CGFloat buttonWidth = SCREEN_WIDTH * 0.55f;
    CGFloat buttonHeight = buttonWidth * 0.17f;
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
      make.bottom.equalTo(tipInfoLabel.mas_top).offset(-margin*3.0f);
      make.centerX.equalTo(containerView.mas_centerX);
      make.width.mas_equalTo(buttonWidth);
      make.height.mas_equalTo(buttonHeight);
    }];
    
    button;
  });
  self.buttonHistory = buttonHistory;
  self.buttonHistory.mas_key = @"buttonHistory";
  
  
  // 打开锦囊
  UIButton *buttonJinLang = ({
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button discoerXuanJiJinLang];
    [button setTitle:@"打开锦囊" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(doLogicJingLangAction:) forControlEvents:UIControlEventTouchUpInside];
    [containerView addSubview:button];
    
    CGFloat buttonWidth = SCREEN_WIDTH * 0.55f;
    CGFloat buttonHeight = buttonWidth * 0.17f;
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
      make.bottom.equalTo(buttonHistory.mas_top).offset(-margin*1.5f);
      make.centerX.equalTo(containerView.mas_centerX);
      make.width.mas_equalTo(buttonWidth);
      make.height.mas_equalTo(buttonHeight);
    }];
    
    button;
  });
  self.buttonJinLang = buttonJinLang;
  self.buttonJinLang.mas_key = @"buttonJinLang";
  
  
  // 锦囊内容二
  UILabel *jinLangContent2Label = ({
    UILabel *label = [UILabel new];
    [containerView addSubview:label];
    [label setHidden:YES];
    [label setUserInteractionEnabled:YES];
    [label setText:STR_APP_TEXT_PLACEHOLDER];
    [label setTextAlignment:NSTextAlignmentCenter];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(17.0f)]];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.bottom.equalTo(buttonJinLang.mas_centerY);
      make.left.equalTo(containerView.mas_left).offset(margin*2.0f);
      make.right.equalTo(containerView.mas_right).offset(-margin*2.0f);
    }];
    
    label;
  });
  self.jinLangContent2Label = jinLangContent2Label;
  self.jinLangContent2Label.mas_key = @"jinLangContent2Label";
  
  
  // 锦囊内容一
  UILabel *jinLangContent1Label = ({
    UILabel *label = [UILabel new];
    [containerView addSubview:label];
    [label setHidden:YES];
    [label setUserInteractionEnabled:YES];
    [label setText:STR_APP_TEXT_PLACEHOLDER];
    [label setTextAlignment:NSTextAlignmentCenter];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(17.0f)]];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.bottom.equalTo(jinLangContent2Label.mas_top).offset(-margin*2.0f);
      make.left.equalTo(containerView.mas_left).offset(margin*2.0f);
      make.right.equalTo(containerView.mas_right).offset(-margin*2.0f);
    }];
    
    label;
  });
  self.jinLangContent1Label = jinLangContent1Label;
  self.jinLangContent1Label.mas_key = @"jinLangContent1Label";
  
  
  // 约束完整
  CGFloat offset = IS_IPHONE_X_OR_GREATER ? margin*4.0f+TAB_BAR_DANGER_HEIGHT : margin*4.0f;
  [containerView mas_makeConstraints:^(MASConstraintMaker *make) {
    make.bottom.mas_greaterThanOrEqualTo(tipInfoLabel.mas_bottom).offset(offset);
  }];
  
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_DISCOVER_XUANJIJINLANG;
}


@end

