//
// 寻宝 - 生肖卡牌
//

#import "CFCBaseCommonViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCShengXiaoKaViewController : CFCBaseCommonViewController

@end

NS_ASSUME_NONNULL_END
