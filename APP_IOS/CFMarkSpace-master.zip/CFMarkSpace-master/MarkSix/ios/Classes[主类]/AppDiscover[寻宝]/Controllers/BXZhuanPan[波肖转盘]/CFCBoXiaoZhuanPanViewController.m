//
// 寻宝 - 波肖转盘
//

#import "CFCBoXiaoZhuanPanViewController.h"
#import "CFCBoXiaoZhuanPanTimer.h"


@interface CFCBoXiaoZhuanPanViewController ()

@property (nonnull, nonatomic, copy) NSString *currentIssue;

@property (nonnull, nonatomic, strong) UIButton *buttonConfirm; // 开始按钮
@property (nonnull, nonatomic, strong) UILabel *currentIssueLabel; // 当前期号
@property (nonnull, nonatomic, strong) UILabel *colorBoLabel; // 色波结果
@property (nonnull, nonatomic, strong) UILabel *shengXiaoLabel; // 生肖结果
@property (nonnull, nonatomic, strong) NSMutableArray<UIView *> *itemColorViewArray;
@property (nonnull, nonatomic, strong) NSMutableArray<UIImageView *> *itemShengXiaoImageViewArray;

@property (nonnull, nonatomic, strong) NSMutableArray<NSString *> *itemLogicIconImageNormal;
@property (nonnull, nonatomic, strong) NSMutableArray<NSString *> *itemLogicIconImageSelected;
@property (nonnull, nonatomic, strong) NSMutableArray<NSNumber *> *itemLogicShengXiaoImageIndexes;
@property (nonnull, nonatomic, strong) NSMutableArray<UIImageView *> *itemLogicShengXiaoImageViewArray;

@property (nonatomic, assign) NSInteger countOfSecond;
@property (nonatomic, assign) NSInteger selectedIndexOfSheBo;
@property (nonatomic, assign) NSInteger selectedIndexOfShengXiao;
@property (nonnull, nonatomic, strong) NSMutableArray<NSNumber *> *selectedIndexs;
@property (nonnull, nonatomic, strong) CFCCountDownObject *countDownObject;
@property (nonnull, nonatomic, strong) CFCBoXiaoZhuanPanTimer *countDownTimer;

@end


@implementation CFCBoXiaoZhuanPanViewController


#pragma mark -
#pragma mark 事件处理 - 生成生肖
- (void)doLogicConfirmAction:(UIButton *)button
{
  NSArray<NSNumber *> *randColorIndexs = [self getRandNumberColorBo:1];
  NSArray<NSNumber *> *randShengXiaoIndexs = [self getRandNumberShengXiao:3];
  
  NSString *rangColorValue = [randColorIndexs componentsJoinedByString:@","];
  NSString *rangShengXiaoValue = [randShengXiaoIndexs componentsJoinedByString:@","];
  NSString *shengXiaoKaResult = [NSString stringWithFormat:@"%@|%@", rangColorValue, rangShengXiaoValue];
  CFCLog(@"[色波 => %@] [生肖=>%@]", rangColorValue, rangShengXiaoValue);
  
  APPINFORMATION.boXiaoZhuanPanIssue = self.currentIssue;
  APPINFORMATION.boXiaoZhuanPanResult = shengXiaoKaResult;
  
  [self doLogicColorIndexs:randColorIndexs shengXiaoIndexs:randShengXiaoIndexs];
}


#pragma mark 事件处理 - 转盘动画
- (void)doLogicColorIndexs:(NSArray<NSNumber *> *)colorIndexs shengXiaoIndexs:(NSArray<NSNumber *> *)shengXiaoIndexs
{
  WEAKSELF(weakSelf);
  
  // 初始化配置数据
  [self setCountOfSecond:0];
  [self setSelectedIndexOfSheBo:0];
  [self setSelectedIndexOfShengXiao:0];
  [self setSelectedIndexs:[NSMutableArray<NSNumber *> array]];
  [self doLogicShengXiaoWinResultWidthSelectdIndex:@[] isFinish:NO];
  
  // 转盘时间计时器
  [self.countDownObject countDownWithSecondBlock:^{
    weakSelf.countOfSecond ++;
    CFCLog(@"计时：%ld", weakSelf.countOfSecond);
  }];
  
  // 开始循环动画显示
  NSNumber *firstSelectedIndex = [shengXiaoIndexs objectAtIndex:0];
  NSNumber *secondSelectedIndex = [shengXiaoIndexs objectAtIndex:1];
  NSNumber *thirdSelectedIndex = [shengXiaoIndexs objectAtIndex:2];
  [self.countDownTimer countDownInterval:0.15f callBackBlock:^{
    // 动画显示选中号
    if (3 > weakSelf.selectedIndexs.count) {
      // 动画显示生肖号
      [weakSelf doShengXiaoAnimatorWidthSelectdIndex:weakSelf.selectedIndexOfShengXiao
                                 itemIconImageNormal:weakSelf.itemLogicIconImageNormal
                               itemIconImageSelected:weakSelf.itemLogicIconImageSelected
                              itemIconImageViewArray:weakSelf.itemLogicShengXiaoImageViewArray];
      // 动画显示色波号
      [weakSelf doColorBoAnimatorWidthSelectdIndex:weakSelf.selectedIndexOfSheBo];
    }
    
    // 当前选中的叫码
    NSInteger indexOfAnimate = [weakSelf.itemLogicShengXiaoImageIndexes objectAtIndex:weakSelf.selectedIndexOfShengXiao].integerValue;
    
    // 第一个转盘号码
    if (weakSelf.countOfSecond >= 2 && 0 == weakSelf.selectedIndexs.count && indexOfAnimate == firstSelectedIndex.integerValue) {
      [weakSelf.selectedIndexs addObject:firstSelectedIndex];
      [weakSelf doLogicShengXiaoWinResultWidthSelectdIndex:weakSelf.selectedIndexs isFinish:NO];
      [weakSelf doShengXiaoColorBoLabelValue:weakSelf.selectedIndexs colorIndex:nil];
    }
    
    // 第二个转盘号码
    if (weakSelf.countOfSecond >= 4 && 1 == weakSelf.selectedIndexs.count && indexOfAnimate == secondSelectedIndex.integerValue) {
      [weakSelf.selectedIndexs addObject:secondSelectedIndex];
      [weakSelf doLogicShengXiaoWinResultWidthSelectdIndex:weakSelf.selectedIndexs isFinish:NO];
      [weakSelf doShengXiaoColorBoLabelValue:weakSelf.selectedIndexs colorIndex:nil];
    }
    
    // 第三个转盘号码
    if (weakSelf.countOfSecond >= 6 && 2 == weakSelf.selectedIndexs.count && indexOfAnimate == thirdSelectedIndex.integerValue) {
      [weakSelf.selectedIndexs addObject:thirdSelectedIndex];
      // 动画显示生肖号
      [weakSelf doLogicShengXiaoWinResultWidthSelectdIndex:weakSelf.selectedIndexs isFinish:YES];
      // 动画显示色波号
      [weakSelf doColorBoAnimatorWidthSelectdIndex:colorIndexs.firstObject.integerValue];
      // 显示最后结果号
      [weakSelf doShengXiaoColorBoLabelValue:weakSelf.selectedIndexs colorIndex:colorIndexs];
    }
    
    // 增加生肖下标
    if (weakSelf.selectedIndexOfShengXiao >= weakSelf.itemLogicShengXiaoImageViewArray.count - 1) {
      weakSelf.selectedIndexOfShengXiao = 0;
    } else {
      weakSelf.selectedIndexOfShengXiao ++;
    }
    
    // 增加波肖下标
    if (weakSelf.selectedIndexOfSheBo >= weakSelf.itemColorViewArray.count - 1) {
      weakSelf.selectedIndexOfSheBo = 0;
    } else {
      weakSelf.selectedIndexOfSheBo ++;
    }
    
  }];
  
}


#pragma mark 事件处理 - 转盘动画 - 生成生肖
- (void)doLogicShengXiaoWinResultWidthSelectdIndex:(NSArray<NSNumber *> *)selectedIndexs isFinish:(BOOL)isFinish
{
  // 筛选已选中的数据
  _itemLogicIconImageNormal = [NSMutableArray<NSString *> array];
  _itemLogicIconImageSelected = [NSMutableArray<NSString *> array];
  _itemLogicShengXiaoImageIndexes = [NSMutableArray<NSNumber *> array];
  _itemLogicShengXiaoImageViewArray = [NSMutableArray<UIImageView *> array];
  NSArray<NSString *> *iconImageNormal = @[ @"icon_shengxiao_1", @"icon_shengxiao_2", @"icon_shengxiao_3", @"icon_shengxiao_4",
                                            @"icon_shengxiao_5", @"icon_shengxiao_6", @"icon_shengxiao_7", @"icon_shengxiao_8",
                                            @"icon_shengxiao_9", @"icon_shengxiao_10", @"icon_shengxiao_11", @"icon_shengxiao_12" ];
  NSArray<NSString *> *iconImageSelected = @[ @"icon_shengxiao_selected_1", @"icon_shengxiao_selected_2", @"icon_shengxiao_selected_3", @"icon_shengxiao_selected_4",
                                              @"icon_shengxiao_selected_5", @"icon_shengxiao_selected_6", @"icon_shengxiao_selected_7", @"icon_shengxiao_selected_8",
                                              @"icon_shengxiao_selected_9", @"icon_shengxiao_selected_10", @"icon_shengxiao_selected_11", @"icon_shengxiao_selected_12" ];
  for (NSInteger idx = 0; idx < self.itemShengXiaoImageViewArray.count; idx ++) {
    NSNumber *idxObj = [NSNumber numberWithInteger:idx];
    if ([selectedIndexs containsObject:idxObj]) {
      UIImageView *iconImageView = [self.itemShengXiaoImageViewArray objectAtIndex:idx];
      [iconImageView setImage:[UIImage imageNamed:iconImageSelected[idx]]];
      continue;
    } else {
      UIImageView *iconImageView = [self.itemShengXiaoImageViewArray objectAtIndex:idx];
      [iconImageView setImage:[UIImage imageNamed:iconImageNormal[idx]]];
      //
      [self.itemLogicIconImageNormal addObject:iconImageNormal[idx]];
      [self.itemLogicIconImageSelected addObject:iconImageSelected[idx]];
      [self.itemLogicShengXiaoImageIndexes addObject:[NSNumber numberWithInteger:idx]];
      [self.itemLogicShengXiaoImageViewArray addObject:self.itemShengXiaoImageViewArray[idx]];
    }
  }
 
  if (isFinish) {
    [self.countDownTimer destoryTimer];
    [self.countDownObject destoryTimer];
    return;
  }
}


#pragma mark 事件处理 - 转盘动画 - 生成生肖
- (void)doShengXiaoAnimatorWidthSelectdIndex:(NSInteger)selectedIndex
                         itemIconImageNormal:(NSArray<NSString *> *)itemIconImageNormalList
                       itemIconImageSelected:(NSArray<NSString *> *)itemIconImageSelectedList
                      itemIconImageViewArray:(NSArray<UIImageView *> *)itemIconImageViewList
{
  for (NSInteger idx = 0; idx < itemIconImageViewList.count; idx ++) {
    UIImageView *iconImageView = [itemIconImageViewList objectAtIndex:idx];
    if (selectedIndex != idx) {
      [iconImageView setImage:[UIImage imageNamed:itemIconImageNormalList[idx]]];
    } else {
      [iconImageView setImage:[UIImage imageNamed:itemIconImageSelectedList[idx]]];
    }
  }
}


#pragma mark 事件处理 - 转盘动画 - 生肖色波
- (void)doColorBoAnimatorWidthSelectdIndex:(NSInteger)selectedIndex
{
  for (NSInteger idx = 0; idx < self.itemColorViewArray.count; idx ++) {
    UIView *colorView = [self.itemColorViewArray objectAtIndex:idx];
    if (selectedIndex != idx) {
      [colorView.layer setBorderWidth:0.0f];
      [colorView.layer setBorderColor:COLOR_HEXSTRING(@"#F1DD4D").CGColor];
    } else {
      [colorView.layer setBorderWidth:1.2f];
      [colorView.layer setBorderColor:COLOR_HEXSTRING(@"#F1DD4D").CGColor];
    }
  }
}


#pragma mark 事件处理 - 转盘动画 - 结果显示
- (void)doShengXiaoColorBoLabelValue:(NSArray<NSNumber *> *)shengXiaoIndexs colorIndex:(NSArray<NSNumber *> *)colorIndexs
{
  [self.buttonConfirm setHidden:YES];
  [self.shengXiaoLabel setHidden:NO];
  [self.colorBoLabel setHidden:NO];
  
  if (shengXiaoIndexs.count > 0) {
    NSMutableArray<NSString *> *shengXiaoNames = [NSMutableArray<NSString *> array];
    for (NSInteger idx = 0; idx < shengXiaoIndexs.count; idx ++) {
      NSInteger index = [shengXiaoIndexs objectAtIndex:idx].integerValue;
      NSString *shengXiaoName = [SHENGXIAO_PLAY_CLASS_LIU_HE_CAI_ARRAY objectAtIndex:index];
      [shengXiaoNames addObject:shengXiaoName];
    }
    NSString *shengXiaoValue = [shengXiaoNames componentsJoinedByString:@" "];
    [self.shengXiaoLabel setText:shengXiaoValue];
  }
  
  if (colorIndexs.count > 0) {
    NSArray<NSString *> *colors = @[ @"红波", @"绿波", @"蓝波", @"红波", @"绿波", @"蓝波", @"红波", @"绿波", @"蓝波" ];
    NSMutableArray<NSString *> *colorNames = [NSMutableArray<NSString *> array];
    for (NSInteger idx = 0; idx < colorIndexs.count; idx ++) {
      NSInteger index = [colorIndexs objectAtIndex:idx].integerValue;
      NSString *colorName = [colors objectAtIndex:index];
      [colorNames addObject:colorName];
    }
    NSString *colorNameValue = [colorNames componentsJoinedByString:@" "];
    [self.colorBoLabel setText:colorNameValue];
  }
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    _countOfSecond = 0;
    _selectedIndexOfSheBo = 0;
    _selectedIndexOfShengXiao = 0;
    _selectedIndexs = [NSMutableArray<NSNumber *> array];
  }
  return self;
}


#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  // 设置背景颜色
  [self.view setBackgroundColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT];
  
  // 创建主要界面
  [self createMainUIView];
  
  // 波肖转盘
  WEAKSELF(weakSelf);
  [CFCAppGameUtil getCurrentIssueNumber:self.view then:^(NSString * _Nonnull year, NSString * _Nonnull issue, NSString * _Nonnull datetime) {
    
    weakSelf.currentIssue = issue;
    
    [self.currentIssueLabel setText:[NSString stringWithFormat:@"%@年第%@期", year, issue]];
    
    if (APPINFORMATION.boXiaoZhuanPanIssue.integerValue > 0
        && APPINFORMATION.boXiaoZhuanPanIssue.integerValue >= issue.integerValue) {
      
      NSString *boXiaoZhuanPanResult = APPINFORMATION.boXiaoZhuanPanResult;
      NSCharacterSet *character = [NSCharacterSet characterSetWithCharactersInString:@"||"];
      NSArray<NSString *> *split = [boXiaoZhuanPanResult componentsSeparatedByCharactersInSet:character];
      NSArray<NSString *> *randColors = split.count > 0 ? [split[0] split:@","] : @[@""];
      NSArray<NSString *> *randShengXiao = split.count > 1 ? [split[1] split:@","] : @[@""];
      CFCLog(@"[色波 => %@] [生肖=>%@]", split[0], split[1]);
      
      NSMutableArray<NSNumber *> *randColorNumbers = [NSMutableArray<NSNumber *> array];
      NSMutableArray<NSNumber *> *randShengXiaoNumbers = [NSMutableArray<NSNumber *> array];
      for (NSInteger idx = 0; idx < randColors.count; idx ++) {
        NSString *value = [randColors objectAtIndex:idx];
        [randColorNumbers addObject:[NSNumber numberWithInteger:value.integerValue]];
      }
      for (NSInteger idx = 0; idx < randShengXiao.count; idx ++) {
        NSString *value = [randShengXiao objectAtIndex:idx];
        [randShengXiaoNumbers addObject:[NSNumber numberWithInteger:value.integerValue]];
      }

      [self doLogicShengXiaoWinResultWidthSelectdIndex:randShengXiaoNumbers isFinish:YES];
      [self doColorBoAnimatorWidthSelectdIndex:randColorNumbers.firstObject.integerValue];
      [self doShengXiaoColorBoLabelValue:randShengXiaoNumbers colorIndex:randColorNumbers];
      
    } else {
      
      // 重置配置
      APPINFORMATION.boXiaoZhuanPanIssue = @"0";
      APPINFORMATION.boXiaoZhuanPanResult = @"";

      [weakSelf.buttonConfirm setHidden:NO];
      [weakSelf.shengXiaoLabel setHidden:YES];
      [weakSelf.colorBoLabel setHidden:YES];
      
    }
  }];
  
}


#pragma mark 创建主要界面
- (void)createMainUIView
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat heightOfHeader = CFC_AUTOSIZING_WIDTH(DISCOVER_INTRODUCE_HEADER_HEIGHT);
  CGFloat left_right_margin = margin * 1.5f;
  
  // 根容器
  UIScrollView *rootScrollView = ({
    UIScrollView *scrollView = [[UIScrollView alloc] init];
    [scrollView setShowsVerticalScrollIndicator:NO];
    [self.view addSubview:scrollView];
    
    [scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(self.view).with.offset(0.0);
      make.right.equalTo(self.view).with.offset(0.0);
      make.top.equalTo(self.view.mas_top).with.offset(0.0f);
      make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0f);
    }];
    
    scrollView;
  });
  
  // 主容器
  UIView *containerView = ({
    UIView *view = [[UIView alloc] init];
    [rootScrollView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.edges.equalTo(rootScrollView);
      make.width.equalTo(rootScrollView);
      make.height.mas_greaterThanOrEqualTo(SCREEN_HEIGHT-STATUS_NAVIGATION_BAR_HEIGHT+1.0);
    }];
    
    view;
  });
  
  // 头部介绍
  UIImageView *headerImageView = ({
    // 背景
    UIImageView *imageView = [UIImageView new];
    [containerView addSubview:imageView];
    [imageView setImage:[UIImage imageNamed:ICON_OPEN_BACKGROUND_HEADER]];
    [imageView setContentMode:UIViewContentModeScaleToFill];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(containerView.mas_top).offset(margin*1.5f);
      make.left.equalTo(containerView.mas_left).offset(left_right_margin);
      make.right.equalTo(containerView.mas_right).offset(-left_right_margin);
      make.height.mas_equalTo(heightOfHeader);
    }];
    
    // 标题
    UILabel *titleLabel = ({
      UILabel *label = [UILabel new];
      [imageView addSubview:label];
      [label setText:@"简介"];
      [label setTextAlignment:NSTextAlignmentCenter];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(imageView.mas_centerY).offset(-margin*1.0f);
        make.left.equalTo(imageView.mas_left).offset(margin*2.0f);
        make.right.equalTo(imageView.mas_right).offset(-margin*2.0f);
      }];
      
      label;
    });
    titleLabel.mas_key = @"titleLabel";
    
    // 内容
    UILabel *contentLabel = ({
      UILabel *label = [UILabel new];
      [imageView addSubview:label];
      [label setText:@"转转转！转出本期的生肖和波色，激动不如行动，赶紧来转出您心目中的生肖和波色！"];
      [label setNumberOfLines:0];
      [label setTextAlignment:NSTextAlignmentLeft];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(12.0f)]];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(imageView.mas_centerY).offset(margin*0.50f);
        make.left.equalTo(imageView.mas_left).offset(margin*2.5f);
        make.right.equalTo(imageView.mas_right).offset(-margin*2.5f);
      }];
      
      label;
    });
    contentLabel.mas_key = @"contentLabel";
    
    imageView;
  });
  headerImageView.mas_key = @"headerImageView";
  
  
  // 波肖转盘
  {
    // 临时变量
    CGFloat square_column = 4;
    CGFloat square_container_size = SCREEN_WIDTH * 0.75f;
    CGFloat square_icon_gap = margin*1.0f;
    CGFloat square_icon_size = (square_container_size - square_icon_gap * (square_column + 1)) / square_column;
    CGFloat square_button_width = square_container_size * 0.25f;
    CGFloat square_button_height = square_button_width * 0.38f;
    CGFloat square_color_width = margin*1.0f;
    CGFloat square_color_height = (square_container_size - (square_icon_size + square_icon_gap) * 2.0f) * 0.80f;
    
    
    _itemColorViewArray = [NSMutableArray<UIView *> arrayWithCapacity:9];
    _itemShengXiaoImageViewArray = [NSMutableArray<UIImageView *> arrayWithCapacity:12];
    
    
    // 容器视图
    UIView *squareContainerView = ({
      UIView *view = [[UIView alloc] init];
      [containerView addSubview:view];
      [view setBackgroundColor:COLOR_HEXSTRING(@"#555555")];
      
      [view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(containerView.mas_centerX);
        make.centerY.equalTo(containerView.mas_centerY).offset(square_container_size*0.07f);
        make.size.mas_equalTo(CGSizeMake(square_container_size, square_container_size));
      }];
      
      view;
    });
    squareContainerView.mas_key = @"squareContainerView";

    
    // 期号标题
    UILabel *currentIssueLabel = ({
      UILabel *label = [UILabel new];
      [containerView addSubview:label];
      [label setText:@"0000年第00期"];
      [label setTextAlignment:NSTextAlignmentCenter];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16.0f) weight:0.1]];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(squareContainerView.mas_centerX);
        make.bottom.equalTo(squareContainerView.mas_top).offset(-margin*1.5f);
      }];
      
      label;
    });
    self.currentIssueLabel = currentIssueLabel;
    self.currentIssueLabel.mas_key = @"currentIssueLabel";
    
    
    // 图标生肖
    NSArray<NSString *> *iconNames = @[ @"icon_shengxiao_1", @"icon_shengxiao_2", @"icon_shengxiao_3", @"icon_shengxiao_4",
                                        @"icon_shengxiao_5", @"icon_shengxiao_6", @"icon_shengxiao_7", @"icon_shengxiao_8",
                                        @"icon_shengxiao_9", @"icon_shengxiao_10", @"icon_shengxiao_11", @"icon_shengxiao_12" ];
    UIImageView *lastItemView = nil;
    for (NSInteger idx = 0; idx < iconNames.count; idx ++) {
      UIImageView *iconImageView = ({
        UIImageView *imageView = [UIImageView new];
        [squareContainerView addSubview:imageView];
        [imageView setImage:[UIImage imageNamed:iconNames[idx]]];
        [imageView setContentMode:UIViewContentModeScaleAspectFit];
        
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
          make.width.equalTo(@(square_icon_size));
          make.height.equalTo(@(square_icon_size));
          
          if (!lastItemView) {
            make.top.equalTo(squareContainerView.mas_top).offset(square_icon_gap);
            make.left.equalTo(squareContainerView.mas_left).offset(square_icon_gap);
          } else {
            if (idx < 4) {
              make.top.equalTo(lastItemView.mas_top);
              make.left.equalTo(lastItemView.mas_right).offset(square_icon_gap);
            } else if (idx < 7) {
              make.top.equalTo(lastItemView.mas_bottom).offset(square_icon_gap);
              make.right.equalTo(squareContainerView.mas_right).offset(-square_icon_gap);
            } else if (idx < 10) {
              make.top.equalTo(lastItemView.mas_top);
              make.right.equalTo(lastItemView.mas_left).offset(-square_icon_gap);
            } else {
              make.bottom.equalTo(lastItemView.mas_top).offset(-square_icon_gap);
              make.left.equalTo(lastItemView.mas_left);
            }
          }
        }];
        
        imageView;
      });
      iconImageView.mas_key = [NSString stringWithFormat:@"iconImageView%ld", idx];
      
      [_itemShengXiaoImageViewArray addObject:iconImageView];
      
      lastItemView = iconImageView;
    }
    
    
    // 色波红点
    CGFloat angle = M_PI * 2 / 9;
    NSArray<NSString *> *colors = @[ @"#C64C2F", @"#468F30", @"#469CF8", @"#C64C2F",
                                     @"#468F30", @"#469CF8", @"#C64C2F", @"#468F30",
                                     @"#469CF8" ];
    for (NSInteger idx = 0; idx < colors.count; idx ++) {
      // 色波容器
      UIView *container = [[UIView alloc] initWithFrame:CGRectMake(0, 0, square_color_width, square_color_height)];
      [squareContainerView addSubview:container];
      [container setTransform:CGAffineTransformMakeRotation(angle*idx)];
      [container mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(squareContainerView.mas_centerX);
        make.centerY.equalTo(squareContainerView.mas_centerY);
        make.width.mas_equalTo(square_color_width);
        make.height.mas_equalTo(square_color_height);
      }];
      
      // 色波按钮
      UIView *colorView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, square_color_width, square_color_width)];
      [colorView setBackgroundColor:COLOR_HEXSTRING(colors[idx])];
      [colorView addCornerRadius:square_color_width*0.5f];
      [container addSubview:colorView];
      
      [_itemColorViewArray addObject:colorView];
    }
    
    
    // 生肖结果
    UILabel *shengXiaoLabel = ({
      UILabel *label = [UILabel new];
      [squareContainerView addSubview:label];
      [label setTextAlignment:NSTextAlignmentCenter];
      [label setTextColor:COLOR_HEXSTRING(@"#E8BD4F")];
      [label setFont:[UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(squareContainerView.mas_centerX);
        make.bottom.equalTo(squareContainerView.mas_centerY).offset(margin*0.25);
      }];
      
      label;
    });
    self.shengXiaoLabel = shengXiaoLabel;
    self.shengXiaoLabel.mas_key = @"shengXiaoLabel";
    
    
    // 色波结果
    UILabel *colorBoLabel = ({
      UILabel *label = [UILabel new];
      [squareContainerView addSubview:label];
      [label setTextAlignment:NSTextAlignmentCenter];
      [label setTextColor:COLOR_HEXSTRING(@"#E8BD4F")];
      [label setFont:[UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(14.0f)]];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(squareContainerView.mas_centerX);
        make.top.equalTo(shengXiaoLabel.mas_bottom).offset(margin*0.5f);
      }];
      
      label;
    });
    self.colorBoLabel = colorBoLabel;
    self.colorBoLabel.mas_key = @"colorBoLabel";
    
    
    // 确认按钮
    UIButton *buttonConfirm = ({
      UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
      [button defaultStyleButton];
      [button.layer setBorderWidth:0.0f];
      [button setTitle:@"开始" forState:UIControlStateNormal];
      [button.titleLabel setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
      [button addTarget:self action:@selector(doLogicConfirmAction:) forControlEvents:UIControlEventTouchUpInside];
      [squareContainerView addSubview:button];
      
      [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(squareContainerView.mas_centerX);
        make.centerY.equalTo(squareContainerView.mas_centerY);
        make.width.mas_equalTo(square_button_width);
        make.height.mas_equalTo(square_button_height);
      }];
      
      button;
    });
    self.buttonConfirm = buttonConfirm;
    self.buttonConfirm.mas_key = @"buttonConfirm";
  }

  
  // 提示信息
  UILabel *tipInfoLabel = ({
    UILabel *label = [UILabel new];
    [containerView addSubview:label];
    [label setNumberOfLines:0];
    [label setText:@"小提示：每期只能进行一次波肖转盘"];
    [label setTextAlignment:NSTextAlignmentCenter];
    [label setTextColor:COLOR_HEXSTRING(@"#D58447")];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(13.0f)]];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerX.equalTo(containerView.mas_centerX);
      make.left.equalTo(containerView.mas_left).offset(margin * 1.5f);
      make.right.equalTo(containerView.mas_right).offset(-margin * 1.5f);
    }];
    
    label;
  });
  tipInfoLabel.mas_key = @"tipInfoLabel";
  
  
  // 约束完整
  CGFloat offset = IS_IPHONE_X_OR_GREATER ? margin*4.0f+TAB_BAR_DANGER_HEIGHT : margin*4.0f;
  [containerView mas_makeConstraints:^(MASConstraintMaker *make) {
    make.bottom.mas_greaterThanOrEqualTo(tipInfoLabel.mas_bottom).offset(offset);
  }];
  
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_DISCOVER_BOXIAOZHUANPAN;
}


#pragma mark -
#pragma mark Private
- (CFCBoXiaoZhuanPanTimer *)countDownTimer
{
  if(!_countDownTimer) {
    _countDownTimer = [[CFCBoXiaoZhuanPanTimer alloc] init];
  }
  return _countDownTimer;
}


- (CFCCountDownObject *)countDownObject
{
  if(!_countDownObject) {
    _countDownObject = [[CFCCountDownObject alloc] init];
  }
  return _countDownObject;
}

- (NSArray<NSNumber *> *)getRandNumberShengXiao:(NSInteger)count
{
  // 全部开奖号码
  NSMutableArray<NSNumber *> *numbers = [NSMutableArray<NSNumber *> arrayWithCapacity:12];
  for (NSInteger idx = 0; idx < 12; idx ++) {
    NSNumber *value = [NSNumber numberWithInteger:idx];
    [numbers addObject:value];
  }
  // 随机排序数组
  if ([numbers count] > 1) {
    for (NSUInteger i = [numbers count] - 1; i > 0; --i) {
      [numbers exchangeObjectAtIndex:i withObjectAtIndex:arc4random_uniform((int32_t)(i + 1))];
    }
  }
  // 获取前N数据
  if (count < numbers.count) {
    return [numbers subarrayWithRange:NSMakeRange(0, count)];
  }
  return [NSArray<NSNumber *> arrayWithArray:numbers];
}

- (NSArray<NSNumber *> *)getRandNumberColorBo:(NSInteger)count
{
  // 全部开奖号码
  NSMutableArray<NSNumber *> *numbers = [NSMutableArray<NSNumber *> arrayWithCapacity:12];
  for (NSInteger idx = 0; idx < 9; idx ++) {
    NSNumber *value = [NSNumber numberWithInteger:idx];
    [numbers addObject:value];
  }
  // 随机排序数组
  if ([numbers count] > 1) {
    for (NSUInteger i = [numbers count] - 1; i > 0; --i) {
      [numbers exchangeObjectAtIndex:i withObjectAtIndex:arc4random_uniform((int32_t)(i + 1))];
    }
  }
  // 获取前N数据
  if (count < numbers.count) {
    return [numbers subarrayWithRange:NSMakeRange(0, count)];
  }
  return [NSArray<NSNumber *> arrayWithArray:numbers];
}


- (void)dealloc
{
  [self.countDownTimer destoryTimer];
  [self.countDownObject destoryTimer];
}


@end

