//
// 寻宝 - 摇一摇
//

#import "CFCYaoYiYaoViewController.h"
#import <AVFoundation/AVFoundation.h>

@interface CFCYaoYiYaoViewController ()

@property (nonnull, nonatomic, strong) UIImageView *backgroundImageView;
@property (nonnull, nonatomic, strong) NSMutableArray<UIView *> *itemContainerArray;
@property (nonnull, nonatomic, strong) NSMutableArray<UILabel *> *itemTitleLabelArray;
@property (nonnull, nonatomic, strong) NSMutableArray<UIImageView *> *itemIconImageViewArray;

@property (nonnull, nonatomic, copy) NSString *currentIssue;

@end


@implementation CFCYaoYiYaoViewController


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    
  }
  return self;
}


#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  // 设置背景颜色
  [self.view setBackgroundColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT];
  
  // 创建主要界面
  [self createMainUIView];
  
  // 摇一摇
  WEAKSELF(weakSelf);
  [CFCAppGameUtil getCurrentIssueNumber:self.view then:^(NSString * _Nonnull year, NSString * _Nonnull issue, NSString * _Nonnull datetime) {
    
    weakSelf.currentIssue = issue;
    
    if (APPINFORMATION.yaoYiYaoIssue.integerValue > 0
        && APPINFORMATION.yaoYiYaoIssue.integerValue >= issue.integerValue) {
      
      // 组装特码
      NSString *randNumberValue = APPINFORMATION.yaoYiYaoResult;
      NSArray<NSString *> *randNumbers = [randNumberValue split:@","];
      NSArray<NSString *> *randColors = IMAGE_LIU_HE_CAI_ARRAY;
      for (NSInteger idx = 0; idx < self.itemTitleLabelArray.count; idx ++) {
        NSString *number_value = randNumbers[idx];
        NSInteger colorIndex = number_value.integerValue - 1;
        if (colorIndex < 0) {
          colorIndex = 0;
        }
        if (colorIndex >= randColors.count) {
          colorIndex = randColors.count-1;
        }

        UILabel *titleLabel = self.itemTitleLabelArray[idx];
        UIImageView *iconImageView = self.itemIconImageViewArray[idx];
        
        [iconImageView setImage:[UIImage imageNamed:randColors[colorIndex]]];
        [titleLabel setText:[NSString stringWithFormat:@"%02ld", number_value.integerValue]];
      }
      
      [self.backgroundImageView setImage:[UIImage imageNamed:@"icon_discover_yaoyiyao_result"]];
      
      // 关闭摇一摇
      [[UIApplication sharedApplication] setApplicationSupportsShakeToEdit:NO];

    } else {
      
      // 重置配置
      APPINFORMATION.yaoYiYaoIssue = @"0";
      APPINFORMATION.yaoYiYaoResult = @"";

      for (NSInteger idx = 0; idx < self.itemTitleLabelArray.count; idx ++) {
        UILabel *titleLabel = self.itemTitleLabelArray[idx];
        UIImageView *iconImageView = self.itemIconImageViewArray[idx];
        [titleLabel setHidden:YES];
        [iconImageView setHidden:YES];
      }
      
      [self.backgroundImageView setImage:[UIImage imageNamed:@"icon_discover_yaoyiyao"]];
      
      // 开始摇一摇
      [[UIApplication sharedApplication] setApplicationSupportsShakeToEdit:YES];
      [self becomeFirstResponder];
      
    }
  }];
}


#pragma mark 视图生命周期（将要消失）
- (void)viewWillDisappear:(BOOL)animated
{
  [super viewWillDisappear:animated];
  
  [self resignFirstResponder];
}


#pragma mark 创建主要界面
- (void)createMainUIView
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat backgroundImageSize = SCREEN_WIDTH * 0.60f;
  CGFloat heightOfHeader = CFC_AUTOSIZING_WIDTH(DISCOVER_INTRODUCE_HEADER_HEIGHT);
  CGFloat left_right_margin = margin * 1.5f;
  
  // 根容器
  UIScrollView *rootScrollView = ({
    UIScrollView *scrollView = [[UIScrollView alloc] init];
    [scrollView setShowsVerticalScrollIndicator:NO];
    [self.view addSubview:scrollView];
    
    [scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(self.view).with.offset(0.0);
      make.right.equalTo(self.view).with.offset(0.0);
      make.top.equalTo(self.view.mas_top).with.offset(0.0f);
      make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0f);
    }];
    
    scrollView;
  });
  
  // 主容器
  UIView *containerView = ({
    UIView *view = [[UIView alloc] init];
    [rootScrollView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.edges.equalTo(rootScrollView);
      make.width.equalTo(rootScrollView);
      make.height.mas_greaterThanOrEqualTo(SCREEN_HEIGHT-STATUS_NAVIGATION_BAR_HEIGHT+1.0);
    }];
    
    view;
  });
  
  // 头部介绍
  UIImageView *headerImageView = ({
    // 背景
    UIImageView *imageView = [UIImageView new];
    [containerView addSubview:imageView];
    [imageView setImage:[UIImage imageNamed:ICON_OPEN_BACKGROUND_HEADER]];
    [imageView setContentMode:UIViewContentModeScaleToFill];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(containerView.mas_top).offset(margin*1.5f);
      make.left.equalTo(containerView.mas_left).offset(left_right_margin);
      make.right.equalTo(containerView.mas_right).offset(-left_right_margin);
      make.height.mas_equalTo(heightOfHeader);
    }];
    
    // 标题
    UILabel *titleLabel = ({
      UILabel *label = [UILabel new];
      [imageView addSubview:label];
      [label setText:@"简介"];
      [label setTextAlignment:NSTextAlignmentCenter];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(imageView.mas_centerY).offset(-margin*1.0f);
        make.left.equalTo(imageView.mas_left).offset(margin*2.0f);
        make.right.equalTo(imageView.mas_right).offset(-margin*2.0f);
      }];
      
      label;
    });
    titleLabel.mas_key = @"titleLabel";
    
    // 内容
    UILabel *contentLabel = ({
      UILabel *label = [UILabel new];
      [imageView addSubview:label];
      [label setText:@"试试您的手气到底有多准！只要摇一摇，就能算出专属您的本期特码！"];
      [label setNumberOfLines:0];
      [label setTextAlignment:NSTextAlignmentLeft];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(12.0f)]];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(imageView.mas_centerY).offset(margin*0.50f);
        make.left.equalTo(imageView.mas_left).offset(margin*2.5f);
        make.right.equalTo(imageView.mas_right).offset(-margin*2.5f);
      }];
      
      label;
    });
    contentLabel.mas_key = @"contentLabel";
    
    imageView;
  });
  headerImageView.mas_key = @"headerImageView";
  
  // 背景图片
  UIImageView *backgroundImageView = ({
    UIImageView *imageView = [UIImageView new];
    [containerView addSubview:imageView];
    [imageView setContentMode:UIViewContentModeScaleAspectFit];
    [imageView setImage:[UIImage imageNamed:@"icon_discover_yaoyiyao"]];
    
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerX.equalTo(containerView.mas_centerX);
      make.centerY.equalTo(containerView.mas_centerY);
      make.width.equalTo(@(backgroundImageSize));
      make.height.equalTo(@(backgroundImageSize));
    }];
    
    imageView;
  });
  self.backgroundImageView = backgroundImageView;
  self.backgroundImageView.mas_key = @"backgroundImageView";
  
  // 本期特码
  {
    // 开奖结果
    NSInteger colum = 3;
    CGFloat left_right_gap = backgroundImageSize * 0.18f;
    CGFloat itemMargin = backgroundImageSize * 0.08f;
    CGFloat itemWidth = (backgroundImageSize - left_right_gap*2.0f - itemMargin*(colum-1)) / colum;
    CGFloat itemHeight = itemWidth * 1.0f;
    CGFloat imageSize = itemWidth;
    UIColor *autoNumbeColor = COLOR_SYSTEM_MAIN_FONT_DEFAULT;
    UIFont *autoNumberFont = [UIFont fontWithName:@"NotoMono" size:CFC_AUTOSIZING_FONT(14)];
    
    _itemTitleLabelArray = [NSMutableArray array];
    _itemIconImageViewArray = [NSMutableArray array];
    _itemContainerArray = [NSMutableArray array];
    
    UIView *lastItemView = nil;
    for (int i = 0; i < colum; i ++) {
      // 容器
      UIView *itemView = ({
        UIView *itemContainerView = [[UIView alloc] init];
        [backgroundImageView addSubview:itemContainerView];
        [itemContainerView mas_remakeConstraints:^(MASConstraintMaker *make) {
          make.width.equalTo(@(itemWidth));
          make.height.equalTo(@(itemHeight));
          
          if (!lastItemView) {
            make.centerY.equalTo(backgroundImageView.mas_centerY);
            make.left.equalTo(backgroundImageView.mas_centerX).offset(-itemWidth*1.5-itemMargin);
          } else {
            make.top.equalTo(lastItemView.mas_top);
            make.left.equalTo(lastItemView.mas_right).offset(itemMargin);
          }
        }];
        itemContainerView.mas_key = [NSString stringWithFormat:@"itemContainerView%d",i];
        
        // 图片
        UIImageView *iconImageView = ({
          UIImageView *imageView = [UIImageView new];
          [itemContainerView addSubview:imageView];
          [imageView setContentMode:UIViewContentModeScaleAspectFit];
          
          [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(itemContainerView.mas_top).offset(0.0f);
            make.centerX.equalTo(itemContainerView.mas_centerX).offset(0.0f);
            make.height.equalTo(@(imageSize));
            make.width.equalTo(@(imageSize));
          }];
          
          imageView;
        });
        iconImageView.mas_key = [NSString stringWithFormat:@"iconImageView%d", i];
        
        // 号码
        UILabel *numberLabel = ({
          UILabel *label = [UILabel new];
          [itemContainerView addSubview:label];
          [label setFont:autoNumberFont];
          [label setTextColor:autoNumbeColor];
          [label setTextAlignment:NSTextAlignmentLeft];
          
          [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(iconImageView.mas_top).offset(imageSize*0.22f);
            make.left.equalTo(itemContainerView.mas_left).offset(imageSize*0.25);
          }];
          
          label;
        });
        numberLabel.mas_key = [NSString stringWithFormat:@"numberLabel%d", i];
        
        // 保存控件
        [_itemTitleLabelArray addObject:numberLabel];
        [_itemIconImageViewArray addObject:iconImageView];
        [_itemContainerArray addObject:itemContainerView];
        
        itemContainerView;
      });
      
      lastItemView = itemView;
    }
  }
  
  // 提示信息
  UILabel *tipInfoLabel = ({
    UILabel *label = [UILabel new];
    [containerView addSubview:label];
    [label setNumberOfLines:0];
    [label setText:@"小提示：每期只能进行一次幸运摇一摇"];
    [label setTextAlignment:NSTextAlignmentCenter];
    [label setTextColor:COLOR_HEXSTRING(@"#D58447")];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(13.0f)]];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerX.equalTo(containerView.mas_centerX);
      make.left.equalTo(containerView.mas_left).offset(margin * 1.5f);
      make.right.equalTo(containerView.mas_right).offset(-margin * 1.5f);
    }];
    
    label;
  });
  tipInfoLabel.mas_key = @"tipInfoLabel";
  
  // 约束完整
  CGFloat offset = IS_IPHONE_X_OR_GREATER ? margin*4.0f+TAB_BAR_DANGER_HEIGHT : margin*4.0f;
  [containerView mas_makeConstraints:^(MASConstraintMaker *make) {
    make.bottom.mas_greaterThanOrEqualTo(tipInfoLabel.mas_bottom).offset(offset);
  }];
  
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_DISCOVER_YAOYIYAO;
}


#pragma mark - ShakeToEdit 摇动手机之后的回调方法

- (void) motionBegan:(UIEventSubtype)motion withEvent:(UIEvent *)event
{
  // 检测到摇动开始
  if (motion == UIEventSubtypeMotionShake) {
    CFCLog(@"检测到摇动开始");
    if (APPINFORMATION.yaoYiYaoIssue.integerValue > 0
        && APPINFORMATION.yaoYiYaoIssue.integerValue >= self.currentIssue.integerValue) {
      
    } else {
      AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    }
  }
}

- (void) motionCancelled:(UIEventSubtype)motion withEvent:(UIEvent *)event
{
  // 摇动取消
  CFCLog(@"摇动取消");
}

- (void) motionEnded:(UIEventSubtype)motion withEvent:(UIEvent *)event
{
  // 摇动结束
  if (event.subtype == UIEventSubtypeMotionShake) {
    CFCLog(@"摇动结束");
    if (APPINFORMATION.yaoYiYaoIssue.integerValue > 0
        && APPINFORMATION.yaoYiYaoIssue.integerValue >= self.currentIssue.integerValue) {
      
    } else {
      // 设置震动
      AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
      
      // 本期特码
      [self doLogicYaoYiYaoAction];
    }
  }
}

- (void)doLogicYaoYiYaoAction
{
  [self.backgroundImageView setImage:[UIImage imageNamed:@"icon_discover_yaoyiyao_result"]];
  
  // 随机开奖号码
  NSArray<NSString *> *randNumbers = [CFCAppGameUtil getRandNumberResult:3];
  NSString *rangNumberValue = [randNumbers componentsJoinedByString:@","];
  NSArray<NSString *> *randColors = IMAGE_LIU_HE_CAI_ARRAY;
  for (NSInteger idx = 0; idx < self.itemTitleLabelArray.count; idx ++) {
    NSString *number_value = randNumbers[idx];
    NSInteger colorIndex = number_value.integerValue - 1;
    if (colorIndex < 0) {
      colorIndex = 0;
    }
    if (colorIndex >= randColors.count) {
      colorIndex = randColors.count-1;
    }
    
    UILabel *titleLabel = self.itemTitleLabelArray[idx];
    UIImageView *iconImageView = self.itemIconImageViewArray[idx];
    
    [titleLabel setHidden:NO];
    [iconImageView setHidden:NO];
    
    [iconImageView setImage:[UIImage imageNamed:randColors[colorIndex]]];
    [titleLabel setText:[NSString stringWithFormat:@"%02ld", number_value.integerValue]];
  }
  
  // 保存当前期结果
  APPINFORMATION.yaoYiYaoIssue = self.currentIssue;
  APPINFORMATION.yaoYiYaoResult = rangNumberValue;
}

@end

