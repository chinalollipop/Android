//
// 寻宝 - 生肖卡牌
//

#import "CFCShengXiaoKaViewController.h"
#import "CFCShengXiaoKaModel.h"


@interface CFCShengXiaoKaViewController ()

@property (nonnull, nonatomic, strong) NSMutableArray<UILabel *> *itemTitleLabelArray;
@property (nonnull, nonatomic, strong) NSMutableArray<UIImageView *> *itemIconImageViewArray;
@property (nonnull, nonatomic, strong) NSMutableArray<UIImageView *> *itemCoverImageViewArray;
@property (nonnull, nonatomic, strong) NSMutableArray<UIView *> *itemContainerArray;
@property (nonnull, nonatomic, strong) NSMutableArray<CFCShengXiaoKaModel *> *itemDataArray;

@property (nonatomic, copy) NSString *currentIssue;

@end

@implementation CFCShengXiaoKaViewController


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    
  }
  return self;
}


#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  WEAKSELF(weakSelf);
  
  // 设置背景颜色
  [self.view setBackgroundColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT];
  
  // 创建主要界面
  [self createMainUIView];
  
  // 是否重围结果
  [CFCAppGameUtil getCurrentIssueNumber:self.view then:^(NSString * _Nonnull year, NSString * _Nonnull issue, NSString * _Nonnull datetime) {
    
    weakSelf.currentIssue = issue;
    
    if (APPINFORMATION.shengXiaoKaIssue.integerValue > 0
        && APPINFORMATION.shengXiaoKaIssue.integerValue >= issue.integerValue) {
      
      NSString *randNumberValue = APPINFORMATION.shengXiaoKaResult;
      NSArray<NSString *> *randShengXiao = [randNumberValue split:@","];
      NSArray<NSString *> *randShengXiaoImage = [CFCAppGameUtil getShengXiaoImageNameByNames:randShengXiao];

      // 创建数据模型
      self->_itemDataArray = [NSMutableArray array];
      for (NSInteger idx = 0; idx < 12; idx ++) {
        CFCShengXiaoKaModel *itemModel = [CFCShengXiaoKaModel new];
        if (idx < randShengXiao.count) {
          [itemModel setName:randShengXiao[idx]];
          [itemModel setImageUrl:randShengXiaoImage[idx]];
          [itemModel setImageCoverUrl:ICON_SHENGXIAO_COVER];
          [itemModel setIsSelected:NO];
          [itemModel setIsShow:YES];
        } else {
          [itemModel setName:@""];
          [itemModel setImageUrl:@""];
          [itemModel setImageCoverUrl:ICON_SHENGXIAO_COVER];
          [itemModel setIsSelected:NO];
          [itemModel setIsShow:NO];
        }
        [self->_itemDataArray addObject:itemModel];
      }
      
      // 更新刷新界面
      for (NSInteger idx = 0; idx < self.itemDataArray.count; idx ++) {
        UIView *itemContainerView = [self.itemContainerArray objectAtIndex:idx];
        if (idx < 3) {
          CFCShengXiaoKaModel *itemModel = [self.itemDataArray objectAtIndex:idx];
          UILabel *itemLabel = [self.itemTitleLabelArray objectAtIndex:idx];
          UIImageView *itemImageView = [self.itemIconImageViewArray objectAtIndex:idx];
          UIImageView *itemcCoverImageView = [self.itemCoverImageViewArray objectAtIndex:idx];
          [itemLabel setText:itemModel.name];
          [itemImageView setImage:[UIImage imageNamed:itemModel.imageUrl]];
          [itemcCoverImageView removeFromSuperview];
        } else {
          [itemContainerView setHidden:YES];
        }
      }
      
    } else {
      
      APPINFORMATION.shengXiaoKaIssue = @"0";
      APPINFORMATION.shengXiaoKaResult = @"";
      
      NSArray<NSString *> *randShengXiao = [CFCAppGameUtil getRandShengXiaoNames:12];
      NSArray<NSString *> *randShengXiaoImage = [CFCAppGameUtil getShengXiaoImageNameByNames:randShengXiao];
     
      // 创建数据模型
      self->_itemDataArray = [NSMutableArray array];
      for (NSInteger idx = 0; idx < 12; idx ++) {
        CFCShengXiaoKaModel *itemModel = [CFCShengXiaoKaModel new];
        if (idx < randShengXiao.count) {
          [itemModel setName:randShengXiao[idx]];
          [itemModel setImageUrl:randShengXiaoImage[idx]];
          [itemModel setImageCoverUrl:ICON_SHENGXIAO_COVER];
          [itemModel setIsSelected:NO];
          [itemModel setIsShow:YES];
        } else {
          [itemModel setName:@""];
          [itemModel setImageUrl:@""];
          [itemModel setImageCoverUrl:ICON_SHENGXIAO_COVER];
          [itemModel setIsSelected:NO];
          [itemModel setIsShow:NO];
        }
        [self->_itemDataArray addObject:itemModel];
      }
      
      // 更新刷新界面
      for (NSInteger idx = 0; idx < self.itemDataArray.count; idx ++) {
        CFCShengXiaoKaModel *itemModel = [self.itemDataArray objectAtIndex:idx];
        UILabel *itemLabel = [self.itemTitleLabelArray objectAtIndex:idx];
        UIImageView *itemImageView = [self.itemIconImageViewArray objectAtIndex:idx];
        UIImageView *itemcCoverImageView = [self.itemCoverImageViewArray objectAtIndex:idx];
        UIView *itemContainerView = [self.itemContainerArray objectAtIndex:idx];
        [itemLabel setText:itemModel.name];
        [itemImageView setImage:[UIImage imageNamed:itemModel.imageUrl]];
        [itemcCoverImageView setHidden:NO];
        [itemContainerView setHidden:NO];
      }
      
    }
  }];
}


#pragma mark 创建主要界面
- (void)createMainUIView
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat heightOfHeader = CFC_AUTOSIZING_WIDTH(DISCOVER_INTRODUCE_HEADER_HEIGHT);
  CGFloat left_right_margin = margin * 1.5f;
  
  // 根容器
  UIScrollView *rootScrollView = ({
    UIScrollView *scrollView = [[UIScrollView alloc] init];
    [scrollView setShowsVerticalScrollIndicator:NO];
    [self.view addSubview:scrollView];
    
    [scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(self.view).with.offset(0.0);
      make.right.equalTo(self.view).with.offset(0.0);
      make.top.equalTo(self.view.mas_top).with.offset(0.0f);
      make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0f);
    }];
    
    scrollView;
  });
  
  // 主容器
  UIView *containerView = ({
    UIView *view = [[UIView alloc] init];
    [rootScrollView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.edges.equalTo(rootScrollView);
      make.width.equalTo(rootScrollView);
      make.height.mas_greaterThanOrEqualTo(SCREEN_HEIGHT-STATUS_NAVIGATION_BAR_HEIGHT+1.0);
    }];
    
    view;
  });
  
  // 头部介绍
  UIImageView *headerImageView = ({
    // 背景
    UIImageView *imageView = [UIImageView new];
    [containerView addSubview:imageView];
    [imageView setImage:[UIImage imageNamed:ICON_OPEN_BACKGROUND_HEADER]];
    [imageView setContentMode:UIViewContentModeScaleToFill];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(containerView.mas_top).offset(margin*1.5f);
      make.left.equalTo(containerView.mas_left).offset(left_right_margin);
      make.right.equalTo(containerView.mas_right).offset(-left_right_margin);
      make.height.mas_equalTo(heightOfHeader);
    }];
    
    // 标题
    UILabel *titleLabel = ({
      UILabel *label = [UILabel new];
      [imageView addSubview:label];
      [label setText:@"简介"];
      [label setTextAlignment:NSTextAlignmentCenter];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(imageView.mas_centerY).offset(-margin*1.0f);
        make.left.equalTo(imageView.mas_left).offset(margin*2.0f);
        make.right.equalTo(imageView.mas_right).offset(-margin*2.0f);
      }];
      
      label;
    });
    titleLabel.mas_key = @"titleLabel";
    
    // 内容
    UILabel *contentLabel = ({
      UILabel *label = [UILabel new];
      [imageView addSubview:label];
      [label setText:@"每期开奖前通过该工具可以快捷的查看三个隐藏在卡牌中的生肖，来试试你的财运！"];
      [label setNumberOfLines:0];
      [label setTextAlignment:NSTextAlignmentLeft];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(12.0f)]];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(imageView.mas_centerY).offset(margin*0.50f);
        make.left.equalTo(imageView.mas_left).offset(margin*2.5f);
        make.right.equalTo(imageView.mas_right).offset(-margin*2.5f);
      }];
      
      label;
    });
    contentLabel.mas_key = @"contentLabel";
    
    imageView;
  });
  headerImageView.mas_key = @"headerImageView";
  
  
  // 十二生肖卡
  UIView *lastItemView = nil;
  {
    int colum = 3;
    CGFloat left_right_gap = left_right_margin;
    CGFloat itemGap = margin * 2.5f;
    CGFloat itemWidth = (SCREEN_WIDTH - left_right_gap*2.0f - itemGap*(colum-1)) /colum;
    CGFloat itemHeight = itemWidth * 1.0f;
    CGFloat imageSize = itemWidth * 0.55;
    UIFont *autoNameFont = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(14.0f)];
    
    NSString *randNumberValue = APPINFORMATION.shengXiaoKaResult;
    NSArray<NSString *> *randShengXiao = [randNumberValue split:@","];
    NSArray<NSString *> *randShengXiaoImage = [CFCAppGameUtil getShengXiaoImageNameByNames:randShengXiao];
    if (0 == APPINFORMATION.shengXiaoKaResult.length) {
      randShengXiao = [CFCAppGameUtil getRandShengXiaoNames:12];
      randShengXiaoImage = [CFCAppGameUtil getShengXiaoImageNameByNames:randShengXiao];
    }
    
    _itemTitleLabelArray = [NSMutableArray array];
    _itemIconImageViewArray = [NSMutableArray array];
    _itemCoverImageViewArray = [NSMutableArray array];
    _itemContainerArray = [NSMutableArray array];
    _itemDataArray = [NSMutableArray array];
    
    for (NSInteger idx = 0; idx < 12; idx ++) {
      CFCShengXiaoKaModel *itemModel = [CFCShengXiaoKaModel new];
      if (idx < randShengXiao.count) {
        [itemModel setName:randShengXiao[idx]];
        [itemModel setImageUrl:randShengXiaoImage[idx]];
        [itemModel setImageCoverUrl:ICON_SHENGXIAO_COVER];
        [itemModel setIsSelected:NO];
        [itemModel setIsShow:YES];
      } else {
        [itemModel setName:@""];
        [itemModel setImageUrl:@""];
        [itemModel setImageCoverUrl:ICON_SHENGXIAO_COVER];
        [itemModel setIsSelected:NO];
        [itemModel setIsShow:NO];
      }
      [_itemDataArray addObject:itemModel];
    }
    
    for (int idx = 0; idx < _itemDataArray.count; idx ++) {
      
      CFCShengXiaoKaModel *itemModel = [_itemDataArray objectAtIndex:idx];
      
      // 容器
      UIView *itemView = ({
        UIView *itemContainerView = [[UIView alloc] init];
        [itemContainerView setTag:8000+idx];
        [containerView addSubview:itemContainerView];
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressItemView:)];
        [itemContainerView addGestureRecognizer:tapGesture];
        [itemContainerView setHidden:!itemModel.isShow];
        [itemContainerView setBackgroundColor:[UIColor whiteColor]];
        [itemContainerView mas_remakeConstraints:^(MASConstraintMaker *make) {
          make.width.equalTo(@(itemWidth));
          make.height.equalTo(@(itemHeight));
          
          if (!lastItemView) {
            make.top.equalTo(headerImageView.mas_bottom).offset(left_right_gap);
            make.left.equalTo(containerView.mas_left).offset(left_right_gap);
          } else {
            if (idx % colum == 0) {
              make.top.equalTo(lastItemView.mas_bottom).offset(itemGap);
              make.left.equalTo(containerView.mas_left).offset(left_right_gap);
            } else {
              make.top.equalTo(lastItemView.mas_top);
              make.left.equalTo(lastItemView.mas_right).offset(itemGap);
            }
          }
        }];
        itemContainerView.mas_key = [NSString stringWithFormat:@"itemContainerView%d", idx];
        
        // 图片
        UIImageView *iconImageView = ({
          UIImageView *imageView = [UIImageView new];
          [itemContainerView addSubview:imageView];
          [imageView setUserInteractionEnabled:YES];
          [imageView setContentMode:UIViewContentModeScaleAspectFit];
          [imageView setImage:[UIImage imageNamed:itemModel.imageUrl]];

          [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(itemContainerView.mas_centerX);
            make.centerY.equalTo(itemContainerView.mas_centerY);
            make.height.equalTo(@(imageSize));
            make.width.equalTo(@(imageSize));
          }];
          
          imageView;
        });
        iconImageView.mas_key = [NSString stringWithFormat:@"iconImageView%d", idx];
        
        // 标题
        UILabel *titleLabel = ({
          UILabel *label = [UILabel new];
          [itemContainerView addSubview:label];
          [label setFont:autoNameFont];
          [label setText:itemModel.name];
          [label setTextColor:COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT];
          [label setTextAlignment:NSTextAlignmentCenter];
          
          [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(itemContainerView.mas_top).offset(margin);
            make.left.equalTo(itemContainerView.mas_left).offset(margin);
          }];
          
          label;
        });
        titleLabel.mas_key = [NSString stringWithFormat:@"titleLabel%d", idx];
        
        // 图片
        UIImageView *coverImageView = ({
          UIImageView *imageView = [UIImageView new];
          [itemContainerView addSubview:imageView];
          [imageView setUserInteractionEnabled:YES];
          [imageView setContentMode:UIViewContentModeScaleAspectFit];
          [imageView setImage:[UIImage imageNamed:itemModel.imageCoverUrl]];
          
          [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(itemContainerView.mas_centerX);
            make.centerY.equalTo(itemContainerView.mas_centerY);
            make.width.equalTo(@(itemWidth));
            make.height.equalTo(@(itemHeight));
          }];
          
          imageView;
        });
        coverImageView.mas_key = [NSString stringWithFormat:@"coverImageView%d", idx];
        
        // 保存控件
        [_itemTitleLabelArray addObject:titleLabel];
        [_itemIconImageViewArray addObject:iconImageView];
        [_itemCoverImageViewArray addObject:coverImageView];
        [_itemContainerArray addObject:itemContainerView];
        
        itemContainerView;
      });
      
      lastItemView = itemView;
    }
  }
  
  
  // 约束完整
  [containerView mas_makeConstraints:^(MASConstraintMaker *make) {
    make.bottom.mas_greaterThanOrEqualTo(lastItemView.mas_bottom).offset(margin*2.0f);
  }];
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_DISCOVER_SHENGXIAOKA;
}



#pragma mark - 操作事件 - 点击事件
- (void)pressItemView:(UITapGestureRecognizer *)gesture
{
  UIView *itemView = (UIView*)gesture.view;
  
  NSUInteger index = itemView.tag - 8000;
  
  if (index >= self.itemDataArray.count) {
    CFCLog(@"数组越界，请检测代码。");
    return;
  }
  
  // 已经选中项，则直接返回
  CFCShengXiaoKaModel *itemModel = [self.itemDataArray objectAtIndex:index];
  if (itemModel.isSelected) {
    return;
  }
  
  // 显示生肖卡牌，更新数据
  UIImageView *coverImageView = [self.itemCoverImageViewArray objectAtIndex:index];
  [coverImageView removeFromSuperview];
  [itemModel setIsSelected:YES];
  
  // 计算已经显示卡牌数量
  __block NSInteger selectedCount = 0;
  __block NSMutableArray<NSString *> *selectedItemNames = [NSMutableArray<NSString *> array];
  __block NSMutableArray<CFCShengXiaoKaModel *> *selectedItemModel = [NSMutableArray<CFCShengXiaoKaModel *> array];
  [self.itemDataArray enumerateObjectsUsingBlock:^(CFCShengXiaoKaModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
    if (obj.isSelected) {
      selectedCount ++;
      [selectedItemModel addObject:obj];
      [selectedItemNames addObject:obj.name];
    }
  }];
  if (selectedCount < 3) {
    return;
  }
  
  // 更新刷新界面
  for (NSInteger idx = 0; idx < self.itemDataArray.count; idx ++) {
    UIView *itemContainerView = [self.itemContainerArray objectAtIndex:idx];
    if (idx < selectedItemModel.count) {
      CFCShengXiaoKaModel *itemModel = [selectedItemModel objectAtIndex:idx];
      UILabel *itemLabel = [self.itemTitleLabelArray objectAtIndex:idx];
      UIImageView *itemImageView = [self.itemIconImageViewArray objectAtIndex:idx];
      UIImageView *itemcCoverImageView = [self.itemCoverImageViewArray objectAtIndex:idx];
      [itemLabel setText:itemModel.name];
      [itemImageView setImage:[UIImage imageNamed:itemModel.imageUrl]];
      [itemcCoverImageView setHidden:YES];
    } else {
      [itemContainerView setHidden:YES];
    }
  }

  // 保存当前期结果
  NSString *shengXiaoValue = [selectedItemNames componentsJoinedByString:@","];
  APPINFORMATION.shengXiaoKaIssue = self.currentIssue;
  APPINFORMATION.shengXiaoKaResult = shengXiaoValue;
}


@end

