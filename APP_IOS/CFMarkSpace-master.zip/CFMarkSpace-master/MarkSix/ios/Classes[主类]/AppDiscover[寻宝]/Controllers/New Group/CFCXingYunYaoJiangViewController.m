//
// 寻宝 - 幸运摇奖
//

#import "CFCXingYunYaoJiangViewController.h"

@interface CFCXingYunYaoJiangViewController ()

@property (nonnull, nonatomic, strong) UIButton *buttonCircle;
@property (nonnull, nonatomic, strong) UIImageView *yaoJiangOnImageView;
@property (nonnull, nonatomic, strong) UIImageView *yaoJiangOffImageView;
@property (nonnull, nonatomic, strong) UIImageView *circleBoardImageView;
@property (nonnull, nonatomic, strong) UIImageView *yaoJiangHaoMaImageView;

@property (nonnull, nonatomic, strong) NSMutableArray<UILabel *> *itemNumLabelArray;
@property (nonnull, nonatomic, strong) NSMutableArray<UIImageView *> *itemImageViewArray;

@property (nonatomic, assign) NSInteger indexOfAnimate;

@end


@implementation CFCXingYunYaoJiangViewController


#pragma mark -
#pragma mark 事件处理 - 开始摇奖
- (void)doButtonCircleAction:(UIButton *)button
{
  // 开始动画
  [self startAnimaition];
  
  // 开奖结果
  [self doShowOpenResultNumbers:YES];
}

#pragma mark 事件处理 - 打开操作
- (void)pressYaoJiangOnView:(UITapGestureRecognizer *)gesture
{
  // 停止动画
  [self stopAnimaition];
}

#pragma mark 事件处理 - 关闭操作
- (void)pressYaoJiangOffView:(UITapGestureRecognizer *)gesture
{
  // 开始动画
  [self startAnimaition];
  
  // 开奖结果
  [self doShowOpenResultNumbers:YES];
}


#pragma mark -
#pragma mark 逻辑处理 - 开奖结果
- (void)doShowOpenResultNumbers:(BOOL)isShowNumber
{
  // 删除控件
  for (NSInteger idx = 0; idx < self.itemImageViewArray.count; idx ++) {
    UILabel *itemNumberLabel = self.itemNumLabelArray[idx];
    UIImageView *itemImageView = [self.itemImageViewArray objectAtIndex:idx];
    [itemNumberLabel removeFromSuperview];
    [itemImageView removeFromSuperview];
  }
  
  // 开奖结果
  {
    int colum = 8;
    CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
    CGFloat left_gap = margin * 2.5f;
    CGFloat right_gap = margin * 3.0f;
    CGFloat itemMargin = margin * 1.2f;
    CGFloat itemWidth = (SCREEN_WIDTH - margin * 2.0f - left_gap - right_gap - itemMargin*(colum-2)) / colum;
    CGFloat itemHeight = itemWidth * 1.0f;
    CGFloat imageSize = itemWidth;
    UIFont *autoNumberFont = [UIFont fontWithName:@"NotoMono" size:CFC_AUTOSIZING_FONT(14)];
    UIColor *autoNumbeColor = COLOR_SYSTEM_MAIN_FONT_DEFAULT;
    
    UIView *lastItemView = nil;
    _itemNumLabelArray = [NSMutableArray<UILabel *> array];
    _itemImageViewArray = [NSMutableArray<UIImageView *> array];
    for (int i = 0; i < colum; i ++) {
      
      // 容器
      UIView *itemView = ({
        UIView *itemContainerView = [[UIView alloc] init];
        [self.yaoJiangHaoMaImageView addSubview:itemContainerView];
        
        [itemContainerView mas_remakeConstraints:^(MASConstraintMaker *make) {
          make.width.equalTo(@(itemWidth));
          make.height.equalTo(@(itemHeight));
          
          if (i != colum - 2) {
            make.top.equalTo(self.yaoJiangHaoMaImageView.mas_centerY);
            make.left.equalTo(self.yaoJiangHaoMaImageView.mas_left).offset(-itemWidth);
          } else {
            make.top.equalTo(self.yaoJiangHaoMaImageView.mas_centerY);
            make.left.equalTo(self.yaoJiangHaoMaImageView.mas_left).offset(left_gap + itemWidth*6.0f + itemMargin*5.5f);
          }
        }];
        
        itemContainerView;
      });
      itemView.mas_key = [NSString stringWithFormat:@"itemView%d",i];
      
      // 图片
      UIImageView *iconImageView = ({
        UIImageView *imageView = [UIImageView new];
        [itemView addSubview:imageView];
        if (i != colum - 2) {
          [imageView setAlpha:0.1];
        }
        [imageView setContentMode:UIViewContentModeScaleAspectFit];
        
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
          make.top.equalTo(itemView.mas_top);
          make.centerX.equalTo(itemView.mas_centerX);
          make.height.equalTo(@(imageSize));
          make.width.equalTo(@(imageSize));
        }];
        
        imageView;
      });
      iconImageView.mas_key = [NSString stringWithFormat:@"iconImageView%d", i];
      
      // 号码
      UILabel *numberLabel = ({
        UILabel *label = [UILabel new];
        [itemView addSubview:label];
        if (i != colum - 2) {
          [label setAlpha:0.1];
        }
        [label setFont:autoNumberFont];
        [label setTextColor:autoNumbeColor];
        [label setTextAlignment:NSTextAlignmentLeft];
        
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
          make.top.equalTo(iconImageView.mas_top).offset(imageSize*0.18f);
          make.left.equalTo(itemView.mas_left).offset(imageSize*0.21);
        }];
        
        label;
      });
      numberLabel.mas_key = [NSString stringWithFormat:@"numberLabel%d", i];
      
      // 保存控件
      [_itemNumLabelArray addObject:numberLabel];
      [_itemImageViewArray addObject:iconImageView];
      
      lastItemView = itemView;
    }
    
    // 开奖号码
    NSArray<NSString *> *itemColors = IMAGE_LIU_HE_CAI_ARRAY;
    NSArray<NSString *> *itemNumber = [CFCAppGameUtil getRandNumberResult:7];
    CFCLog(@"摇奖结果 => %@", [itemNumber componentsJoinedByString:@" "]);
    for (int idx = 0; idx < self.itemImageViewArray.count; idx ++) {
      NSString *number_value = idx < itemNumber.count ? itemNumber[idx] : itemNumber.lastObject;
      NSInteger colorIndex = number_value.integerValue - 1;
      if (colorIndex < 0) {
        colorIndex = 0;
      }
      if (colorIndex >= itemColors.count) {
        colorIndex = itemColors.count-1;
      }
      UILabel *itemNumberLabel = self.itemNumLabelArray[idx];
      UIImageView *itemImageView = self.itemImageViewArray[idx];
      if (itemNumber.count == idx + 1) {
        [itemNumberLabel setText:STR_APP_TEXT_EMPTY];
        [itemImageView setImage:[UIImage imageNamed:ICON_DISCOVER_XYYJ_RESULT_PLUS]];
        [itemImageView setTransform:CGAffineTransformMakeScale(0.7f,0.7f)];
      } else {
        [itemImageView setImage:[UIImage imageNamed:itemColors[colorIndex]]];
        [itemNumberLabel setText:[NSString stringWithFormat:@"%02ld", number_value.integerValue]];
      }
    }
  }
  
  // 动画显示开奖结果
  if (isShowNumber) {
    self.indexOfAnimate = 0;
    [self showOpenResultAnimate];
  }
  
}

#pragma mark 逻辑处理 - 开奖动画
- (void)showOpenResultAnimate
{
  int colum = 8;
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat left_gap = margin * 2.5f;
  CGFloat right_gap = margin * 3.0f;
  CGFloat itemMargin = margin * 1.2f;
  CGFloat itemWidth = (SCREEN_WIDTH - margin * 2.0f - left_gap - right_gap - itemMargin*(colum-2)) / colum;
  
  CGFloat offsetX = 0;
  if (self.indexOfAnimate < 6) {
    offsetX = left_gap + itemMargin * self.indexOfAnimate + itemWidth * (self.indexOfAnimate + 1);
  } else if (self.indexOfAnimate == 6) {
    self.indexOfAnimate ++;
    [self showOpenResultAnimate];
    return;
  } else {
    offsetX = left_gap + itemMargin * (self.indexOfAnimate - 1) + itemWidth * (self.indexOfAnimate + 1);
  }
  
  WEAKSELF(weakSelf);
  UILabel *itemNumberLabel = self.itemNumLabelArray[self.indexOfAnimate];
  UIImageView *itemImageView = self.itemImageViewArray[self.indexOfAnimate];
  [UIView animateWithDuration:1.0 animations:^{
    [itemImageView setAlpha:1.0];
    [itemNumberLabel setAlpha:1.0];
    [itemImageView setTransform:CGAffineTransformMakeTranslation(offsetX, 0)];
    [itemNumberLabel setTransform:CGAffineTransformMakeTranslation(offsetX, 0)];
  } completion:^(BOOL finished) {
    weakSelf.indexOfAnimate ++;
    if (weakSelf.indexOfAnimate > 7) {
      [weakSelf stopAnimaition];
    } else {
      [weakSelf showOpenResultAnimate];
    }
  }];
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    _indexOfAnimate = 0.0f;
  }
  return self;
}


#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  // 设置背景颜色
  [self.view setBackgroundColor:COLOR_HEXSTRING(@"#F0F1EC")];
  
  // 创建主要界面
  [self createMainUIView];
  
  // 创建开奖结果
  [self doShowOpenResultNumbers:NO];
}


#pragma mark 创建主要界面
- (void)createMainUIView
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  
  
  // 根容器
  UIScrollView *rootScrollView = ({
    UIScrollView *scrollView = [[UIScrollView alloc] init];
    [scrollView setShowsVerticalScrollIndicator:NO];
    [self.view addSubview:scrollView];
    
    [scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(self.view).with.offset(0.0);
      make.right.equalTo(self.view).with.offset(0.0);
      make.top.equalTo(self.view.mas_top).with.offset(0.0f);
      make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0f);
    }];
    
    scrollView;
  });
  
  
  // 主容器
  UIView *containerView = ({
    UIView *view = [[UIView alloc] init];
    [rootScrollView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.edges.equalTo(rootScrollView);
      make.width.equalTo(rootScrollView);
      make.height.mas_greaterThanOrEqualTo(SCREEN_HEIGHT-STATUS_NAVIGATION_BAR_HEIGHT+1.0);
    }];
    
    view;
  });
  
  
  // 头部介绍
  UIImageView *headerImageView = ({
    CGFloat heightOfHeader = SCREEN_WIDTH*0.116f;
    UIImageView *imageView = [UIImageView new];
    [containerView addSubview:imageView];
    [imageView setUserInteractionEnabled:YES];
    [imageView setImage:[UIImage imageNamed:@"icon_discover_xyyj_headerimage"]];
    [imageView setContentMode:UIViewContentModeScaleToFill];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(containerView.mas_top);
      make.left.equalTo(containerView.mas_left);
      make.right.equalTo(containerView.mas_right);
      make.height.mas_equalTo(heightOfHeader);
    }];
    
    imageView;
  });
  headerImageView.mas_key = @"headerImageView";
  
  
  // 幸运号码 - 动画区域
  UIImageView *circleBackgroundImageView = ({
    CGFloat heightOfHeader = SCREEN_WIDTH*0.59f;
    UIImageView *imageView = [UIImageView new];
    [containerView addSubview:imageView];
    [imageView setUserInteractionEnabled:YES];
    [imageView setImage:[UIImage imageNamed:@"icon_discover_xyyj_circle_background"]];
    [imageView setContentMode:UIViewContentModeScaleToFill];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(containerView.mas_bottom).multipliedBy(0.3f);
      make.left.equalTo(containerView.mas_left);
      make.right.equalTo(containerView.mas_right);
      make.height.mas_equalTo(heightOfHeader);
    }];
    
    imageView;
  });
  circleBackgroundImageView.mas_key = @"circleBackgroundImageView";
  

  // 幸运号码 - 动画区域 - 抽奖转盘
  UIImageView *circleBoardImageView = ({
    CGFloat sizeOfBoard = SCREEN_WIDTH * 0.42f;
    UIImageView *imageView = [UIImageView new];
    [circleBackgroundImageView addSubview:imageView];
    [imageView setUserInteractionEnabled:YES];
    [imageView setImage:[UIImage imageNamed:@"icon_discover_xyyj_circle_board"]];
    [imageView setContentMode:UIViewContentModeScaleToFill];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerX.equalTo(circleBackgroundImageView.mas_centerX);
      make.centerY.equalTo(circleBackgroundImageView.mas_centerY);
      make.size.mas_equalTo(CGSizeMake(sizeOfBoard, sizeOfBoard));
    }];
    
    imageView;
  });
  self.circleBoardImageView = circleBoardImageView;
  self.circleBoardImageView.mas_key = @"circleBoardImageView";
  
  
  // 幸运号码 - 动画区域 - 摇号按钮
  UIButton *buttonCircle = ({
    CGFloat button_size = SCREEN_WIDTH * 0.15f;
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button.titleLabel setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
    [button setBackgroundImage:[UIImage imageNamed:@"icon_discover_xyyj_circle_button"]
                      forState:UIControlStateNormal];
    [button setBackgroundImage:[UIImage imageNamed:@"icon_discover_xyyj_circle_button"]
                      forState:UIControlStateHighlighted];
    [button addTarget:self action:@selector(doButtonCircleAction:) forControlEvents:UIControlEventTouchUpInside];
    [circleBackgroundImageView addSubview:button];
    
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerX.equalTo(circleBoardImageView.mas_centerX);
      make.centerY.equalTo(circleBoardImageView.mas_centerY);
      make.width.mas_equalTo(button_size);
      make.height.mas_equalTo(button_size);
    }];
    
    button;
  });
  self.buttonCircle = buttonCircle;
  self.buttonCircle.mas_key = @"buttonCircle";
  
  
  // 幸运号码 - 动画区域 - 开奖按钮 - 右关
  UIImageView *yaoJiangOffImageView = ({
    CGFloat width = SCREEN_WIDTH * 0.06f;
    CGFloat height = width * 2.57f;
    UIImageView *imageView = [UIImageView new];
    [circleBackgroundImageView addSubview:imageView];
    [imageView setUserInteractionEnabled:YES];
    [imageView setImage:[UIImage imageNamed:@"icon_discover_xyyj_button_off"]];
    [imageView setContentMode:UIViewContentModeScaleToFill];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressYaoJiangOffView:)];
    [imageView addGestureRecognizer:tapGesture];
    
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(circleBackgroundImageView.mas_centerY).offset(-height*0.2f);
      make.centerX.equalTo(circleBackgroundImageView.mas_right).multipliedBy(0.82f);
      make.size.mas_equalTo(CGSizeMake(width, height));
    }];
    
    imageView;
  });
  self.yaoJiangOffImageView = yaoJiangOffImageView;
  self.yaoJiangOffImageView.mas_key = @"yaoJiangOffImageView";
  
  
  // 幸运号码 - 动画区域 - 开奖按钮 - 右开
  UIImageView *yaoJiangOnImageView = ({
    CGFloat width = SCREEN_WIDTH * 0.06f;
    CGFloat height = width * 2.57f;
    UIImageView *imageView = [UIImageView new];
    [circleBackgroundImageView addSubview:imageView];
    [imageView setHidden:YES];
    [imageView setUserInteractionEnabled:YES];
    [imageView setImage:[UIImage imageNamed:@"icon_discover_xyyj_button_on"]];
    [imageView setContentMode:UIViewContentModeScaleToFill];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressYaoJiangOnView:)];
    [imageView addGestureRecognizer:tapGesture];
    
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(circleBackgroundImageView.mas_centerY).offset(height*0.25f);
      make.centerX.equalTo(circleBackgroundImageView.mas_right).multipliedBy(0.82f);
      make.size.mas_equalTo(CGSizeMake(width, height));
    }];
    
    imageView;
  });
  self.yaoJiangOnImageView = yaoJiangOnImageView;
  self.yaoJiangOnImageView.mas_key = @"yaoJiangOnImageView";
  
  
  // 幸运号码 - 结果区域
  UIImageView *yaoJiangHaoMaImageView = ({
    // 背景
    CGFloat widthOfContent = SCREEN_WIDTH - margin * 2.0f;
    CGFloat heightOfContent = widthOfContent * 0.38f;
    UIImageView *contentImageView = [UIImageView new];
    [containerView addSubview:contentImageView];
    [contentImageView.layer setMasksToBounds:YES];
    [contentImageView setImage:[UIImage imageNamed:@"icon_discover_xyyj_background"]];
    [contentImageView setContentMode:UIViewContentModeScaleToFill];
    [contentImageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(containerView.mas_centerY);
      make.centerX.equalTo(containerView.mas_centerX);
      make.width.mas_equalTo(widthOfContent);
      make.height.mas_equalTo(heightOfContent);
    }];
    
    // 标题
    CGFloat widthOfTitle = widthOfContent * 0.33f;
    CGFloat heightOfTitle = widthOfTitle * 0.224f;
    UIImageView *titleImageView = [UIImageView new];
    [contentImageView addSubview:titleImageView];
    [titleImageView setImage:[UIImage imageNamed:@"icon_discover_xyyj_background_title"]];
    [titleImageView setContentMode:UIViewContentModeScaleToFill];
    [titleImageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(contentImageView.mas_top).offset(heightOfContent*0.15f);
      make.centerX.equalTo(contentImageView.mas_centerX);
      make.width.mas_equalTo(widthOfTitle);
      make.height.mas_equalTo(heightOfTitle);
    }];
    
    contentImageView;
  });
  self.yaoJiangHaoMaImageView = yaoJiangHaoMaImageView;
  self.yaoJiangHaoMaImageView.mas_key = @"yaoJiangHaoMaImageView";
  
  
  // 提示信息
  UILabel *tipInfoLabel = ({
    UILabel *label = [UILabel new];
    [containerView addSubview:label];
    [label setText:@"幸运摇奖只用于模拟开奖，点击摇奖，系统将自动摇出一组幸运号码。"];
    [label setNumberOfLines:0];
    [label setTextAlignment:NSTextAlignmentCenter];
    [label setTextColor:COLOR_HEXSTRING(@"#D58447")];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(13.0f)]];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerX.equalTo(containerView.mas_centerX);
      make.left.equalTo(containerView.mas_left).offset(margin * 1.5f);
      make.right.equalTo(containerView.mas_right).offset(-margin * 1.5f);
    }];
    
    label;
  });
  tipInfoLabel.mas_key = @"tipInfoLabel";
  
  
  // 约束完整
  CGFloat offset = IS_IPHONE_X_OR_GREATER ? margin*4.0f+TAB_BAR_DANGER_HEIGHT : margin*4.0f;
  [containerView mas_makeConstraints:^(MASConstraintMaker *make) {
    make.bottom.mas_greaterThanOrEqualTo(tipInfoLabel.mas_bottom).offset(offset);
  }];
  
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_DISCOVER_XINGYUNYAOJIANG;
}


#pragma mark 抽奖动画 - 开始
- (void)startAnimaition
{
  [self.yaoJiangOnImageView setHidden:NO];
  [self.yaoJiangOffImageView setHidden:YES];
  [self.buttonCircle setUserInteractionEnabled:NO];
  [self.yaoJiangOnImageView setUserInteractionEnabled:NO];
  [self.yaoJiangOffImageView setUserInteractionEnabled:NO];
  
  [self.circleBoardImageView.layer removeAnimationForKey:@"AnimationKey"];
  
  CABasicAnimation* rotationAnimation;
  rotationAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
  rotationAnimation.repeatCount = MAXFLOAT;
  rotationAnimation.duration = 0.7f;
  rotationAnimation.cumulative = YES;
  rotationAnimation.removedOnCompletion = NO;
  rotationAnimation.fillMode = kCAFillModeForwards;
  rotationAnimation.toValue = [NSNumber numberWithFloat:M_PI*2.0f];
  [self.circleBoardImageView.layer setAnchorPoint:CGPointMake(0.5, 0.5)];
  [self.circleBoardImageView.layer addAnimation:rotationAnimation forKey:@"AnimationKey"];
}


#pragma mark 抽奖动画 - 结束
- (void)stopAnimaition
{
  [self.yaoJiangOnImageView setHidden:YES];
  [self.yaoJiangOffImageView setHidden:NO];
  [self.buttonCircle setUserInteractionEnabled:YES];
  [self.yaoJiangOnImageView setUserInteractionEnabled:YES];
  [self.yaoJiangOffImageView setUserInteractionEnabled:YES];
  
  [self.circleBoardImageView.layer removeAnimationForKey:@"AnimationKey"];
}



@end

