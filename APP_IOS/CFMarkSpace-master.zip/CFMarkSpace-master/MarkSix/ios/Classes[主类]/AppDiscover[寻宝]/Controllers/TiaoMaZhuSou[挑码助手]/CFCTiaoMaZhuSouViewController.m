//
// 寻宝 - 挑码助手
//

#import "CFCTiaoMaZhuSouViewController.h"

@interface CFCTiaoMaZhuSouViewController ()

@end

@implementation CFCTiaoMaZhuSouViewController



#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_DISCOVER_TIAOMAZHUSHOU;
}

@end
