//
// 寻宝 - 恋人特码
//

#import "CFCLianRenTeMaViewController.h"
#import "PGDatePickManager.h"


@interface CFCLianRenTeMaViewController ()

@property (nonatomic, strong) UIButton *buttonConfirm;

@property (nonatomic, strong) CFCCheckboxButton *checkboxMen;
@property (nonatomic, strong) CFCCheckboxButton *checkboxWomen;
@property (nonatomic, strong) UILabel *birthdayMenLabel;
@property (nonatomic, strong) UILabel *birthdayWomenLabel;

@property (nonatomic, copy) NSString *birthdayMen;
@property (nonatomic, copy) NSString *birthdayWomen;

@property (nonatomic, copy) NSString *currentIssue;

@end


@implementation CFCLianRenTeMaViewController


#pragma mark -
#pragma mark 事件处理 - 性别 - 男
- (void)doCheckboxMenButtonAction:(CFCCheckboxButton *)button
{
  [self.checkboxMen setChecked:YES];
  [self.checkboxWomen setChecked:NO];
}


#pragma mark 事件处理 - 性别 - 女
- (void)doCheckboxWomenButtonAction:(CFCCheckboxButton *)button
{
  [self.checkboxMen setChecked:NO];
  [self.checkboxWomen setChecked:YES];
}

#pragma mark 事件处理 - 生日 - 男
- (void)pressItemViewBirthdayMen:(UITapGestureRecognizer *)gesture
{
  PGDatePickManager *datePickManager = [[PGDatePickManager alloc]init];
  datePickManager.isShadeBackground = true;
  datePickManager.headerViewBackgroundColor = [UIColor groupTableViewBackgroundColor];
  datePickManager.cancelButtonTextColor = COLOR_SYSTEM_MAIN_BUTTON_BACKGROUND_SELECT_DEFAULT;
  datePickManager.confirmButtonTextColor = COLOR_SYSTEM_MAIN_BUTTON_BACKGROUND_SELECT_DEFAULT;
  
  PGDatePicker *datePicker = datePickManager.datePicker;
  datePicker.isHiddenMiddleText = false;
  datePicker.datePickerMode = PGDatePickerModeDate;
  datePicker.lineBackgroundColor = COLOR_HEXSTRING(@"#EAEAEA");
  datePicker.textColorOfSelectedRow = [UIColor blackColor];
  [datePicker setSelectedDate:^(NSDateComponents *dateComponents) {
    NSDate *date = [CFCDateUtil getDateWithDateComponents:dateComponents];
    self->_birthdayMen = date.yyyyMMddByLineWithDate;
    [self->_birthdayMenLabel setText:date.yyyyMMddByLineWithDate];
  }];
  [self presentViewController:datePickManager animated:false completion:nil];
}

#pragma mark 事件处理 - 生日 - 女
- (void)pressItemViewBirthdayWomen:(UITapGestureRecognizer *)gesture
{
  PGDatePickManager *datePickManager = [[PGDatePickManager alloc]init];
  datePickManager.isShadeBackground = true;
  datePickManager.headerViewBackgroundColor = [UIColor groupTableViewBackgroundColor];
  datePickManager.cancelButtonTextColor = COLOR_SYSTEM_MAIN_BUTTON_BACKGROUND_SELECT_DEFAULT;
  datePickManager.confirmButtonTextColor = COLOR_SYSTEM_MAIN_BUTTON_BACKGROUND_SELECT_DEFAULT;
  
  PGDatePicker *datePicker = datePickManager.datePicker;
  datePicker.isHiddenMiddleText = false;
  datePicker.datePickerMode = PGDatePickerModeDate;
  datePicker.lineBackgroundColor = COLOR_HEXSTRING(@"#EAEAEA");
  datePicker.textColorOfSelectedRow = [UIColor blackColor];
  [datePicker setSelectedDate:^(NSDateComponents *dateComponents) {
    NSDate *date = [CFCDateUtil getDateWithDateComponents:dateComponents];
    self->_birthdayWomen = date.yyyyMMddByLineWithDate;
    [self->_birthdayWomenLabel setText:date.yyyyMMddByLineWithDate];
  }];
  [self presentViewController:datePickManager animated:false completion:nil];
}

#pragma mark 事件处理 - 匹配一下
- (void)doLogicConfrimAction:(UIButton *)button
{
  // 您的生日
  NSString *birthdayMen = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.birthdayMen];
  if ([CFCSysUtil validateStringEmpty:birthdayMen]) {
    [self alertPromptInfoMessage:@"请选择您的生日！"];
    return;
  }
  
  // 对象生日
  NSString *birthdayWomen = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.birthdayWomen];
  if ([CFCSysUtil validateStringEmpty:birthdayWomen]) {
    [self alertPromptInfoMessage:@"请选择恋人的生日！"];
    return;
  }
  
  // 随机开奖号码
  NSArray<NSString *> *randNumber = [CFCAppGameUtil getRandNumberResult:6];
  NSString *rangNumberValue = [randNumber componentsJoinedByString:@","];
  
  // 保存当前期结果
  APPINFORMATION.lianRenTeMaIssue = self.currentIssue;
  APPINFORMATION.lianRenTeMaResult = rangNumberValue;
  
  // 重绘主要界面
  {
    [self.view.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [self createMainUIView];
  }
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    
  }
  return self;
}


#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  // 设置背景颜色
  [self.view setBackgroundColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT];
  
  // 创建主要界面
  [self createMainUIView];
}


#pragma mark 创建主要界面
- (void)createMainUIView
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat heightOfHeader = CFC_AUTOSIZING_WIDTH(DISCOVER_INTRODUCE_HEADER_HEIGHT);
  CGFloat left_right_margin = margin * 1.5f;
  
  // 根容器
  UIScrollView *rootScrollView = ({
    UIScrollView *scrollView = [[UIScrollView alloc] init];
    [scrollView setShowsVerticalScrollIndicator:NO];
    [self.view addSubview:scrollView];
    
    [scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(self.view).with.offset(0.0);
      make.right.equalTo(self.view).with.offset(0.0);
      make.top.equalTo(self.view.mas_top).with.offset(0.0f);
      make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0f);
    }];
    
    scrollView;
  });
  
  // 主容器
  UIView *containerView = ({
    UIView *view = [[UIView alloc] init];
    [rootScrollView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.edges.equalTo(rootScrollView);
      make.width.equalTo(rootScrollView);
      make.height.mas_greaterThanOrEqualTo(SCREEN_HEIGHT-STATUS_NAVIGATION_BAR_HEIGHT+1.0);
    }];
    
    view;
  });
  
  // 头部介绍
  UIImageView *headerImageView = ({
    // 背景
    UIImageView *imageView = [UIImageView new];
    [containerView addSubview:imageView];
    [imageView setImage:[UIImage imageNamed:ICON_OPEN_BACKGROUND_HEADER]];
    [imageView setContentMode:UIViewContentModeScaleToFill];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(containerView.mas_top).offset(margin*1.5f);
      make.left.equalTo(containerView.mas_left).offset(left_right_margin);
      make.right.equalTo(containerView.mas_right).offset(-left_right_margin);
      make.height.mas_equalTo(heightOfHeader);
    }];
    
    // 标题
    UILabel *titleLabel = ({
      UILabel *label = [UILabel new];
      [imageView addSubview:label];
      [label setText:@"简介"];
      [label setTextAlignment:NSTextAlignmentCenter];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(imageView.mas_centerY).offset(-margin*1.0f);
        make.left.equalTo(imageView.mas_left).offset(margin*2.0f);
        make.right.equalTo(imageView.mas_right).offset(-margin*2.0f);
      }];
      
      label;
    });
    titleLabel.mas_key = @"titleLabel";
    
    // 内容
    UILabel *contentLabel = ({
      UILabel *label = [UILabel new];
      [imageView addSubview:label];
      [label setText:@"请输入您和他/她的生日。计算本期特码，赶紧来试试！"];
      [label setNumberOfLines:0];
      [label setTextAlignment:NSTextAlignmentCenter];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(12.0f)]];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(imageView.mas_centerY).offset(margin*0.70f);
        make.left.equalTo(imageView.mas_left).offset(margin*1.5f);
        make.right.equalTo(imageView.mas_right).offset(-margin*1.5f);
      }];
      
      label;
    });
    contentLabel.mas_key = @"contentLabel";
    
    imageView;
  });
  headerImageView.mas_key = @"headerImageView";
  
  // 恋人特码
  WEAKSELF(weakSelf);
  [CFCAppGameUtil getCurrentIssueNumber:self.view then:^(NSString * _Nonnull year, NSString * _Nonnull issue, NSString * _Nonnull datetime) {
    
    weakSelf.currentIssue = issue;
    
    if (APPINFORMATION.lianRenTeMaIssue.integerValue > 0
        && APPINFORMATION.lianRenTeMaIssue.integerValue >= issue.integerValue) {
      
      // 主要视图
      UIView *mainUIView = [self createMainResultUIView:containerView topView:headerImageView];
      
      // 约束完整
      [containerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_greaterThanOrEqualTo(mainUIView.mas_bottom).offset(margin*1.0f);
      }];
      
    } else {
      
      // 重置配置
      APPINFORMATION.lianRenTeMaIssue = @"0";
      APPINFORMATION.lianRenTeMaResult = @"";
      
      // 主要视图
      UIView *mainUIView = [self createMainComputeUIView:containerView topView:headerImageView];
      
      // 约束完整
      [containerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_greaterThanOrEqualTo(mainUIView.mas_bottom).offset(margin*4.0f);
      }];
      
    }
  }];

}


#pragma mark 创建主要界面 - 本期计算页面
- (UIView *)createMainComputeUIView:(UIView *)container topView:(UIView *)topView
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat item_size_width = SCREEN_WIDTH * 0.15f;
  CGFloat item_size_height = item_size_width * 0.45;
  CGFloat item_text_width = SCREEN_WIDTH * 0.45f;
  CGFloat item_text_height = item_text_width * 0.19f;
  
  // 男+女
  UIImageView *lianRenTeMaImageView = ({
    UIImageView *imageView = [UIImageView new];
    [container addSubview:imageView];
    [imageView setContentMode:UIViewContentModeScaleAspectFit];
    [imageView setImage:[UIImage imageNamed:@"icon_discover_lianrentema"]];

    CGFloat imageWidth = SCREEN_WIDTH * 0.47f;
    CGFloat imageHeight = imageWidth * 0.26f;
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(topView.mas_bottom).offset(margin*3.0f);
      make.centerX.equalTo(container.mas_centerX);
      make.width.equalTo(@(imageWidth));
      make.height.equalTo(@(imageHeight));
    }];
    
    imageView;
  });
  lianRenTeMaImageView.mas_key = @"lianRenTeMaImageView";
  
  
  // 说明
  UILabel *lianRenTeMaLabel = ({
    UILabel *label = [UILabel new];
    [container addSubview:label];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(12.0f)]];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    [label setTextAlignment:NSTextAlignmentCenter];
    [label setText:@"来测试一下你们的恋人特码吧！"];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(lianRenTeMaImageView.mas_bottom).offset(margin*0.5f);
      make.centerX.equalTo(container.mas_centerX);
    }];
    
    label;
  });
  lianRenTeMaLabel.mas_key = @"lianRenTeMaLabel";
  
  
  // 性别 - 标题
  UILabel *xingBieTitleLabel = ({
    UILabel *label = [UILabel new];
    [container addSubview:label];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)]];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    [label setTextAlignment:NSTextAlignmentRight];
    [label setText:@"请选择您的性别："];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(lianRenTeMaLabel.mas_bottom).offset(margin*5.0f);
      make.right.equalTo(container.mas_centerX).offset(-margin*0.5f);
    }];
    
    label;
  });
  xingBieTitleLabel.mas_key = @"xingBieTitleLabel";

  
  // 性别 - 男
  CFCCheckboxButton *checkboxMen = ({
    CGRect frame = CGRectMake(0, 0, item_size_width, item_size_height);
    CFCCheckboxButton *itemCheckbox = [[CFCCheckboxButton alloc] initWithFrame:frame];
    [itemCheckbox setChecked:YES];
    [itemCheckbox setText:@"男"];
    [itemCheckbox setTextFont:[UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)]];
    [itemCheckbox setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    [itemCheckbox setNormalBgImage:@"icon_check_box_men_normal"];
    [itemCheckbox setSelectBgImage:@"icon_check_box_men_selected"];
    [itemCheckbox setBackgroundColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT];
    [itemCheckbox addTarget:self action:@selector(doCheckboxMenButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [container addSubview:itemCheckbox];
    
    [itemCheckbox mas_remakeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(container.mas_centerX);
      make.centerY.equalTo(xingBieTitleLabel.mas_centerY);
      make.width.equalTo(@(item_size_width));
      make.height.equalTo(@(item_size_height));
    }];
    
    itemCheckbox;
  });
  self.checkboxMen = checkboxMen;
  self.checkboxMen.mas_key = @"checkboxMen";
  
  
  // 性别 - 女
  CFCCheckboxButton *checkboxWomen = ({
    CGRect frame = CGRectMake(0, 0, item_size_width, item_size_height);
    CFCCheckboxButton *itemCheckbox = [[CFCCheckboxButton alloc] initWithFrame:frame];
    [itemCheckbox setText:@"女"];
    [itemCheckbox setTextFont:[UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)]];
    [itemCheckbox setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    [itemCheckbox setNormalBgImage:@"icon_check_box_women_normal"];
    [itemCheckbox setSelectBgImage:@"icon_check_box_women_selected"];
    [itemCheckbox setBackgroundColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT];
    [itemCheckbox addTarget:self action:@selector(doCheckboxWomenButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [container addSubview:itemCheckbox];
    
    [itemCheckbox mas_remakeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(checkboxMen.mas_right).offset(margin*0.5f);
      make.centerY.equalTo(xingBieTitleLabel.mas_centerY);
      make.width.equalTo(@(item_size_width));
      make.height.equalTo(@(item_size_height));
    }];
    
    itemCheckbox;
  });
  self.checkboxWomen = checkboxWomen;
  self.checkboxWomen.mas_key = @"checkboxWomen";
  
  
  // 生日 - 您的生日
  UILabel *niShengRiTitleLabel = ({
    UILabel *label = [UILabel new];
    [container addSubview:label];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)]];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    [label setTextAlignment:NSTextAlignmentLeft];
    [label setText:@"您的生日："];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(xingBieTitleLabel.mas_bottom).offset(margin*3.0f);
      make.left.equalTo(xingBieTitleLabel.mas_left);
    }];
    
    label;
  });
  niShengRiTitleLabel.mas_key = @"niShengRiTitleLabel";
  
  
  // 生日 - 您的生日
  UILabel *birthdayMenLabel = ({
    UILabel *label = [UILabel new];
    [container addSubview:label];
    [label addBorderWithColor:COLOR_SYSTEM_MAIN_FONT_ASSIST_DEFAULT
                 cornerRadius:5.0
                     andWidth:1.0f];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_ASSIST_DEFAULT];
    [label setTextAlignment:NSTextAlignmentCenter];
    [label setUserInteractionEnabled:YES];
    [label setText:@"请选择您的生日"];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressItemViewBirthdayMen:)];
    [label addGestureRecognizer:tapGesture];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(niShengRiTitleLabel.mas_centerY);
      make.centerX.equalTo(checkboxMen.mas_right).offset(-margin*0.25f);
      make.width.equalTo(@(item_text_width));
      make.height.equalTo(@(item_text_height));
    }];
    
    label;
  });
  self.birthdayMenLabel= birthdayMenLabel;
  self.birthdayMenLabel.mas_key = @"birthdayMenLabel";
  
  
  // 生日 - 对象生日
  UILabel *duiXiangShengRiTitleLabel = ({
    UILabel *label = [UILabel new];
    [container addSubview:label];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)]];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    [label setTextAlignment:NSTextAlignmentLeft];
    [label setText:@"对象生日："];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(niShengRiTitleLabel.mas_bottom).offset(margin*3.0f);
      make.left.equalTo(niShengRiTitleLabel.mas_left);
    }];
    
    label;
  });
  duiXiangShengRiTitleLabel.mas_key = @"duiXiangShengRiTitleLabel";
  
  
  // 生日 - 对象生日
  UILabel *birthdayWomenLabel = ({
    UILabel *label = [UILabel new];
    [container addSubview:label];
    [label addBorderWithColor:COLOR_SYSTEM_MAIN_FONT_ASSIST_DEFAULT
                 cornerRadius:5.0
                     andWidth:1.0f];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_ASSIST_DEFAULT];
    [label setTextAlignment:NSTextAlignmentCenter];
    [label setUserInteractionEnabled:YES];
    [label setText:@"请选择恋人的生日"];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressItemViewBirthdayWomen:)];
    [label addGestureRecognizer:tapGesture];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(duiXiangShengRiTitleLabel.mas_centerY);
      make.centerX.equalTo(birthdayMenLabel.mas_centerX);
      make.width.equalTo(@(item_text_width));
      make.height.equalTo(@(item_text_height));
    }];
    
    label;
  });
  self.birthdayWomenLabel= birthdayWomenLabel;
  self.birthdayWomenLabel.mas_key = @"birthdayWomenLabel";
  
  
  // 匹配一下
  UIButton *buttonConfirm = ({
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button defaultStyleButton];
    [button.layer setBorderWidth:0.0f];
    [button setTitle:@"匹配一下" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(doLogicConfrimAction:) forControlEvents:UIControlEventTouchUpInside];
    [container addSubview:button];
    
    CGFloat buttonWidth = SCREEN_WIDTH * 0.45f;
    CGFloat buttonHeight = buttonWidth * 0.22f;
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(duiXiangShengRiTitleLabel.mas_bottom).offset(margin*4.5f);
      make.centerX.equalTo(container.mas_centerX);
      make.width.mas_equalTo(buttonWidth);
      make.height.mas_equalTo(buttonHeight);
    }];
    
    button;
  });
  self.buttonConfirm = buttonConfirm;
  self.buttonConfirm.mas_key = @"buttonConfirm";
  
  return niShengRiTitleLabel;
}


#pragma mark 创建主要界面 - 结果显示界面
- (UIView *)createMainResultUIView:(UIView *)container topView:(UIView *)topView
{
  // 组装特码
  NSString *randNumberValue = APPINFORMATION.lianRenTeMaResult;
  NSArray<NSString *> *randNumbers = [randNumberValue split:@","];
  NSArray<NSString *> *randColors = IMAGE_LIU_HE_CAI_ARRAY;
  
  // 开奖结果
  NSInteger colum = randNumbers.count;
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat left_gap = margin * 3.5f;
  CGFloat right_gap = margin * 3.5f;
  CGFloat itemMargin = margin * 2.0f;
  CGFloat itemWidth = (SCREEN_WIDTH - left_gap - right_gap - itemMargin*(colum-1)) / colum;
  CGFloat itemHeight = itemWidth * 1.0f;
  CGFloat imageSize = itemWidth;
  UIColor *autoNumbeColor = COLOR_SYSTEM_MAIN_FONT_DEFAULT;
  UIFont *autoNumberFont = [UIFont fontWithName:@"NotoMono" size:CFC_AUTOSIZING_FONT(14)];
  
  UIView *lastItemView = nil;
  for (int i = 0; i < colum; i ++) {
    NSString *number_value = randNumbers[i];
    NSInteger colorIndex = number_value.integerValue - 1;
    if (colorIndex < 0) {
      colorIndex = 0;
    }
    if (colorIndex >= randColors.count) {
      colorIndex = randColors.count-1;
    }
    
    // 容器
    UIView *itemView = ({
      UIView *itemContainerView = [[UIView alloc] init];
      [container addSubview:itemContainerView];
      [itemContainerView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@(itemWidth));
        make.height.equalTo(@(itemHeight));
        
        if (!lastItemView) {
          make.top.equalTo(topView.mas_bottom).offset(margin*5.0f);
          make.left.equalTo(container.mas_left).offset(left_gap);
        } else {
          make.top.equalTo(lastItemView.mas_top);
          make.left.equalTo(lastItemView.mas_right).offset(itemMargin);
        }
      }];
      itemContainerView.mas_key = [NSString stringWithFormat:@"itemContainerView%d",i];
      
      // 图片
      UIImageView *iconImageView = ({
        UIImageView *imageView = [UIImageView new];
        [itemContainerView addSubview:imageView];
        [imageView setContentMode:UIViewContentModeScaleAspectFit];
        [imageView setImage:[UIImage imageNamed:randColors[colorIndex]]];
        
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
          make.top.equalTo(itemContainerView.mas_top).offset(0.0f);
          make.centerX.equalTo(itemContainerView.mas_centerX).offset(0.0f);
          make.height.equalTo(@(imageSize));
          make.width.equalTo(@(imageSize));
        }];
        
        imageView;
      });
      iconImageView.mas_key = [NSString stringWithFormat:@"iconImageView%d", i];
      
      // 号码
      UILabel *numberLabel = ({
        UILabel *label = [UILabel new];
        [itemContainerView addSubview:label];
        [label setFont:autoNumberFont];
        [label setTextColor:autoNumbeColor];
        [label setTextAlignment:NSTextAlignmentLeft];
        [label setText:[NSString stringWithFormat:@"%02ld", number_value.integerValue]];
        
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
          make.top.equalTo(iconImageView.mas_top).offset(imageSize*0.20f);
          make.left.equalTo(itemContainerView.mas_left).offset(imageSize*0.25);
        }];
        
        label;
      });
      numberLabel.mas_key = [NSString stringWithFormat:@"numberLabel%d", i];
      
      itemContainerView;
    });
    
    lastItemView = itemView;
  }
  
  return lastItemView ? lastItemView : topView;
}



#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_DISCOVER_LIANRENTEMA;
}


@end

