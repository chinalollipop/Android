//
// 寻宝 - 玄机锦囊 - 历史记录
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCXuanJiJinLangHistoryModel : NSObject

@property (nonatomic, strong) NSNumber *year;
@property (nonatomic, strong) NSNumber *period;
@property (nonatomic, copy) NSString *content;
@property (nonatomic, assign) BOOL isShowContent;


@end

NS_ASSUME_NONNULL_END
