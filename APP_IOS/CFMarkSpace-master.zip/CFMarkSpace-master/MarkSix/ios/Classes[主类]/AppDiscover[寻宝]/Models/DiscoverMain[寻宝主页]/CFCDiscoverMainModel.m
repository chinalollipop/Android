//
// 寻宝 - 寻宝数据
//

#import "CFCDiscoverMainModel.h"

@implementation CFCDiscoverMainModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{ };
}

+ (NSMutableArray<CFCDiscoverMainModel *> *) buildingDataModles
{
  NSMutableArray<CFCDiscoverMainModel *> *models = [NSMutableArray array];
  {
    NSArray<NSString *> *titles = @[ @"恋人特码",
                                     @"生肖卡牌",
                                     @"摇一摇",
                                     @"玄机锦囊",
                                     @"幸运摇奖",
                                     @"波肖转盘",
                                     @"搅珠日期",
                                     @"天机测算",
                                     @"挑码助手" ];
    NSArray<NSString *> *markIds = @[ STR_MARKID_DISCOVER_MAIN_LIAN_REN,
                                      STR_MARKID_DISCOVER_MAIN_SHENG_XIAO,
                                      STR_MARKID_DISCOVER_MAIN_YAO_YI_YAO,
                                      STR_MARKID_DISCOVER_MAIN_XUANJIJINNANG,
                                      STR_MARKID_DISCOVER_MAIN_XINGYUNYAOJIANG,
                                      STR_MARKID_DISCOVER_MAIN_BOXIAOZHUANPAN,
                                      STR_MARKID_DISCOVER_MAIN_JIAOZHURIQI,
                                      STR_MARKID_DISCOVER_MAIN_TIANJICESUAN,
                                      STR_MARKID_DISCOVER_MAIN_TIAOMAZHUSHOU ];
    NSArray<NSString *> *images = @[ @"icon_tool_lianren",
                                     @"icon_tool_shengxiao",
                                     @"icon_tool_yaoyiyao",
                                     @"icon_tool_xuanjijinnang",
                                     @"icon_tool_xingyunyaojiang",
                                     @"icon_tool_boxiaozhuanpan",
                                     @"icon_tool_jiaozhuriqi",
                                     @"icon_tool_tianjicesuan",
                                     @"icon_tool_tiaomazhushou" ];
    for (int index = 0; index < titles.count; index ++) {
      CFCDiscoverMainModel *model = [[CFCDiscoverMainModel alloc] init];
      [model setTitle:titles[index]];
      [model setMarkId:markIds[index]];
      [model setImageUrl:images[index]];
      [models addObject:model];
    }
  }
  
  return models;
}

@end
