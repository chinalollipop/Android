//
// 寻宝 - 搅珠日期
//


#import "CFCJiaoZhuRiQiModel.h"

@implementation CFCJiaoZhuRiQiOpenDateModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"uuid" : @"id",
           @"issue" : @"issue",
           @"year" : @"year",
           @"datetime" : @"date"
           };
}

@end


@implementation CFCJiaoZhuRiQiModel

@end


