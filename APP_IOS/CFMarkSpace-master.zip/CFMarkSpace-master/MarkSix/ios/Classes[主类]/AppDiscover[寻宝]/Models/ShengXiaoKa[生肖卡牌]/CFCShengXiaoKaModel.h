//
// 寻宝 - 生肖卡牌
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCShengXiaoKaModel : NSObject

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *imageUrl;
@property (nonatomic, copy) NSString *imageCoverUrl;
@property (nonatomic, assign) BOOL isSelected;
@property (nonatomic, assign) BOOL isShow;

@end

NS_ASSUME_NONNULL_END
