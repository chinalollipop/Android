//
// 寻宝 - 寻宝数据
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCDiscoverMainModel : NSObject

@property (nonatomic, copy) NSString *markId;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *imageUrl;
@property (nonatomic, copy) NSString *isShow;

+ (NSMutableArray<CFCDiscoverMainModel *> *) buildingDataModles;

@end

NS_ASSUME_NONNULL_END
