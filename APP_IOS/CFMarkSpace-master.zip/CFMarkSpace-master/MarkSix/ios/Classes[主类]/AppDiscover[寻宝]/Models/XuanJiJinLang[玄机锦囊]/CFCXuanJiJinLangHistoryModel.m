//
// 寻宝 - 玄机锦囊 - 历史记录
//

#import "CFCXuanJiJinLangHistoryModel.h"

@implementation CFCXuanJiJinLangHistoryModel

@end
