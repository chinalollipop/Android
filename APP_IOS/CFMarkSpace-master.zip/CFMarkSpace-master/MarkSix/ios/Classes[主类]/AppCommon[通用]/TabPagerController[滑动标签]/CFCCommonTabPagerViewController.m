//
//  TabPager 控制器基类
//


#import "CFCCommonTabPagerViewController.h"

@interface CFCCommonTabPagerViewController () <CFCTabPagerDelegate, CFCTabPagerDataSource>

@end

@implementation CFCCommonTabPagerViewController


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.tabPagerIds = @[].mutableCopy;
        self.tabPagerCodes = @[].mutableCopy;
        self.tabPagerTitles = @[].mutableCopy;
        self.tabPagerViewControllers = @[].mutableCopy;
    }
    return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    WEAKSELF(weakSelf);
    
    // 设置数据源代理
    [self setDataSource:self];
    [self setDelegate:self];
    
    // 初始化数据，成功则刷新页面
    if ([self viewDidLoadWithDataSource]) {
        
        // 加载并初始化数据后，创建子控制器前
        [self viewDidLoadWithDataSourceThenBeforeReloadData];
        
        // 加载请求网络或缓存数据
        [self viewDidLoadNetworkDataSourceThen:^(BOOL success, NSUInteger count){
            
            // 加载请求网络数据后，创建子控制器
            if (success && count > 0) {
                [weakSelf viewDidLoadNetworkDataSourceThenAfterSuccess];
            } else {
                [weakSelf viewDidLoadNetworkDataSourceThenAfterFailure];
            }
            
            // 加载并初始化数据后，创建子控制器后
            [weakSelf viewDidLoadWithDataSourceThenAfterReloadData];
            
        }];
        
    }
    
}

#pragma mark 加载并初始化数据
- (BOOL)viewDidLoadWithDataSource
{
    // TODO: 子类必须继承，并加载数据，成功返回则返回YES，默认返回NO
    
    return NO;
}

#pragma mark 加载并初始化数据后，请求网络数据前
- (void)viewDidLoadWithDataSourceThenBeforeReloadData
{
    // TODO: 子类继承实现，并加载数据成功后，创建子控制器前，做一些操作
    
}

#pragma mark 加载并初始化数据后，请求网络数据后
- (void)viewDidLoadWithDataSourceThenAfterReloadData
{
    // TODO: 子类继承实现，并加载数据成功后，创建子控制器后，做一些操作
    
}

#pragma mark 加载请求网络数据
- (void)viewDidLoadNetworkDataSourceThen:(void (^)(BOOL success, NSUInteger count))then
{
    // TODO: 子类继承实现，并加载请求网络数据后成功后，创建子控制器
    
    !then ?: then(YES,0);
}

#pragma mark 加载请求网络数据成功
- (void)viewDidLoadNetworkDataSourceThenAfterSuccess
{
    // TODO: 子类继承实现，并加载请求网络数据后成功后，做一些操作
    [self reloadData];
}

#pragma mark 加载请求网络数据失败
- (void)viewDidLoadNetworkDataSourceThenAfterFailure
{
    // TODO: 子类继承实现，并加载请求网络数据后失败后，做一些操作
    
}


#pragma mark -
#pragma mark Tab Pager Data Source
- (NSInteger)numberOfViewControllers
{
    return self.tabPagerViewControllers.count;
}

- (UIViewController *)viewControllerForIndex:(NSInteger)index
{
    Class myClass = NSClassFromString(self.tabPagerViewControllers[index]);
    CFCBaseCommonViewController *viewController = [[myClass alloc] init];
    return viewController;
}

- (NSString *)titleForTabAtIndex:(NSInteger)index
{
    return self.tabPagerTitles[index];
}

#pragma mark -
#pragma mark Tab Pager Delegate

- (void)tabPager:(CFCTabPagerViewController *)tabPager willTransitionToTabAtIndex:(NSInteger)index viewControllerAtIndex:(UIViewController *)viewController
{
    // CFCLog(@"From tab %ld to %ld", [self selectedIndex], (long)index);
}

- (void)tabPager:(CFCTabPagerViewController *)tabPager didTransitionToTabAtIndex:(NSInteger)index viewControllerAtIndex:(UIViewController *)viewController
{
    // CFCLog(@"Done to tab %ld", (long)index);
}


@end
