//
//  TabPager 控制器基类
//


#import "CFCTabPagerViewController.h"

NS_ASSUME_NONNULL_BEGIN

@protocol CFCCommonTabPagerViewControllerProtocol <NSObject>
@required
#pragma mark 加载并初始化数据
- (BOOL)viewDidLoadWithDataSource;
@optional
#pragma mark 加载并初始化数据后，请求网络数据前
- (void)viewDidLoadWithDataSourceThenBeforeReloadData;
#pragma mark 加载并初始化数据后，请求网络数据后
- (void)viewDidLoadWithDataSourceThenAfterReloadData;
#pragma mark 加载请求网络数据
- (void)viewDidLoadNetworkDataSourceThen:(void (^)(BOOL success))then;
@end

@interface CFCCommonTabPagerViewController : CFCTabPagerViewController <CFCCommonTabPagerViewControllerProtocol>

@property (nonatomic, strong) NSArray<NSString *> *tabPagerIds;
@property (nonatomic, strong) NSArray<NSString *> *tabPagerCodes;
@property (nonatomic, strong) NSArray<NSString *> *tabPagerTitles;
@property (nonatomic, strong) NSArray<NSString *> *tabPagerViewControllers;

#pragma mark -
#pragma mark 加载并初始化数据
- (BOOL)viewDidLoadWithDataSource;
#pragma mark 加载并初始化数据后，请求网络数据前
- (void)viewDidLoadWithDataSourceThenBeforeReloadData;
#pragma mark 加载并初始化数据后，请求网络数据后
- (void)viewDidLoadWithDataSourceThenAfterReloadData;

#pragma mark 加载请求网络数据
- (void)viewDidLoadNetworkDataSourceThen:(void (^)(BOOL success, NSUInteger count))then;
#pragma mark 加载请求网络数据成功
- (void)viewDidLoadNetworkDataSourceThenAfterSuccess;
#pragma mark 加载请求网络数据失败
- (void)viewDidLoadNetworkDataSourceThenAfterFailure;

@end

NS_ASSUME_NONNULL_END
