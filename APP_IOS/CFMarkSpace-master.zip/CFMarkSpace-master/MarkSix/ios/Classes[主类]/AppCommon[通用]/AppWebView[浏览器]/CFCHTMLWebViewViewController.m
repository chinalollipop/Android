
#import "CFCHTMLWebViewViewController.h"

@interface CFCHTMLWebViewViewController ()

@end

@implementation CFCHTMLWebViewViewController


#pragma mark -
#pragma mark 事件处理 - 刷新
- (void)pressButtonWebViewRefreshAction
{
    [super pressButtonWebViewRefreshAction];
    
    [self startLoadRequestWebHtml];
}


#pragma mark -
#pragma mark 加载Web网页内容
- (void)startLoadRequestWebHtml
{
    // 加载HTML页面
    if ([CFCSysUtil validateStringEmpty:self.htmlUrlString]) {
        
        // 获取到需要加载的HTML
        NSString *HtmlString = @"<p>警告提示：加载网页出错，请浏览其它内容！</p>";
        
        // 获取error文件的路径
        NSString *errorHtmlPath = [[NSBundle mainBundle] pathForResource:@"html_error" ofType:@"html"];
        
        // 加载error内容为字符串
        NSString *errorHtml = [NSString stringWithContentsOfFile:errorHtmlPath encoding:NSUTF8StringEncoding error:nil];
        
        // 替换占位符{{Content_holder}}为需要加载的HTML代码
        errorHtml = [errorHtml stringByReplacingOccurrencesOfString:@"{{Content_holder}}" withString:HtmlString];
        
        // error目录下的js文件在根路径，因此需要在加载HTMLString时指定根路径
        NSString *basePath = [[NSBundle mainBundle] bundlePath];
        NSURL *baseURL = [NSURL fileURLWithPath:basePath];
        
        // 加载HTMLString
        [self.webView loadHTMLString:errorHtml baseURL:baseURL];
        
    } else {
        
        // 获取文件的路径
        NSString *htmlPath = [[NSBundle mainBundle] pathForResource:self.htmlUrlString ofType:@"html"];
        
        // 加载字符串内容
        NSString *htmlString = [NSString stringWithContentsOfFile:htmlPath encoding:NSUTF8StringEncoding error:nil];
                
        // 目录下的css文件在根路径，因此需要在加载HTMLString时指定根路径
        NSString *basePath = [[NSBundle mainBundle] bundlePath];
        NSURL *baseURL = [NSURL fileURLWithPath:basePath];
        
        // 加载HTMLString
        [self.webView loadHTMLString:htmlString baseURL:baseURL];
    }
    
}


@end
