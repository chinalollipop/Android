//
// 分享推广
//

#import "CFCAppSharingViewController.h"

@interface CFCAppSharingViewController ()

@end

@implementation CFCAppSharingViewController


- (void)viewWillAppear:(BOOL)animated
{
  [super viewWillAppear:animated];
  
  APPINFORMATION.isShowAppSharePage = YES;
}


- (void)viewWillDisappear:(BOOL)animated
{
  [super viewWillDisappear:animated];
  
  APPINFORMATION.isShowAppSharePage = NO;
}


@end

