//
// 分享推广
//

#import "CFCBaseWKWebViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCAppSharingViewController : CFCBaseWKWebViewController

@end

NS_ASSUME_NONNULL_END
