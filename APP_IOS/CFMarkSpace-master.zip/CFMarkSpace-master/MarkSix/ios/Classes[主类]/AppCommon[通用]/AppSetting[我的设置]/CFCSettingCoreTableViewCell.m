

#import "CFCSettingCoreTableViewCell.h"
#import "CFCSettingCoreModel.h"
#import "CFCSwitch.h"

// Cell Identifier
NSString * const CELL_IDENTIFIER_SETTING_CORE = @"CFCSettingCoreTableViewCellIdentifier";

@interface CFCSettingCoreTableViewCell ()


@end


@implementation CFCSettingCoreTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
  if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
    [self createViewAtuoLayout];
  }
  return self;
}


#pragma mark - 创建子控件
- (void)createViewAtuoLayout
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  
  // 根容器
  UIView *rootContainerView = ({
    UIView *view = [[UIView alloc] init];
    [self.contentView insertSubview:view atIndex:0];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
    }];
    
    view;
  });
  self.rootContainerView = rootContainerView;
  self.rootContainerView.mas_key = @"rootContainerView";
  
  // 公共容器
  UIView *publicContainerView = ({
    UIView *view = [[UIView alloc] init];
    [view.layer setMasksToBounds:YES];
    [rootContainerView addSubview:view];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressPublicItemView:)];
    tapGesture.numberOfTapsRequired = 1;
    tapGesture.numberOfTouchesRequired = 1;
    [view addGestureRecognizer:tapGesture];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(rootContainerView.mas_left).offset(0.0f);
      make.top.equalTo(rootContainerView.mas_top).offset(0.0f);
      make.right.equalTo(rootContainerView.mas_right).offset(0.0f);
      make.bottom.equalTo(rootContainerView.mas_bottom).offset(0.0f);
    }];
    
    view;
  });
  self.publicContainerView = publicContainerView;
  self.publicContainerView.mas_key = @"publicContainerView";
  
  // 箭头控件
  UIImageView *arrowImageView = ({
    CGSize imageSize = CGSizeMake(CFC_AUTOSIZING_WIDTH(8.0f), CFC_AUTOSIZING_WIDTH(15.0f));
    UIImageView *imageView = [UIImageView new];
    [publicContainerView addSubview:imageView];
    [imageView.layer setMasksToBounds:YES];
    [imageView setUserInteractionEnabled:YES];
    [imageView setContentMode:UIViewContentModeScaleAspectFit];
    [imageView setImage:[[UIImage imageNamed:ICON_SETTING_TABLE_ARROW] imageByScalingProportionallyToSize:imageSize]];
    
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(publicContainerView.mas_centerY).offset(0.0f);
      make.right.equalTo(publicContainerView.mas_right).offset(-margin*1.5);
      make.size.mas_equalTo(imageSize);
    }];
    
    imageView;
  });
  self.arrowImageView = arrowImageView;
  self.arrowImageView.mas_key = [NSString stringWithFormat:@"arrowImageView"];
  
  // 开关按钮
  CFCSwitch *switchButton = ({
    CGSize switchSize = CGSizeMake(CFC_AUTOSIZING_WIDTH(50.0f), CFC_AUTOSIZING_WIDTH(25.0f));
    CFCSwitch *switchButton = [[CFCSwitch alloc] init];
    [self.publicContainerView addSubview:switchButton];
    [switchButton setOnText:@"开"];
    [switchButton setOffText:@"关"];
    [switchButton setBackgroundColor:[UIColor clearColor]];
    [switchButton setTintColor:COLOR_HEXSTRING(@"#989898")];
    [switchButton setOnTintColor:COLOR_HEXSTRING(@"#C1A07B")];
    [switchButton addTarget:self action:@selector(pressSwitchButtonAction:) forControlEvents:UIControlEventValueChanged];
    
    [switchButton mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(self.publicContainerView.mas_centerY).offset(0.0);
      make.right.equalTo(self.arrowImageView.mas_left).offset(-margin);
      make.size.mas_equalTo(switchSize);
    }];
    
    switchButton;
  });
  self.switchButton = switchButton;
  self.switchButton.mas_key = [NSString stringWithFormat:@"switchButton"];
  
  // 标题控件
  UILabel *titleLabel = ({
    UILabel *label = [UILabel new];
    [label setNumberOfLines:1];
    [label setUserInteractionEnabled:YES];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)]];
    [label setTextColor:COLOR_HEXSTRING(@"#101010")];
    [label setTextAlignment:NSTextAlignmentLeft];
    [publicContainerView addSubview:label];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(publicContainerView.mas_top).offset(margin*1.2f);
      make.left.equalTo(publicContainerView.mas_left).offset(margin);
    }];
    
    label;
  });
  self.titleLabel = titleLabel;
  self.titleLabel.mas_key = @"titleLabel";
  
  // 内容控件
  UILabel *contentLabel = ({
    UILabel *label = [UILabel new];
    [label setNumberOfLines:1];
    [label setUserInteractionEnabled:YES];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)]];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_ASSIST_DEFAULT];
    [label setTextAlignment:NSTextAlignmentRight];
    [publicContainerView addSubview:label];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(publicContainerView.mas_centerY).offset(0.0);
      make.left.equalTo(titleLabel.mas_right).offset(margin);
      make.right.equalTo(arrowImageView.mas_left).offset(-margin);
    }];
    
    label;
  });
  self.contentLabel = contentLabel;
  self.contentLabel.mas_key = @"contentLabel";
  
  // 分割线
  UIView *separatorLineView = ({
    UIView *view = [[UIView alloc] init];
    [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
    [publicContainerView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(titleLabel.mas_bottom).offset(margin*1.2f);
      make.left.equalTo(publicContainerView.mas_left).offset(0.0f);
      make.right.equalTo(publicContainerView.mas_right).offset(0.0f);
      make.height.equalTo(@(1.0f));
    }];
    
    view;
  });
  self.separatorLineView = separatorLineView;
  self.separatorLineView.mas_key = @"separatorLineView";
  
  // 约束的完整性
  [publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
    make.bottom.equalTo(separatorLineView.mas_bottom).offset(0.0f).priority(749);
  }];
  
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCSettingCoreModel *)model
{
  // 类型安全检查
  if (![model isKindOfClass:[CFCSettingCoreModel class]]) {
    return;
  }
  
  // 数据赋值
  _model = model;
  
  // 配置变量
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGSize switchSize = CGSizeMake(CFC_AUTOSIZING_WIDTH(50.0f), CFC_AUTOSIZING_WIDTH(25.0f));
  
  // 标题
  [self.titleLabel setText:_model.title];
  
  // 箭头
  [self.arrowImageView setHidden:!_model.isEdit];
  
  // 文字内容
  [self.contentLabel setText:_model.content];
  
  // 显示文字或按钮
  if (_model.isSwitch) {
    // 隐藏文字，显示按钮
    [self.contentLabel setHidden:YES];
    [self.switchButton setHidden:NO];
    // 按钮选择状态
    [self.switchButton setOn:_model.content.boolValue];
    // 设置控件位置
    if (_model.isEdit) {
      [self.switchButton mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.publicContainerView.mas_centerY).offset(0.0);
        make.right.equalTo(self.arrowImageView.mas_left).offset(-margin);
        make.size.mas_equalTo(switchSize);
      }];
    } else {
      [self.switchButton mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.publicContainerView.mas_centerY).offset(0.0);
        make.right.equalTo(self.publicContainerView.mas_right).offset(-margin*1.5);
        make.size.mas_equalTo(switchSize);
      }];
    }
    [self.contentLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(self.publicContainerView.mas_centerY).offset(0.0);
      make.left.equalTo(self.titleLabel.mas_right).offset(margin);
      make.right.equalTo(self.switchButton.mas_left).offset(-margin);
    }];
  } else {
    // 显示文字，隐藏按钮
    [self.contentLabel setHidden:NO];
    [self.switchButton setHidden:YES];
    // 显示文字，隐藏按钮
    [self.contentLabel setText:_model.content];
    // 设置控件位置
    if (_model.isEdit) {
      [self.contentLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.publicContainerView.mas_centerY).offset(0.0);
        make.left.equalTo(self.titleLabel.mas_right).offset(margin);
        make.right.equalTo(self.arrowImageView.mas_left).offset(-margin);
      }];
    } else {
      [self.contentLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.publicContainerView.mas_centerY).offset(0.0);
        make.left.equalTo(self.titleLabel.mas_right).offset(margin);
        make.right.equalTo(self.publicContainerView.mas_right).offset(-margin*1.5);
      }];
    }
  }
}


#pragma mark - 触发操作事件
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture
{
  if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectRowAtSettingCoreModel:)]) {
    [self.delegate didSelectRowAtSettingCoreModel:self.model];
  }
}

#pragma mark - 触发操作事件 - 音效开关
- (void)pressSwitchButtonAction:(UISwitch *)switchButton
{
  BOOL isButtonOn = [switchButton isOn];
  if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectRowAtSettingCoreModel:withButtonStatus:)]) {
    [self.delegate didSelectRowAtSettingCoreModel:self.model withButtonStatus:isButtonOn];
  }
}

@end



