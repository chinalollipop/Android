

#import <UIKit/UIKit.h>
@class CFCSettingCoreModel, CFCSwitch;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_SETTING_CORE;

@protocol CFCSettingCoreTableViewCellProtocol <NSObject>
@required
- (void)createViewAtuoLayout;
- (void)setModel:(CFCSettingCoreModel *)model;
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture;
@end

@protocol CFCSettingCoreTableViewCellDelegate <NSObject>
@optional
- (void)didSelectRowAtSettingCoreModel:(CFCSettingCoreModel *)model;
- (void)didSelectRowAtSettingCoreModel:(CFCSettingCoreModel *)model withButtonStatus:(BOOL)status;
@end


@interface CFCSettingCoreTableViewCell : UITableViewCell <CFCSettingCoreTableViewCellProtocol>
/**
 * 根容器组件
 */
@property (nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonatomic, strong) UIView *publicContainerView;
/**
 * 标题控件
 */
@property (nonatomic, strong) UILabel *titleLabel;
/**
 * 内容控件
 */
@property (nonatomic, strong) UILabel *contentLabel;
/**
 * 箭头控件
 */
@property (nonatomic, strong) UIImageView *arrowImageView;
/**
 * 选择控件
 */
@property (nonatomic, strong) CFCSwitch *switchButton;
/**
 * 分割线控件
 */
@property (nonatomic, strong) UIView *separatorLineView;
/**
 * 数据模型
 */
@property (nonatomic, strong) CFCSettingCoreModel *model;

/**
 * 表格代理
 */
@property (nonatomic, weak) id<CFCSettingCoreTableViewCellDelegate> delegate;


@end

NS_ASSUME_NONNULL_END
