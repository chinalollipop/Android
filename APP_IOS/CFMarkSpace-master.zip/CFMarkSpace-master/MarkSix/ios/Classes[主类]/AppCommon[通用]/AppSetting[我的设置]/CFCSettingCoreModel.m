

#import "CFCSettingCoreModel.h"

@implementation CFCSettingCoreModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           };
}

+ (NSMutableArray *) buildingDataModles
{
  NSMutableArray<NSMutableArray *> *modelGroups = [NSMutableArray array];
  {
    NSArray *titles = @[
                        @[ @"密码设置", @"清除缓存" ],
                        @[ @"刷新声音", @"WIFI网络自动下载", @"使用2G/3G/4G网络下载" ],
                        @[ @"用户协议", @"当前版本" ],
                        @[ @"退出登录" ]
                        ];
    NSArray *contents = @[
                          @[ @"", @"" ],
                          @[ @"", @"", @"" ],
                          @[ @"", [NSString stringWithFormat:@"V %@", APP_VERSION] ],
                          @[ @"" ]
                          ];
    NSArray *markIds = @[
                         @[ @"", @"" ],
                         @[ @"", @"", @"" ],
                         @[ @"", @"" ],
                         @[ @"" ]
                         ];
    NSArray *isEdits = @[
                         @[ [NSNumber numberWithBool:YES], [NSNumber numberWithBool:YES] ],
                         @[ [NSNumber numberWithBool:NO], [NSNumber numberWithBool:NO], [NSNumber numberWithBool:NO] ],
                         @[ [NSNumber numberWithBool:YES], [NSNumber numberWithBool:YES] ],
                         @[ [NSNumber numberWithBool:NO] ]
                         ];
    NSArray *isSwitchs = @[ @[ [NSNumber numberWithBool:NO], [NSNumber numberWithBool:NO] ],
                            @[ [NSNumber numberWithBool:YES], [NSNumber numberWithBool:YES], [NSNumber numberWithBool:YES] ],
                            @[ [NSNumber numberWithBool:NO], [NSNumber numberWithBool:NO]],
                            @[ [NSNumber numberWithBool:NO] ]
                            ];
    for (int index = 0; index < titles.count; index ++) {
      NSMutableArray<CFCSettingCoreModel *> *models = [NSMutableArray array];
      NSArray *groupTitles = titles[index];
      NSArray *groupContents = contents[index];
      NSArray *groupMarkIds = markIds[index];
      NSArray *groupEdits = isEdits[index];
      NSArray *groupSwitchs = isSwitchs[index];
      for (int k = 0; k < groupTitles.count; k ++) {
        CFCSettingCoreModel *model = [[CFCSettingCoreModel alloc] init];
        [model setMarkId:groupMarkIds[k]];
        [model setTitle:groupTitles[k]];
        [model setContent:groupContents[k]];
        [model setIsEdit:[groupEdits[k] boolValue]];
        [model setIsSwitch:[groupSwitchs[k] boolValue]];
        [models addObject:model];
      }
      [modelGroups addObject:models];
    }
  }
  
  return modelGroups;
}


@end
