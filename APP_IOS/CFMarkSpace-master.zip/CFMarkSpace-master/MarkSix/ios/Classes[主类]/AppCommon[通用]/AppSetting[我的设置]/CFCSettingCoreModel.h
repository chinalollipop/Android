

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCSettingCoreModel : NSObject

@property (nonatomic, copy) NSString *markId; // 标识
@property (nonatomic, copy) NSString *title; // 标题
@property (nonatomic, copy) NSString *content; // 文字内容
@property (nonatomic, assign) BOOL isEdit; // 是否可编辑
@property (nonatomic, assign) BOOL isSwitch; // 是否为UISwitch

+ (NSMutableArray *) buildingDataModles;

@end

NS_ASSUME_NONNULL_END
