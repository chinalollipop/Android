//
// 开奖记录 - 记录列表 - 详情信息
//

#import <UIKit/UIKit.h>
@class CFCDrawResultRecordDetailModel;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_DRAW_RESULT_RECORD_DETAIL_IDENTIFIER;

@interface CFCDrawResultRecordDetailTableViewCell : UITableViewCell

@property (nonatomic, strong) CFCDrawResultRecordDetailModel *model;

@end

NS_ASSUME_NONNULL_END
