//
// 开奖记录 - 分组头部
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCDrawResultRecordSectionHeaderModel : NSObject

@property (nonatomic, copy) NSString *year;
@property (nonatomic, assign) BOOL isSortDesc; // 是否降序显示
@property (nonatomic, assign) BOOL isShowWuXing; // 是否显示五行

@end

NS_ASSUME_NONNULL_END
