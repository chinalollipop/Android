//
// 开奖记录 - 记录列表 - 详情信息
//

#import "CFCDrawResultRecordDetailTableViewCell.h"
#import "CFCDrawResultRecordDetailModel.h"

// Cell Identifier
NSString * const CELL_IDENTIFIER_DRAW_RESULT_RECORD_DETAIL_IDENTIFIER = @"CFCDrawResultRecordDetailTableViewCellIdentifier";

@interface CFCDrawResultRecordDetailTableViewCell ()

/**
 * 根容器
 */
@property (nonnull, nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonnull, nonatomic, strong) UIView *publicContainerView;
/**
 * 日期图片
 */
@property (nonnull, nonatomic, strong) UIImageView *calendarImageView;
/**
 * 当前期号
 */
@property (nonnull, nonatomic, strong) UILabel *issueCurrentLabel;
/**
 * 特码单双
 */
@property (nonnull, nonatomic, strong) UILabel *teMaDanShuangLabel;
/**
 * 特码大小
 */
@property (nonnull, nonatomic, strong) UILabel *teMaDaXiaoLabel;
/**
 * 总和大小
 */
@property (nonnull, nonatomic, strong) UILabel *zongHeDaXiaoLabel;
/**
 * 总和单双
 */
@property (nonnull, nonatomic, strong) UILabel *zongHeDanShuangLabel;
/**
 * 开奖结果
 */
@property (nonnull, nonatomic, strong) NSMutableArray<UILabel *> *itemNumLabelArray;
@property (nonnull, nonatomic, strong) NSMutableArray<UIImageView *> *itemImageViewArray;
@property (nonnull, nonatomic, strong) NSMutableArray<UILabel *> *itemShengXiaoLabelArray;

@end

@implementation CFCDrawResultRecordDetailTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
  if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
    [self createViewAtuoLayout];
  }
  return self;
}

#pragma mark 创建子控件
- (void)createViewAtuoLayout
{
  WEAKSELF(weakSelf);
  
  // 定义变量
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  
  // 根容器组件
  UIView *rootContainerView = ({
    UIView *view = [[UIView alloc] init];
    [self.contentView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(@0);
      make.left.equalTo(@0);
      make.right.equalTo(@0);
      make.bottom.equalTo(weakSelf.contentView.mas_bottom).with.offset(0);
    }];
    
    view;
  });
  self.rootContainerView = rootContainerView;
  self.rootContainerView.mas_key = @"rootContainerView";
  
  // 公共容器
  UIView *publicContainerView = ({
    UIView *view = [[UIView alloc] init];
    [view.layer setMasksToBounds:YES];
    [self.rootContainerView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(@0);
      make.left.equalTo(@0);
      make.right.equalTo(@0);
      make.bottom.equalTo(weakSelf.rootContainerView.mas_bottom).offset(0);
    }];
    
    view;
  });
  self.publicContainerView = publicContainerView;
  self.publicContainerView.mas_key = @"publicContainerView";
  
  // 日历图片
  UIImageView *calendarImageView = ({
    UIImageView *imageView = [UIImageView new];
    [self.publicContainerView addSubview:imageView];
    [imageView setImage:[UIImage imageNamed:ICON_CALENDAR]];
    [imageView setContentMode:UIViewContentModeScaleAspectFit];
    
    CGFloat imageSize = CFC_AUTOSIZING_WIDTH(14.0f);
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(publicContainerView.mas_top).offset(margin*1.0f);
      make.left.equalTo(publicContainerView.mas_left).offset(margin*1.5f);
      make.size.mas_equalTo(CGSizeMake(imageSize, imageSize));
    }];
    
    imageView;
  });
  self.calendarImageView = calendarImageView;
  self.calendarImageView.mas_key = [NSString stringWithFormat:@"calendarImageView"];
  
  // 当前期号
  UILabel *issueCurrentLabel = ({
    UILabel *label = [UILabel new];
    [self.publicContainerView addSubview:label];
    [label setNumberOfLines:0];
    [label setText:STR_APP_TEXT_PLACEHOLDER];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    [label setTextAlignment:NSTextAlignmentLeft];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(13.0f)]];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(calendarImageView.mas_centerY);
      make.left.equalTo(calendarImageView.mas_right).offset(margin*0.5f);
      make.right.equalTo(publicContainerView.mas_right).offset(-margin*2.5f);
    }];
    
    label;
  });
  self.issueCurrentLabel = issueCurrentLabel;
  self.issueCurrentLabel.mas_key = @"issueCurrentLabel";
  
  // 开奖结果
  int colum = 8;
  CGFloat left_gap = margin * 3.0f;
  CGFloat right_gap = margin * 3.0f;
  CGFloat itemMargin = margin * 1.6f;
  CGFloat itemWidth = (SCREEN_WIDTH - left_gap - right_gap - itemMargin*(colum-3)) / colum;
  CGFloat itemHeight = itemWidth * 2.0f;
  CGFloat imageSize = itemWidth;
  UIFont *autoNumberFont = [UIFont fontWithName:@"NotoMono" size:CFC_AUTOSIZING_FONT(15)];
  UIFont *autoShengXiaoFont = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(14.0f)];
  UIColor *autoNumbeColor = COLOR_SYSTEM_MAIN_FONT_DEFAULT;
  UIColor *autoShengXiaoColor = COLOR_SYSTEM_MAIN_FONT_DEFAULT;
  
  _itemNumLabelArray = [NSMutableArray array];
  _itemImageViewArray = [NSMutableArray array];
  _itemShengXiaoLabelArray = [NSMutableArray array];
  
  UIView *lastItemView = nil;
  for (int i = 0; i < colum; i ++) {
    
    // 容器
    UIView *itemView = ({
      UIView *itemContainerView = [[UIView alloc] init];
      [publicContainerView addSubview:itemContainerView];
      [itemContainerView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@(itemWidth));
        make.height.equalTo(@(itemHeight));
        
        if (!lastItemView) {
          make.top.equalTo(issueCurrentLabel.mas_bottom).offset(margin*1.25f);
          make.left.equalTo(publicContainerView.mas_left).offset(left_gap);
        } else {
          if (i < colum - 2) {
            make.top.equalTo(lastItemView.mas_top).offset(0);
            make.left.equalTo(lastItemView.mas_right).offset(itemMargin);
          } else {
            make.top.equalTo(lastItemView.mas_top);
            make.left.equalTo(lastItemView.mas_right);
          }
        }
      }];
      itemContainerView.mas_key = [NSString stringWithFormat:@"itemContainerView%d",i];
      
      // 图片
      UIImageView *iconImageView = ({
        UIImageView *imageView = [UIImageView new];
        [itemContainerView addSubview:imageView];
        [imageView setContentMode:UIViewContentModeScaleAspectFit];
        
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
          make.top.equalTo(itemContainerView.mas_top).offset(0.0f);
          make.centerX.equalTo(itemContainerView.mas_centerX).offset(0.0f);
          make.height.equalTo(@(imageSize));
          make.width.equalTo(@(imageSize));
        }];
        
        imageView;
      });
      iconImageView.mas_key = [NSString stringWithFormat:@"iconImageView%d", i];
      
      // 号码
      UILabel *numberLabel = ({
        UILabel *label = [UILabel new];
        [itemContainerView addSubview:label];
        [label setFont:autoNumberFont];
        [label setTextColor:autoNumbeColor];
        [label setTextAlignment:NSTextAlignmentLeft];
        
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
          make.top.equalTo(iconImageView.mas_top).offset(imageSize*0.17f);
          make.left.equalTo(itemContainerView.mas_left).offset(imageSize*0.20);
        }];
        
        label;
      });
      numberLabel.mas_key = [NSString stringWithFormat:@"numberLabel%d", i];
      
      // 生肖
      UILabel *shengXiaoLabel = ({
        UILabel *label = [UILabel new];
        [itemContainerView addSubview:label];
        [label setFont:autoShengXiaoFont];
        [label setTextColor:autoShengXiaoColor];
        [label setTextAlignment:NSTextAlignmentCenter];
        
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
          make.centerX.equalTo(itemContainerView.mas_centerX);
          make.top.equalTo(iconImageView.mas_bottom).offset(margin*1.0f);
        }];
        
        label;
      });
      shengXiaoLabel.mas_key = [NSString stringWithFormat:@"shengXiaoLabel%d", i];
      
      // 保存控件
      [_itemNumLabelArray addObject:numberLabel];
      [_itemImageViewArray addObject:iconImageView];
      [_itemShengXiaoLabelArray addObject:shengXiaoLabel];
      
      itemContainerView;
    });
    
    lastItemView = itemView;
  }
  
  // 底部的分割线
  UIView *separatorLineView = ({
    UIView *view = [[UIView alloc] init];
    [self.publicContainerView addSubview:view];
    [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(lastItemView.mas_bottom).offset(margin*1.0f);
      make.left.equalTo(self.publicContainerView.mas_left);
      make.right.equalTo(self.publicContainerView.mas_right);
      make.height.equalTo(@(margin));
    }];
    
    view;
  });
  separatorLineView.mas_key = @"separatorLineView";
  
  // 特码单双 - 总和大小
  UILabel *lastTeMaSumLabel = nil;
  {
    CGFloat height = margin*4.0f;
    UIFont *autoTeMaSumFont = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(14.0f)];
    
    // 特码单双
    UILabel *teMaDanShuangLabel = ({
      UILabel *label = [UILabel new];
      [self.publicContainerView addSubview:label];
      [label setText:STR_APP_TEXT_PLACEHOLDER];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setTextAlignment:NSTextAlignmentLeft];
      [label setFont:autoTeMaSumFont];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(separatorLineView.mas_bottom);
        make.left.equalTo(publicContainerView.mas_left).offset(margin*1.5f);
        make.right.equalTo(publicContainerView.mas_centerX).offset(-SEPARATOR_LINE_HEIGHT/2.0f);
        make.height.mas_equalTo(height);
      }];
      
      label;
    });
    self.teMaDanShuangLabel = teMaDanShuangLabel;
    self.teMaDanShuangLabel.mas_key = @"teMaDanShuangLabel";
    
    // 特码大小
    UILabel *teMaDaXiaoLabel = ({
      UILabel *label = [UILabel new];
      [self.publicContainerView addSubview:label];
      [label setText:STR_APP_TEXT_PLACEHOLDER];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setTextAlignment:NSTextAlignmentLeft];
      [label setFont:autoTeMaSumFont];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(teMaDanShuangLabel.mas_top);
        make.left.equalTo(teMaDanShuangLabel.mas_right).offset(margin+SEPARATOR_LINE_HEIGHT/2.0f);
        make.right.equalTo(publicContainerView.mas_right);
        make.height.mas_equalTo(height);
      }];
      
      label;
    });
    self.teMaDaXiaoLabel = teMaDaXiaoLabel;
    self.teMaDaXiaoLabel.mas_key = @"teMaDaXiaoLabel";
    
    // 总和大小
    UILabel *zongHeDaXiaoLabel = ({
      UILabel *label = [UILabel new];
      [self.publicContainerView addSubview:label];
      [label setText:STR_APP_TEXT_PLACEHOLDER];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setTextAlignment:NSTextAlignmentLeft];
      [label setFont:autoTeMaSumFont];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(teMaDanShuangLabel.mas_bottom).offset(SEPARATOR_LINE_HEIGHT);
        make.left.equalTo(teMaDanShuangLabel.mas_left);
        make.right.equalTo(teMaDanShuangLabel.mas_right);
        make.height.mas_equalTo(height);
      }];
      
      label;
    });
    self.zongHeDaXiaoLabel = zongHeDaXiaoLabel;
    self.zongHeDaXiaoLabel.mas_key = @"zongHeDaXiaoLabel";
    
    // 总和单双
    UILabel *zongHeDanShuangLabel = ({
      UILabel *label = [UILabel new];
      [self.publicContainerView addSubview:label];
      [label setText:STR_APP_TEXT_PLACEHOLDER];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setTextAlignment:NSTextAlignmentLeft];
      [label setFont:autoTeMaSumFont];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(zongHeDaXiaoLabel.mas_top);
        make.left.equalTo(teMaDaXiaoLabel.mas_left);
        make.right.equalTo(teMaDaXiaoLabel.mas_right);
        make.height.mas_equalTo(height);
      }];
      
      label;
    });
    self.zongHeDanShuangLabel = zongHeDanShuangLabel;
    self.zongHeDanShuangLabel.mas_key = @"zongHeDanShuangLabel";
    
    // 水平分割线
    UIView *separatorLineViewH = ({
      UIView *view = [[UIView alloc] init];
      [self.publicContainerView addSubview:view];
      [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
      
      [view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(teMaDanShuangLabel.mas_bottom);
        make.left.equalTo(publicContainerView.mas_left);
        make.right.equalTo(publicContainerView.mas_right);
        make.height.mas_equalTo(SEPARATOR_LINE_HEIGHT);
      }];
      
      view;
    });
    separatorLineViewH.mas_key = @"separatorLineViewH";
    
    // 垂直分割线
    UIView *separatorLineViewV = ({
      UIView *view = [[UIView alloc] init];
      [self.publicContainerView addSubview:view];
      [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
      
      [view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(teMaDanShuangLabel.mas_top);
        make.bottom.equalTo(zongHeDaXiaoLabel.mas_bottom);
        make.centerX.equalTo(publicContainerView.mas_centerX);
        make.width.mas_equalTo(SEPARATOR_LINE_HEIGHT);
      }];
      
      view;
    });
    separatorLineViewV.mas_key = @"separatorLineViewV";
    
    // 最后一个控件
    lastTeMaSumLabel = zongHeDanShuangLabel;
  }

  // 约束完整性
  [self.publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
    make.bottom.equalTo(lastTeMaSumLabel.mas_bottom).offset(margin*0.0f).priority(749);
  }];
  
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCDrawResultRecordDetailModel *)model
{
  // 类型安全检查
  if (![model isKindOfClass:[CFCDrawResultRecordDetailModel class]]) {
    return;
  }
  
  _model = model;
  
  // 当前期号
  NSDate *datetime = [CFCDateUtil secondToDate:self.model.date.doubleValue];
  NSString *dateTimeString = [CFCDateUtil dateFormattingWithDate:datetime toFormate:@"yyyy年MM月dd日"];
  NSString *issueCurrentString = [NSString stringWithFormat:@"%@ 第%@期", dateTimeString, self.model.issue];
  [self.issueCurrentLabel setText:issueCurrentString];
  
  // 特码单双
  NSString *teMaDanShuang = (1 == self.model.special_single_double.integerValue ? @"双" : @"单");
  NSString *teMaDanShuangString = [NSString stringWithFormat:@"特码单双：%@", teMaDanShuang];
  [self.teMaDanShuangLabel setText:teMaDanShuangString];
  
  // 特码大小
  NSString *teMaDaXiao = (1 == self.model.special_big_small.integerValue ? @"小" : @"大" );
  NSString *teMaDaXiaoString = [NSString stringWithFormat:@"特码大小：%@", teMaDaXiao];
  [self.teMaDaXiaoLabel setText:teMaDaXiaoString];
  
  // 总和大小
  NSString *zongHeDaXiao = (1 == self.model.sum_big_small.integerValue ? @"小" : @"大");
  NSString *zongHeDaXiaoString = [NSString stringWithFormat:@"总和大小：%@", zongHeDaXiao];
  [self.zongHeDaXiaoLabel setText:zongHeDaXiaoString];
  
  // 总和单双
  NSString *zongHeDanShuang = (1 == self.model.sum_single_double.integerValue ? @"双" : @"单");
  NSString *zongHeDanShuangString = [NSString stringWithFormat:@"总和单双：%@", zongHeDanShuang];
  [self.zongHeDanShuangLabel setText:zongHeDanShuangString];
  
  // 开奖号码
  NSArray<NSString *> *itemNumber = [self.model.data split:@","];
  NSArray<NSString *> *itemColors = [self.model.color split:@","];
  NSArray<NSString *> *itemWXNumbers = [self.model.wx split:@","];
  NSArray<NSString *> *itemShengXiao = [CFCAppGameUtil getChinaShengXiaoByNumberArray:itemNumber];
  for (int idx = 0; idx < self.itemImageViewArray.count; idx ++) {
    
    UILabel *itemNumberLabel = self.itemNumLabelArray[idx];
    UIImageView *itemImageView = self.itemImageViewArray[idx];
    UILabel *itemShengXiaoLabel = self.itemShengXiaoLabelArray[idx];
    
    if (itemNumber.count == idx + 1) {
      [itemNumberLabel setText:STR_APP_TEXT_EMPTY];
      [itemShengXiaoLabel setText:STR_APP_TEXT_EMPTY];
      [itemImageView setImage:[UIImage imageNamed:ICON_OPEN_RESULT_PLUS]];
      [itemImageView setTransform:CGAffineTransformMakeScale(0.5f,0.5f)];
    } else {
      // 号码
      NSString *number_value = idx < itemNumber.count ? itemNumber[idx] : itemNumber.lastObject;
      [itemNumberLabel setText:[NSString stringWithFormat:@"%02ld", number_value.integerValue]];
      // 图片
      NSString *image_name_value = idx < itemNumber.count ? itemColors[idx] : itemColors.lastObject;
      [itemImageView setImage:[UIImage imageNamed:[CFCAppGameUtil getIconImageNameByNumber:image_name_value]]];
      // 生肖
      NSString *sheng_xiao_value = idx < itemNumber.count ? itemShengXiao[idx] : itemShengXiao.lastObject;
      [itemShengXiaoLabel setText:[CFCSysUtil stringByTrimmingWhitespaceAndNewline:sheng_xiao_value]];
      // 五行
      if (self.model.isShowWuXing) {
        NSString *wu_xing_num = idx < itemWXNumbers.count ? itemWXNumbers[idx] : itemWXNumbers.lastObject;
        NSString *wu_xing_value = [CFCAppGameUtil getWuXingNameByNumber:wu_xing_num];
        [itemShengXiaoLabel setText:[NSString stringWithFormat:@"%@/%@",
                                     [CFCSysUtil stringByTrimmingWhitespaceAndNewline:sheng_xiao_value],
                                     [CFCSysUtil stringByTrimmingWhitespaceAndNewline:wu_xing_value]]];
      }
    }
    
  } // for (int idx = 0; idx < self.itemImageViewArray.count; idx ++)
  
}


@end



