//
// 开奖记录 - 主控制器
//

#import "CFCCommonTabPagerViewController.h"
@protocol CFCDrawResultPagerViewControllerProtocol;


NS_ASSUME_NONNULL_BEGIN

@interface CFCDrawResultPagerViewController : CFCCommonTabPagerViewController
@property (nonatomic, weak) id<CFCDrawResultPagerViewControllerProtocol> delegate_record;
@end


@protocol CFCDrawResultPagerViewControllerProtocol <NSObject>
@required
- (NSString *)yearOfDrawResultRecordFromRecordViewController;
- (void)doRefreshDrawResultRecordToRecordViewControllerByYear:(NSString *)year animated:(BOOL)animated;
@end


NS_ASSUME_NONNULL_END

