//
// 开奖记录 - 记录列表 - 推荐号码
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCDrawResultRecordSuggestModel : NSObject

@property (nonatomic, copy) NSString *year;
@property (nonatomic, copy) NSString *issue;
@property (nonatomic, copy) NSString *datetime;
@property (nonatomic, copy) NSString *content;

@end

NS_ASSUME_NONNULL_END
