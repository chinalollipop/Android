

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCDrawResultRecordYearsModel : NSObject

@property (nonatomic, strong) NSNumber *uuid;
@property (nonatomic, strong) NSNumber *year;

@end

NS_ASSUME_NONNULL_END
