//
// 开奖记录 - 记录列表 - 详情信息
//

#import "CFCDrawResultRecordDetailViewController.h"
#import "CFCDrawResultRecordDetailTableViewCell.h"
#import "CFCDrawResultRecordDetailModel.h"
#import "CFCDrawResultRecordSuggestTableViewCell.h"
#import "CFCDrawResultRecordSuggestModel.h"

@interface CFCDrawResultRecordDetailViewController ()

@end

@implementation CFCDrawResultRecordDetailViewController


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    self.hasCacheData = YES;
    self.hasRefreshHeader = NO;
    self.hasRefreshFooter = NO;
  }
  return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_DRAWRESULT_RECORD_DETAIL;
}


#pragma mark -
#pragma mark 请求地址
- (NSString *)getRequestURLString
{
  return URL_API_DRAW_RESULT_RECORD_DETAIL;
}

#pragma mark 请求参数
- (NSMutableDictionary *)getRequestParamerter
{
  NSDate *datetime = [CFCDateUtil secondToDate:self.drawResultRecord.date.doubleValue];
  NSString *year = [CFCDateUtil dateFormattingWithDate:datetime toFormate:@"yyyy"];
  return [CFCNetworkParamsUtil getDrawResultRecordDetailParameters:year issue:self.drawResultRecord.issue];
}

#pragma mark 请求网络数据或加载缓存
- (NSMutableArray *)loadNetworkDataOrCacheDataSingle:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData
{
  WEAKSELF(weakSelf);
  
  NSDictionary *responseData = (NSDictionary *)responseDataOrCacheData;
  CFCLog(@"[本期开奖查询][%@] => %@\n", CFC_DATA_TYPE(isCacheData), responseData);
  
  // 请求成功，解析数据
  NSDictionary *data = [responseData objectForKey:CFC_REQUEST_KEY_DATA];
  NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
  if (![CFCSysUtil validateResultCodeIsSuccess:status] || [CFCSysUtil validateObjectIsNull:data]) {
    return [NSMutableArray array];
  }
  
  
  /////////////////////////////////////////////////////////////////
  // A、组装数据 -> 开始
  /////////////////////////////////////////////////////////////////
  
  NSMutableArray<CFCDrawResultRecordDetailModel *> *allDrawResultRecordModels = [NSMutableArray<CFCDrawResultRecordDetailModel *> array];
  [data[@"open"] enumerateObjectsUsingBlock:^(NSDictionary *  _Nonnull dict, NSUInteger idx, BOOL * _Nonnull stop) {
    CFCDrawResultRecordDetailModel *itemModel = [CFCDrawResultRecordDetailModel mj_objectWithKeyValues:dict];
    [itemModel setIsShowWuXing:[NSNumber numberWithBool:YES]];
    [allDrawResultRecordModels addObject:itemModel];
  }];
  
  NSMutableArray<CFCDrawResultRecordSuggestModel *> *allDrawResultSuggestModels = [NSMutableArray<CFCDrawResultRecordSuggestModel *> array];
  [data[@"info"] enumerateObjectsUsingBlock:^(NSDictionary *  _Nonnull dict, NSUInteger idx, BOOL * _Nonnull stop) {
    CFCDrawResultRecordSuggestModel *itemModel = [CFCDrawResultRecordSuggestModel mj_objectWithKeyValues:dict];
    [allDrawResultSuggestModels addObject:itemModel];
  }];
  
  /////////////////////////////////////////////////////////////////
  // A、组装数据 -> 结束
  /////////////////////////////////////////////////////////////////
  
  
  /////////////////////////////////////////////////////////////////
  // B、配置数据源  -> 开始
  /////////////////////////////////////////////////////////////////
  
  // 初始化数据源
  weakSelf.tableDataRefresh = [NSMutableArray array];
  if (allDrawResultRecordModels && 0 < allDrawResultRecordModels.count) {
    [weakSelf.tableDataRefresh addObject:allDrawResultRecordModels.mutableCopy];
  }
  if (allDrawResultSuggestModels && 0 < allDrawResultSuggestModels.count) {
    [weakSelf.tableDataRefresh addObject:allDrawResultSuggestModels.mutableCopy];
  }
  /////////////////////////////////////////////////////////////////
  // B、配置数据源  -> 结束
  /////////////////////////////////////////////////////////////////
  
  return weakSelf.tableDataRefresh;
}


#pragma mark -
#pragma mark 注册 UITableViewCell
- (void)tableViewRefreshRegisterClass:(UITableView *)tableView
{
  [self.tableViewRefresh registerClass:[CFCDrawResultRecordDetailTableViewCell class]
                forCellReuseIdentifier:CELL_IDENTIFIER_DRAW_RESULT_RECORD_DETAIL_IDENTIFIER];
  
  [self.tableViewRefresh registerClass:[CFCDrawResultRecordSuggestTableViewCell class]
                forCellReuseIdentifier:CELL_IDENTIFIER_DRAW_RESULT_RECORD_SUGGEST_IDENTIFIER];
}


#pragma mark -
#pragma mark UITableViewDelegate UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0) {
    return self.tableDataRefresh.count;
  }
  return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0 && self.tableDataRefresh.count > section) {
    if ([self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
      NSMutableArray *group = self.tableDataRefresh[section];
      if ([group isKindOfClass:[NSArray class]]) {
        return group.count;
      }
    }
  }
  return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  switch (indexPath.section) {
      // 详细信息
    case CFCDrawResultRecordDetailTableSectionDetail: {
      CFCDrawResultRecordDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_DRAW_RESULT_RECORD_DETAIL_IDENTIFIER];
      if (!cell) {
        cell = [[CFCDrawResultRecordDetailTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_DRAW_RESULT_RECORD_DETAIL_IDENTIFIER];
      }
      cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
      cell.selectionStyle = UITableViewCellSelectionStyleNone;
      return cell;
    }
      // 推荐号码
    case CFCDrawResultRecordDetailTableSectionSuggest: {
      CFCDrawResultRecordSuggestTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_DRAW_RESULT_RECORD_SUGGEST_IDENTIFIER];
      if (!cell) {
        cell = [[CFCDrawResultRecordSuggestTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_DRAW_RESULT_RECORD_SUGGEST_IDENTIFIER];
      }
      cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
      cell.selectionStyle = UITableViewCellSelectionStyleNone;
      return cell;
    }
      // 默认设置
    default: {
      return nil;
    }
  }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  switch (indexPath.section) {
      // 详细信息
    case CFCDrawResultRecordDetailTableSectionDetail: {
      return [self.tableViewRefresh fd_heightForCellWithIdentifier:CELL_IDENTIFIER_DRAW_RESULT_RECORD_DETAIL_IDENTIFIER cacheByIndexPath:indexPath configuration:^(CFCDrawResultRecordDetailTableViewCell *cell) {
        cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
      }];
    }
      // 推荐号码
    case CFCDrawResultRecordDetailTableSectionSuggest: {
      return [self.tableViewRefresh fd_heightForCellWithIdentifier:CELL_IDENTIFIER_DRAW_RESULT_RECORD_SUGGEST_IDENTIFIER cacheByIndexPath:indexPath configuration:^(CFCDrawResultRecordSuggestTableViewCell *cell) {
        cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
      }];
    }
      // 默认设置
    default: {
      return FLOAT_MIN;
    }
  }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableViewRefresh.frame.size.width, CFC_AUTOSIZING_MARGIN(MARGIN))];
  return headerView;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableViewRefresh.frame.size.width, CFC_AUTOSIZING_MARGIN(MARGIN))];
  [footerView setBackgroundColor:COLOR_TABLEVIEW_FOOTER_VIEW_BACKGROUND_DEFAULT];
  return footerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return FLOAT_MIN;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return FLOAT_MIN;
}


@end

