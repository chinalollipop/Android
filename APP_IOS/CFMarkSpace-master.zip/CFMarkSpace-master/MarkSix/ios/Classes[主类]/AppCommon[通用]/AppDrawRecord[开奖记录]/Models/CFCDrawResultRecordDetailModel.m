//
// 开奖记录 - 记录列表 - 详情信息
//

#import "CFCDrawResultRecordDetailModel.h"

@implementation CFCDrawResultRecordDetailModel

@end
