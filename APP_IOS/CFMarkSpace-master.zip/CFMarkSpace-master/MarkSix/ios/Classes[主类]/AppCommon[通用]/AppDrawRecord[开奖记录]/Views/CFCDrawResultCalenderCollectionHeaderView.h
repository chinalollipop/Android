//
// 开奖记录 - 记录列表 - 开奖日期
//

#import <UIKit/UIKit.h>
@class CFCDrawResultCalenderModel;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN CGFloat const HEIGHT_DRAW_RESULT_CALENDER_COLLECTION_SECTION_HEADER;

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_RESULT_CALENDER_COLLECTION_SECTION_HEADER;

@protocol CFCDrawResultCalenderCollectionHeaderViewDelegate <NSObject>
@optional
- (void)doLogicPressButtonLastMounthAction;
- (void)doLogicPressButtonNextMounthAction;
@end

@interface CFCDrawResultCalenderCollectionHeaderView : UICollectionReusableView
@property (nonatomic, assign) BOOL isMondayOfWeekFirst;
@property (nonatomic, strong) CFCDrawResultCalenderModel *selectedDateTime;
@property (nonatomic, weak) id<CFCDrawResultCalenderCollectionHeaderViewDelegate> delegate;
@end

NS_ASSUME_NONNULL_END
