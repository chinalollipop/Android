//
// 开奖记录 - 记录列表
//

#import "CFCDrawResultRecordModel.h"

@implementation CFCDrawResultRecordModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"date" : @"date"
           };
}

@end
