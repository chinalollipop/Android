//
// 开奖记录 - 记录列表 - 开奖日期
//

#import <UIKit/UIKit.h>
@class CFCDrawResultCalenderModel;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_RESULT_CALENDER_COLLECTION_VIEW_CELL;

@interface CFCDrawResultCalenderCollectionViewCell : UICollectionViewCell

@property (nonatomic, strong) CFCDrawResultCalenderModel *model;

@end

NS_ASSUME_NONNULL_END
