//
// 开奖记录 - 主控制器
//

#import "CFCDrawResultPagerViewController.h"
#import "CFCDrawResultRecordViewController.h"
#import "CFCDrawRecordYearPickerView.h"
#import "CFCDrawResultRecordYearsModel.h"

#define DRAWRESULT_TAB_UUID_RECORD                                   @"0"
#define DRAWRESULT_TAB_UUID_CALENDER                                 @"1"
#define DRAWRESULT_TAB_CODE_RECORD                                   @"RECORD"
#define DRAWRESULT_TAB_CODE_CALENDER                                 @"CALENDER"
#define DRAWRESULT_TAB_NAME_RECORD                                   @"开奖记录"
#define DRAWRESULT_TAB_NAME_CALENDER                                 @"开奖日期"

@interface CFCDrawResultPagerViewController ()

@property(nonatomic, strong) NSMutableArray<CFCDrawResultRecordYearsModel *> *drawResultRecordYears;

@end

@implementation CFCDrawResultPagerViewController


#pragma mark -
#pragma mark 事件处理 - 选择年份事件
- (void)pressNavigationBarRightButtonItem:(id)sender
{
  // 默认选中年份
  NSString *year = [NSString stringWithFormat:@"%ld", [NSDate new].year];
  if (self.delegate_record && [self.delegate_record respondsToSelector:@selector(yearOfDrawResultRecordFromRecordViewController)]) {
    year = [self.delegate_record yearOfDrawResultRecordFromRecordViewController];
  } else {
    NSAssert(NO, @"[CFCDrawResultRecordViewController]类必须实现代理方法[yearOfDrawResultRecordFromRecordViewController]");
  }
  
  // 显示选择视图
  WEAKSELF(weakSelf);
  UIWindow *window = [UIApplication sharedApplication].keyWindow;
  CFCDrawRecordYearPickerView *pickerView = [[CFCDrawRecordYearPickerView alloc] initWithFrame:window.frame
                                                                                    dataSource:self.drawResultRecordYears
                                                                                 selectedValue:year];
  [pickerView setSelectedBlock:^(CFCDrawResultRecordYearsModel *selectedValue) {
    if (weakSelf.delegate_record && [weakSelf.delegate_record respondsToSelector:@selector(doRefreshDrawResultRecordToRecordViewControllerByYear:animated:)]) {
      [weakSelf.delegate_record doRefreshDrawResultRecordToRecordViewControllerByYear:selectedValue.year.stringValue animated:YES];
    } else {
      NSAssert(NO, @"[CFCDrawResultRecordViewController]类必须实现代理方法[doRefreshDrawResultRecordToRecordViewControllerByYear:animated:]");
    }
  }];
  [window addSubview:pickerView];
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_DRAWRESULT_TAB_PAGER;
}

#pragma mark 导航栏右边按钮类型
- (CFCNavBarButtonItemType)prefersNavigationBarRightButtonItemType
{
  return CFCNavBarButtonItemTypeCustom;
}

#pragma mark 导航栏右边按钮标题
- (NSString *)prefersNavigationBarRightButtonItemTitle
{
  return @"选择年份";
}

#pragma mark -
#pragma mark 视图生命周期
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  WEAKSELF(weakSelf);
  [self viewDidLoadNetworkDataSourceOfYearThen:^(BOOL success, NSUInteger count) {
    [weakSelf viewDidLoadNetworkDataSourceOfYearThenAfterSuccess];
  }];
}

#pragma mark 初始化默认标签数据
- (BOOL)viewDidLoadWithDataSource
{
  [super viewDidLoadWithDataSource];
  
  self.tabPagerIds = @[ DRAWRESULT_TAB_UUID_RECORD, DRAWRESULT_TAB_UUID_CALENDER ];
  self.tabPagerCodes = @[ DRAWRESULT_TAB_CODE_RECORD, DRAWRESULT_TAB_CODE_CALENDER ];
  self.tabPagerTitles = @[ DRAWRESULT_TAB_NAME_RECORD, DRAWRESULT_TAB_NAME_CALENDER ];
  self.tabPagerViewControllers = @[ @"CFCDrawResultRecordViewController", @"CFCDrawResultCalenderViewController" ];
  
  return YES;
}

#pragma mark 加载请求区域标签数据
- (void)viewDidLoadNetworkDataSourceThen:(void (^)(BOOL success, NSUInteger count))then
{
  then(YES,1);
}


#pragma mark -
#pragma mark 年份选择 - 加载请求网络数据成功
- (void)viewDidLoadNetworkDataSourceOfYearThen:(void (^)(BOOL success, NSUInteger count))then
{
  WEAKSELF(weakSelf);
  
  // 请求数据是否成功
  __block BOOL isSuccess = NO;
  __block NSUInteger listCount = 0;
  
  // 请求地址与参数
  NSString *url = URL_API_DRAW_RESULT_RECORD_YEARS;
  NSMutableDictionary *params = [CFCNetworkParamsUtil getDrawResultRecordYearsParameters];
  CFCLog(@"\n请求地址：%@ \n请求参数：%@", url, params);
  
  // 请求网络数据
  [CFCNetworkHTTPSessionUtil GET:url parameters:params success:^(id responseObject) {
    
    // 加载解析网络数据
    NSMutableArray *responseTableData = [weakSelf loadDrawRecordYearsNetworkDataOrCacheData:responseObject isCacheData:NO];
    
    // 更新请求数据状态
    listCount = responseTableData.count;
    if (listCount > 0) {
      isSuccess = YES;
      CFCLog(@"加载请求网络数据成功");
    } else {
      isSuccess = YES;
      CFCLog(@"没有更多网络数据");
    }
    
    // 刷新界面
    then(isSuccess,listCount);
    
  } failure:^(NSError *error) {
    
    CFCLog(@"加载请求网络数据异常：%@", error);
    
    // 刷新界面
    then(isSuccess,listCount);
    
  } showProgressHUD:YES showProgressView:self.view];
}

#pragma mark 年份选择 - 请求网络数据或加载缓存
- (NSMutableArray *)loadDrawRecordYearsNetworkDataOrCacheData:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData
{
  WEAKSELF(weakSelf);
  
  NSDictionary *responseData = (NSDictionary *)responseDataOrCacheData;
  CFCLog(@"[开奖记录年份][%@] => %@\n", CFC_DATA_TYPE(isCacheData), responseData);
  
  // 请求成功，解析数据
  NSDictionary *data = [responseData objectForKey:CFC_REQUEST_KEY_DATA];
  NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
  if (![CFCSysUtil validateResultCodeIsSuccess:status] || [CFCSysUtil validateObjectIsNull:data]) {
    return [NSMutableArray array];
  }
  
  NSMutableArray<CFCDrawResultRecordYearsModel *> *allDrawResultYearsModels = [NSMutableArray<CFCDrawResultRecordYearsModel *> array];
  [data[@"list"] enumerateObjectsUsingBlock:^(NSDictionary *  _Nonnull dict, NSUInteger idx, BOOL * _Nonnull stop) {
    CFCDrawResultRecordYearsModel *itemModel = [CFCDrawResultRecordYearsModel mj_objectWithKeyValues:dict];
    [allDrawResultYearsModels addObject:itemModel];
  }];
  
  weakSelf.drawResultRecordYears = [NSMutableArray array];
  if (allDrawResultYearsModels && 0 < allDrawResultYearsModels.count) {
    [weakSelf.drawResultRecordYears addObjectsFromArray:allDrawResultYearsModels];
  }
  
  return weakSelf.drawResultRecordYears;
}

#pragma mark 年份选择 - 加载请求网络数据成功
- (void)viewDidLoadNetworkDataSourceOfYearThenAfterSuccess
{
  if (self.drawResultRecordYears.count > 0) {
    if (self.delegate_record && [self.delegate_record respondsToSelector:@selector(doRefreshDrawResultRecordToRecordViewControllerByYear:animated:)]) {
      CFCDrawResultRecordYearsModel *model = self.drawResultRecordYears.firstObject;
      [self.delegate_record doRefreshDrawResultRecordToRecordViewControllerByYear:model.year.stringValue animated:NO];
    } else {
      NSAssert(NO, @"[CFCDrawResultRecordViewController]类必须实现代理方法[doRefreshDrawResultRecordToRecordViewControllerByYear:animated:]");
    }
  }
}


#pragma mark -
#pragma mark 区域标签 - Tab Pager Data Source
- (NSInteger)tabCountAtOnePage
{
  return 3;
}

- (CFCTabPagerHeaderDirection)tabDirection
{
  return CFCTabPagerHeaderDirectionBottom;
}

- (CGFloat)tabHeight
{
  return TAB_BAR_HEIGHT;
}

- (CGFloat)tabIndicatorHeight
{
  return FLOAT_MIN;
}

- (UIColor *)tabLineColor
{
  return COLOR_DRAWRESULT_SUB_TAB_PAGER_TAB_LINE;
}

- (UIColor *)tabIndicatorColor
{
  return COLOR_DRAWRESULT_SUB_TAB_PAGER_TAB_INDICATOR;
}

- (UIColor *)tabBackgroundColor
{
  return COLOR_DRAWRESULT_SUB_TAB_PAGER_BACKGROUND;
}

- (UIFont *)titleFont
{
  return [UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)];
}

- (UIColor *)titleColor
{
  return COLOR_DRAWRESULT_SUB_TAB_PAGER_TITLE_NORMAL;
}

- (BOOL)selectTabbarIndexAnimation
{
  return NO;
}

- (UIColor *)titleSelectColor
{
  return COLOR_DRAWRESULT_SUB_TAB_PAGER_TITLE_SELECT;
}

- (UIViewController *)viewControllerForIndex:(NSInteger)index
{
  Class myClass = NSClassFromString(self.tabPagerViewControllers[index]);
  CFCBaseCommonViewController *viewController = [[myClass alloc] init];
  if (index < self.tabPagerCodes.count
      && [DRAWRESULT_TAB_CODE_RECORD isEqualToString:self.tabPagerCodes[index]]) {
    CFCDrawResultRecordViewController *recordViewController = (CFCDrawResultRecordViewController *)viewController;
    self.delegate_record = recordViewController;
  }
  return viewController;
}

- (void)tabPager:(CFCTabPagerViewController *)tabPager didTransitionToTabAtIndex:(NSInteger)index viewControllerAtIndex:(UIViewController *)viewController
{
  if (index < self.tabPagerCodes.count
      && [DRAWRESULT_TAB_CODE_RECORD isEqualToString:self.tabPagerCodes[index]]) {
    [self.navigationBarRightButtonItem setHidden:NO];
  } else {
    [self.navigationBarRightButtonItem setHidden:YES];
  }
}


@end


