//
// 开奖记录 - 记录列表 - 详情信息
//

#import "CFCTableRefreshViewController.h"
@class CFCDrawResultRecordModel;

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, CFCDrawResultRecordDetailTableSection) {
  CFCDrawResultRecordDetailTableSectionDetail = 0, // 详细信息
  CFCDrawResultRecordDetailTableSectionSuggest = 1, // 推荐号码
};

@interface CFCDrawResultRecordDetailViewController : CFCTableRefreshViewController

@property (nonatomic, strong) CFCDrawResultRecordModel *drawResultRecord;

@end

NS_ASSUME_NONNULL_END
