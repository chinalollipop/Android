//
// 开奖记录 - 分组头部
//

#import <UIKit/UIKit.h>
@class CFCDrawResultRecordSectionHeaderModel;

NS_ASSUME_NONNULL_BEGIN

#pragma mark 头部高度
UIKIT_EXTERN CGFloat const CONST_DRAW_RESULT_RECORD_SECTION_HEADER_HIGHT;

@protocol CFCDrawResultRecordSectionHeaderDelegate <NSObject>
@optional
- (void)didSelectAtDrawResultRecordSectionHeaderOfSort:(CFCDrawResultRecordSectionHeaderModel *)drawResultModel;
- (void)didSelectAtDrawResultRecordSectionHeaderOfWuXing:(CFCDrawResultRecordSectionHeaderModel *)drawResultModel;
@end

@interface CFCDrawResultRecordSectionHeader : UIView

@property (nonatomic, strong) CFCDrawResultRecordSectionHeaderModel *sectionHeaderModel;

@property (nonatomic, weak) id<CFCDrawResultRecordSectionHeaderDelegate> delegate;

- (instancetype)initWithFrame:(CGRect)frame
                     delegate:(id<CFCDrawResultRecordSectionHeaderDelegate>)delegate
           sectionHeaderModel:(CFCDrawResultRecordSectionHeaderModel *)sectionHeaderModel;

@end

NS_ASSUME_NONNULL_END

