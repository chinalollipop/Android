//
// 开奖记录 - 记录列表 - 推荐号码
//

#import "CFCDrawResultRecordSuggestModel.h"

@implementation CFCDrawResultRecordSuggestModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"year" : @"year",
           @"issue" : @"issue",
           @"datetime" : @"date",
           @"content" : @"data"
           };
}

@end
