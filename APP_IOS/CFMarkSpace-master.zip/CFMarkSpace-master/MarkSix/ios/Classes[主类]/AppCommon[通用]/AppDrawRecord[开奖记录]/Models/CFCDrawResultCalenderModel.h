//
// 开奖记录 - 记录列表 - 开奖日期
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


@interface CFCDrawResultOpenDateModel : NSObject
@property (nonatomic, strong) NSNumber *uuid;
@property (nonatomic, strong) NSNumber *issue;
@property (nonatomic, strong) NSNumber *year;
@property (nonatomic, copy) NSString *datetime;
@end

@interface CFCDrawResultCalenderModel : NSObject
@property (assign, nonatomic) NSInteger dayValue;
@property (assign, nonatomic) BOOL isCurrentDay; // 是否为当天日期
@property (assign, nonatomic) BOOL isSelectedDay; // 是否选中的天数
@property (assign, nonatomic) BOOL isOpenResultDay; // 是否为开奖结果日期
@property (nullable, strong, nonatomic) NSNumber *issue; // 开奖期号
@property (nullable, strong, nonatomic) NSDate *dateValue;
@end




NS_ASSUME_NONNULL_END
