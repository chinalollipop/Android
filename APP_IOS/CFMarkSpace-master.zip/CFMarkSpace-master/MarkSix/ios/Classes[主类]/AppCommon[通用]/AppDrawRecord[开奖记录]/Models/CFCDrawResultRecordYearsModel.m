

#import "CFCDrawResultRecordYearsModel.h"

@implementation CFCDrawResultRecordYearsModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"uuid" : @"id",
           @"year" : @"year"
           };
}

@end
