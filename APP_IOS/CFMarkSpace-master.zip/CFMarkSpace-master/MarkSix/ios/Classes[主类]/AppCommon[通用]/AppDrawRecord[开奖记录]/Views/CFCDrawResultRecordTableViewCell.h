//
// 开奖记录 - 记录列表
//

#import <UIKit/UIKit.h>
@class CFCDrawResultRecordModel;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_DRAW_RESULT_RECORD_IDENTIFIER;

@protocol CFCDrawResultRecordTableViewCellDelegate <NSObject>
@optional
- (void)didSelectRowAtDrawResultRecordModel:(CFCDrawResultRecordModel *)model;
@end

@interface CFCDrawResultRecordTableViewCell : UITableViewCell

@property (nonatomic, strong) CFCDrawResultRecordModel *model;

@property (nonatomic, weak) id<CFCDrawResultRecordTableViewCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
