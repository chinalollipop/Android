//
// 开奖记录 - 记录列表 - 详情信息
//

#import "CFCDrawResultRecordModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCDrawResultRecordDetailModel : CFCDrawResultRecordModel

@end

NS_ASSUME_NONNULL_END
