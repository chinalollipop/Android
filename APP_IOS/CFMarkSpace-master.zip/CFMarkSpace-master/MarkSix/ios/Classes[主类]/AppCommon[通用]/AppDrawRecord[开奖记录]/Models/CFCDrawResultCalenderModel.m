//
// 开奖记录 - 记录列表 - 开奖日期
//


#import "CFCDrawResultCalenderModel.h"

@implementation CFCDrawResultOpenDateModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"uuid" : @"id",
           @"issue" : @"issue",
           @"year" : @"year",
           @"datetime" : @"date"
           };
}

@end


@implementation CFCDrawResultCalenderModel

@end


