
#import "CFCDrawRecordYearPickerView.h"
#import "CFCDrawResultRecordYearsModel.h"

#define PICKERHEIGHT CFC_AUTOSIZING_HEIGTH(185)
#define BGHEIGHT     CFC_AUTOSIZING_HEIGTH(225)

#define KEY_WINDOW_HEIGHT [UIApplication sharedApplication].keyWindow.frame.size.height

@interface CFCDrawRecordYearPickerView () <UIPickerViewDelegate,UIPickerViewDataSource>

@property(nonatomic, strong) UIPickerView * pickerView;

@property(nonatomic, strong) UIView * bgView;

@property(nonatomic, strong) UIView * toolBar;

@property(nonatomic, strong) UIButton * cancleBtn;

@property(nonatomic, strong) UIButton * confirmBtn;

@property(nonatomic, copy) NSString *defaultSelectedYear;

@end

@implementation CFCDrawRecordYearPickerView

#pragma mark -- lazy

- (UIButton *)cancleBtn
{
  if (!_cancleBtn) {
    _cancleBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _cancleBtn.frame = CGRectMake(10, 5, 55, BGHEIGHT - PICKERHEIGHT - 10);
    [_cancleBtn setTitle:@"取消" forState:UIControlStateNormal];
    _cancleBtn.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    _cancleBtn.layer.borderColor = [UIColor whiteColor].CGColor;
    _cancleBtn.layer.borderWidth = 0.5;
    _cancleBtn.layer.cornerRadius = 5;
    _cancleBtn.backgroundColor = COLOR_SYSTEM_MAIN_BUTTON_BACKGROUND_SELECT_DEFAULT;
    [_cancleBtn addTarget:self action:@selector(cancleBtnClick) forControlEvents:UIControlEventTouchUpInside];
  }
  return _cancleBtn;
}

- (UIButton *)confirmBtn
{
  if (!_confirmBtn) {
    _confirmBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _confirmBtn.frame = CGRectMake(self.frame.size.width - 65, 5, 55, BGHEIGHT - PICKERHEIGHT - 10);
    [_confirmBtn setTitle:@"确定" forState:UIControlStateNormal];
    _confirmBtn.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    _confirmBtn.layer.borderColor = [UIColor whiteColor].CGColor;
    _confirmBtn.layer.borderWidth = 0.5;
    _confirmBtn.layer.cornerRadius = 5;
    _confirmBtn.backgroundColor = COLOR_SYSTEM_MAIN_BUTTON_BACKGROUND_SELECT_DEFAULT;
    [_confirmBtn addTarget:self action:@selector(confirmBtnClick) forControlEvents:UIControlEventTouchUpInside];
  }
  return _confirmBtn;
}

- (UIView *)toolBar
{
  if (!_toolBar) {
    _toolBar = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, BGHEIGHT - PICKERHEIGHT)];
    _toolBar.backgroundColor = [UIColor groupTableViewBackgroundColor];
  }
  return _toolBar;
}
- (UIView *)bgView
{
  if (!_bgView) {
    _bgView = [[UIView alloc] initWithFrame:CGRectMake(0, self.frame.size.height , self.frame.size.width, BGHEIGHT)];
    _bgView.backgroundColor = [UIColor whiteColor];
  }
  return _bgView;
}

- (UIPickerView *)pickerView
{
  if (!_pickerView) {
    _pickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, BGHEIGHT - PICKERHEIGHT, self.frame.size.width, PICKERHEIGHT)];
    _pickerView.delegate = self;
    _pickerView.dataSource = self;
  }
  return _pickerView;
}


#pragma mark -- init
- (instancetype)initWithFrame:(CGRect)frame dataSource:(NSArray<CFCDrawResultRecordYearsModel *> *)dataSource selectedValue:(NSString *)selectedValue
{
  if (self = [super initWithFrame:frame]) {
    _dataSource = dataSource;
    _defaultSelectedYear = selectedValue;
    [self initSuViews];
    [self initDefSetting];
  }
  return self;
}

- (void)initDefSetting
{
  __block NSInteger selectedIndex = 0;
  __block CFCDrawResultRecordYearsModel *selectedModel = nil;
  [_dataSource enumerateObjectsUsingBlock:^(CFCDrawResultRecordYearsModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
    if ([self->_defaultSelectedYear isEqualToString:obj.year.stringValue]) {
      selectedIndex = idx;
      selectedModel = obj;
      *stop = YES;
    }
  }];
  [self setSelectedValue:selectedModel];
  [self.pickerView selectRow:selectedIndex inComponent:0 animated:NO];
}

#pragma mark -- loadSubViews
- (void)initSuViews
{
  [self addSubview:self.bgView];
  [self.bgView addSubview:self.toolBar];
  [self.bgView addSubview:self.pickerView];
  [self.toolBar addSubview:self.cancleBtn];
  [self.toolBar addSubview:self.confirmBtn];
  
  [self showPickerView];
}

#pragma mark -- showPickerView
- (void)showPickerView
{
  [UIView animateWithDuration:0.3 animations:^{
    self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.5];
    self->_bgView.frame = CGRectMake(0, self.frame.size.height - BGHEIGHT, self.frame.size.width, BGHEIGHT);
  }];
}


- (void)hidePickerView
{
  [UIView animateWithDuration:0.3 animations:^{
    self->_bgView.frame = CGRectMake(0, self.frame.size.height , self.frame.size.width, BGHEIGHT);
    self.alpha = 0;
  } completion:^(BOOL finished) {
    [self removeFromSuperview];
  }];
}

#pragma mark -- UIPickerView
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
  return self.dataSource.count;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view
{
  UILabel * label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width / 3, 30)];
  label.adjustsFontSizeToFitWidth = YES;
  label.textAlignment = NSTextAlignmentCenter;
  label.font = [UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(17.0f)];
  
  if (0 <= row && row < self.dataSource.count) {
    CFCDrawResultRecordYearsModel *model = self.dataSource[row];
    label.text = [NSString stringWithFormat:@"%@年", model.year.stringValue];
  } else {
    label.text = @"空";
  }

  return label;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
  if (0 <= row && row < self.dataSource.count) {
    self.selectedValue = self.dataSource[row];
  }
}

- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component
{
  return 40.0;
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
  return 1;
}


#pragma mark -- Button
- (void)cancleBtnClick
{
  [self hidePickerView];
}

- (void)confirmBtnClick
{
  [self hidePickerView];
  
  if (self.selectedBlock != nil) {
    self.selectedBlock(self.selectedValue);
  }
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
  if ([touches.anyObject.view isKindOfClass:[self class]]) {
    [self hidePickerView];
  }
}


@end

