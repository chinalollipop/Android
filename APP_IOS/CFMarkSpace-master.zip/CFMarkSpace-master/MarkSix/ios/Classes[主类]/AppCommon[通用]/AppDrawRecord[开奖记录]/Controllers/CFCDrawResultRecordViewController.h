//
// 开奖记录 - 记录列表
//

#import "CFCTableRefreshViewController.h"
@protocol CFCDrawResultPagerViewControllerProtocol;

NS_ASSUME_NONNULL_BEGIN

@interface CFCDrawResultRecordViewController : CFCTableRefreshViewController <CFCDrawResultPagerViewControllerProtocol>

@end



NS_ASSUME_NONNULL_END
