//
// 开奖记录 - 记录列表
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCDrawResultRecordModel : NSObject
@property (nonatomic, copy) NSString *issue;
@property (nonatomic, copy) NSString *data;
@property (nonatomic, copy) NSString *color;
@property (nonatomic, copy) NSString *sx;
@property (nonatomic, copy) NSString *wx;
@property (nonatomic, strong) NSNumber *date;
@property (nonatomic, strong) NSNumber *sum_single_double;
@property (nonatomic, strong) NSNumber *sum_big_small;
@property (nonatomic, strong) NSNumber *special_single_double;
@property (nonatomic, strong) NSNumber *special_big_small;

@property (nonatomic, strong) NSNumber *isShowWuXing;

@end

NS_ASSUME_NONNULL_END
