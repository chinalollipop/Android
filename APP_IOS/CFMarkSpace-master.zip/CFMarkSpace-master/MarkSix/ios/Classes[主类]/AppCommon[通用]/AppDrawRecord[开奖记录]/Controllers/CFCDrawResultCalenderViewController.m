//
// 开奖记录 - 开奖日期
//

#import "CFCDrawResultCalenderViewController.h"
#import "CFCDrawResultCalenderCollectionHeaderView.h"
#import "CFCDrawResultCalenderCollectionFooterView.h"
#import "CFCDrawResultCalenderCollectionViewCell.h"
#import "CFCDrawResultCalenderModel.h"


@interface CFCDrawResultCalenderViewController () <CFCDrawResultCalenderCollectionHeaderViewDelegate>
@property (nonatomic, assign) BOOL isMondayOfWeekFirst; // 每周第一天是否为星期一
@property (nonatomic, strong) NSDate *calendarOfDate; // 当前日期变量
@property (nonatomic, assign) NSInteger lastSelectIndex; // 上一次选择index，初始值为今天的index

@property (nonatomic, strong) CFCDrawResultCalenderCollectionHeaderView *sectionHeaderView;
@property (nonatomic, strong) CFCDrawResultCalenderCollectionFooterView *sectionFooterView;

@end


@implementation CFCDrawResultCalenderViewController


#pragma mark -
#pragma mark 事件处理 - 上一月
- (void)doLogicPressButtonLastMounthAction
{
  self.calendarOfDate = [self getLastMonth:self.calendarOfDate];
  if ([self.calendarOfDate.yyyyMMByLineWithDate isEqualToString:[NSDate date].yyyyMMByLineWithDate]) {
    self.calendarOfDate = [NSDate date];
  } else {
    self.calendarOfDate = [self firstDateOfMonth:self.calendarOfDate];
  }
  // 请求数据
  [self setIsShowLoadingHUD:YES];
  [self loadData];
}

#pragma mark 事件处理 - 下一月
- (void)doLogicPressButtonNextMounthAction
{
  self.calendarOfDate = [self getNextMonth:self.calendarOfDate];
  if ([self.calendarOfDate.yyyyMMByLineWithDate isEqualToString:[NSDate date].yyyyMMByLineWithDate]) {
    self.calendarOfDate = [NSDate date];
  } else {
    self.calendarOfDate = [self firstDateOfMonth:self.calendarOfDate];
  }
  // 请求数据
  [self setIsShowLoadingHUD:YES];
  [self loadData];
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    self.hasCacheData = NO;
    self.hasRefreshHeader = NO;
    self.hasRefreshFooter = NO;
    //
    self.isMondayOfWeekFirst = YES;
    self.calendarOfDate = [NSDate date];
  }
  return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  
}


#pragma mark -
#pragma mark 请求地址
- (NSString *)getRequestURLString
{
  return URL_API_DRAW_RESULT_RECORD_DATETIEM;
}

#pragma mark 请求参数
- (NSMutableDictionary *)getRequestParamerter
{
  NSString *datetime = [self.calendarOfDate yyyyMMByLineWithDate];
  return [CFCNetworkParamsUtil getDrawResultRecordDateTimeParameters:datetime];
}

#pragma mark 请求网络数据或加载缓存
- (NSMutableArray *)loadNetworkDataOrCacheDataSingle:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData
{
  WEAKSELF(weakSelf);
  
  NSDictionary *responseData = (NSDictionary *)responseDataOrCacheData;
  CFCLog(@"[开奖日期][%@] => %@\n", CFC_DATA_TYPE(isCacheData), responseData);
  
  // 请求成功，解析数据
  NSArray *data = [responseData objectForKey:CFC_REQUEST_KEY_DATA];
  NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
  if (![CFCSysUtil validateResultCodeIsSuccess:status] || [CFCSysUtil validateObjectIsNull:data]) {
    return [NSMutableArray array];
  }
  
  
  /////////////////////////////////////////////////////////////////
  // A、组装数据 -> 开始
  /////////////////////////////////////////////////////////////////
  
  // 开奖日期
  NSMutableArray<CFCDrawResultOpenDateModel *> *allDrawResultOpenTimeModels = [NSMutableArray<CFCDrawResultOpenDateModel *> array];
  [data enumerateObjectsUsingBlock:^(NSDictionary *  _Nonnull dict, NSUInteger idx, BOOL * _Nonnull stop) {
    CFCDrawResultOpenDateModel *model = [CFCDrawResultOpenDateModel mj_objectWithKeyValues:dict];
    [allDrawResultOpenTimeModels addObject:model];
  }];
  
  // 日历数据
  NSMutableArray<CFCDrawResultCalenderModel *> *allDrawResultCalenderModels = [NSMutableArray<CFCDrawResultCalenderModel *> array];
  allDrawResultCalenderModels = [self getDrawResultCalenderModels:allDrawResultOpenTimeModels calendarOfDate:self.calendarOfDate];
  
  /////////////////////////////////////////////////////////////////
  // A、组装数据 -> 结束
  /////////////////////////////////////////////////////////////////
  
  
  /////////////////////////////////////////////////////////////////
  // B、配置数据源  -> 开始
  /////////////////////////////////////////////////////////////////
  
  // 初始化数据源
  weakSelf.collectionViewDataRefresh = [NSMutableArray array];
  if (allDrawResultCalenderModels && 0 < allDrawResultCalenderModels.count) {
    [weakSelf.collectionViewDataRefresh addObject:allDrawResultCalenderModels.mutableCopy];
  }
  
  /////////////////////////////////////////////////////////////////
  // B、配置数据源  -> 结束
  /////////////////////////////////////////////////////////////////
  
  return weakSelf.collectionViewDataRefresh;
}



#pragma mark -
#pragma mark 获取日历每月的数据模型
- (NSMutableArray<CFCDrawResultCalenderModel *> *)getDrawResultCalenderModels:(NSArray<CFCDrawResultOpenDateModel *> *)openDateModels calendarOfDate:(NSDate *)date
{
  NSMutableArray<CFCDrawResultCalenderModel *> *calenderDays = [[NSMutableArray<CFCDrawResultCalenderModel *> alloc] initWithCapacity:42];
  NSInteger week = [self startDayOfWeek:date];
  NSUInteger days = [self numberOfDaysInMonth:date];
  int day = 1;
  if (self.isMondayOfWeekFirst) {
    week = (0 == week - 1) ? 7 : (week - 1);
  }
  for (int i= 1; i< days + week; i ++) {
    if (i < week) {
      CFCDrawResultCalenderModel *itemDayModel = [CFCDrawResultCalenderModel new];
      [itemDayModel setDayValue:0]; // 空白
      [itemDayModel setDateValue:nil];
      [itemDayModel setIsCurrentDay:NO];
      [itemDayModel setIsSelectedDay:NO];
      [itemDayModel setIsOpenResultDay:NO];
      [calenderDays addObject:itemDayModel];
    } else {
      NSDate *dayDate = [self dateOfDay:day];
      BOOL isOpenResultDay = NO;
      NSNumber *openResultIssue = nil;
      CFCDrawResultOpenDateModel *openResultDay = [self isOpenResultDateOf:dayDate allOpenResultDateModels:openDateModels];
      if (openResultDay) {
        isOpenResultDay = YES;
        openResultIssue = openResultDay.issue;
      }
      CFCDrawResultCalenderModel *itemDayModel = [CFCDrawResultCalenderModel new];
      [itemDayModel setDayValue:day];
      [itemDayModel setDateValue:dayDate];
      [itemDayModel setIssue:openResultIssue];
      [itemDayModel setIsOpenResultDay:isOpenResultDay];
      if ([dayDate.yyyyMMddByLineWithDate isEqualToString:[NSDate date].yyyyMMddByLineWithDate]) {
        [itemDayModel setIsCurrentDay:YES];
        [itemDayModel setIsSelectedDay:YES];
        self.lastSelectIndex = i - 1;
      }
      if (![[self.calendarOfDate yyyyMMByLineWithDate] isEqualToString:[NSDate date].yyyyMMByLineWithDate]) {
        if (1 == day) {
          [itemDayModel setIsSelectedDay:YES];
          self.lastSelectIndex = i - 1;
        }
      }
      [calenderDays addObject:itemDayModel];
      day++;
    }
  }
  
  if (calenderDays.count % 7) {
    NSInteger count = 7 - calenderDays.count % 7;
    for (NSInteger idx = 0; idx < count; idx ++) {
      CFCDrawResultCalenderModel *itemDayModel = [CFCDrawResultCalenderModel new];
      [itemDayModel setDayValue:0]; // 空白
      [itemDayModel setDateValue:nil];
      [itemDayModel setIsCurrentDay:NO];
      [itemDayModel setIsSelectedDay:NO];
      [itemDayModel setIsOpenResultDay:NO];
      [calenderDays addObject:itemDayModel];
    }
  }
  
  return calenderDays;
}

- (CFCDrawResultOpenDateModel *)isOpenResultDateOf:(NSDate *)dayDate allOpenResultDateModels:(NSArray<CFCDrawResultOpenDateModel *> *)openDateModel
{
  __block CFCDrawResultOpenDateModel *isOpenResultDay = nil;
  NSString *dateString = dayDate.yyyyMMddByLineWithDate;
  [openDateModel enumerateObjectsUsingBlock:^(CFCDrawResultOpenDateModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
    NSString *openDateString = [CFCDateUtil dateFormattingWithDateString:obj.datetime dateFormate:@"yyyy-MM-dd HH:mm" toFormate:@"yyyy-MM-dd"];
    if ([dateString isEqualToString:openDateString]) {
      isOpenResultDay = obj;
      *stop = YES;
    }
  }];
  return isOpenResultDay;
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_PROJECT_ZILIAODAQUAN;
}


#pragma mark -
#pragma mark 注册 UICollectionView
- (void)collectionViewRefreshRegisterClass:(UICollectionView *)collectionView
{
  [super collectionViewRefreshRegisterClass:collectionView];
  
  // 注册 UICollectionReusableView Section Header（必须）
  [self.collectionViewRefresh registerClass:[CFCDrawResultCalenderCollectionHeaderView class]
                 forSupplementaryViewOfKind:UICollectionElementKindSectionHeader
                        withReuseIdentifier:CELL_IDENTIFIER_RESULT_CALENDER_COLLECTION_SECTION_HEADER];
  
  // 注册 UICollectionReusableView Section Footer（必须）
  [self.collectionViewRefresh registerClass:[CFCDrawResultCalenderCollectionFooterView class]
                 forSupplementaryViewOfKind:UICollectionElementKindSectionFooter
                        withReuseIdentifier:CELL_IDENTIFIER_RESULT_CALENDER_COLLECTION_SECTION_FOOTER];
  
  // 注册 CFCDrawResultCalenderCollectionViewCell（必须）
  [self.collectionViewRefresh registerClass:[CFCDrawResultCalenderCollectionViewCell class]
                 forCellWithReuseIdentifier:CELL_IDENTIFIER_RESULT_CALENDER_COLLECTION_VIEW_CELL];
}

#pragma mark 设置 CFCCollectionViewLayoutType 布局
- (CFCCollectionViewLayoutType)collectionViewLayoutType
{
  return CFCCollectionViewLayoutTypeWaterFallLayout;
}

#pragma mark 设置 CFCCollectionViewLayoutType 布局
- (UICollectionViewLayout *)collectionViewLayout
{
  CGFloat margin_item = CFC_AUTOSIZING_WIDTH(1.0f);
  CGFloat margin_inset = CFC_AUTOSIZING_WIDTH(15.0f);
  CFCCollectionRefreshViewWaterFallLayout *flowLayout = [[CFCCollectionRefreshViewWaterFallLayout alloc] init];
  flowLayout.delegate = self;
  flowLayout.margin = margin_item;
  flowLayout.sectionInset = UIEdgeInsetsMake(margin_item, margin_inset, margin_item, margin_inset);
  return flowLayout;
}


#pragma mark -
#pragma mark UICollectionViewDataSource UICollectionViewDelegate
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
  if (self.collectionViewDataRefresh && self.collectionViewDataRefresh.count > 0) {
    return self.collectionViewDataRefresh.count;
  }
  return 0;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
  if (self.collectionViewDataRefresh && self.collectionViewDataRefresh.count > 0 && self.collectionViewDataRefresh.count > section) {
    if ([self.collectionViewDataRefresh[section] isKindOfClass:[NSArray class]]) {
      NSMutableArray *group = self.collectionViewDataRefresh[section];
      if ([group isKindOfClass:[NSArray class]]) {
        return group.count;
      }
    }
  }
  return 0;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.collectionViewDataRefresh
      || self.collectionViewDataRefresh.count <= 0
      || self.collectionViewDataRefresh.count <= indexPath.section
      || ![self.collectionViewDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  CFCDrawResultCalenderCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:CELL_IDENTIFIER_RESULT_CALENDER_COLLECTION_VIEW_CELL forIndexPath:indexPath];
  if (!cell) {
    cell = [[CFCDrawResultCalenderCollectionViewCell alloc] init];
  }
  cell.model = self.collectionViewDataRefresh[indexPath.section][indexPath.row];
  return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
  CFCDrawResultCalenderModel *calenderDateTime = self.collectionViewDataRefresh[indexPath.section][self.lastSelectIndex];
  if (kind == UICollectionElementKindSectionHeader) {
    CFCDrawResultCalenderCollectionHeaderView *sectionHeaderView
    = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader
                                         withReuseIdentifier:CELL_IDENTIFIER_RESULT_CALENDER_COLLECTION_SECTION_HEADER
                                                forIndexPath:indexPath];
    [sectionHeaderView setDelegate:self];
    [sectionHeaderView setSelectedDateTime:calenderDateTime];
    [sectionHeaderView setIsMondayOfWeekFirst:self.isMondayOfWeekFirst];
    [self setSectionHeaderView:sectionHeaderView];
    return sectionHeaderView;
  } else if (kind == UICollectionElementKindSectionFooter) {
    CFCDrawResultCalenderCollectionFooterView *sectionFooterView
    = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionFooter
                                         withReuseIdentifier:CELL_IDENTIFIER_RESULT_CALENDER_COLLECTION_SECTION_FOOTER
                                                forIndexPath:indexPath];
    [sectionFooterView setSelectedDateTime:calenderDateTime];
    [self setSectionFooterView:sectionFooterView];
    return sectionFooterView;
  }
  return [super collectionView:collectionView viewForSupplementaryElementOfKind:kind atIndexPath:indexPath];
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
  if (indexPath.row == self.lastSelectIndex) return;
  
  CFCDrawResultCalenderModel *selectedModel = self.collectionViewDataRefresh[indexPath.section][indexPath.row];
  if (0 == selectedModel.dayValue) {
    return;
  }
  
  CFCDrawResultCalenderModel *lastSelecredModel = self.collectionViewDataRefresh[indexPath.section][self.lastSelectIndex];
  if (lastSelecredModel.dayValue > 0) {
    [lastSelecredModel setIsSelectedDay:NO];
  }
  
  // 刷新选择的元素
  [selectedModel setIsSelectedDay:YES];
  NSIndexPath *lastSelectPath = [NSIndexPath indexPathForItem:self.lastSelectIndex inSection:indexPath.section];
  [self.collectionViewRefresh reloadItemsAtIndexPaths:@[lastSelectPath, indexPath]];
  self.lastSelectIndex = indexPath.row;
  
  // 刷新表格Footer
  [self.sectionFooterView setSelectedDateTime:selectedModel];
}


#pragma mark -
#pragma mark CFCCollectionRefreshViewWaterFallLayoutDelegate
#pragma mark 自定义表格每一个分组的列数
- (NSInteger)numberOfColumnsInSectionForIndexPath:(NSIndexPath *)indexPath
{
  return 7;
}

#pragma mark 自定义表格每一行的高度
- (CGFloat)heightOfCellItemForCollectionViewAtIndexPath:(NSIndexPath *)indexPath
{
  CGFloat margin_item = CFC_AUTOSIZING_WIDTH(1.0f);
  CGFloat margin_inset = CFC_AUTOSIZING_WIDTH(15.0f);
  NSInteger column = [self numberOfColumnsInSectionForIndexPath:indexPath];
  CGFloat width = (SCREEN_WIDTH - ((column-1) * margin_item) - margin_inset * 2.0f) / column;
  return width * 0.95f;
}

#pragma mark 自定义表格的 SectionHeader 的高度
- (CGFloat)heightOfSectionHeaderForIndexPath:(NSIndexPath *)indexPath
{
  return CFC_AUTOSIZING_WIDTH(HEIGHT_DRAW_RESULT_CALENDER_COLLECTION_SECTION_HEADER);
}

#pragma mark 自定义表格的 SectionFooter 的高度
- (CGFloat)heightOfSectionFooterForIndexPath:(NSIndexPath *)indexPath
{
  return CFC_AUTOSIZING_WIDTH(40);
}


#pragma mark - Private
- (NSUInteger)numberOfDaysInMonth:(NSDate *)date
{
  NSCalendar *greCalendar = [[NSCalendar alloc]initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
  [greCalendar setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
  return [greCalendar rangeOfUnit:NSCalendarUnitDay inUnit:NSCalendarUnitMonth forDate:date].length;
}

- (NSDate *)firstDateOfMonth:(NSDate *)date
{
  NSCalendar *greCalendar = [[NSCalendar alloc]initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
  [greCalendar setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
  NSDateComponents *comps = [greCalendar
                             components:NSCalendarUnitYear | NSCalendarUnitMonth |NSCalendarUnitWeekday | NSCalendarUnitDay
                             fromDate:date];
  comps.day = 1;
  return [greCalendar dateFromComponents:comps];
}

- (NSUInteger)startDayOfWeek:(NSDate *)date
{
  NSCalendar *greCalendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
  [greCalendar setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
  NSDateComponents *comps = [greCalendar
                             components:NSCalendarUnitYear | NSCalendarUnitMonth |NSCalendarUnitWeekday | NSCalendarUnitDay
                             fromDate:[self firstDateOfMonth:date]];
  return comps.weekday;
}

- (NSDate *)getLastMonth:(NSDate *)date
{
  NSCalendar *greCalendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
  [greCalendar setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
  NSDateComponents *comps = [greCalendar
                             components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay
                             fromDate:date];
  comps.month -= 1;
  return [greCalendar dateFromComponents:comps];
}

- (NSDate *)getNextMonth:(NSDate *)date
{
  NSCalendar *greCalendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
  [greCalendar setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
  NSDateComponents *comps = [greCalendar
                             components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay
                             fromDate:date];
  comps.month += 1;
  return [greCalendar dateFromComponents:comps];
}

- (NSDate *)dateOfDay:(NSInteger)day
{
  NSCalendar *greCalendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
  [greCalendar setTimeZone:[NSTimeZone timeZoneWithName:@"GMT"]];
  NSDateComponents *comps = [greCalendar
                             components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay
                             fromDate:self.calendarOfDate];
  comps.day = day;
  return [greCalendar dateFromComponents:comps];
}


@end



