//
// 开奖记录 - 记录列表
//

#import "CFCDrawResultRecordViewController.h"
#import "CFCDrawResultPagerViewController.h"
#import "CFCDrawResultRecordDetailViewController.h"
#import "CFCDrawResultRecordSectionHeader.h"
#import "CFCDrawResultRecordSectionHeaderModel.h"
#import "CFCDrawResultRecordTableViewCell.h"
#import "CFCDrawResultRecordModel.h"

@interface CFCDrawResultRecordViewController () <CFCDrawResultRecordTableViewCellDelegate, CFCDrawResultRecordSectionHeaderDelegate>

@property (nonatomic, strong) CFCDrawResultRecordSectionHeaderModel *sectionHeaderModel;

@end

@implementation CFCDrawResultRecordViewController


#pragma mark -
#pragma mark 事件处理 - 记录详情
- (void)didSelectRowAtDrawResultRecordModel:(CFCDrawResultRecordModel *)model
{
  CFCDrawResultRecordDetailViewController *viewController = [[CFCDrawResultRecordDetailViewController alloc] init];
  [viewController setDrawResultRecord:model];
  [self.navigationController pushViewController:viewController animated:YES];
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    self.hasCacheData = YES;
    self.hasRefreshFooter = NO;
  }
  return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
}


#pragma mark -
#pragma mark 请求地址
- (NSString *)getRequestURLString
{
  return URL_API_DRAW_RESULT_RECORD_LIST;
}

#pragma mark 请求参数
- (NSMutableDictionary *)getRequestParamerter
{
  return [CFCNetworkParamsUtil getDrawResultRecordParameters:self.sectionHeaderModel.year];
}

#pragma mark 请求网络数据或加载缓存
- (NSMutableArray *)loadNetworkDataOrCacheDataSingle:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData
{
  WEAKSELF(weakSelf);
  
  NSDictionary *responseData = (NSDictionary *)responseDataOrCacheData;
  CFCLog(@"[开奖记录][%@] => %@\n", CFC_DATA_TYPE(isCacheData), responseData);
  
  // 请求成功，解析数据
  NSDictionary *data = [responseData objectForKey:CFC_REQUEST_KEY_DATA];
  NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
  if (![CFCSysUtil validateResultCodeIsSuccess:status] || [CFCSysUtil validateObjectIsNull:data]) {
    return [NSMutableArray array];
  }
  
  
  /////////////////////////////////////////////////////////////////
  // A、组装数据 -> 开始
  /////////////////////////////////////////////////////////////////
  
  // 开奖记录列表
  NSMutableArray<CFCDrawResultRecordModel *> *allDrawResultModels = [NSMutableArray<CFCDrawResultRecordModel *> array];
  [data[@"list"] enumerateObjectsUsingBlock:^(NSDictionary *  _Nonnull dict, NSUInteger idx, BOOL * _Nonnull stop) {
    CFCDrawResultRecordModel *itemModel = [CFCDrawResultRecordModel mj_objectWithKeyValues:dict];
    NSNumber *isShouWuXing = [NSNumber numberWithBool:self.sectionHeaderModel.isShowWuXing];
    [itemModel setIsShowWuXing:isShouWuXing];
    [allDrawResultModels addObject:itemModel];
  }];
  
  // 判断当前排序
  if (allDrawResultModels.count > 1) {
    CFCDrawResultRecordModel *firstModel = [allDrawResultModels objectAtIndex:0];
    CFCDrawResultRecordModel *secondModel = [allDrawResultModels objectAtIndex:1];
    if (firstModel.issue.integerValue > secondModel.issue.integerValue) {
      if (!self.sectionHeaderModel.isSortDesc) {
        __block NSMutableArray<CFCDrawResultRecordModel *> *allSortDrawResultModels = [NSMutableArray<CFCDrawResultRecordModel *> array];
        [allDrawResultModels enumerateObjectsWithOptions:NSEnumerationReverse usingBlock:^(CFCDrawResultRecordModel * _Nonnull itemModel, NSUInteger itemIdx, BOOL * _Nonnull itemStop) {
          [allSortDrawResultModels addObject:itemModel];
        }];
        allDrawResultModels = allSortDrawResultModels;
      }
    } else {
      if (self.sectionHeaderModel.isSortDesc) {
        __block NSMutableArray<CFCDrawResultRecordModel *> *allSortDrawResultModels = [NSMutableArray<CFCDrawResultRecordModel *> array];
        [allDrawResultModels enumerateObjectsWithOptions:NSEnumerationReverse usingBlock:^(CFCDrawResultRecordModel * _Nonnull itemModel, NSUInteger itemIdx, BOOL * _Nonnull itemStop) {
          [allSortDrawResultModels addObject:itemModel];
        }];
        allDrawResultModels = allSortDrawResultModels;
      }
    }
  }
  
  /////////////////////////////////////////////////////////////////
  // A、组装数据 -> 结束
  /////////////////////////////////////////////////////////////////
  
  
  /////////////////////////////////////////////////////////////////
  // B、配置数据源  -> 开始
  /////////////////////////////////////////////////////////////////
  
  // 初始化数据源
  weakSelf.tableDataRefresh = [NSMutableArray array];
  if (allDrawResultModels && 0 < allDrawResultModels.count) {
    [weakSelf.tableDataRefresh addObject:allDrawResultModels.mutableCopy];
  }
  
  /////////////////////////////////////////////////////////////////
  // B、配置数据源  -> 结束
  /////////////////////////////////////////////////////////////////
  
  return weakSelf.tableDataRefresh;
}


#pragma mark -
#pragma mark 设置 UITableView 表格类型
- (UITableViewStyle)tableViewRefreshStyle
{
  return UITableViewStylePlain;
}

#pragma mark 注册 UITableViewCell
- (void)tableViewRefreshRegisterClass:(UITableView *)tableView
{
  [self.tableViewRefresh registerClass:[CFCDrawResultRecordTableViewCell class]
                forCellReuseIdentifier:CELL_IDENTIFIER_DRAW_RESULT_RECORD_IDENTIFIER];
}


#pragma mark -
#pragma mark UITableViewDelegate UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0) {
    return self.tableDataRefresh.count;
  }
  return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0 && self.tableDataRefresh.count > section) {
    if ([self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
      NSMutableArray *group = self.tableDataRefresh[section];
      if ([group isKindOfClass:[NSArray class]]) {
        return group.count;
      }
    }
  }
  return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  CFCDrawResultRecordTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_DRAW_RESULT_RECORD_IDENTIFIER];
  if (!cell) {
    cell = [[CFCDrawResultRecordTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_DRAW_RESULT_RECORD_IDENTIFIER];
  }
  cell.delegate = self;
  cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
  cell.selectionStyle = UITableViewCellSelectionStyleNone;
  return cell;
  
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return [self.tableViewRefresh fd_heightForCellWithIdentifier:CELL_IDENTIFIER_DRAW_RESULT_RECORD_IDENTIFIER cacheByIndexPath:indexPath configuration:^(CFCDrawResultRecordTableViewCell *cell) {
    cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
  }];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  CGRect frameOfHeader = CGRectMake(0, 0, self.tableViewRefresh.width, CFC_AUTOSIZING_WIDTH(CONST_DRAW_RESULT_RECORD_SECTION_HEADER_HIGHT));
  CFCDrawResultRecordSectionHeader *headerView = [[CFCDrawResultRecordSectionHeader alloc] initWithFrame:frameOfHeader
                                                                                                delegate:self
                                                                                      sectionHeaderModel:self.sectionHeaderModel];
  return headerView;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableViewRefresh.frame.size.width, CFC_AUTOSIZING_MARGIN(MARGIN))];
  [footerView setBackgroundColor:COLOR_TABLEVIEW_FOOTER_VIEW_BACKGROUND_DEFAULT];
  return footerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return CFC_AUTOSIZING_WIDTH(CONST_DRAW_RESULT_RECORD_SECTION_HEADER_HIGHT);
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return FLOAT_MIN;
}


#pragma mark -
#pragma mark CFCDrawResultPagerViewControllerProtocol
- (NSString *)yearOfDrawResultRecordFromRecordViewController
{
  return self.sectionHeaderModel.year;
}

- (void)doRefreshDrawResultRecordToRecordViewControllerByYear:(NSString *)year animated:(BOOL)animated
{
  if (year.integerValue == self.sectionHeaderModel.year.integerValue) {
    return;
  }
  
  [self.sectionHeaderModel setYear:year];
  if (animated) {
    [self.tableViewRefresh.mj_header beginRefreshing];
  } else {
    [self loadData];
  }
}


#pragma mark -
#pragma mark CFCDrawResultRecordSectionHeaderDelegate
- (void)didSelectAtDrawResultRecordSectionHeaderOfSort:(CFCDrawResultRecordSectionHeaderModel *)drawResultModel
{
  self.sectionHeaderModel.isSortDesc = !self.sectionHeaderModel.isSortDesc;
  __block NSMutableArray<CFCDrawResultRecordModel *> *allDrawResultModels = [NSMutableArray<CFCDrawResultRecordModel *> array];
  [self.tableDataRefresh enumerateObjectsUsingBlock:^(NSMutableArray<CFCDrawResultRecordModel *> * _Nonnull section, NSUInteger idx, BOOL * _Nonnull stop) {
    [section enumerateObjectsWithOptions:NSEnumerationReverse usingBlock:^(CFCDrawResultRecordModel * _Nonnull itemModel, NSUInteger itemIdx, BOOL * _Nonnull itemStop) {
      NSNumber *isShouWuXing = [NSNumber numberWithBool:self.sectionHeaderModel.isShowWuXing];
      [itemModel setIsShowWuXing:isShouWuXing];
      [allDrawResultModels addObject:itemModel];
    }];
  }];
  self.tableDataRefresh = [NSMutableArray array];
  if (allDrawResultModels && 0 < allDrawResultModels.count) {
    [self.tableDataRefresh addObject:allDrawResultModels.mutableCopy];
  }
  [self.tableViewRefresh reloadData];
}

- (void)didSelectAtDrawResultRecordSectionHeaderOfWuXing:(CFCDrawResultRecordSectionHeaderModel *)drawResultModel
{
  self.sectionHeaderModel.isShowWuXing = !self.sectionHeaderModel.isShowWuXing;
  [self.tableDataRefresh enumerateObjectsUsingBlock:^(NSMutableArray<CFCDrawResultRecordModel *> * _Nonnull section, NSUInteger idx, BOOL * _Nonnull stop) {
    [section enumerateObjectsUsingBlock:^(CFCDrawResultRecordModel * _Nonnull itemModel, NSUInteger itemIdx, BOOL * _Nonnull itemStop) {
      NSNumber *isShouWuXing = [NSNumber numberWithBool:self.sectionHeaderModel.isShowWuXing];
      [itemModel setIsShowWuXing:isShouWuXing];
    }];
  }];
  [self.tableViewRefresh reloadData];
}


#pragma mark -
#pragma mark Getter / Setter
- (CFCDrawResultRecordSectionHeaderModel *)sectionHeaderModel
{
  if (!_sectionHeaderModel) {
    NSString *year = [NSString stringWithFormat:@"%ld", [NSDate new].year];
    CFCDrawResultRecordSectionHeaderModel *sectionHeaderModel = [[CFCDrawResultRecordSectionHeaderModel alloc] init];
    [sectionHeaderModel setYear:year];
    [sectionHeaderModel setIsSortDesc:YES];
    [sectionHeaderModel setIsShowWuXing:NO];
    _sectionHeaderModel = sectionHeaderModel;
  }
  return _sectionHeaderModel;
}


@end



