
#import <UIKit/UIKit.h>
@class CFCDrawResultRecordYearsModel;

typedef void(^CFCDrawRecordYearPickerViewSelectedHandle)(CFCDrawResultRecordYearsModel * selectedValue);

@interface CFCDrawRecordYearPickerView : UIView

@property(nonatomic, strong) NSArray<CFCDrawResultRecordYearsModel *> *dataSource;

@property(nonatomic, strong) CFCDrawResultRecordYearsModel *selectedValue;

@property(nonatomic, copy) CFCDrawRecordYearPickerViewSelectedHandle selectedBlock;

- (instancetype)initWithFrame:(CGRect)frame dataSource:(NSArray<CFCDrawResultRecordYearsModel *> *)dataSource selectedValue:(NSString *)selectedValue;

@end
