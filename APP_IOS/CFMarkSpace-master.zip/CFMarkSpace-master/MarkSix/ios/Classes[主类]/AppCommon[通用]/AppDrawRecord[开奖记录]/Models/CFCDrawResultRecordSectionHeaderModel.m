//
// 开奖记录 - 分组头部
//

#import "CFCDrawResultRecordSectionHeaderModel.h"

@implementation CFCDrawResultRecordSectionHeaderModel

@end
