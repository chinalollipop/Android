//
// 开奖记录 - 记录列表 - 开奖日期
//

#import "CFCDrawResultCalenderCollectionHeaderView.h"
#import "CFCDrawResultCalenderModel.h"

CGFloat const HEIGHT_DRAW_RESULT_CALENDER_COLLECTION_SECTION_HEADER = 220.0;

// Section Header Identifier
NSString * const CELL_IDENTIFIER_RESULT_CALENDER_COLLECTION_SECTION_HEADER = @"CFCDrawResultCalenderCollectionHeaderViewIdentifier";

@interface CFCDrawResultCalenderCollectionHeaderView ()
/**
 * 标题容器
 */
@property (nonnull, nonatomic, strong) UIImageView *titleContainerView;
/**
 * 日历容器
 */
@property (nonnull, nonatomic, strong) UIView *calenderContainerView;
/**
 * 图片容器
 */
@property (nonnull, nonatomic, strong) UIImageView *backgroundImageView;
/**
 * 标题月份
 */
@property (nonatomic, strong) UILabel *titleDateTimeLabel;
/**
 * 前月按钮
 */
@property(nonnull, nonatomic, strong) UIButton *buttonLastMounth;
/**
 * 下月按钮按钮
 */
@property(nonnull, nonatomic, strong) UIButton *buttonNextMounth;

@end

@implementation CFCDrawResultCalenderCollectionHeaderView

- (instancetype)initWithFrame:(CGRect)frame
{
  self = [super initWithFrame:frame];
  if (self) {
    [self createViewAtuoLayout];
  }
  return self;
}

- (void) createViewAtuoLayout
{
  // 定义变量
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat left_right_margin = margin * 1.5f;
  CGFloat heightOfHeader = CFC_AUTOSIZING_WIDTH(100.0f);
  CGFloat heightOfBackground = CFC_AUTOSIZING_WIDTH(HEIGHT_DRAW_RESULT_CALENDER_COLLECTION_SECTION_HEADER-heightOfHeader);
  CGFloat heightOfTitle = heightOfBackground * 0.33f;
  CGFloat sizeOfBtnImage = heightOfTitle * 0.45f;
  
  // 背景图片
  UIImageView *backgroundImageView = ({
    // 背景
    UIImageView *imageView = [UIImageView new];
    [self addSubview:imageView];
    [imageView setUserInteractionEnabled:YES];
    [imageView setImage:[UIImage imageNamed:ICON_OPEN_BACKGROUND_HEADER]];
    [imageView setContentMode:UIViewContentModeScaleToFill];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(self.mas_top).offset(margin*1.5f);
      make.left.equalTo(self.mas_left).offset(left_right_margin);
      make.right.equalTo(self.mas_right).offset(-left_right_margin);
      make.height.mas_equalTo(heightOfHeader);
    }];
    
    // 标题
    UILabel *titleLabel = ({
      UILabel *label = [UILabel new];
      [imageView addSubview:label];
      [label setText:@"简介"];
      [label setTextAlignment:NSTextAlignmentCenter];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(imageView.mas_centerY).offset(-margin*0.75f);
        make.left.equalTo(imageView.mas_left).offset(margin*2.0f);
        make.right.equalTo(imageView.mas_right).offset(-margin*2.0f);
      }];
      
      label;
    });
    titleLabel.mas_key = @"titleLabel";
    
    // 内容
    UILabel *contentLabel = ({
      UILabel *label = [UILabel new];
      [imageView addSubview:label];
      [label setText:@"搅珠日期对照表，可查看当月及下一个月的搅珠开奖日期"];
      [label setNumberOfLines:0];
      [label setTextAlignment:NSTextAlignmentCenter];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(12.0f)]];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(imageView.mas_centerY).offset(margin*0.50f);
        make.left.equalTo(imageView.mas_left).offset(margin*1.5f);
        make.right.equalTo(imageView.mas_right).offset(-margin*1.5f);
      }];
      
      label;
    });
    contentLabel.mas_key = @"contentLabel";
    
    imageView;
  });
  self.backgroundImageView = backgroundImageView;
  self.backgroundImageView.mas_key = [NSString stringWithFormat:@"backgroundImageView"];
  
  // 日历容器
  UIView *calenderContainerView = ({
    UIView *view = [[UIView alloc] init];
    [view setBackgroundColor:[UIColor whiteColor]];
    [self addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.bottom.equalTo(self.mas_bottom);
      make.left.equalTo(self.mas_left).offset(left_right_margin);
      make.right.equalTo(self.mas_right).offset(-left_right_margin);
      make.height.mas_equalTo(heightOfTitle);
    }];
    
    view;
  });
  self.calenderContainerView = calenderContainerView;
  self.calenderContainerView.mas_key = @"calenderContainerView";
  
  // 标题区域
  {
    // 标题容器
    UIImageView *titleContainerView = ({
      UIImageView *imageView = [UIImageView new];
      [self addSubview:imageView];
      [imageView setUserInteractionEnabled:YES];
      [imageView setImage:[UIImage imageNamed:ICON_CALENDAR_HEADER_BACKGROUND]];
      [imageView setContentMode:UIViewContentModeScaleToFill];
      
      [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(calenderContainerView.mas_top);
        make.left.equalTo(self.mas_left).offset(left_right_margin);
        make.right.equalTo(self.mas_right).offset(-left_right_margin);
        make.height.mas_equalTo(heightOfTitle);
      }];
      
      imageView;
    });
    self.titleContainerView = titleContainerView;
    self.titleContainerView.mas_key = @"titleContainerView";
    
    // 标题日期
    UILabel *titleDateTimeLabel = ({
      UILabel *label = [UILabel new];
      [self.titleContainerView addSubview:label];
      [label setTextColor:[UIColor whiteColor]];
      [label setTextAlignment:NSTextAlignmentCenter];
      [label setBackgroundColor:COLOR_HEXSTRING(@"#B13A20")];
      [label setFont:[UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(titleContainerView.mas_centerX);
        make.top.equalTo(titleContainerView.mas_top);
        make.bottom.equalTo(titleContainerView.mas_bottom);
        make.width.equalTo(titleContainerView.mas_width).multipliedBy(0.68f);
      }];
      
      label;
    });
    self.titleDateTimeLabel = titleDateTimeLabel;
    self.titleDateTimeLabel.mas_key = @"titleDateTimeLabel";
    
    // 标题圆环 - 左
    UIImageView *leftCircleImageView = ({
      UIImageView *imageView = [UIImageView new];
      [self addSubview:imageView];
      [imageView setImage:[UIImage imageNamed:ICON_CALENDAR_HEADER_TITLE]];
      [imageView setContentMode:UIViewContentModeScaleAspectFit];
      
      CGFloat margin_bottom = heightOfTitle * 0.25f;
      CGFloat imageSizeHeight = heightOfTitle * 0.55f;
      CGFloat imageSizeWidth = imageSizeHeight * 0.45f;
      [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(titleDateTimeLabel.mas_left).offset(margin*2.0f);
        make.bottom.equalTo(titleDateTimeLabel.mas_top).offset(margin_bottom);
        make.size.mas_equalTo(CGSizeMake(imageSizeWidth, imageSizeHeight));
      }];
      
      imageView;
    });
    leftCircleImageView.mas_key = @"leftCircleImageView";
    
    // 标题圆环 - 右
    UIImageView *rightCircleImageView = ({
      UIImageView *imageView = [UIImageView new];
      [self addSubview:imageView];
      [imageView setImage:[UIImage imageNamed:ICON_CALENDAR_HEADER_TITLE]];
      [imageView setContentMode:UIViewContentModeScaleAspectFit];
      
      CGFloat margin_bottom = heightOfTitle * 0.25f;
      CGFloat imageSizeHeight = heightOfTitle * 0.55f;
      CGFloat imageSizeWidth = imageSizeHeight * 0.45f;
      [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(titleDateTimeLabel.mas_right).offset(-margin*2.0f);
        make.bottom.equalTo(titleDateTimeLabel.mas_top).offset(margin_bottom);
        make.size.mas_equalTo(CGSizeMake(imageSizeWidth, imageSizeHeight));
      }];
      
      imageView;
    });
    rightCircleImageView.mas_key = @"rightCircleImageView";
    
    // 前月按钮
    UIButton *buttonLastMounth = ({
      UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
      [titleContainerView addSubview:button];
      [button setImage:[[UIImage imageNamed:ICON_CALENDAR_BUTTON_LAST_MOUNTH] imageScaledFittingToSize:CGSizeMake(sizeOfBtnImage, sizeOfBtnImage)]
              forState:UIControlStateNormal];
      [button addTarget:self action:@selector(pressButtonLastMounthAction) forControlEvents:UIControlEventTouchUpInside];
      
      [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(titleContainerView.mas_left);
        make.top.equalTo(titleContainerView.mas_top);
        make.right.equalTo(titleDateTimeLabel.mas_left);
        make.bottom.equalTo(titleContainerView.mas_bottom);
      }];
      
      button;
    });
    self.buttonLastMounth = buttonLastMounth;
    self.buttonLastMounth.mas_key = @"buttonLastMounth";
    
    // 下月按钮
    UIButton *buttonNextMounth = ({
      UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
      [titleContainerView addSubview:button];
      [button setImage:[[UIImage imageNamed:ICON_CALENDAR_BUTTON_NEXT_MOUNTH] imageScaledFittingToSize:CGSizeMake(sizeOfBtnImage, sizeOfBtnImage)]
              forState:UIControlStateNormal];
      [button addTarget:self action:@selector(pressButtonNextMounthAction) forControlEvents:UIControlEventTouchUpInside];
      
      [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(titleDateTimeLabel.mas_right);
        make.top.equalTo(titleContainerView.mas_top);
        make.right.equalTo(titleContainerView.mas_right);
        make.bottom.equalTo(titleContainerView.mas_bottom);
      }];
      
      button;
    });
    self.buttonNextMounth = buttonNextMounth;
    self.buttonNextMounth.mas_key = @"buttonNextMounth";
  }
  
}

- (void)setIsMondayOfWeekFirst:(BOOL)isMondayOfWeekFirst
{
  _isMondayOfWeekFirst = isMondayOfWeekFirst;
  
  [self.calenderContainerView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
  
  NSInteger column = 7;
  CGFloat margin_item = CFC_AUTOSIZING_WIDTH(1.0f);
  CGFloat margin_inset = CFC_AUTOSIZING_WIDTH(15.0f);
  CGFloat size = (SCREEN_WIDTH - ((column-1) * margin_item) - margin_inset * 2.0f) / column;
  NSArray *weekArray = [[NSArray alloc] initWithObjects:@"日", @"一", @"二", @"三", @"四", @"五", @"六", nil];
  if (self.isMondayOfWeekFirst) {
    weekArray = [[NSArray alloc] initWithObjects:@"一", @"二", @"三", @"四", @"五", @"六", @"日", nil];
  }
  UILabel *lastItemLabel = nil;
  for (NSInteger idx = 0; idx < weekArray.count; idx ++) {
    
    UILabel *itemWeekLabel = ({
      UILabel *label = [UILabel new];
      [self.calenderContainerView addSubview:label];
      [label setText:weekArray[idx]];
      [label setTextColor:[UIColor blackColor]];
      [label setTextAlignment:NSTextAlignmentCenter];
      [label setFont:[UIFont boldSystemFontOfSize:15.0f]];

      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.calenderContainerView.mas_top);
        make.bottom.equalTo(self.calenderContainerView.mas_bottom);
        make.width.equalTo(@(size));
        if (!lastItemLabel) {
          make.left.equalTo(self.calenderContainerView.mas_left);
        } else {
          make.left.equalTo(lastItemLabel.mas_right).offset(margin_item);
        }
       }];
      
      label;
    });
    itemWeekLabel.mas_key = [NSString stringWithFormat:@"itemWeekLabel%ld", idx];
    
    lastItemLabel = itemWeekLabel;
  }
}

- (void)setSelectedDateTime:(CFCDrawResultCalenderModel *)selectedDateTime
{
  _selectedDateTime = selectedDateTime;
  
  // 日历标题
  [_titleDateTimeLabel setText:[_selectedDateTime.dateValue yyyyMMByLineWithDate]];
  
  // 上月日历
  NSString *currentDateString = [NSDate new].yyyyMMByLineWithDate;
  NSString *selectedDateString = [self.selectedDateTime.dateValue yyyyMMByLineWithDate];
  if ([currentDateString isEqualToString:selectedDateString]) {
    [self.buttonLastMounth setHidden:YES];
    [self.buttonNextMounth setHidden:NO];
  } else {
    [self.buttonLastMounth setHidden:NO];
    [self.buttonNextMounth setHidden:YES];
  }
}


#pragma mark - 触发操作事件 - 前月按钮
- (void)pressButtonLastMounthAction
{
  if (self.delegate && [self.delegate respondsToSelector:@selector(doLogicPressButtonLastMounthAction)]) {
    [self.delegate doLogicPressButtonLastMounthAction];
  }
}


#pragma mark - 触发操作事件 - 下月按钮
- (void)pressButtonNextMounthAction
{
  if (self.delegate && [self.delegate respondsToSelector:@selector(doLogicPressButtonNextMounthAction)]) {
    [self.delegate doLogicPressButtonNextMounthAction];
  }
}


@end




