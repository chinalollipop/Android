//
// 开奖记录 - 记录列表 - 开奖日期
//

#import <UIKit/UIKit.h>
@class CFCDrawResultCalenderModel;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_RESULT_CALENDER_COLLECTION_SECTION_FOOTER;

@interface CFCDrawResultCalenderCollectionFooterView : UICollectionReusableView

@property (nonatomic, strong) CFCDrawResultCalenderModel *selectedDateTime;

@end

NS_ASSUME_NONNULL_END
