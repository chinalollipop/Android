//
// 开奖记录 - 记录列表 - 推荐号码
//

#import <UIKit/UIKit.h>
@class CFCDrawResultRecordSuggestModel;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_DRAW_RESULT_RECORD_SUGGEST_IDENTIFIER;

@interface CFCDrawResultRecordSuggestTableViewCell : UITableViewCell

@property (nonatomic, strong) CFCDrawResultRecordSuggestModel *model;

@end

NS_ASSUME_NONNULL_END
