//
// 开奖记录 - 分组头部
//

#import "CFCDrawResultRecordSectionHeader.h"
#import "CFCDrawResultRecordSectionHeaderModel.h"

#pragma mark 头部高度
CGFloat const CONST_DRAW_RESULT_RECORD_SECTION_HEADER_HIGHT = 40.0f;

@interface CFCDrawResultRecordSectionHeader ()
/**
 * 根容器
 */
@property (nonnull, nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonnull, nonatomic, strong) UIView *publicContainerView;
/**
 * 标题控件
 */
@property (nonnull, nonatomic, strong) UILabel *titleLabel;
/**
 * 五行按钮
 */
@property(nonnull, nonatomic, strong) UIButton *buttonWuXing;
/**
 * 排序按钮
 */
@property(nonnull, nonatomic, strong) UIButton *buttonPaiXu;

@end

@implementation CFCDrawResultRecordSectionHeader

- (instancetype)initWithFrame:(CGRect)frame
                     delegate:(id<CFCDrawResultRecordSectionHeaderDelegate>)delegate
           sectionHeaderModel:(CFCDrawResultRecordSectionHeaderModel *)sectionHeaderModel
{
  self = [super initWithFrame:frame];
  if (self) {
    // 变量赋值
    _delegate = delegate;
    _sectionHeaderModel = sectionHeaderModel;
    
    // 创建子控件
    [self createViewAtuoLayout];
    // 设置控件数据
    [self createViewAutoSetting];
  }
  return self;
}

#pragma mark 创建子控件
- (void)createViewAtuoLayout
{
  WEAKSELF(weakSelf);
  
  // 定义变量
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat heightOfBackground = CFC_AUTOSIZING_WIDTH(CONST_DRAW_RESULT_RECORD_SECTION_HEADER_HIGHT);
  CGFloat btnHeight = heightOfBackground * 0.60f;
  CGFloat btnWidth = btnHeight * 2.25f;
  UIColor *backgroundColor = COLOR_HEXSTRING(@"#F0F1EC");
  
  // 根容器组件
  UIView *rootContainerView = ({
    UIView *view = [[UIView alloc] init];
    [self addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(@0);
      make.left.equalTo(@0);
      make.right.equalTo(@0);
      make.bottom.equalTo(weakSelf.mas_bottom).with.offset(0);
    }];
    
    view;
  });
  self.rootContainerView = rootContainerView;
  self.rootContainerView.mas_key = @"rootContainerView";
  
  // 公共容器
  UIView *publicContainerView = ({
    UIView *view = [[UIView alloc] init];
    [view.layer setMasksToBounds:YES];
    [view setBackgroundColor:backgroundColor];
    [self.rootContainerView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(@0);
      make.left.equalTo(@0);
      make.right.equalTo(@0);
      make.bottom.equalTo(weakSelf.rootContainerView.mas_bottom);
      make.height.mas_equalTo(heightOfBackground);
    }];
    
    view;
  });
  self.publicContainerView = publicContainerView;
  self.publicContainerView.mas_key = @"publicContainerView";
  
  // 标题控件
  UILabel *titleLabel = ({
    UILabel *label = [UILabel new];
    [self.publicContainerView addSubview:label];
    [label setNumberOfLines:0];
    [label setText:STR_APP_TEXT_PLACEHOLDER];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    [label setTextAlignment:NSTextAlignmentCenter];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)]];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(publicContainerView.mas_centerY);
      make.left.equalTo(publicContainerView.mas_left).offset(margin*1.5f);
    }];
    
    label;
  });
  self.titleLabel = titleLabel;
  self.titleLabel.mas_key = @"titleLabel";
  
  // 五行按钮
  UIButton *buttonWuXing = ({
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.publicContainerView addSubview:button];
    [button setTitle:@"五 行" forState:UIControlStateNormal];
    [button.layer setBorderWidth:1.0f];
    [button.layer setCornerRadius:btnHeight*0.5f];
    [button.layer setBorderColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT.CGColor];
    [button setBackgroundColor:backgroundColor];
    [button setTitleColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT forState:UIControlStateNormal];
    [button.titleLabel setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(13.0f)]];
    [button addTarget:self action:@selector(pressButtonClickWuXing) forControlEvents:UIControlEventTouchUpInside];
    
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(publicContainerView.mas_centerY);
      make.right.equalTo(publicContainerView.mas_right).offset(-margin*1.0f);
      make.size.mas_equalTo(CGSizeMake(btnWidth, btnHeight));
    }];
    
    button;
  });
  self.buttonWuXing = buttonWuXing;
  self.buttonWuXing.mas_key = @"buttonWuXing";
  
  // 排序按钮
  UIButton *buttonPaiXu = ({
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.publicContainerView addSubview:button];
    [button setTitle:@"降 序" forState:UIControlStateNormal];
    [button.layer setBorderWidth:1.0f];
    [button.layer setCornerRadius:btnHeight*0.5f];
    [button.layer setBorderColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT.CGColor];
    [button setBackgroundColor:backgroundColor];
    [button setTitleColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT forState:UIControlStateNormal];
    [button.titleLabel setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(13.0f)]];
    [button addTarget:self action:@selector(pressButtonClickPaiXu) forControlEvents:UIControlEventTouchUpInside];
    
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(publicContainerView.mas_centerY);
      make.right.equalTo(buttonWuXing.mas_left).offset(-margin*1.0f);
      make.size.mas_equalTo(CGSizeMake(btnWidth, btnHeight));
    }];
    
    button;
  });
  self.buttonPaiXu = buttonPaiXu;
  self.buttonPaiXu.mas_key = @"buttonPaiXu";
}

#pragma mark 设置控件数据
- (void)createViewAutoSetting
{
  // 当前期号
  NSString *title = [NSString stringWithFormat:@"%@年历史开奖记录", self.sectionHeaderModel.year];
  [self.titleLabel setText:title];
  
  // 五行按钮
  if (self.sectionHeaderModel.isShowWuXing) {
    [self.buttonWuXing setBackgroundColor:COLOR_HEXSTRING(@"#2A2A2A")];
    [self.buttonWuXing setTitleColor:COLOR_HEXSTRING(@"#FFFFFFF") forState:UIControlStateNormal];
    [self.buttonWuXing.titleLabel setFont:[UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(13.0f)]];
  } else {
    [self.buttonWuXing setBackgroundColor:COLOR_HEXSTRING(@"#F0F1EC")];
    [self.buttonWuXing setTitleColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT forState:UIControlStateNormal];
    [self.buttonWuXing.titleLabel setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(13.0f)]];
  }
  
  // 排序按钮
  if (self.sectionHeaderModel.isSortDesc) {
    [self.buttonPaiXu setTitle:@"降 序" forState:UIControlStateNormal];
  } else {
    [self.buttonPaiXu setTitle:@"升 序" forState:UIControlStateNormal];
  }
}


#pragma mark - 触发操作事件 - 五行按钮
- (void)pressButtonClickWuXing
{
  if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectAtDrawResultRecordSectionHeaderOfWuXing:)]) {
    [self.delegate didSelectAtDrawResultRecordSectionHeaderOfWuXing:self.sectionHeaderModel];
  }
}

#pragma mark - 触发操作事件 - 排序按钮
- (void)pressButtonClickPaiXu
{
  if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectAtDrawResultRecordSectionHeaderOfSort:)]) {
    [self.delegate didSelectAtDrawResultRecordSectionHeaderOfSort:self.sectionHeaderModel];
  }
}


@end

