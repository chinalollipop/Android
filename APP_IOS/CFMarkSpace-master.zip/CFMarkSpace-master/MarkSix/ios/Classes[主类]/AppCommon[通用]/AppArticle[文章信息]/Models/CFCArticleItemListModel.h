//
// 首页 - 文章信息 - 分类列表
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCArticleItemListModel : NSObject

@property (nonatomic, strong) NSNumber *uuid;
@property (nonatomic, strong) NSNumber *comments;
@property (nonatomic, strong) NSNumber *period_count;
@property (nonatomic, strong) NSNumber *column_id;
@property (nonatomic, strong) NSNumber *right_lian;
@property (nonatomic, copy) NSString *des;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, strong) NSNumber *good;
@property (nonatomic, copy) NSString *dateline;
@property (nonatomic, copy) NSString *avatar;
@property (nonatomic, strong) NSNumber *percent;
@property (nonatomic, strong) NSNumber *right_count;
@property (nonatomic, strong) NSNumber *fans;
@property (nonatomic, copy) NSString *name;

@end

NS_ASSUME_NONNULL_END
