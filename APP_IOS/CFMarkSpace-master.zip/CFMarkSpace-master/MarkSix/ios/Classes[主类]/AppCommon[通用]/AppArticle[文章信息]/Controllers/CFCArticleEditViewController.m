//
// 首页 - 文章信息 - 分类列表
//

#import "CFCArticleEditViewController.h"
#import "CFCTextView.h"


@interface CFCArticleEditViewController () <UITextViewDelegate>

@property (nonatomic, strong) UIView *articleNormalContainerView;
@property (nonatomic, strong) UITextField *articleTitleTextView;
@property (nonatomic, strong) CFCTextView *articleContentTextView;
@property (nonatomic, strong) UIButton *confirmButton;

@end

@implementation CFCArticleEditViewController


#pragma mark -
#pragma mark 事件处理 - 发布帖子
- (void)doConfirmAction:(UIButton *)button
{
  [self resignFirstResponderOfTextField];
  
  // 文章标题
  NSString *title = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.articleTitleTextView.text];
  if ([CFCSysUtil validateStringEmpty:title]) {
    [self alertPromptInfoMessage:@"文章标题不能为空！"];
    return;
  }
  
  // 帖子内容
  NSString *content = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.articleContentTextView.text];
  if ([CFCSysUtil validateStringEmpty:content]) {
    [self alertPromptInfoMessage:@"发帖内容不能为空！"];
    return;
  }
  
  // 提交操作
  [self doConfirmActionArticleContent:content articleTitle:title];
}


#pragma mark 事件处理 - 发布帖子 - 逻辑操作
- (void)doConfirmActionArticleContent:(NSString *)content articleTitle:(NSString *)title
{
  NSString *url = URL_API_HOME_MAIN_PROJECT_ARTICLE_EDIT_SUBMIT;
  NSMutableDictionary *params = [CFCNetworkParamsUtil getArticleEditSubmitParameters:self.classifyId title:title content:content];
  CFCLog(@"\n请求地址：%@ \n请求参数：%@", url, params);
  [CFCNetworkHTTPSessionUtil POST:url parameters:params headerField:params success:^(id responseObject) {
    NSDictionary *responseData = (NSDictionary *)responseObject;
    CFCLog(@"[提交成功] => %@\n", responseData);
    NSString *message = [responseObject objectForKey:CFC_REQUEST_KEY_MESS];
    NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
    if ([CFCSysUtil validateResultCodeIsSuccess:status]) {
      [self alertPromptMessage:message okActionBlock:^(NSString *content) {
        [self.navigationController popViewControllerAnimated:YES];
      }];
    } else {
      NSString *message = [responseObject objectForKey:CFC_REQUEST_KEY_MESS];
      [self alertPromptErrorMessage:message];
    }
  } failure:^(NSError *error) {
    CFCLog(@"提交失败 = %@", error);
    [self alertPromptErrorMessage:@"发帖失败！"];
  } showMessage:@"发帖中" showProgressHUD:YES showProgressView:self.view isHideErrorMessage:YES];
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    
  }
  return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  [self createMainUIView];
}

#pragma mark 创建主要界面
- (void)createMainUIView
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat margin_top = margin * 1.50f;
  CGFloat margin_left = margin * 1.50f;
  CGFloat margin_right = margin * 1.50f;
  CGFloat margin_bottom = margin * 2.00f;
  CGFloat text_view_height = SCREEN_WIDTH * 0.7f;
  
  CGFloat buttonHeight = CFC_AUTOSIZING_WIDTH(SYSTEM_GLOBAL_BUTTON_HEIGHT); // 登录、快速注册按钮高度
  CGFloat textFieldHeight = CFC_AUTOSIZING_WIDTH(45.0f); // 用户名、密码输入框高度

  UIFont *textFieldFont = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]; // 输入框字体
  UIColor *textFieldColor = [UIColor colorWithRed:0.20 green:0.20 blue:0.20 alpha:1.00]; // 输入框文字颜色
  UIColor *textFieldPlaceholderColor = COLOR_HEXSTRING(@"#9B9B9B"); // 输入框暂位符颜色
  UIColor *textBackgroundColor = COLOR_HEXSTRING(@"#F0F1F2"); // 输入框背景颜色
  
  
  // 根容器
  UIScrollView *rootScrollView = ({
    TPKeyboardAvoidingScrollView *scrollView = [[TPKeyboardAvoidingScrollView alloc] init];
    [scrollView setShowsVerticalScrollIndicator:NO];
    [self.view addSubview:scrollView];
    
    [scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(self.view).with.offset(0.0);
      make.right.equalTo(self.view).with.offset(0.0);
      make.top.equalTo(self.view.mas_top).with.offset(0.0f);
      make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0f);
    }];
    
    scrollView;
  });
  
  
  // 主容器
  UIView *containerView = ({
    UIView *view = [[UIView alloc] init];
    [rootScrollView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.edges.equalTo(rootScrollView);
      make.width.equalTo(rootScrollView);
      make.height.mas_equalTo(SCREEN_HEIGHT-STATUS_NAVIGATION_BAR_HEIGHT+1.0f);
    }];
    view;
  });
  
  
  // 主要区域
  {
    // 容器视图
    UIView *articleNormalContainerView = ({
      UIView *view = [[UIView alloc] init];
      [containerView addSubview:view];
      
      [view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(@0);
        make.right.equalTo(@0);
        make.top.equalTo(containerView.mas_top);
      }];
      
      view;
    });
    self.articleNormalContainerView = articleNormalContainerView;
    
    
    // 文章标题
    UITextField *articleTitleTextView = [UITextField new];
    [articleNormalContainerView addSubview:articleTitleTextView];
    [articleTitleTextView setFont:textFieldFont];
    [articleTitleTextView setTextColor:textFieldColor];
    [articleTitleTextView setBorderStyle:UITextBorderStyleRoundedRect];
    [articleTitleTextView setBackgroundColor:textBackgroundColor];
    [articleTitleTextView setClearButtonMode:UITextFieldViewModeWhileEditing];
    [articleTitleTextView setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
    [articleTitleTextView setAttributedPlaceholder:[[NSAttributedString alloc] initWithString:@"标题：请输入标题" attributes:@{ NSForegroundColorAttributeName : textFieldPlaceholderColor }]];
    [articleTitleTextView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(articleNormalContainerView.mas_top).offset(margin_top);
      make.left.equalTo(articleNormalContainerView.mas_left).offset(margin_left);
      make.right.equalTo(articleNormalContainerView.mas_right).with.offset(-margin_right);
      make.height.equalTo(@(textFieldHeight));
    }];
    self.articleTitleTextView = articleTitleTextView;
    self.articleTitleTextView.mas_key = @"articleTitleTextView";
    
    
    // 输入控件
    CFCTextView *articleContentTextView = ({
      CFCTextView *textView = [CFCTextView textView];
      [textView setDelegate:self];
      [textView setFont:textFieldFont];
      [textView setBorderWidth:0.5f];
      [textView setCornerRadius:5.0f];
      [textView setTextColor:textFieldColor];
      [textView setBorderColor:UIColor.lightGrayColor];
      [textView setBackgroundColor:textBackgroundColor];
      [textView setPlaceholder:@"内容：请输入内容"];
      [textView setPlaceholderFont:textFieldFont];
      [textView setPlaceholderColor:textFieldPlaceholderColor];
      [textView setTranslatesAutoresizingMaskIntoConstraints:NO];
      [articleNormalContainerView addSubview:textView];
      
      [articleNormalContainerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"H:|-%f-[textView]-%f-|", margin_left, margin_right]
                                                                                         options:kNilOptions
                                                                                         metrics:nil
                                                                                           views:NSDictionaryOfVariableBindings(textView)]];
      [articleNormalContainerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"V:|-[articleTitleTextView]-%f-[textView(==%f)]", margin_top, text_view_height]
                                                                                         options:kNilOptions
                                                                                         metrics:nil
                                                                                           views:NSDictionaryOfVariableBindings(textView,articleTitleTextView)]];
      
      textView;
    });
    self.articleContentTextView = articleContentTextView;
    self.articleContentTextView.mas_key = @"articleContentTextView";
    
    
    // 发布帖子
    UIButton *confirmButton = ({
      UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
      [button loginStyleButton];
      [button setTitle:@"发布帖子" forState:UIControlStateNormal];
      [button addTarget:self action:@selector(doConfirmAction:) forControlEvents:UIControlEventTouchUpInside];
      [articleNormalContainerView addSubview:button];
      
      [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(articleContentTextView.mas_bottom).offset(margin*2.5f);
        make.left.equalTo(articleNormalContainerView.mas_left).offset(margin_left);
        make.right.equalTo(articleNormalContainerView.mas_right).with.offset(-margin_right);
        make.height.equalTo(@(buttonHeight));
      }];
      
      button;
    });
    self.confirmButton = confirmButton;
    
    
    // 约束的完整性
    [articleNormalContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.bottom.equalTo(confirmButton.mas_bottom).offset(margin_bottom);
    }];
    
  } // 登录区域
  
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_ARTICLE_EDIT;
}


#pragma mark -
#pragma mark 注销输入框响应事件
- (void)resignFirstResponderOfTextField
{
  [self.view endEditing:YES];
  [self.articleTitleTextView resignFirstResponder];
  [self.articleContentTextView resignFirstResponder];
}


#pragma mark 响应点击事件
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
  [self resignFirstResponderOfTextField];
}




@end
