//
// 首页 - 文章信息 - 分类列表
//

#import "CFCArticleItemListModel.h"

@implementation CFCArticleItemListModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"uuid" : @"id"
           };
}

@end
