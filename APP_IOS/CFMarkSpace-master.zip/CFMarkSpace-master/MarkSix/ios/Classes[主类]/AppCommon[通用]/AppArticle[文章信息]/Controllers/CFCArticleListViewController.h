//
// 首页 - 文章信息 - 分类列表
//

#import "CFCTableRefreshViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCArticleListViewController : CFCTableRefreshViewController

@property (nonnull, nonatomic, copy) NSString *classifyId;

@end

NS_ASSUME_NONNULL_END
