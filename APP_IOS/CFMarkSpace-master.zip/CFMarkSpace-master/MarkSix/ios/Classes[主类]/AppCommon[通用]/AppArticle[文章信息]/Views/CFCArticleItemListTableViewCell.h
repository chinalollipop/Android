//
// 首页 - 文章信息 - 分类列表
//

#import <UIKit/UIKit.h>
@class CFCArticleItemListModel;


NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_ARTICLE_ITEM_LIST_IDENTIFIER;

@protocol CFCArticleItemListTableViewCellDelegate <NSObject>
@optional
- (void)didSelectRowAtArticleItemListModel:(CFCArticleItemListModel *)model rowAtIndexPath:(NSIndexPath *)indexPath;
- (void)didFavouriteButtonAtArticleItemListModel:(CFCArticleItemListModel *)model rowAtIndexPath:(NSIndexPath *)indexPath;
@end

@interface CFCArticleItemListTableViewCell : UITableViewCell

@property (nonatomic, strong) NSIndexPath *indexPath;

@property (nonatomic, strong) CFCArticleItemListModel *model;

@property (nonatomic, weak) id<CFCArticleItemListTableViewCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
