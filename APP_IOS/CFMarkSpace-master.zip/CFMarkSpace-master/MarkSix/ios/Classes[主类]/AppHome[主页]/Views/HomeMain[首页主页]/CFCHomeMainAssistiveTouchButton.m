// 首页 - 悬浮按钮

#import "CFCHomeMainAssistiveTouchButton.h"

@implementation CFCHomeMainAssistiveTouchButton

- (void)drawRect:(CGRect)rect
{
  CGFloat itemSize = rect.size.width*0.5f;
  UIView *closeContainer = [[UIView alloc] init];
  [self addSubview:closeContainer];
  UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressCloseContainerView:)];
  [closeContainer addGestureRecognizer:tapGesture];
  [closeContainer setFrame:CGRectMake(rect.size.width-itemSize*1.0f, 0, itemSize, itemSize)];
  
  CGFloat size = itemSize * 0.65f;
  UIImage *image = [UIImage imageNamed:ICON_TOUCH_CLOSE];
  UIImageView *closeImageView = [[UIImageView alloc] initWithImage:image];
  [closeImageView setFrame:CGRectMake(itemSize-size, 0, size, size)];
  [closeImageView setUserInteractionEnabled:YES];
  [closeContainer addSubview:closeImageView];
}

- (void)pressCloseContainerView:(UITapGestureRecognizer *)gesture
{
  if (self.clickCloseBlock) {
    self.clickCloseBlock();
  }
}

@end

