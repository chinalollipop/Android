//
// 首页 - 项目列表
//

#import <UIKit/UIKit.h>
@class CFCHomeMainProjectModel, CFCHomeMainProjectItemModel;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_HOME_MAIN_PROJECT_IDENTIFIER;

@protocol CFCHomeMainProjectTableViewCellDelegate <NSObject>
@optional
- (void)didSelectRowAtHomeMainProjecrtItemModel:(CFCHomeMainProjectItemModel *)model;
@end

@interface CFCHomeMainProjectTableViewCell : UITableViewCell

@property (nonatomic, strong) CFCHomeMainProjectModel *model;

@property (nonatomic, weak) id<CFCHomeMainProjectTableViewCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
