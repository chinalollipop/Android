//
//  首页 - 通知公告
//

#import <UIKit/UIKit.h>
@class CFCHomeMainNoticeModel, CFCHomeMainNoticeItemModel;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_HOME_MAIN_NOTICE_IDENTIFIER;

@protocol CFCHomeMainNoticeTableViewCellDelegate <NSObject>
@optional
- (void)didSelectRowAtHomeMainNoticeItemModel:(CFCHomeMainNoticeItemModel *)model;
@end

@interface CFCHomeMainNoticeTableViewCell : UITableViewCell

@property (nonatomic, strong) CFCHomeMainNoticeModel *model;

@property (nonatomic, weak) id<CFCHomeMainNoticeTableViewCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
