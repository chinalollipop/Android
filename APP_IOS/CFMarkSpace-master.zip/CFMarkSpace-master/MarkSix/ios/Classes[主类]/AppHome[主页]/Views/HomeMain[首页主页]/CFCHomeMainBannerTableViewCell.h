//
//  首页 - 广告横幅
//

#import <UIKit/UIKit.h>
@class CFCHomeMainBannerModel, CFCHomeMainBannerItemModel;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_HOME_MAIN_BANNER_IDENTIFIER;

@protocol CFCHomeMainBannerTableViewCellDelegate <NSObject>
@optional
- (void)didSelectRowAtHomeMainBannerItemModel:(CFCHomeMainBannerItemModel *)model;
@end

@interface CFCHomeMainBannerTableViewCell : UITableViewCell

@property (nonatomic, strong) CFCHomeMainBannerModel *model;

@property (nonatomic, weak) id<CFCHomeMainBannerTableViewCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
