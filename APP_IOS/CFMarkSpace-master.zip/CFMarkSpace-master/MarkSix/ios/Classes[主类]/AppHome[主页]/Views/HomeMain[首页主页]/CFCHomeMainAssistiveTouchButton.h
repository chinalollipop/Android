// 首页 - 悬浮按钮

#import "CFCAssistiveTouchButton.h"

NS_ASSUME_NONNULL_BEGIN

typedef void(^CFCHomeMainAssistiveTouchButtonClickCloseBlock)(void);

@interface CFCHomeMainAssistiveTouchButton : CFCAssistiveTouchButton

@property (nonatomic, copy) CFCHomeMainAssistiveTouchButtonClickCloseBlock clickCloseBlock;

@end

NS_ASSUME_NONNULL_END
