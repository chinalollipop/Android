//
// 首页 - 开奖历史
//

#import <UIKit/UIKit.h>
@class CFCProjectKJLSModel;


NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_PROJECT_KAIJIANGLISHI_IDENTIFIER;

@protocol CFCProjectKJLSTableViewCellDelegate <NSObject>
@optional
- (void)didSelectRowAtProjectKJLSModel:(CFCProjectKJLSModel *)model;
@end

@interface CFCProjectKJLSTableViewCell : UITableViewCell

@property (nonatomic, strong) CFCProjectKJLSModel *model;

@property (nonatomic, weak) id<CFCProjectKJLSTableViewCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
