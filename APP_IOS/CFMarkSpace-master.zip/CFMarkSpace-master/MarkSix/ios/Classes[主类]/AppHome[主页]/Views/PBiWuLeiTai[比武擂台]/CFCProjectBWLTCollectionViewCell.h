//
// 首页 - 比武擂台
//

#import <UIKit/UIKit.h>
@class CFCProjectBWLTModel;


NS_ASSUME_NONNULL_BEGIN


UIKIT_EXTERN NSString * const CELL_IDENTIFIER_PROJECT_BWLT_COLLECTION_VIEW_CELL;


@protocol CFCProjectBWLTCollectionViewCellDelegate <NSObject>
@optional
- (void)didSelectRowAtProjectBWLTModel:(CFCProjectBWLTModel *)model indexPath:(NSIndexPath *)indexPath;
@end


@interface CFCProjectBWLTCollectionViewCell : UICollectionViewCell
/**
 * 数据下标
 */
@property (nonatomic, strong) NSIndexPath *indexPath;
/**
 * 数据模型
 */
@property (nonatomic, strong) CFCProjectBWLTModel *model;
/**
 * 表格代理
 */
@property (nonatomic, weak) id<CFCProjectBWLTCollectionViewCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END

