//
// 首页 - 开奖历史
//

#import "CFCProjectKJLSTableViewCell.h"
#import "CFCProjectKJLSModel.h"


// Cell Identifier
NSString * const CELL_IDENTIFIER_PROJECT_KAIJIANGLISHI_IDENTIFIER = @"CFCProjectKJLSTableViewCellIdentifier";

@interface CFCProjectKJLSTableViewCell ()
/**
 * 根容器组件
 */
@property (nonnull, nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonnull, nonatomic, strong) UIView *publicContainerView;
/**
 * 标题容器
 */
@property (nonnull, nonatomic, strong) UIView *titleContainerView;
/**
 * 标题控件
 */
@property (nonnull, nonatomic, strong) UILabel *titleIssueLabel;
/**
 * 分割控件
 */
@property (nonnull, nonatomic, strong) UIView *separatorLineView;


@end

@implementation CFCProjectKJLSTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
  if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
    [self createViewAtuoLayout];
  }
  return self;
}

#pragma mark 创建子控件
- (void)createViewAtuoLayout
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  
  // 根容器
  UIView *rootContainerView = ({
    UIView *view = [[UIView alloc] init];
    [self.contentView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
    }];
    
    view;
  });
  self.rootContainerView = rootContainerView;
  self.rootContainerView.mas_key = @"rootContainerView";
  
  // 标题期号
  UIView *titleContainerView = ({
    // 容器
    UIView *container = [[UIView alloc] init];
    [container setBackgroundColor:COLOR_TABLEVIEW_HEADER_VIEW_BACKGROUND_DEFAULT];
    [rootContainerView addSubview:container];
    [container mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.height.mas_equalTo(CFC_AUTOSIZING_HEIGTH(37.0f));
    }];
    
    // 期号
    UILabel *titleIssueLabel = ({
      UILabel *label = [UILabel new];
      [container addSubview:label];
      [label setFont:[UIFont fontWithName:@"NotoMono" size:CFC_AUTOSIZING_FONT(14)]];
      [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
      [label setTextAlignment:NSTextAlignmentLeft];
      
      [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(container.mas_centerY);
        make.left.equalTo(container.mas_left).offset(margin*1.5f);
      }];
      
      label;
    });
    self.titleIssueLabel = titleIssueLabel;
    self.titleIssueLabel.mas_key = @"titleIssueLabel";
    
    container;
  });
  self.titleContainerView = titleContainerView;
  self.titleContainerView.mas_key = @"titleContainerView";
  
  // 公共容器
  UIView *publicContainerView = ({
    UIView *view = [[UIView alloc] init];
    [view.layer setMasksToBounds:YES];
    [view setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_DEFAULT];
    [rootContainerView addSubview:view];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressPublicItemView:)];
    [view addGestureRecognizer:tapGesture];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(titleContainerView.mas_bottom);
      make.right.equalTo(@0.0f);
      make.bottom.equalTo(rootContainerView.mas_bottom);
    }];
    
    view;
  });
  self.publicContainerView = publicContainerView;
  self.publicContainerView.mas_key = @"publicContainerView";
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCProjectKJLSModel *)model
{
  // 类型安全检查
  if (![model isKindOfClass:[CFCProjectKJLSModel class]]) {
    return;
  }
  
  _model = model;
  
  // 标题期号
  NSDate *datetime = [CFCDateUtil secondToDate:_model.datetime.doubleValue];
  NSString *dateTimeString = [CFCDateUtil dateFormattingWithDate:datetime toFormate:@"yyyy年MM月dd日"];
  NSString *titleString = [NSString stringWithFormat:@"%@第%@期推荐", dateTimeString, _model.issue];
  [self.titleIssueLabel setText:titleString];
  
  // 删除控件
  [self.publicContainerView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
  
  // 推荐内容
  NSCharacterSet *character = [NSCharacterSet characterSetWithCharactersInString:@"\n"];
  NSArray<NSString *> *splitConents = [_model.content componentsSeparatedByCharactersInSet:character];
  if (splitConents && splitConents.count > 0) {
    
    // 大小间距
    CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
    CGFloat margin_top = margin * 1.5f;
    CGFloat margin_left = margin * 1.5f;
    CGFloat margin_bottom = margin * 1.5f;
    CGFloat item_margin = margin * 1.2f;
    
    // 推荐内容元素
    UILabel *lastItemLabel = nil;
    for (NSInteger idx = 0; idx < splitConents.count; idx ++) {
      
      NSString *content = [splitConents objectAtIndex:idx];
      NSCharacterSet *character = [NSCharacterSet characterSetWithCharactersInString:@"||"];
      NSArray<NSString *> *splits = [content componentsSeparatedByCharactersInSet:character];
      if (!splits || splits.count == 0) {
        continue;
      }

      // 内容
      UILabel *itemLabel = ({
        UILabel *label = [UILabel new];
        [self.publicContainerView addSubview:label];
        [label setText:splits.firstObject];
        [label setTextAlignment:NSTextAlignmentLeft];
        [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
        [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(13)]];

        [label mas_makeConstraints:^(MASConstraintMaker *make) {
          if (!lastItemLabel) {
            make.top.equalTo(self.publicContainerView.mas_top).offset(margin_top);
            make.left.equalTo(self.publicContainerView.mas_left).offset(margin_left);
          } else {
            make.top.equalTo(lastItemLabel.mas_bottom).offset(item_margin);
            make.left.equalTo(lastItemLabel.mas_left);
          }
        }];
        
        label;
      });
      itemLabel.mas_key = [NSString stringWithFormat:@"itemLabel%ld", idx];
      
      // 标识
      if (splits.count > 1) {
        NSString *mark= [splits objectAtIndex:1];
        if (mark.boolValue) {
          NSString *markString = @"中";
          UIColor *mark_color = COLOR_HEXSTRING(@"#FFFFFF");
          UIColor *mark_background = COLOR_HEXSTRING(@"#FB0101");
          UIFont *mark_font = [UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(12)];
          CGFloat mark_width = [markString widthWithFont:mark_font constrainedToHeight:MAXFLOAT] + margin*0.35f;
          CGFloat mark_height = [markString heightWithFont:mark_font constrainedToWidth:MAXFLOAT] + margin*0.35f;
          
          UILabel *markLabel = ({
            UILabel *label = [UILabel new];
            [self.publicContainerView addSubview:label];
            [label setText:markString];
            [label setFont:mark_font];
            [label setTextColor:mark_color];
            [label setBackgroundColor:mark_background];
            [label setTextAlignment:NSTextAlignmentCenter];
            [label addCornerRadius:margin*0.25f];
            
            [label mas_makeConstraints:^(MASConstraintMaker *make) {
              make.width.equalTo(@(mark_width));
              make.height.equalTo(@(mark_height));
              make.centerY.equalTo(itemLabel.mas_centerY);
              make.left.equalTo(itemLabel.mas_right).offset(margin*1.0f);
            }];
            
            label;
          });
          markLabel.mas_key = [NSString stringWithFormat:@"markLabel%ld", idx];
        }
      }
      
      lastItemLabel = itemLabel;
    } // for (NSInteger idx = 0; idx < splitConents.count; idx ++)
    
    // 约束的完整性
    [self.publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.bottom.equalTo(lastItemLabel.mas_bottom).offset(margin_bottom).priority(749);
    }];
    
  } else {
    
    // 底部的分割线
    UIView *separatorLineView = ({
      UIView *view = [[UIView alloc] init];
      [self.publicContainerView addSubview:view];
      [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
      
      [view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleContainerView.mas_bottom).offset(0.0f);
        make.left.equalTo(self.publicContainerView.mas_left).offset(0.0f);
        make.right.equalTo(self.publicContainerView.mas_right).offset(0.0f);
        make.height.equalTo(@(SEPARATOR_LINE_HEIGHT));
      }];
      
      view;
    });
    separatorLineView.mas_key = @"separatorLineView";
    
    // 约束的完整性
    [self.publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.bottom.equalTo(separatorLineView.mas_bottom).offset(0.0f).priority(749);
    }];
  }
  
}

#pragma mark - 操作事件 - 点击事件
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture
{
  if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectRowAtProjectKJLSModel:)]) {
    [self.delegate didSelectRowAtProjectKJLSModel:self.model];
  }
  
}

@end





