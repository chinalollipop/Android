//
// 首页 - 六合高手
//

#import <UIKit/UIKit.h>
@class CFCProjectLHGSModel;


NS_ASSUME_NONNULL_BEGIN


UIKIT_EXTERN NSString * const CELL_IDENTIFIER_PROJECT_LHGS_COLLECTION_VIEW_CELL;


@protocol CFCProjectLHGSCollectionViewCellDelegate <NSObject>
@optional
- (void)didSelectRowAtProjectLHGSModel:(CFCProjectLHGSModel *)model indexPath:(NSIndexPath *)indexPath;
@end


@interface CFCProjectLHGSCollectionViewCell : UICollectionViewCell
/**
 * 数据下标
 */
@property (nonatomic, strong) NSIndexPath *indexPath;
/**
 * 数据模型
 */
@property (nonatomic, strong) CFCProjectLHGSModel *model;
/**
 * 表格代理
 */
@property (nonatomic, weak) id<CFCProjectLHGSCollectionViewCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END

