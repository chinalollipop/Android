//
// 首页 - 六合高手 - 分类列表
//

#import "CFCLHGSClassifyListTableViewCell.h"
#import "CFCLHGSClassifyListModel.h"


// Cell Identifier
NSString * const CELL_IDENTIFIER_LHGS_CLASSIFY_LIST_IDENTIFIER = @"CFCLHGSClassifyListTableViewCellIdentifier";

@interface CFCLHGSClassifyListTableViewCell ()
/**
 * 根容器组件
 */
@property (nonnull, nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonnull, nonatomic, strong) UIView *publicContainerView;
/**
 * 标签控件
 */
@property (nonnull, nonatomic, strong) UIView *markContainerView;
/**
 * 序号控件
 */
@property (nonnull, nonatomic, strong) UILabel *numberLabel;
/**
 * 头像控件
 */
@property (nonnull, nonatomic, strong) UIImageView *headerImageView;
/**
 * 描述控件
 */
@property (nonnull, nonatomic, strong) UILabel *descriptionLabel;
/**
 * 灰色分割
 */
@property (nonnull, nonatomic, strong) UIView *separatorLineView;
/**
 * 标题控件
 */
@property (nonnull, nonatomic, strong) UILabel *titleLabel;
/**
 * 中奖期数
 */
@property (nonnull, nonatomic, strong) UILabel *zhongJiangQiShuLabel;
/**
 * 粉丝控件
 */
@property (nonnull, nonatomic, strong) UILabel *fenShiLabel;
/**
 * 连中期数
 */
@property (nonnull, nonatomic, strong) UILabel *lianZhongLabel;
/**
 * 胜率
 */
@property (nonnull, nonatomic, strong) UILabel *winRateTitleLabel;
/**
 * 中奖概率
 */
@property (nonnull, nonatomic, strong) UILabel *winRateContentLabel;


@end


@implementation CFCLHGSClassifyListTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
  if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
    [self createViewAtuoLayout];
  }
  return self;
}

#pragma mark 创建子控件
- (void)createViewAtuoLayout
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat margin_top = margin*1.2f;
  CGFloat margin_left = margin*1.8f;
  CGFloat margin_right = margin*1.8f;
  CGFloat margin_bottom = margin*1.5f;
  
  CGFloat markSize = SCREEN_WIDTH * 0.10f;
  CGFloat imageSize = SCREEN_WIDTH * 0.14f;
  
  UIFont *autoDesFont = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16)];
  UIFont *autoTitleFont = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(17)];
  UIFont *autoContentFont = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15)];
  
  // 根容器
  UIView *rootContainerView = ({
    UIView *view = [[UIView alloc] init];
    [self.contentView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
    }];
    
    view;
  });
  self.rootContainerView = rootContainerView;
  self.rootContainerView.mas_key = @"rootContainerView";
  
  
  // 公共容器
  UIView *publicContainerView = ({
    UIView *view = [[UIView alloc] init];
    [view.layer setMasksToBounds:YES];
    [view setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_DEFAULT];
    [rootContainerView addSubview:view];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressPublicItemView:)];
    [view addGestureRecognizer:tapGesture];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.bottom.equalTo(rootContainerView.mas_bottom);
    }];
    
    view;
  });
  self.publicContainerView = publicContainerView;
  self.publicContainerView.mas_key = @"publicContainerView";
  
  
  // 灰色分割线
  UIView *separatorLineView = ({
    UIView *view = [[UIView alloc] init];
    [self.publicContainerView addSubview:view];
    [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(self.publicContainerView.mas_top);
      make.left.equalTo(self.publicContainerView.mas_left).offset(0.0f);
      make.right.equalTo(self.publicContainerView.mas_right).offset(0.0f);
      make.height.equalTo(@(margin));
    }];
    
    view;
  });
  separatorLineView.mas_key = @"separatorLineView";
  
  
  // 标签控件
  UIView *markContainerView = ({
    UIView *view = [[UIView alloc] init];
    [view.layer setMasksToBounds:YES];
    [view setBackgroundColor:COLOR_HEXSTRING(@"#B8C3C3")];
    [self.publicContainerView addSubview:view];

    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(separatorLineView.mas_bottom);
      make.size.mas_equalTo(CGSizeMake(markSize, markSize));
    }];
    
    view;
  });
  self.markContainerView = markContainerView;
  self.markContainerView.mas_key = @"markContainerView";
  
  
  // 序号控件
  UILabel *numberLabel = ({
    UILabel *label = [UILabel new];
    [markContainerView addSubview:label];
    [label setTextColor:[UIColor whiteColor]];
    [label setTextAlignment:NSTextAlignmentCenter];
    [label setFont:[UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(16)]];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(markContainerView.mas_top).offset(margin*0.3f);
      make.left.equalTo(markContainerView.mas_left).offset(margin*0.3f);
    }];
    
    label;
  });
  self.numberLabel = numberLabel;
  self.numberLabel.mas_key = @"numberLabel";
  
  
  // 头像控件
  UIImageView *headerImageView = ({
    UIImageView *imageView = [UIImageView new];
    [self.publicContainerView addSubview:imageView];
    [imageView setUserInteractionEnabled:YES];
    [imageView setContentMode:UIViewContentModeScaleAspectFit];
    [imageView addCornerRadius:imageSize*0.5f];
    
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(separatorLineView.mas_bottom).offset(margin_top);
      make.left.equalTo(self.publicContainerView.mas_left).offset(margin_left);
      make.size.mas_equalTo(CGSizeMake(imageSize, imageSize));
    }];
    
    imageView;
  });
  self.headerImageView = headerImageView;
  self.headerImageView.mas_key = @"headerImageView";
  

  // 标题控件
  UILabel *titleLabel = ({
    UILabel *label = [UILabel new];
    [self.publicContainerView addSubview:label];
    [label setNumberOfLines:2];
    [label setFont:autoTitleFont];
    [label setTextAlignment:NSTextAlignmentLeft];
    [label setTextColor:COLOR_HEXSTRING(@"#EE8100")];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(separatorLineView.mas_bottom).offset(margin_top*1.3f);
      make.left.equalTo(self.headerImageView.mas_right).offset(margin*1.0f);
      make.right.equalTo(self.publicContainerView.mas_centerX);
    }];
    
    label;
  });
  self.titleLabel = titleLabel;
  self.titleLabel.mas_key = @"titleLabel";
  
  
  // 中奖期数
  UILabel *zhongJiangQiShuLabel = ({
    UILabel *label = [UILabel new];
    [self.publicContainerView addSubview:label];
    [label setFont:autoContentFont];
    [label setTextAlignment:NSTextAlignmentLeft];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.bottom.equalTo(titleLabel.mas_bottom);
      make.left.equalTo(self.publicContainerView.mas_centerX).offset(margin*1.0f);
    }];
    
    label;
  });
  self.zhongJiangQiShuLabel = zhongJiangQiShuLabel;
  self.zhongJiangQiShuLabel.mas_key = @"zhongJiangQiShuLabel";

  
  // 中奖概率
  UILabel *winRateContentLabel = ({
    UILabel *label = [UILabel new];
    [self.publicContainerView addSubview:label];
    [label setFont:autoContentFont];
    [label setTextAlignment:NSTextAlignmentLeft];
    [label setTextColor:COLOR_HEXSTRING(@"#EA3223")];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.bottom.equalTo(self.titleLabel.mas_bottom);
      make.right.equalTo(self.publicContainerView.mas_right).offset(-margin_right);
    }];
    
    label;
  });
  self.winRateContentLabel = winRateContentLabel;
  self.winRateContentLabel.mas_key = @"winRateContentLabel";
  
  
  // 粉丝数量
  UILabel *fenShiLabel = ({
    UILabel *label = [UILabel new];
    [self.publicContainerView addSubview:label];
    [label setFont:autoContentFont];
    [label setTextAlignment:NSTextAlignmentLeft];
    [label setTextColor:COLOR_HEXSTRING(@"#EA3223")];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(self.titleLabel.mas_bottom).offset(imageSize*0.20f);
      make.left.equalTo(self.titleLabel.mas_left);
    }];
    
    label;
  });
  self.fenShiLabel = fenShiLabel;
  self.fenShiLabel.mas_key = @"fenShiLabel";
  
  
  // 连中期数
  UILabel *lianZhongLabel = ({
    UILabel *label = [UILabel new];
    [self.publicContainerView addSubview:label];
    [label setFont:autoContentFont];
    [label setTextAlignment:NSTextAlignmentLeft];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.bottom.equalTo(self.fenShiLabel.mas_bottom);
      make.left.equalTo(self.zhongJiangQiShuLabel.mas_left);
    }];
    
    label;
  });
  self.lianZhongLabel = lianZhongLabel;
  self.lianZhongLabel.mas_key = @"lianZhongLabel";
  
  
  // 中奖概率
  UILabel *winRateTitleLabel = ({
    UILabel *label = [UILabel new];
    [self.publicContainerView addSubview:label];
    [label setText:@"胜率"];
    [label setFont:autoContentFont];
    [label setTextAlignment:NSTextAlignmentLeft];
    [label setTextColor:COLOR_HEXSTRING(@"#EA3223")];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.bottom.equalTo(self.fenShiLabel.mas_bottom);
      make.right.equalTo(self.publicContainerView.mas_right).offset(-margin_right);
    }];
    
    label;
  });
  self.winRateTitleLabel = winRateTitleLabel;
  self.winRateTitleLabel.mas_key = @"winRateTitleLabel";
  
  
  // 内容
  UILabel *descriptionLabel = ({
    UILabel *label = [UILabel new];
    [self.publicContainerView addSubview:label];
    [label setUserInteractionEnabled:YES];
    [label setNumberOfLines:0];
    [label setFont:autoDesFont];
    [label setTextAlignment:NSTextAlignmentLeft];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(self.fenShiLabel.mas_bottom).offset(margin_left);
      make.left.equalTo(self.headerImageView.mas_left);
      make.right.equalTo(self.publicContainerView.mas_right).offset(-margin_right);
    }];
    
    label;
  });
  self.descriptionLabel = descriptionLabel;
  self.descriptionLabel.mas_key = @"descriptionLabel";
  
  
  // 约束的完整性
  [self.publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
    make.bottom.equalTo(descriptionLabel.mas_bottom).offset(margin_bottom).priority(749);
  }];
  
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCLHGSClassifyListModel *)model
{
  // 类型安全检查
  if (![model isKindOfClass:[CFCLHGSClassifyListModel class]]) {
    return;
  }
  
  _model = model;
  
  // 描述信息
  [self.descriptionLabel setText:_model.des];
  
  // 标题控件
  [self.titleLabel setText:_model.name];
  
  // 中奖期数
  NSString *zhongJiangQiShuString = [NSString stringWithFormat:@"%@中%@", _model.period_count.stringValue, _model.right_count.stringValue];
  [self.zhongJiangQiShuLabel setText:zhongJiangQiShuString];
  
  // 中奖概率
  [self.winRateContentLabel setText:[NSString stringWithFormat:@"%@%%", _model.percent.stringValue]];
  
  // 粉丝数量
  NSDictionary *attributesString = @{ NSForegroundColorAttributeName:COLOR_SYSTEM_MAIN_FONT_DEFAULT };
  NSDictionary *attributesNumber = @{ NSForegroundColorAttributeName:COLOR_HEXSTRING(@"#EA3223") };
  NSAttributedString *attributedString = [CFCSysUtil attributedString:@[ @"粉丝：", _model.fans.stringValue]
                                                       attributeArray:@[ attributesString, attributesNumber]];
  [self.fenShiLabel setAttributedText:attributedString];

  // 连中期数
  [self.lianZhongLabel setText:[NSString stringWithFormat:@"最大连中%@期", _model.right_lian.stringValue]];
  
  // 头像控件
  WEAKSELF(weakSelf);
  __block UIActivityIndicatorView *activityIndicator = nil;
  [self.headerImageView sd_setImageWithURL:[NSURL URLWithString:_model.avatar] placeholderImage:nil options:0 progress:^(NSInteger receivedSize, NSInteger expectedSize, NSURL * _Nullable targetURL) {
    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
      if (!activityIndicator) {
        [weakSelf.headerImageView addSubview:activityIndicator = [UIActivityIndicatorView.alloc initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite]];
        [activityIndicator setColor:COLOR_ACTIVITY_INDICATOR_BACKGROUND];
        [activityIndicator setCenter:weakSelf.headerImageView.center];
        [activityIndicator startAnimating];
      }
    }];
  } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
    [activityIndicator removeFromSuperview];
    activityIndicator = nil;
  }];
}


- (void)setIndexPath:(NSIndexPath *)indexPath
{
  _indexPath = indexPath;
  
  // 标签控件
  if (0 == self.indexPath.row) {
    [self.markContainerView setBackgroundColor:COLOR_HEXSTRING(@"#E73E3C")];
    [self.numberLabel setText:[NSString stringWithFormat:@"%ld", indexPath.row+1]];
    [self.numberLabel setFont:[UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(19)]];
  } else if (1 == self.indexPath.row) {
    [self.markContainerView setBackgroundColor:COLOR_HEXSTRING(@"#EE973E")];
    [self.numberLabel setText:[NSString stringWithFormat:@"%ld", indexPath.row+1]];
    [self.numberLabel setFont:[UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(19)]];
  } else if (2 == self.indexPath.row) {
    [self.markContainerView setBackgroundColor:COLOR_HEXSTRING(@"#F5D048")];
    [self.numberLabel setText:[NSString stringWithFormat:@"%ld", indexPath.row+1]];
    [self.numberLabel setFont:[UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(19)]];
  } else {
    [self.markContainerView setBackgroundColor:COLOR_HEXSTRING(@"#B8C3C3")];
    [self.numberLabel setText:[NSString stringWithFormat:@"%ld", indexPath.row+1]];
    [self.numberLabel setFont:[UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(17)]];
  }
}


#pragma mark - 操作事件 - 点击事件
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture
{
  if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectRowAtLHGSClassifyListModel:)]) {
    [self.delegate didSelectRowAtLHGSClassifyListModel:self.model];
  }
  
}


@end


