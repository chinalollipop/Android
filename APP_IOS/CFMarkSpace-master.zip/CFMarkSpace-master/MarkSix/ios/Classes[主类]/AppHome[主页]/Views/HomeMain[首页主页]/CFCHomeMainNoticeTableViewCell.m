//
//  首页 - 通知公告
//

#import "CFCHomeMainNoticeTableViewCell.h"
#import "CFCHomeMainNoticeModel.h"
#import "CFCMarqueeView.h"

CGFloat const SCROLL_BASE_NOTICE_HEIGHT = 40.0;

// Cell Identifier
NSString * const CELL_IDENTIFIER_HOME_MAIN_NOTICE_IDENTIFIER = @"CFCHomeMainNoticeTableViewCellIdentifier";

@interface CFCHomeMainNoticeTableViewCell ()<CFCMarqueeViewDelegate>
/**
 * 根容器
 */
@property (nonnull, nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonnull, nonatomic, strong) UIView *publicContainerView;
/**
 * 内容容器
 */
@property (nonnull, nonatomic, strong) CFCMarqueeView *marqueeView;
/**
 * 图标控件
 */
@property (nonnull, nonatomic, strong) UIImageView *iconImageView;

@end

@implementation CFCHomeMainNoticeTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
  if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
    [self createViewAtuoLayout];
  }
  return self;
}

#pragma mark 创建子控件
- (void)createViewAtuoLayout
{
  // 根容器组件
  self.rootContainerView = ({
    UIView *view = [[UIView alloc] init];
    [self.contentView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(@0);
      make.left.equalTo(@0);
      make.right.equalTo(@0);
      make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
    }];
    
    view;
  });
  self.rootContainerView.mas_key = @"rootContainerView";
  
  // 公共容器组件
  self.publicContainerView = ({
    UIView *view = [[UIView alloc] init];
    [view.layer setMasksToBounds:YES];
    [self.rootContainerView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(@0);
      make.left.equalTo(@0);
      make.right.equalTo(@0);
      make.bottom.equalTo(self.rootContainerView.mas_bottom).offset(0);
    }];

    view;
  });
  self.publicContainerView.mas_key = @"publicContainerView";
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCHomeMainNoticeModel *)model
{
  // 类型安全检查
  if (![model isKindOfClass:[CFCHomeMainNoticeModel class]]) {
    return;
  }
  
  _model = model;
  
  if (!model || model.items.count == 0) {
    return;
  }
  
  // Cell复用机制会出现阴影
  for(UIView *view in self.publicContainerView.subviews) {
    [view removeFromSuperview];
  }
  
  // 定义变量
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat heightOfMarque = CFC_AUTOSIZING_HEIGTH(SCROLL_BASE_NOTICE_HEIGHT);
  CGFloat widthOfMarque = SCREEN_WIDTH - heightOfMarque-margin;
  
  // 滚动公告
  self.marqueeView = ({
    CFCMarqueeView *marqueeView = [[CFCMarqueeView alloc] initWithFrame:CGRectMake(0, 0, widthOfMarque, heightOfMarque)
                                                              direction:CFCMarqueeViewDirectionLeftward];
    [marqueeView setDelegate:self];
    [marqueeView setTouchEnabled:YES];
    [marqueeView setTimeDurationPerScroll:0.5f];
    [marqueeView setTimeIntervalPerScroll:3.0f];
    [self.publicContainerView addSubview:marqueeView];
    [marqueeView reloadData];

    [marqueeView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(@0.0f);
      make.left.equalTo(@0.0f).offset(heightOfMarque);
      make.width.mas_equalTo(widthOfMarque);
      make.height.mas_equalTo(heightOfMarque);
    }];
    
    marqueeView;
  });
  self.marqueeView.mas_key = @"marqueeView";
  
  // 分割线 - 下
  UIView *separatorLineView = ({
    UIView *view = [[UIView alloc] init];
    [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
    [self.publicContainerView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(self.marqueeView.mas_bottom).offset(0.0f);
      make.left.equalTo(self.publicContainerView.mas_left).offset(0.0f);
      make.right.equalTo(self.publicContainerView.mas_right).offset(0.0f);
      make.height.mas_equalTo(SEPARATOR_LINE_HEIGHT);
    }];
    
    view;
  });
  separatorLineView.mas_key = @"separatorLineView";
  
  // 图标组件
  UIImageView *iconImageView = ({
    UIImageView *imageView = [UIImageView new];
    [self.publicContainerView addSubview:imageView];
    [imageView setImage:[UIImage imageNamed:ICON_MARQUE]];
    [imageView setContentMode:UIViewContentModeScaleAspectFit];

    CGFloat height = heightOfMarque*0.43f;
    CGFloat width = height * 1.125f;
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(self.publicContainerView.mas_left).offset(margin);
      make.centerY.equalTo(self.publicContainerView.mas_centerY);
      make.width.mas_equalTo(width);
      make.height.mas_equalTo(height);
    }];
    
    imageView;
  });
  iconImageView.mas_key = [NSString stringWithFormat:@"iconImageView"];
  
  // 约束完整性
  [self.publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
    make.bottom.equalTo(separatorLineView.mas_bottom).offset(0.0).priority(749);
  }];
}


#pragma mark -
#pragma mark CFCMarqueeViewDelegate
- (NSUInteger)numberOfDataForMarqueeView:(CFCMarqueeView*)marqueeView
{
  return self.model.items ? self.model.items.count : 0;
}

- (void)createItemView:(UIView*)itemView forMarqueeView:(CFCMarqueeView*)marqueeView
{
  UIFont *fontOfContent = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(14.0f)];
  MarqueeLabel *contentLabel = [[MarqueeLabel alloc] initWithFrame:itemView.bounds
                                                          duration:15.0f
                                                     andFadeLength:10.0f];
  [contentLabel setTag:1001];
  [contentLabel setFont:fontOfContent];
  [contentLabel setTextColor:COLOR_HEXSTRING(@"#D32D26")];
  [contentLabel setTextAlignment:NSTextAlignmentLeft];
  [itemView addSubview:contentLabel];
}

- (void)updateItemView:(UIView*)itemView atIndex:(NSUInteger)index forMarqueeView:(CFCMarqueeView*)marqueeView
{
  if (!self.model.items || self.model.items.count <= 0) {
    return;
  }
  if (index > self.model.items.count-1) {
    index = self.model.items.count-1;
  }
  CFCHomeMainNoticeItemModel *model = self.model.items[index];
  
  UILabel *contentLabel = [itemView viewWithTag:1001];
  if (![CFCSysUtil validateStringEmpty:model.content]) {
    NSCharacterSet *character = [NSCharacterSet characterSetWithCharactersInString:@"\n\r"];
    NSArray<NSString *> *splits = [model.content componentsSeparatedByCharactersInSet:character];
    NSString *content = [splits componentsJoinedByString:@""];
    contentLabel.text = content;
  }
}

- (NSUInteger)numberOfVisibleItemsForMarqueeView:(CFCMarqueeView*)marqueeView
{
  return 1;
}

- (void)didTouchItemViewAtIndex:(NSUInteger)index forMarqueeView:(CFCMarqueeView*)marqueeView;
{
  if (index >= self.model.items.count) {
    CFCLog(@"数组越界，请检测代码。");
    return;
  }
  
  if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectRowAtHomeMainNoticeItemModel:)]) {
    [self.delegate didSelectRowAtHomeMainNoticeItemModel:self.model.items[index]];
  }
}

@end



