//
// 首页 - 最新开奖
//

#import <UIKit/UIKit.h>
@class CFCProjectKJLSDrawModel;

NS_ASSUME_NONNULL_BEGIN

#pragma mark 头部高度
UIKIT_EXTERN CGFloat const CONST_PROJECT_KJLS_TABLE_SECTION_HEADER_HIGHT;

@protocol CFCProjectKJLSDrawSectionHeaderDelegate <NSObject>
@optional
- (void)didSelectAtProjectKJLSDrawSecionHeader:(CFCProjectKJLSDrawModel *)drawResultModel;
@end

@interface CFCProjectKJLSDrawSectionHeader : UIView

@property (nonatomic, strong) CFCProjectKJLSDrawModel *drawResultModel;

@property (nonatomic, weak) id<CFCProjectKJLSDrawSectionHeaderDelegate> delegate;

- (instancetype)initWithFrame:(CGRect)frame
                     delegate:(id<CFCProjectKJLSDrawSectionHeaderDelegate>)delegate
              drawResultModel:(CFCProjectKJLSDrawModel *)drawResultModel;

@end

NS_ASSUME_NONNULL_END
