//
// 首页 - 六合高手 - 分类列表
//

#import <UIKit/UIKit.h>
@class CFCLHGSClassifyListModel;


NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_LHGS_CLASSIFY_LIST_IDENTIFIER;

@protocol CFCLHGSClassifyListTableViewCellDelegate <NSObject>
@optional
- (void)didSelectRowAtLHGSClassifyListModel:(CFCLHGSClassifyListModel *)model;
@end

@interface CFCLHGSClassifyListTableViewCell : UITableViewCell

@property (nonatomic, strong) NSIndexPath *indexPath;

@property (nonatomic, strong) CFCLHGSClassifyListModel *model;

@property (nonatomic, weak) id<CFCLHGSClassifyListTableViewCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
