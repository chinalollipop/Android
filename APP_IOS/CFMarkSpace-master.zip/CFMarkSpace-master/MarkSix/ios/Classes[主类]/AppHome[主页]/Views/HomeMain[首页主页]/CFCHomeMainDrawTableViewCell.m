//
// 首页 - 开奖结果
//

#import "CFCHomeMainDrawTableViewCell.h"
#import "CFCHomeMainDrawModel.h"

CGFloat const SCROLL_BASE_DRAW_HEIGHT = 146.0;

// Cell Identifier
NSString * const CELL_IDENTIFIER_HOME_MAIN_DRAW_IDENTIFIER = @"CFCHomeMainDrawTableViewCellIdentifier";

@interface CFCHomeMainDrawTableViewCell ()

/**
 * 根容器
 */
@property (nonnull, nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonnull, nonatomic, strong) UIView *publicContainerView;
/**
 * 图片容器
 */
@property (nonnull, nonatomic, strong) UIImageView *backgroundImageView;
/**
 * 当前期号
 */
@property (nonnull, nonatomic, strong) UILabel *issueCurrentLabel;
/**
 * 下期期号
 */
@property (nonnull, nonatomic, strong) UILabel *issueNextLabel;
/**
 * 指示箭头
 */
@property (nonnull, nonatomic, strong) UIImageView *arrowImageView;
/**
 * 开奖结果
 */
@property (nonnull, nonatomic, strong) NSMutableArray<UILabel *> *itemNumLabelArray;
@property (nonnull, nonatomic, strong) NSMutableArray<UIImageView *> *itemImageViewArray;
@property (nonnull, nonatomic, strong) NSMutableArray<UILabel *> *itemShengXiaoLabelArray;

@end

@implementation CFCHomeMainDrawTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
  if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
    [self createViewAtuoLayout];
  }
  return self;
}

#pragma mark 创建子控件
- (void)createViewAtuoLayout
{
  WEAKSELF(weakSelf);
  
  // 定义变量
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat heightOfBackground = CFC_AUTOSIZING_WIDTH(SCROLL_BASE_DRAW_HEIGHT);
  CGFloat left_right_margin_background_image = margin * 1.0f;
  
  // 根容器组件
  UIView *rootContainerView = ({
    UIView *view = [[UIView alloc] init];
    [self.contentView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(@0);
      make.left.equalTo(@0);
      make.right.equalTo(@0);
      make.bottom.equalTo(weakSelf.contentView.mas_bottom).with.offset(0);
    }];
    
    view;
  });
  self.rootContainerView = rootContainerView;
  self.rootContainerView.mas_key = @"rootContainerView";
  
  // 公共容器
  UIView *publicContainerView = ({
    UIView *view = [[UIView alloc] init];
    [view.layer setMasksToBounds:YES];
    [self.rootContainerView addSubview:view];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressItemView:)];
    [view addGestureRecognizer:tapGesture];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(@0);
      make.left.equalTo(@0);
      make.right.equalTo(@0);
      make.bottom.equalTo(weakSelf.rootContainerView.mas_bottom).offset(0);
    }];
    
    view;
  });
  self.publicContainerView = publicContainerView;
  self.publicContainerView.mas_key = @"publicContainerView";
  
  // 背景图片
  UIImageView *backgroundImageView = ({
    UIImageView *imageView = [UIImageView new];
    [self.publicContainerView addSubview:imageView];
    [imageView setUserInteractionEnabled:YES];
    [imageView setImage:[UIImage imageNamed:ICON_OPEN_RESULT_BACKGROUND]];
    [imageView setContentMode:UIViewContentModeScaleToFill];

    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(self.publicContainerView.mas_top).offset(margin*0.75f);
      make.left.equalTo(self.publicContainerView.mas_left).offset(left_right_margin_background_image);
      make.right.equalTo(self.publicContainerView.mas_right).offset(-left_right_margin_background_image);
      make.height.mas_equalTo(heightOfBackground);
    }];
    
    imageView;
  });
  self.backgroundImageView = backgroundImageView;
  self.backgroundImageView.mas_key = [NSString stringWithFormat:@"backgroundImageView"];
  
  // 当前期号
  UILabel *issueCurrentLabel = ({
    UILabel *label = [UILabel new];
    [self.publicContainerView addSubview:label];
    [label setNumberOfLines:0];
    [label setText:STR_APP_TEXT_PLACEHOLDER];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    [label setTextAlignment:NSTextAlignmentCenter];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(backgroundImageView.mas_top).offset(margin*1.0f);
      make.left.equalTo(backgroundImageView.mas_left).offset(margin*2.0f);
      make.right.equalTo(backgroundImageView.mas_right).offset(-margin*2.0f);
    }];
    
    label;
  });
  self.issueCurrentLabel = issueCurrentLabel;
  self.issueCurrentLabel.mas_key = [NSString stringWithFormat:@"issueCurrentLabel"];
  
  // 下期期号
  UILabel *issueNextLabel = ({
    UILabel *label = [UILabel new];
    [self.publicContainerView addSubview:label];
    [label setNumberOfLines:0];
    [label setText:STR_APP_TEXT_PLACEHOLDER];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    [label setTextAlignment:NSTextAlignmentCenter];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(13.0f)]];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.bottom.equalTo(backgroundImageView.mas_bottom).offset(-margin*2.0f);
      make.left.equalTo(backgroundImageView.mas_left).offset(margin*2.0f);
      make.right.equalTo(backgroundImageView.mas_right).offset(-margin*2.0f);
    }];
    
    label;
  });
  self.issueNextLabel = issueNextLabel;
  self.issueNextLabel.mas_key = [NSString stringWithFormat:@"issueNextLabel"];
  
  // 开奖结果
  {
    int colum = 8;
    CGFloat left_gap = margin * 2.5f;
    CGFloat right_gap = margin * 4.0f;
    CGFloat itemMargin = margin * 1.0f;
    CGFloat itemWidth = (SCREEN_WIDTH - left_right_margin_background_image*2.0f - left_gap - right_gap - itemMargin*(colum-3)) / colum;
    CGFloat itemHeight = itemWidth * 2.0f;
    CGFloat imageSize = itemWidth;
    UIFont *autoNumberFont = [UIFont fontWithName:@"NotoMono" size:CFC_AUTOSIZING_FONT(14)];
    UIFont *autoShengXiaoFont = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(14.0f)];
    UIColor *autoNumbeColor = COLOR_SYSTEM_MAIN_FONT_DEFAULT;
    UIColor *autoShengXiaoColor = COLOR_SYSTEM_MAIN_FONT_DEFAULT;
    
    _itemNumLabelArray = [NSMutableArray array];
    _itemImageViewArray = [NSMutableArray array];
    _itemShengXiaoLabelArray = [NSMutableArray array];
    
    UIView *lastItemView = nil;
    for (int i = 0; i < colum; i ++) {
      
      // 容器
      UIView *itemView = ({
        UIView *itemContainerView = [[UIView alloc] init];
        [backgroundImageView addSubview:itemContainerView];
        [itemContainerView mas_remakeConstraints:^(MASConstraintMaker *make) {
          make.width.equalTo(@(itemWidth));
          make.height.equalTo(@(itemHeight));
          
          if (!lastItemView) {
            make.centerY.equalTo(backgroundImageView.mas_centerY);
            make.left.equalTo(backgroundImageView.mas_left).offset(left_gap);
          } else {
            if (i < colum - 2) {
              make.top.equalTo(lastItemView.mas_top).offset(0);
              make.left.equalTo(lastItemView.mas_right).offset(itemMargin);
            } else {
              make.top.equalTo(lastItemView.mas_top);
              make.left.equalTo(lastItemView.mas_right);
            }
          }
        }];
        itemContainerView.mas_key = [NSString stringWithFormat:@"itemContainerView%d",i];
        
        // 图片
        UIImageView *iconImageView = ({
          UIImageView *imageView = [UIImageView new];
          [itemContainerView addSubview:imageView];
          [imageView setContentMode:UIViewContentModeScaleAspectFit];
          
          [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(itemContainerView.mas_top).offset(0.0f);
            make.centerX.equalTo(itemContainerView.mas_centerX).offset(0.0f);
            make.height.equalTo(@(imageSize));
            make.width.equalTo(@(imageSize));
          }];
          
          imageView;
        });
        iconImageView.mas_key = [NSString stringWithFormat:@"iconImageView%d", i];
        
        // 号码
        UILabel *numberLabel = ({
          UILabel *label = [UILabel new];
          [itemContainerView addSubview:label];
          [label setFont:autoNumberFont];
          [label setTextColor:autoNumbeColor];
          [label setTextAlignment:NSTextAlignmentLeft];
          
          [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(iconImageView.mas_top).offset(imageSize*0.18f);
            make.left.equalTo(itemContainerView.mas_left).offset(imageSize*0.21);
          }];
          
          label;
        });
        numberLabel.mas_key = [NSString stringWithFormat:@"numberLabel%d", i];

        // 生肖
        UILabel *shengXiaoLabel = ({
          UILabel *label = [UILabel new];
          [itemContainerView addSubview:label];
          [label setFont:autoShengXiaoFont];
          [label setTextColor:autoShengXiaoColor];
          [label setTextAlignment:NSTextAlignmentCenter];
          
          [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(itemContainerView.mas_centerX);
            make.top.equalTo(iconImageView.mas_bottom).offset(margin*1.0f);
          }];
          
          label;
        });
        shengXiaoLabel.mas_key = [NSString stringWithFormat:@"shengXiaoLabel%d", i];
        
        // 保存控件
        [_itemNumLabelArray addObject:numberLabel];
        [_itemImageViewArray addObject:iconImageView];
        [_itemShengXiaoLabelArray addObject:shengXiaoLabel];
        
        itemContainerView;
      });
      
      lastItemView = itemView;
    }
    
    // 指示箭头
    UIImageView *arrowImageView = ({
      UIImageView *imageView = [UIImageView new];
      [self.publicContainerView addSubview:imageView];
      [imageView setUserInteractionEnabled:YES];
      [imageView setImage:[UIImage imageNamed:ICON_OPEN_RESULT_ARROW]];
      [imageView setContentMode:UIViewContentModeScaleAspectFit];
      
      CGFloat width = imageSize*0.32f;
      CGFloat height = width*2.5f;
      [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(lastItemView.mas_right).offset(margin*1.0f);
        make.centerY.equalTo(lastItemView.mas_centerY);
        make.width.mas_equalTo(width);
        make.height.mas_equalTo(height);
      }];
      
      imageView;
    });
    self.arrowImageView = arrowImageView;
    self.arrowImageView.mas_key = [NSString stringWithFormat:@"arrowImageView"];
  }
  
  // 约束完整性
  [self.publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
    make.bottom.equalTo(backgroundImageView.mas_bottom).offset(-margin*0.25f).priority(749);
  }];
  
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCHomeMainDrawModel *)model
{
  // 类型安全检查
  if (![model isKindOfClass:[CFCHomeMainDrawModel class]]) {
    return;
  }
  
  _model = model;

  // 当前期号
  NSString *issueCurrent = [NSString stringWithFormat:@"第%@期最新开奖结果", self.model.drawCurrentModel.issue];
  [self.issueCurrentLabel setText:issueCurrent];
 
  // 下期期号
  NSString *issueNext = [NSString stringWithFormat:@"第%@期开奖：%@", self.model.drawNextModel.issue, self.model.drawNextModel.dateString];
  [self.issueNextLabel setText:issueNext];
  
  // 开奖号码
  NSArray<NSString *> *itemNumber = [self.model.drawCurrentModel.data split:@","];
  NSArray<NSString *> *itemColors = [self.model.drawCurrentModel.color split:@","];
  NSArray<NSString *> *itemShengXiao = [CFCAppGameUtil getChinaShengXiaoByNumberArray:itemNumber];
  for (int idx = 0; idx < self.itemImageViewArray.count; idx ++) {
    
    UILabel *itemNumberLabel = self.itemNumLabelArray[idx];
    UIImageView *itemImageView = self.itemImageViewArray[idx];
    UILabel *itemShengXiaoLabel = self.itemShengXiaoLabelArray[idx];
    
    if (itemNumber.count == idx + 1) {
      [itemNumberLabel setText:STR_APP_TEXT_EMPTY];
      [itemShengXiaoLabel setText:STR_APP_TEXT_EMPTY];
      [itemImageView setImage:[UIImage imageNamed:ICON_OPEN_RESULT_PLUS]];
      [itemImageView setTransform:CGAffineTransformMakeScale(0.5f,0.5f)];
    } else {
      // 号码
      NSString *number_value = idx < itemNumber.count ? itemNumber[idx] : itemNumber.lastObject;
      [itemNumberLabel setText:[NSString stringWithFormat:@"%02ld", number_value.integerValue]];
      // 图片
      NSString *image_name_value = idx < itemNumber.count ? itemColors[idx] : itemColors.lastObject;
      [itemImageView setImage:[UIImage imageNamed:[CFCAppGameUtil getIconImageNameByNumber:image_name_value]]];
      // 生肖
      NSString *sheng_xiao_value = idx < itemNumber.count ? itemShengXiao[idx] : itemShengXiao.lastObject;
      [itemShengXiaoLabel setText:[CFCSysUtil stringByTrimmingWhitespaceAndNewline:sheng_xiao_value]];
    }
    
  } // for (int idx = 0; idx < self.itemImageViewArray.count; idx ++)
  
}

#pragma mark - 操作事件 - 点击事件
- (void)pressItemView:(UITapGestureRecognizer *)gesture
{
  if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectRowAtHomeMainDrawModel:)]) {
    [self.delegate didSelectRowAtHomeMainDrawModel:self.model];
  }
  
}

@end



