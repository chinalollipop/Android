//
// 首页 - 资料大全
//

#import <UIKit/UIKit.h>
@class CFCProjectZLDQModel;


NS_ASSUME_NONNULL_BEGIN


UIKIT_EXTERN NSString * const CELL_IDENTIFIER_PROJECT_ZLDQ_COLLECTION_VIEW_CELL;


@protocol CFCProjectZLDQCollectionViewCellDelegate <NSObject>
@optional
- (void)didSelectRowAtProjectZLDQModel:(CFCProjectZLDQModel *)model indexPath:(NSIndexPath *)indexPath;
@end


@interface CFCProjectZLDQCollectionViewCell : UICollectionViewCell
/**
 * 数据下标
 */
@property (nonatomic, strong) NSIndexPath *indexPath;
/**
 * 数据模型
 */
@property (nonatomic, strong) CFCProjectZLDQModel *model;
/**
 * 表格代理
 */
@property (nonatomic, weak) id<CFCProjectZLDQCollectionViewCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END

