//
// 首页 - 资料大全
//

#import "CFCProjectZLDQCollectionViewCell.h"
#import "CFCProjectZLDQModel.h"


// Cell Identifier
NSString * const CELL_IDENTIFIER_PROJECT_ZLDQ_COLLECTION_VIEW_CELL = @"CFCProjectZLDQCollectionViewCellIdentifier";


@interface CFCProjectZLDQCollectionViewCell ()
/**
 * 根容器组件
 */
@property (nonnull, nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonnull, nonatomic, strong) UIView *publicContainerView;
/**
 * 标题控件
 */
@property (nonnull, nonatomic, strong) UILabel *titleLabel;

@end


@implementation CFCProjectZLDQCollectionViewCell

-(instancetype)initWithFrame:(CGRect)frame
{
  self = [super initWithFrame:frame];
  if(self) {
    [self createViewAtuoLayout];
  }
  return self;
}

#pragma mark 创建子控件
- (void) createViewAtuoLayout
{
  // 根容器
  UIView *rootContainerView = ({
    UIView *view = [[UIView alloc] init];
    [self.contentView insertSubview:view atIndex:0];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
    }];
    
    view;
  });
  self.rootContainerView = rootContainerView;
  self.rootContainerView.mas_key = @"rootContainerView";
  
  // 公共容器
  UIView *publicContainerView = ({
    UIView *view = [[UIView alloc] init];
    [rootContainerView addSubview:view];
    [view addBorderWithColor:COLOR_HEXSTRING(@"#E88B00")
                cornerRadius:5.0f
                    andWidth:1.0f];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressPublicItemView:)];
    [view addGestureRecognizer:tapGesture];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(rootContainerView.mas_left).offset(0.0f);
      make.top.equalTo(rootContainerView.mas_top).offset(0.0f);
      make.right.equalTo(rootContainerView.mas_right).offset(0.0f);
      make.bottom.equalTo(rootContainerView.mas_bottom).offset(0.0f);
    }];
    
    view;
  });
  self.publicContainerView = publicContainerView;
  self.publicContainerView.mas_key = @"publicContainerView";
  
  // 标题控件
  UILabel *titleLabel = ({
    UILabel *label = [UILabel new];
    [label setText:STR_APP_TEXT_PLACEHOLDER];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    [label setTextAlignment:NSTextAlignmentCenter];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
    [publicContainerView addSubview:label];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerX.equalTo(publicContainerView.mas_centerX);
      make.centerY.equalTo(publicContainerView.mas_centerY);
    }];
    
    label;
  });
  self.titleLabel = titleLabel;
  self.titleLabel.mas_key = @"titleLabel";
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCProjectZLDQModel *)model
{
  // 类型安全检查
  if (![model isKindOfClass:[CFCProjectZLDQModel class]]) {
    return;
  }
  
  // 数据赋值
  _model = (CFCProjectZLDQModel *)model;
  
  // 标题
  NSString *title = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:_model.title];
  [self.titleLabel setText:title];
}


#pragma mark - 操作事件 - 操作按钮
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture
{
  // 执行代理
  if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectRowAtProjectZLDQModel:indexPath:)]) {
    [self.delegate didSelectRowAtProjectZLDQModel:self.model indexPath:self.indexPath];
  }
}


@end





