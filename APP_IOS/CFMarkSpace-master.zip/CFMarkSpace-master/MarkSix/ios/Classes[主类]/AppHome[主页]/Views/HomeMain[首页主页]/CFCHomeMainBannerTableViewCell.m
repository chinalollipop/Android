//
//  首页 - 广告横幅
//

#import "CFCHomeMainBannerTableViewCell.h"
#import "CFCHomeMainBannerModel.h"

CGFloat const SCROLL_BASE_BANNER_HEIGHT = 110.0;

// Cell Identifier
NSString * const CELL_IDENTIFIER_HOME_MAIN_BANNER_IDENTIFIER = @"CFCHomeMainBannerTableViewCellIdentifier";

@interface CFCHomeMainBannerTableViewCell () <SDCycleScrollViewDelegate>

/**
 * 根容器
 */
@property (nonnull, nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonnull, nonatomic, strong) UIView *publicContainerView;
/**
 * 图片容器
 */
@property (nonnull, nonatomic, strong) SDCycleScrollView *cycleBannerADView;

@end

@implementation CFCHomeMainBannerTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
  if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
    [self createViewAtuoLayout];
  }
  return self;
}

#pragma mark 创建子控件
- (void)createViewAtuoLayout
{
  WEAKSELF(weakSelf);
  
  // 根容器组件
  self.rootContainerView = ({
    UIView *view = [[UIView alloc] init];
    [self.contentView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(@0);
      make.left.equalTo(@0);
      make.right.equalTo(@0);
      make.bottom.equalTo(weakSelf.contentView.mas_bottom).with.offset(0);
    }];
    
    view;
  });
  self.rootContainerView.mas_key = @"rootContainerView";
  
  
  // 公共容器组件
  self.publicContainerView = ({
    UIView *view = [[UIView alloc] init];
    [view.layer setMasksToBounds:YES];
    [self.rootContainerView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(@0);
      make.left.equalTo(@0);
      make.right.equalTo(@0);
      make.bottom.equalTo(weakSelf.rootContainerView.mas_bottom).offset(0);
    }];
    
    view;
  });
  self.publicContainerView.mas_key = @"publicContainerView";
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCHomeMainBannerModel *)model
{
  // 类型安全检查
  if (![model isKindOfClass:[CFCHomeMainBannerModel class]]) {
    return;
  }
  
  _model = model;
  
  if (!model || model.banners.count == 0) {
    return;
  }
  
  // Cell复用机制会出现阴影
  for(UIView *view in self.publicContainerView.subviews) {
    [view removeFromSuperview];
  }
  
  // 滚动广告栏
  self.cycleBannerADView = ({
    // 图片数据
    NSMutableArray<NSString *> *titleArray = [NSMutableArray array];
    NSMutableArray<NSString *> *imageUrlArray = [NSMutableArray array];
    [_model.banners enumerateObjectsUsingBlock:^(CFCHomeMainBannerItemModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
      [titleArray addObject:obj.title];
      [imageUrlArray addObject:obj.imageUrl];
    }];
    
    // 循环容器
    SDCycleScrollView *cycleBannerADView = [[SDCycleScrollView alloc] init];
    [cycleBannerADView setDelegate:self];
    [cycleBannerADView setShowPageControl:YES];
    [cycleBannerADView setAutoScrollTimeInterval:BANNER_ANIMATE_GAP_DURATION];
    [cycleBannerADView setPageControlStyle:SDCycleScrollViewPageContolStyleNone];
    [cycleBannerADView setPageControlAliment:SDCycleScrollViewPageContolAlimentCenter];
    [cycleBannerADView setPageDotColor:[UIColor colorWithRed:0.97 green:0.97 blue:0.97 alpha:1.00]];
    [cycleBannerADView setCurrentPageDotColor:[UIColor colorWithRed:0.83 green:0.15 blue:0.25 alpha:1.00]];
    [cycleBannerADView setCurrentPageDotImage:[UIImage imageNamed:@"pageControlCurrentDot"]];
    [cycleBannerADView setPageDotImage:[UIImage imageNamed:@"pageControlDot"]];
    [cycleBannerADView setPageControlDotSize:CGSizeMake(6, 6)];
    [cycleBannerADView setImageURLStringsGroup:imageUrlArray];
    // [cycleBannerADView setTitlesGroup:titleArray];
    [self.publicContainerView addSubview:cycleBannerADView];

    [cycleBannerADView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.height.equalTo(@(CFC_AUTOSIZING_HEIGTH(SCROLL_BASE_BANNER_HEIGHT)));
    }];
    
    cycleBannerADView;
  });
  self.cycleBannerADView.mas_key = @"cycleBannerADView";
  
  // 约束的完整性
  WEAKSELF(weakSelf);
  [self.publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
    make.bottom.equalTo(weakSelf.cycleBannerADView.mas_bottom).priority(749);
  }];
}

#pragma mark - 操作事件 - 点击事件
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index
{
  if (index >= self.model.banners.count) {
    CFCLog(@"数组越界，请检测代码。");
    return;
  }
  
  if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectRowAtHomeMainBannerItemModel:)]) {
    [self.delegate didSelectRowAtHomeMainBannerItemModel:self.model.banners[index]];
  }
}

@end



