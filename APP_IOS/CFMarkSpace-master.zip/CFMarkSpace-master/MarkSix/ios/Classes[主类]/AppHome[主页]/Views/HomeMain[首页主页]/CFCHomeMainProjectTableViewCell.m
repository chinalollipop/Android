//
// 首页 - 项目列表
//

#import "CFCHomeMainProjectTableViewCell.h"
#import "CFCHomeMainProjectModel.h"

// Cell Identifier
NSString * const CELL_IDENTIFIER_HOME_MAIN_PROJECT_IDENTIFIER = @"CFCHomeMainProjectTableViewCellIdentifier";

@interface CFCHomeMainProjectTableViewCell ()
/**
 * 根容器组件
 */
@property (nonnull, nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonnull, nonatomic, strong) UIView *publicContainerView;
/**
 * 分割控件
 */
@property (nonnull, nonatomic, strong) UIView *separatorLineView;
/**
 * 图片 - 标题
 */
@property (nonnull, nonatomic, strong) NSMutableArray<UILabel *> *itemTitleLabelArray;
@property (nonnull, nonatomic, strong) NSMutableArray<UIImageView *> *itemIconImageViewArray;
@property (nonnull, nonatomic, strong) NSMutableArray<UIView *> *itemContainerArray;

@end

@implementation CFCHomeMainProjectTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
  if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
    [self createViewAtuoLayout];
  }
  return self;
}

#pragma mark 创建子控件
- (void)createViewAtuoLayout
{
  // 根容器
  UIView *rootContainerView = ({
    UIView *view = [[UIView alloc] init];
    [self.contentView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
    }];
    
    view;
  });
  self.rootContainerView = rootContainerView;
  self.rootContainerView.mas_key = @"rootContainerView";
  
  // 公共容器
  UIView *publicContainerView = ({
    UIView *view = [[UIView alloc] init];
    [view.layer setMasksToBounds:YES];
    [view setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_DEFAULT];
    [rootContainerView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.bottom.equalTo(rootContainerView.mas_bottom).offset(0.0f);
    }];
    
    view;
  });
  self.publicContainerView = publicContainerView;
  self.publicContainerView.mas_key = @"publicContainerView";
  
  // 图片 - 标题 - 详情
  int colum = 3; // 列数
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat left_right_gap = margin * 0.0f;
  CGFloat itemWidth = (SCREEN_WIDTH - left_right_gap*2.0f) /colum;
  CGFloat itemHeight = itemWidth * 0.9f;
  CGFloat imageSize = itemWidth * 0.50;
  UIFont *autoNameFont = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(13.0f)];
  CGFloat autoHeightTitle = [@"标题" heightWithFont:autoNameFont constrainedToWidth:MAXFLOAT];
  
  _itemTitleLabelArray = [NSMutableArray array];
  _itemIconImageViewArray = [NSMutableArray array];
  _itemContainerArray = [NSMutableArray array];
  
  UIView *lastItemView = nil;
  for (int i = 0; i < colum; i ++) {
    
    // 容器
    UIView *itemView = ({
      UIView *itemContainerView = [[UIView alloc] init];
      [itemContainerView setTag:8000+i];
      [publicContainerView addSubview:itemContainerView];
      UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressItemView:)];
      [itemContainerView addGestureRecognizer:tapGesture];
      [itemContainerView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@(itemWidth));
        make.height.equalTo(@(itemHeight));
        
        if (!lastItemView) {
          make.top.equalTo(publicContainerView.mas_top).offset(0.0);
          make.left.equalTo(publicContainerView.mas_left).offset(left_right_gap);
        } else {
          if (i % colum == 0) {
            make.top.equalTo(lastItemView.mas_bottom).offset(0.0);
            make.left.equalTo(publicContainerView.mas_left).offset(left_right_gap);
          } else {
            make.top.equalTo(lastItemView.mas_top).offset(0);
            make.left.equalTo(lastItemView.mas_right).offset(0);
          }
        }
      }];
      itemContainerView.mas_key = [NSString stringWithFormat:@"itemContainerView%d",i];
      
      // 图片
      UIImageView *iconImageView = ({
        UIImageView *imageView = [UIImageView new];
        [itemContainerView addSubview:imageView];
        [imageView setUserInteractionEnabled:YES];
        [imageView setContentMode:UIViewContentModeScaleAspectFit];
        
        CGFloat offset_top = (itemHeight - imageSize - autoHeightTitle) /2.0f;
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
          make.top.equalTo(itemContainerView.mas_top).offset(offset_top);
          make.centerX.equalTo(itemContainerView.mas_centerX).offset(0.0f);
          make.height.equalTo(@(imageSize));
          make.width.equalTo(@(imageSize));
        }];
        
        imageView;
      });
      iconImageView.mas_key = [NSString stringWithFormat:@"iconImageView%d",i];
      
      // 标题
      UILabel *titleLabel = ({
        UILabel *label = [UILabel new];
        [itemContainerView addSubview:label];
        [label setNumberOfLines:0];
        [label setFont:autoNameFont];
        [label setText:STR_APP_TEXT_PLACEHOLDER];
        [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
        [label setTextAlignment:NSTextAlignmentCenter];
        
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
          make.left.equalTo(itemContainerView.mas_left).offset(margin/2.0f);
          make.right.equalTo(itemContainerView.mas_right).offset(-margin/2.0f);
          make.top.equalTo(iconImageView.mas_bottom).offset(margin/2.0f);
        }];
        
        label;
      });
      titleLabel.mas_key = [NSString stringWithFormat:@"titleLabel%d",i];
      
      // 分割线
      if (i < colum-1) {
        UIView *separatorLineView = ({
          UIView *view = [[UIView alloc] init];
          [itemContainerView addSubview:view];
          [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
          
          [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(itemContainerView.mas_right).offset(-SEPARATOR_LINE_HEIGHT/2.0);
            make.top.equalTo(itemContainerView.mas_top).offset(0.0f);
            make.bottom.equalTo(itemContainerView.mas_bottom).offset(0.0f);
            make.width.mas_equalTo(SEPARATOR_LINE_HEIGHT);
          }];
          
          view;
        });
        separatorLineView.mas_key = @"separatorLineView";
      }
      
      // 保存控件
      [_itemTitleLabelArray addObject:titleLabel];
      [_itemIconImageViewArray addObject:iconImageView];
      [_itemContainerArray addObject:itemContainerView];
      
      itemContainerView;
    });
    
    lastItemView = itemView;
  }
  
  // 分割线
  UIView *separatorLineView = ({
    UIView *view = [[UIView alloc] init];
    [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
    [publicContainerView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(lastItemView.mas_bottom).offset(0.0f);
      make.left.equalTo(publicContainerView.mas_left).offset(0.0f);
      make.right.equalTo(publicContainerView.mas_right).offset(0.0f);
      make.height.mas_equalTo(SEPARATOR_LINE_HEIGHT);
    }];
    
    view;
  });
  self.separatorLineView = separatorLineView;
  self.separatorLineView.mas_key = @"separatorLineView";
  
  // 约束完整性
  [self.publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
    make.bottom.equalTo(separatorLineView.mas_bottom).offset(0.0).priority(749);
  }];
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCHomeMainProjectModel *)model
{
  // 类型安全检查
  if (![model isKindOfClass:[CFCHomeMainProjectModel class]]) {
    return;
  }
  
  _model = model;
  
  for (int idx = 0; idx < self.itemIconImageViewArray.count; idx ++) {
    
    UILabel *itemTitleLable = self.itemTitleLabelArray[idx];
    UIImageView *itemImageView = self.itemIconImageViewArray[idx];
    UIView *itemContainerView = self.itemContainerArray[idx];
    
    if (idx < self.model.items.count) {
      [itemTitleLable setHidden:NO];
      [itemImageView setHidden:NO];
      [itemContainerView setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_DEFAULT];
      
      CFCHomeMainProjectItemModel *classModel = self.model.items[idx];
      // 标题
      [itemTitleLable setText:[CFCSysUtil stringByTrimmingWhitespaceAndNewline:classModel.title]];
      // 图片
      __block UIActivityIndicatorView *activityIndicator = nil;
      [itemImageView sd_setImageWithURL:[NSURL URLWithString:classModel.imageUrl] placeholderImage:nil options:0 progress:^(NSInteger receivedSize, NSInteger expectedSize, NSURL * _Nullable targetURL) {
        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
          if (!activityIndicator) {
            [itemImageView addSubview:activityIndicator = [UIActivityIndicatorView.alloc initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite]];
            [activityIndicator setColor:COLOR_ACTIVITY_INDICATOR_BACKGROUND];
            [activityIndicator setCenter:itemImageView.center];
            [activityIndicator startAnimating];
          }
        }];
      } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        [activityIndicator removeFromSuperview];
        activityIndicator = nil;
      }];
      
    } else {
      [itemTitleLable setHidden:YES];
      [itemImageView setHidden:YES];
      [itemContainerView setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
    }
    
  }
}

#pragma mark - 操作事件 - 点击事件
- (void)pressItemView:(UITapGestureRecognizer *)gesture
{
  UIView *itemView = (UIView*)gesture.view;
  
  NSUInteger index = itemView.tag - 8000;
  
  if (index >= self.model.items.count) {
    CFCLog(@"数组越界，请检测代码。");
    return;
  }
  
  if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectRowAtHomeMainProjecrtItemModel:)]) {
    [self.delegate didSelectRowAtHomeMainProjecrtItemModel:self.model.items[index]];
  }
  
}

@end





