//
// 首页 - 开奖结果
//

#import <UIKit/UIKit.h>
@class CFCHomeMainDrawModel;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_HOME_MAIN_DRAW_IDENTIFIER;

@protocol CFCHomeMainDrawTableViewCellDelegate <NSObject>
@optional
- (void)didSelectRowAtHomeMainDrawModel:(CFCHomeMainDrawModel *)model;
@end

@interface CFCHomeMainDrawTableViewCell : UITableViewCell

@property (nonatomic, strong) CFCHomeMainDrawModel *model;

@property (nonatomic, weak) id<CFCHomeMainDrawTableViewCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
