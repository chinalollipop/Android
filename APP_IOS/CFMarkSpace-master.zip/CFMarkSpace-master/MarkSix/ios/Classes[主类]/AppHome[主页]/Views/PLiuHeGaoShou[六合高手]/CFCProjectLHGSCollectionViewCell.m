//
// 首页 - 六合高手
//

#import "CFCProjectLHGSCollectionViewCell.h"
#import "CFCProjectLHGSModel.h"


// Cell Identifier
NSString * const CELL_IDENTIFIER_PROJECT_LHGS_COLLECTION_VIEW_CELL = @"CFCProjectLHGSCollectionViewCellIdentifier";


@interface CFCProjectLHGSCollectionViewCell ()
/**
 * 根容器组件
 */
@property (nonnull, nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonnull, nonatomic, strong) UIView *publicContainerView;
/**
 * 图片控件
 */
@property (nonnull, nonatomic, strong) UIImageView *iconImageView;

@end


@implementation CFCProjectLHGSCollectionViewCell

-(instancetype)initWithFrame:(CGRect)frame
{
  self = [super initWithFrame:frame];
  if(self) {
    [self createViewAtuoLayout];
  }
  return self;
}

#pragma mark 创建子控件
- (void) createViewAtuoLayout
{
  // 根容器
  UIView *rootContainerView = ({
    UIView *view = [[UIView alloc] init];
    [self.contentView insertSubview:view atIndex:0];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
    }];
    
    view;
  });
  self.rootContainerView = rootContainerView;
  self.rootContainerView.mas_key = @"rootContainerView";
  
  // 公共容器
  UIView *publicContainerView = ({
    UIView *view = [[UIView alloc] init];
    [rootContainerView addSubview:view];

    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressPublicItemView:)];
    [view addGestureRecognizer:tapGesture];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(rootContainerView.mas_left).offset(0.0f);
      make.top.equalTo(rootContainerView.mas_top).offset(0.0f);
      make.right.equalTo(rootContainerView.mas_right).offset(0.0f);
      make.bottom.equalTo(rootContainerView.mas_bottom).offset(0.0f);
    }];
    
    view;
  });
  self.publicContainerView = publicContainerView;
  self.publicContainerView.mas_key = @"publicContainerView";
  
  // 图片控件
  UIImageView *iconImageView = ({
    UIImageView *imageView = [UIImageView new];
    [self.publicContainerView addSubview:imageView];
    [imageView setUserInteractionEnabled:YES];
    [imageView setContentMode:UIViewContentModeScaleAspectFit];
    
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.edges.equalTo(self.publicContainerView);
    }];
    
    imageView;
  });
  self.iconImageView = iconImageView;
  self.iconImageView.mas_key = @"iconImageView";
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCProjectLHGSModel *)model
{
  // 类型安全检查
  if (![model isKindOfClass:[CFCProjectLHGSModel class]]) {
    return;
  }
  
  // 数据赋值
  _model = (CFCProjectLHGSModel *)model;
  
  // 图片控件
  WEAKSELF(weakSelf);
  __block UIActivityIndicatorView *activityIndicator = nil;
  [self.iconImageView sd_setImageWithURL:[NSURL URLWithString:_model.imageUrl] placeholderImage:nil options:0 progress:^(NSInteger receivedSize, NSInteger expectedSize, NSURL * _Nullable targetURL) {
    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
      if (!activityIndicator) {
        [weakSelf.iconImageView addSubview:activityIndicator = [UIActivityIndicatorView.alloc initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite]];
        [activityIndicator setColor:COLOR_ACTIVITY_INDICATOR_BACKGROUND];
        [activityIndicator setCenter:weakSelf.iconImageView.center];
        [activityIndicator startAnimating];
      }
    }];
  } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
    [activityIndicator removeFromSuperview];
    activityIndicator = nil;
  }];
}


#pragma mark - 操作事件 - 操作按钮
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture
{
  // 执行代理
  if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectRowAtProjectLHGSModel:indexPath:)]) {
    [self.delegate didSelectRowAtProjectLHGSModel:self.model indexPath:self.indexPath];
  }
}


@end





