//
// 首页 - 开奖结果
//

#import "CFCHomeMainDrawModel.h"

@implementation CFCHomeMainDrawNextModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"dateString" : @"date"
           };
}

@end

@implementation CFCHomeMainDrawCurrentModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"date" : @"date"
           };
}

@end

@implementation CFCHomeMainDrawModel

@end
