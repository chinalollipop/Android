//
// 首页 - 资料大全
//

#import "CFCProjectZLDQModel.h"


@implementation CFCProjectZLDQModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"uuid" : @"id",
           @"title" : @"name",
           @"linkUrl" : @"url",
           @"imageUrl" : @"icon",
           @"isShow" : @"is_show"
           };
}

@end
