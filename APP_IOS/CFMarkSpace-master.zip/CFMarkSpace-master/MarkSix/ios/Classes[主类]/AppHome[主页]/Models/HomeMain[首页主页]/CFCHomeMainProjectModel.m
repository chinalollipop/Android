//
// 首页 - 项目列表
//

#import "CFCHomeMainProjectModel.h"

@implementation CFCHomeMainProjectItemModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"uuid" : @"id",
           @"markId" : @"sign",
           @"title" : @"name",
           @"imageUrl" : @"icon",
           @"isShow" : @"is_show"
           };
}

@end


@implementation CFCHomeMainProjectModel

@end
