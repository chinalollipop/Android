//
// 首页 - 开奖历史
//

#import "CFCProjectKJLSModel.h"

@implementation CFCProjectKJLSModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"year" : @"year",
           @"issue" : @"issue",
           @"datetime" : @"date",
           @"content" : @"data"
           };
}

@end
