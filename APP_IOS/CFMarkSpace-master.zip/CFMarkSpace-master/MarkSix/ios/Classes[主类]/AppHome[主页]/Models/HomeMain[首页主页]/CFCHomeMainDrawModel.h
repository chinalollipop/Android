//
// 首页 - 开奖结果
//

#import "CFCHomeMainBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCHomeMainDrawNextModel : NSObject
@property (nonatomic, strong) NSNumber *year;
@property (nonatomic, strong) NSNumber *issue;
@property (nonatomic, strong) NSNumber *number;
@property (nonatomic, copy) NSString *dateString;
@end

@interface CFCHomeMainDrawCurrentModel : NSObject
@property (nonatomic, copy) NSString *issue;
@property (nonatomic, copy) NSString *data;
@property (nonatomic, copy) NSString *color;
@property (nonatomic, copy) NSString *sx;
@property (nonatomic, copy) NSString *wx;
@property (nonatomic, strong) NSNumber *date;
@property (nonatomic, strong) NSNumber *sum_single_double;
@property (nonatomic, strong) NSNumber *sum_big_small;
@property (nonatomic, strong) NSNumber *special_single_double;
@property (nonatomic, strong) NSNumber *special_big_small;
@end

@interface CFCHomeMainDrawModel : CFCHomeMainBaseModel
@property (nonatomic, strong) CFCHomeMainDrawNextModel *drawNextModel;
@property (nonatomic, strong) CFCHomeMainDrawCurrentModel *drawCurrentModel;
@end

NS_ASSUME_NONNULL_END
