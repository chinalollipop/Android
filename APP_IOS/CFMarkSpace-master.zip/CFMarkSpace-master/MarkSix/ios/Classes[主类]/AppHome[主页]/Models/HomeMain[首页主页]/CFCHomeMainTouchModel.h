//
// 首页 - 全局触摸
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCHomeMainTouchModel : NSObject
@property (nonatomic, copy) NSString *linkUrl;
@property (nonatomic, copy) NSString *imageUrl;
@property (nonatomic, copy) NSString *isShow;
@end

NS_ASSUME_NONNULL_END
