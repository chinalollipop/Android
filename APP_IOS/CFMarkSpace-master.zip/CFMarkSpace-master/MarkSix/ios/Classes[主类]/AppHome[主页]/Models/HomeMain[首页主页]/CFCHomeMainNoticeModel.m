//
//  首页 - 通知公告
//

#import "CFCHomeMainNoticeModel.h"

@implementation CFCHomeMainNoticeItemModel

@end

@implementation CFCHomeMainNoticeModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"title" : @"app_title",
           @"content" : @"app_notice"
           };
}

@end
