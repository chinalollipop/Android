//
// 首页 - 开奖历史
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCProjectKJLSModel : NSObject

@property (nonatomic, copy) NSString *year;
@property (nonatomic, copy) NSString *issue;
@property (nonatomic, copy) NSString *datetime;
@property (nonatomic, copy) NSString *content;

@end

NS_ASSUME_NONNULL_END
