//
// 首页 - 六合高手 - 分类列表
//

#import "CFCLHGSClassifyListModel.h"

@implementation CFCLHGSClassifyListModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"uuid" : @"id"
           };
}

@end
