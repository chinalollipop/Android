//
// 首页 - 比武擂台
//

#import "CFCProjectBWLTModel.h"

@implementation CFCProjectBWLTModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"uuid" : @"id",
           @"title" : @"name",
           @"linkUrl" : @"url",
           @"imageUrl" : @"icon",
           @"isShow" : @"is_show"
           };
}

@end

