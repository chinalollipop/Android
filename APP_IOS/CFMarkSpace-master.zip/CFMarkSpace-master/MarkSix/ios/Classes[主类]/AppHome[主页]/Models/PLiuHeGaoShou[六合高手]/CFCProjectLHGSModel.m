//
// 首页 - 六合高手
//

#import "CFCProjectLHGSModel.h"

@implementation CFCProjectLHGSModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"uuid" : @"id",
           @"title" : @"name",
           @"linkUrl" : @"url",
           @"imageUrl" : @"icon",
           @"isShow" : @"is_show"
           };
}

@end
