// 首页 - 悬浮按钮

#import "CFCHomeMainTouchButtonModel.h"

@implementation CFCHomeMainTouchButtonModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"linkUrl" : @"url",
           @"imageUrl" : @"tip",
           @"isShow" : @"is_show"
           };
}

@end
