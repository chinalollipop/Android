//
// 首页 - 基础模型
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, CFCHomeMainTableSection) {
  CFCHomeMainTableSectionBanner, // 广告横幅
  CFCHomeMainTableSectionDrawresult, // 开奖结果
  CFCHomeMainTableSectionNoticeMessage, // 通知公告
  CFCHomeMainTableSectionToolLists // 工具列表
};

NS_ASSUME_NONNULL_BEGIN

@interface CFCHomeMainBaseModel : NSObject

@property (nonatomic, copy) NSString *sectonTitle;
@property (nonatomic, assign) CFCHomeMainTableSection sectionType;

@end

NS_ASSUME_NONNULL_END
