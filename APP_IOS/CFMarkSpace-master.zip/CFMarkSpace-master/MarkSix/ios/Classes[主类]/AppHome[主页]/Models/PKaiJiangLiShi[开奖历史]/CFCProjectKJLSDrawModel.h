//
// 首页 - 开奖历史 - 开奖结果
//

#import "CFCHomeMainDrawModel.h"
@class CFCHomeMainDrawNextModel, CFCHomeMainDrawCurrentModel;

NS_ASSUME_NONNULL_BEGIN

@interface CFCProjectKJLSDrawModel : NSObject
@property (nonatomic, strong) CFCHomeMainDrawNextModel *drawNextModel;
@property (nonatomic, strong) CFCHomeMainDrawCurrentModel *drawCurrentModel;
@end

NS_ASSUME_NONNULL_END
