//
// 首页 - 广告横幅
//

#import "CFCHomeMainBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCHomeMainBannerItemModel : NSObject
@property (nonatomic, strong) NSNumber *uuid;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *linkUrl;
@property (nonatomic, copy) NSString *imageUrl;
@end


@interface CFCHomeMainBannerModel : CFCHomeMainBaseModel
@property (nonatomic, strong) NSArray<CFCHomeMainBannerItemModel *> *banners;
@end

NS_ASSUME_NONNULL_END
