//
// 首页 - 基础模型
//


#import "CFCHomeMainBaseModel.h"

@implementation CFCHomeMainBaseModel

@end
