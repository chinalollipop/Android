//
// 首页 - 项目列表
//

#import "CFCHomeMainBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCHomeMainProjectItemModel : NSObject
@property (nonatomic, strong) NSNumber *uuid;
@property (nonatomic, copy) NSString *markId;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *imageUrl;
@property (nonatomic, copy) NSString *isShow;
@end


@interface CFCHomeMainProjectModel : CFCHomeMainBaseModel
@property (nonatomic, strong) NSArray<CFCHomeMainProjectItemModel *> *items;
@end

NS_ASSUME_NONNULL_END
