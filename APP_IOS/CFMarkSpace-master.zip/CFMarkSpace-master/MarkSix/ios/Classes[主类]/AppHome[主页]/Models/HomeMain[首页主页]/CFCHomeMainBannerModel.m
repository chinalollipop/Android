//
// 首页 - 广告横幅
//

#import "CFCHomeMainBannerModel.h"

@implementation CFCHomeMainBannerItemModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"uuid" : @"id",
           @"title" : @"desc",
           @"linkUrl" : @"url",
           @"imageUrl" : @"banner"
           };
}

@end

@implementation CFCHomeMainBannerModel

@end
