//
//  首页 - 通知公告
//

#import "CFCHomeMainBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCHomeMainNoticeItemModel : NSObject
@property (nonatomic, copy) NSString *uuid;
@property (nonatomic, copy) NSString *content;
@end


@interface CFCHomeMainNoticeModel : CFCHomeMainBaseModel
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *content;
@property (nonatomic, strong) NSArray<CFCHomeMainNoticeItemModel *> *items;
@end

NS_ASSUME_NONNULL_END
