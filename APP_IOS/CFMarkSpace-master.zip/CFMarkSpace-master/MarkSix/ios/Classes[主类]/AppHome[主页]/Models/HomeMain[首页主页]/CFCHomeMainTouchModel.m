//
// 首页 - 全局触摸
//

#import "CFCHomeMainTouchModel.h"

@implementation CFCHomeMainTouchModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"linkUrl" : @"url",
           @"imageUrl" : @"tip",
           @"isShow" : @"is_show"
           };
}

@end
