//
// 首页 - 资料大全 - 分类列表
//

#import "CFCArticleListViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCZLDQClassifyListViewController : CFCArticleListViewController

@end

NS_ASSUME_NONNULL_END
