//
// 首页 - 六合高手
//

#import "CFCProjectLHGSViewController.h"
#import "CFCProjectLHGSCollectionViewCell.h"
#import "CFCProjectLHGSModel.h"

// 跳转
#import "CFCLHGSClassifyListViewController.h"


@interface CFCProjectLHGSViewController () <CFCProjectLHGSCollectionViewCellDelegate>

@end


@implementation CFCProjectLHGSViewController


#pragma mark -
#pragma mark 事件处理 - 六合高手
- (void)didSelectRowAtProjectLHGSModel:(CFCProjectLHGSModel *)model indexPath:(NSIndexPath *)indexPath
{
  CFCLHGSClassifyListViewController *viewController = [[CFCLHGSClassifyListViewController alloc] init];
  [viewController setTitle:model.title];
  [viewController setClassifyId:model.uuid.stringValue];
  [self.navigationController pushViewController:viewController animated:YES];
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    self.hasCacheData = YES; // 是否需要加载缓存
    self.hasRefreshFooter = NO; // 是否可上拉加载
  }
  return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  
}


#pragma mark -
#pragma mark 请求地址
- (NSString *)getRequestURLString
{
  return URL_API_HOME_MAIN_PROJECT_LIUHEGAOSHOU;
}

#pragma mark 请求参数
- (NSMutableDictionary *)getRequestParamerter
{
  return [CFCNetworkParamsUtil getHomeMainProjectLiuHeGaoShouParameters];
}

#pragma mark 请求网络数据或加载缓存
- (NSMutableArray *)loadNetworkDataOrCacheDataSingle:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData
{
  WEAKSELF(weakSelf);
  
  NSDictionary *responseData = (NSDictionary *)responseDataOrCacheData;
  CFCLog(@"[六合高手][%@] => %@\n", CFC_DATA_TYPE(isCacheData), responseData);
  
  // 请求成功，解析数据
  NSDictionary *data = [responseData objectForKey:CFC_REQUEST_KEY_DATA];
  NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
  if (![CFCSysUtil validateResultCodeIsSuccess:status] || [CFCSysUtil validateObjectIsNull:data]) {
    return [NSMutableArray array];
  }
  
  
  /////////////////////////////////////////////////////////////////
  // A、组装数据 -> 开始
  /////////////////////////////////////////////////////////////////
  
  NSMutableArray<CFCProjectLHGSModel *> *allProjectLHGSModels = [NSMutableArray<CFCProjectLHGSModel *> array];
  [data[@"list"] enumerateObjectsUsingBlock:^(NSDictionary *  _Nonnull dict, NSUInteger idx, BOOL * _Nonnull stop) {
    CFCProjectLHGSModel *model = [CFCProjectLHGSModel mj_objectWithKeyValues:dict];
    if (model.isShow.boolValue) {
      [allProjectLHGSModels addObject:model];
    }
  }];
  
  /////////////////////////////////////////////////////////////////
  // A、组装数据 -> 结束
  /////////////////////////////////////////////////////////////////
  
  
  /////////////////////////////////////////////////////////////////
  // B、配置数据源  -> 开始
  /////////////////////////////////////////////////////////////////
  
  // 初始化数据源
  weakSelf.collectionViewDataRefresh = [NSMutableArray array];
  
  if (allProjectLHGSModels && 0 < allProjectLHGSModels.count) {
    [weakSelf.collectionViewDataRefresh addObject:allProjectLHGSModels.mutableCopy];
  }
  
  /////////////////////////////////////////////////////////////////
  // B、配置数据源  -> 结束
  /////////////////////////////////////////////////////////////////
  
  return weakSelf.collectionViewDataRefresh;
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_PROJECT_LIUHEGAOSHOU;
}


#pragma mark -
#pragma mark 注册 UICollectionView
- (void)collectionViewRefreshRegisterClass:(UICollectionView *)collectionView
{
  [super collectionViewRefreshRegisterClass:collectionView];
  
  // 注册 CFCProjectLHGSCollectionViewCell（必须）
  [self.collectionViewRefresh registerClass:[CFCProjectLHGSCollectionViewCell class]
                 forCellWithReuseIdentifier:CELL_IDENTIFIER_PROJECT_LHGS_COLLECTION_VIEW_CELL];
  
}

#pragma mark 设置 CFCCollectionViewLayoutType 布局
- (CFCCollectionViewLayoutType)collectionViewLayoutType
{
  return CFCCollectionViewLayoutTypeWaterFallLayout;
}

#pragma mark 设置 CFCCollectionViewLayoutType 布局
- (UICollectionViewLayout *)collectionViewLayout
{
  CGFloat margin = CFC_AUTOSIZING_WIDTH(10.0f);
  CFCCollectionRefreshViewWaterFallLayout *flowLayout = [[CFCCollectionRefreshViewWaterFallLayout alloc] init];
  flowLayout.delegate = self;
  flowLayout.margin = margin;
  flowLayout.sectionInset = UIEdgeInsetsMake(margin, margin, margin, margin);
  return flowLayout;
}


#pragma mark -
#pragma mark UICollectionViewDataSource UICollectionViewDelegate
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
  if (self.collectionViewDataRefresh && self.collectionViewDataRefresh.count > 0) {
    return self.collectionViewDataRefresh.count;
  }
  return 0;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
  if (self.collectionViewDataRefresh && self.collectionViewDataRefresh.count > 0 && self.collectionViewDataRefresh.count > section) {
    if ([self.collectionViewDataRefresh[section] isKindOfClass:[NSArray class]]) {
      NSMutableArray *group = self.collectionViewDataRefresh[section];
      if ([group isKindOfClass:[NSArray class]]) {
        return group.count;
      }
    }
  }
  return 0;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.collectionViewDataRefresh
      || self.collectionViewDataRefresh.count <= 0
      || self.collectionViewDataRefresh.count <= indexPath.section
      || ![self.collectionViewDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  CFCProjectLHGSCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:CELL_IDENTIFIER_PROJECT_LHGS_COLLECTION_VIEW_CELL forIndexPath:indexPath];
  if (!cell) {
    cell = [[CFCProjectLHGSCollectionViewCell alloc] init];
  }
  cell.delegate = self;
  cell.indexPath = indexPath;
  cell.model = self.collectionViewDataRefresh[indexPath.section][indexPath.row];
  return cell;
}


#pragma mark -
#pragma mark CFCCollectionRefreshViewWaterFallLayoutDelegate

#pragma mark 自定义表格每一个分组的列数
- (NSInteger)numberOfColumnsInSectionForIndexPath:(NSIndexPath *)indexPath
{
  return 2;
}

#pragma mark 自定义表格每一行的高度
- (CGFloat)heightOfCellItemForCollectionViewAtIndexPath:(NSIndexPath *)indexPath
{
  NSInteger column = [self numberOfColumnsInSectionForIndexPath:indexPath];
  CFCCollectionRefreshViewWaterFallLayout *layout = (CFCCollectionRefreshViewWaterFallLayout *)[self collectionViewLayout];
  CGFloat width = (SCREEN_WIDTH - (column * layout.margin)) / column;
  return width * 0.35f;
}


@end

