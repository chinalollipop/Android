//
// 首页 - 比武擂台
//

#import "CFCProjectBWLTRNViewController.h"


@interface CFCProjectBWLTRNViewController () <RCTBridgeDelegate>

@end


@implementation CFCProjectBWLTRNViewController


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    
  }
  return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  RCTRootView *rootView = [self didLaunchWithOptionsOfReactNative];
  [rootView setFrame:self.view.bounds];
  [self.view addSubview:rootView];
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_PROJECT_BIWULEITAI;
}


#pragma mark -
#pragma mark React Native 混合开发
- (RCTRootView *)didLaunchWithOptionsOfReactNative
{
  NSDictionary *properties = @{
                               @"url" : URL_API_HOME_MAIN_PROJECT_BIWULEITAI,
                               @"params" : [CFCNetworkParamsUtil getHomeMainProjectBiWuLeiTaiParameters]
                               };
  RCTBridge *bridge = [[RCTBridge alloc] initWithDelegate:self launchOptions:nil];
  RCTRootView *rootView = [[RCTRootView alloc] initWithBridge:bridge
                                                   moduleName:@"MarkSix"
                                            initialProperties:properties];
  return rootView;
}

- (NSURL *)sourceURLForBridge:(RCTBridge *)bridge
{
#if DEBUG
  return [[RCTBundleURLProvider sharedSettings] jsBundleURLForBundleRoot:@"index" fallbackResource:nil];
#else
  return [[NSBundle mainBundle] URLForResource:@"main" withExtension:@"jsbundle"];
#endif
}

@end
