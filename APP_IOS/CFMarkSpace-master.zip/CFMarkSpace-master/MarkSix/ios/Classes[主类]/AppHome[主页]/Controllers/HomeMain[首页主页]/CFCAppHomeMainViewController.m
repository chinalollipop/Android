//
// 首页 - 主页数据
//

#import "CFCAppHomeMainViewController.h"
// 广告横幅
#import "CFCHomeMainBannerTableViewCell.h"
#import "CFCHomeMainBannerModel.h"
// 开奖结果
#import "CFCHomeMainDrawTableViewCell.h"
#import "CFCHomeMainDrawModel.h"
// 通知公告
#import "CFCHomeMainNoticeTableViewCell.h"
#import "CFCHomeMainNoticeModel.h"
// 工具列表
#import "CFCHomeMainProjectTableViewCell.h"
#import "CFCHomeMainProjectModel.h"
// 悬浮按钮
#import "CFCHomeMainAssistiveTouchButton.h"
#import "CFCHomeMainTouchButtonModel.h"


// 跳转页面
#import "CFCProjectKJLSViewController.h"  // 开奖历史
#import "CFCProjectCXZSViewController.h"  // 查询助手
#import "CFCProjectZLDQViewController.h"  // 资料大全
#import "CFCProjectLHGSViewController.h"  // 六合高手
#import "CFCProjectBWLTViewController.h"  // 比武擂台
#import "CFCProjectBWLTRNViewController.h"  // 比武擂台
#import "CFCAppSharingViewController.h"  // 分享推广
#import "CFCDrawResultPagerViewController.h"  // 开奖记录


// Cell Identifier
NSString * const CELL_IDENTIFIER_HOME_MAIN_DEFAULT_IDENTIFIER = @"CFCAppHomeMainViewControllerDefaultTableViewCellIdentifier";


@interface CFCAppHomeMainViewController () <CFCHomeMainBannerTableViewCellDelegate, CFCHomeMainDrawTableViewCellDelegate, CFCHomeMainNoticeTableViewCellDelegate, CFCHomeMainProjectTableViewCellDelegate>
/**
 * 悬浮按钮
 */
@property (nonatomic, strong) CFCHomeMainTouchButtonModel *touchButtonModel;
@property (nonatomic, strong) CFCHomeMainAssistiveTouchButton *touchAssistiveButton;
@property (nonatomic, assign) BOOL hasShowTouchAssistiveButton; // 控制只创建加载一次

@end


@implementation CFCAppHomeMainViewController


#pragma mark -
#pragma mark 事件处理 - 广告横幅
- (void)didSelectRowAtHomeMainBannerItemModel:(CFCHomeMainBannerItemModel *)model
{
  [self alertPromptMessage:[NSString stringWithFormat:@"[%@]", model.title]];
}

#pragma mark 事件处理 - 开奖结果
- (void)didSelectRowAtHomeMainDrawModel:(CFCHomeMainDrawModel *)model
{
  CFCDrawResultPagerViewController *viewController = [[CFCDrawResultPagerViewController alloc] init];
  [self.navigationController pushViewController:viewController animated:YES];
}

#pragma mark 事件处理 - 广告横幅
- (void)didSelectRowAtHomeMainNoticeItemModel:(CFCHomeMainNoticeItemModel *)model
{
  [self alertPromptMessage:[NSString stringWithFormat:@"[%@]", model.content]];
}

#pragma mark 事件处理 - 工具列表
- (void)didSelectRowAtHomeMainProjecrtItemModel:(CFCHomeMainProjectItemModel *)model
{
  NSString *MARKID = model.markId.uppercaseString;
  CFCBaseCommonViewController *viewController = nil;
  
  // 开奖历史
  if ([STR_MARKID_HOME_MAIN_PROJECT_KJLS isEqualToString:MARKID.uppercaseString]) {
    viewController = [[CFCProjectKJLSViewController alloc] init];
  }
  // 六合图库
  else if ([STR_MARKID_HOME_MAIN_PROJECT_LHTK isEqualToString:MARKID.uppercaseString]) {
    
  }
  // 查询助手
  else if ([STR_MARKID_HOME_MAIN_PROJECT_CXZS isEqualToString:MARKID.uppercaseString]) {
    viewController = [[CFCProjectCXZSViewController alloc] initWithLocalHTMLString:@"chaxunzhushou"];
  }
  // 六合高手
  else if ([STR_MARKID_HOME_MAIN_PROJECT_LHGS isEqualToString:MARKID.uppercaseString]) {
    viewController = [[CFCProjectLHGSViewController alloc] init];
  }
  // 资讯统计
  else if ([STR_MARKID_HOME_MAIN_PROJECT_TJZX isEqualToString:MARKID.uppercaseString]) {
    
  }
  // 资料大全
  else if ([STR_MARKID_HOME_MAIN_PROJECT_ZLDQ isEqualToString:MARKID.uppercaseString]) {
    viewController = [[CFCProjectZLDQViewController alloc] init];
  }
  // 比武擂台
  else if ([STR_MARKID_HOME_MAIN_PROJECT_BWLT isEqualToString:MARKID.uppercaseString]) {
#if NATIVE
    viewController = [[CFCProjectBWLTViewController alloc] init];
#else
    viewController = [[CFCProjectBWLTRNViewController alloc] init];
#endif
  }
  // 幽默猜猜
  else if ([STR_MARKID_HOME_MAIN_PROJECT_YMCC isEqualToString:MARKID.uppercaseString]) {
    
  }
  // 香港挂牌
  else if ([STR_MARKID_HOME_MAIN_PROJECT_XGGP isEqualToString:MARKID.uppercaseString]) {
    
  }
  // 四不像
  else if ([STR_MARKID_HOME_MAIN_PROJECT_SBXO isEqualToString:MARKID.uppercaseString]) {
    
  }
  
  // 跳转页面
  if (viewController) {
    [self.navigationController pushViewController:viewController animated:YES];
  } else {
    [self alertPromptMessage:[NSString stringWithFormat:@"[%@]", model.title]];
  }
}

#pragma mark 事件处理 - 悬浮按钮 - 打开
- (void)pressTouchAssistiveButtonActionOpen
{
  NSString *htmlUrl = [CFCSysUtil validateStringUrl:self.touchButtonModel.linkUrl] ? self.touchButtonModel.linkUrl : @"https://www.baidu.com";
  CFCAppSharingViewController *viewController = [[CFCAppSharingViewController alloc] initWithHTMLUrlString:htmlUrl];
  UIViewController *topViewController = [CFCAppUtil getTopViewController];
  [topViewController.navigationController pushViewController:viewController animated:YES];
}

#pragma mark 事件处理 - 悬浮按钮 - 关闭
- (void)pressTouchAssistiveButtonActionClose
{
  [self.touchAssistiveButton removeFromSuperview];
  [self setTouchAssistiveButton:nil];
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    self.hasCacheData = YES; // 是否需要加载缓存
    self.isShowLoadingHUD = YES; // 显示加载进度
    self.hasRefreshFooter = NO; // 是否可上拉加载
    self.hasMultiRequestURL = YES; // 是否多接口获取数据
    self.hasShowTouchAssistiveButton = NO; // 是否已显示悬浮按钮
  }
  return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  // 监听 isShowAppSharePage 属性，用于判断悬浮的显示与隐藏
  [APPINFORMATION addObserver:self forKeyPath:@"isShowAppSharePage" options:NSKeyValueObservingOptionNew context:nil];
}


#pragma mark -
#pragma mark 请求数据
- (NSArray<CFCBaseRequest *> *)getRequestArrayMultiple
{
  NSMutableArray<CFCBaseRequest *> *requestArray = [NSMutableArray<CFCBaseRequest *> array];
  
  // 请求地址与参数 -> 主页数据
  {
    NSString *url = URL_API_HOME_MAIN;
    NSMutableDictionary *params = [CFCNetworkParamsUtil getHomeMainRefreshParameters];
    CFCBaseRequest *request = [[CFCBaseRequest alloc] initWithRequestUrl:url parameters:params];
    request.animatingText = nil;
    request.isHideErrorMessage = YES;
    request.method = self.requestMethod;
    request.cacheTimeInSeconds = CACHE_TIME_IN_SECONDS_NONE;
    [requestArray addObject:request];
    CFCLog(@"\n请求地址：%@ \n请求参数：%@", url, params);
  }

  // 请求地址与参数 -> 最新开奖
  {
    NSString *url = URL_API_LASTEST_CURRENT_DRAW;
    NSMutableDictionary *params = [CFCNetworkParamsUtil getLastestCurrentDrawParameters];
    CFCBaseRequest *request = [[CFCBaseRequest alloc] initWithRequestUrl:url parameters:params];
    request.animatingText = nil;
    request.isHideErrorMessage = YES;
    request.method = self.requestMethod;
    request.cacheTimeInSeconds = CACHE_TIME_IN_SECONDS_NONE;
    [requestArray addObject:request];
    CFCLog(@"\n请求地址：%@ \n请求参数：%@", url, params);
  }
  
  return requestArray;
}

#pragma mark 请求网络数据或加载缓存
- (NSMutableArray *)loadNetworkDataOrCacheDataMultiple:(YTKBatchRequest * _Nonnull)batchRequest isCacheData:(BOOL)isCacheData
{
  WEAKSELF(weakSelf);
  
  // 获取所有数据
  __block NSInteger status = 0;
  __block NSMutableDictionary *data = [NSMutableDictionary dictionary];
  [batchRequest.requestArray enumerateObjectsUsingBlock:^(YTKRequest * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
    NSDictionary *response = (NSDictionary *)obj.responseJSONObject;
    NSDictionary *subdata = [response objectForKey:CFC_REQUEST_KEY_DATA];
    NSInteger subtatus = [[response objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
    if ([CFCSysUtil validateResultCodeIsSuccess:subtatus] && ![CFCSysUtil validateObjectIsNull:subdata]) {
      status = subtatus;
      [data addEntriesFromDictionary:subdata];
    }
  }];
  CFCLog(@"[首页数据][%@] => %@\n", CFC_DATA_TYPE(isCacheData), data);

  // 请求成功，解析数据
  if (![CFCSysUtil validateResultCodeIsSuccess:status] || [CFCSysUtil validateObjectIsNull:data]) {
    weakSelf.tableDataRefresh = @[].mutableCopy;
    return weakSelf.tableDataRefresh;
  }
  
  /////////////////////////////////////////////////////////////////
  // A、组装数据 -> 开始
  /////////////////////////////////////////////////////////////////
  
  // 广告横幅
  NSMutableArray<CFCHomeMainBannerModel *> *allBannerModels = [NSMutableArray<CFCHomeMainBannerModel *> array];
  {
    NSMutableArray<CFCHomeMainBannerItemModel *> *allBannerItemModels = [NSMutableArray<CFCHomeMainBannerItemModel *> array];
    [data[@"banners"] enumerateObjectsUsingBlock:^(NSDictionary *  _Nonnull dict, NSUInteger idx, BOOL * _Nonnull stop) {
      CFCHomeMainBannerItemModel *model = [CFCHomeMainBannerItemModel mj_objectWithKeyValues:dict];
      [allBannerItemModels addObject:model];
    }];
    if (allBannerItemModels && 0 < allBannerItemModels.count) {
      CFCHomeMainBannerModel *bannerModel = [[CFCHomeMainBannerModel alloc] init];
      [bannerModel setBanners:allBannerItemModels];
      [bannerModel setSectionType:CFCHomeMainTableSectionBanner];
      [allBannerModels addObject:bannerModel];
    }
  }
  
  // 开奖结果
  NSMutableArray<CFCHomeMainDrawModel *> *allDrawModels = [NSMutableArray<CFCHomeMainDrawModel *> array];
  if (![CFCSysUtil validateObjectIsNull:data[@"now"]]) {
    CFCHomeMainDrawNextModel *drawNextModel = [CFCHomeMainDrawNextModel mj_objectWithKeyValues:data[@"next"]];
    CFCHomeMainDrawCurrentModel *drawCurrentModel = [CFCHomeMainDrawCurrentModel mj_objectWithKeyValues:data[@"now"]];
    //
    CFCHomeMainDrawModel *drawModel = [[CFCHomeMainDrawModel alloc] init];
    [drawModel setDrawNextModel:drawNextModel];
    [drawModel setDrawCurrentModel:drawCurrentModel];
    [drawModel setSectionType:CFCHomeMainTableSectionDrawresult];
    [allDrawModels addObject:drawModel];
  }
  
  // 通知公告
  NSMutableArray<CFCHomeMainNoticeModel *> *allNoticeModels = [NSMutableArray<CFCHomeMainNoticeModel *> array];
  if (![CFCSysUtil validateObjectIsNull:data[@"config"]]) {
    NSMutableArray<CFCHomeMainNoticeItemModel *> *allNoticeItemModels = [NSMutableArray<CFCHomeMainNoticeItemModel *> array];
    CFCHomeMainNoticeModel *noticeModel = [CFCHomeMainNoticeModel mj_objectWithKeyValues:data[@"config"]];
    NSArray<NSString *> *splitNotices = [noticeModel.content split:@","];
    [splitNotices enumerateObjectsUsingBlock:^(NSString * _Nonnull content, NSUInteger idx, BOOL * _Nonnull stop) {
      CFCHomeMainNoticeItemModel *noticeItemModel = [[CFCHomeMainNoticeItemModel alloc] init];
      [noticeItemModel setUuid:[NSString stringWithFormat:@"%ld",idx]];
      [noticeItemModel setContent:content];
      [allNoticeItemModels addObject:noticeItemModel];
    }];
    if (allNoticeItemModels && 0 < allNoticeItemModels.count) {
      [noticeModel setItems:allNoticeItemModels];
      [noticeModel setSectionType:CFCHomeMainTableSectionNoticeMessage];
      [allNoticeModels addObject:noticeModel];
    }
  }
  
  // 工具列表
  NSMutableArray<CFCHomeMainProjectModel *> *allProjectModels = [NSMutableArray<CFCHomeMainProjectModel *> array];
  {
    NSMutableArray<CFCHomeMainProjectItemModel *> *allProjectItemModels = [NSMutableArray array];
    [data[@"columns"] enumerateObjectsUsingBlock:^(NSDictionary *  _Nonnull dict, NSUInteger idx, BOOL * _Nonnull stop) {
      CFCHomeMainProjectItemModel *model = [CFCHomeMainProjectItemModel mj_objectWithKeyValues:dict];
      if (model.isShow.boolValue) {
        [allProjectItemModels addObject:model];
      }
    }];
    // 拆分（每3个一组）
    for (int idx = 0; idx < allProjectItemModels.count;) {
      NSMutableArray<CFCHomeMainProjectItemModel *> *elemList = [NSMutableArray array];
      // 分类N01
      if (idx < allProjectItemModels.count) {
        CFCHomeMainProjectItemModel *itemModel = allProjectItemModels[idx];
        [elemList addObject:itemModel];
        idx ++;
      }
      // 分类N02
      if (idx < allProjectItemModels.count) {
        CFCHomeMainProjectItemModel *itemModel = allProjectItemModels[idx];
        [elemList addObject:itemModel];
        idx ++;
      }
      // 分类N03
      if (idx < allProjectItemModels.count) {
        CFCHomeMainProjectItemModel *itemModel = allProjectItemModels[idx];
        [elemList addObject:itemModel];
        idx ++;
      }
      // 每行3列
      CFCHomeMainProjectModel *projectModel = [[CFCHomeMainProjectModel alloc] init];
      [projectModel setItems:elemList];
      [projectModel setSectionType:CFCHomeMainTableSectionToolLists];
      [projectModel setSectonTitle:[NSString stringWithFormat:@"第%d行工具", idx%3+1]];
      // 所有组
      [allProjectModels addObject:projectModel];
    }
  }
  
  // 悬浮按钮
  if (![CFCSysUtil validateObjectIsNull:data[@"tip"]]) {
    CFCHomeMainTouchButtonModel *touchButtonModel = [CFCHomeMainTouchButtonModel mj_objectWithKeyValues:data[@"tip"]];
    self.touchButtonModel = touchButtonModel;
  }
  
  /////////////////////////////////////////////////////////////////
  // A、组装数据 -> 结束
  /////////////////////////////////////////////////////////////////
  
  
  /////////////////////////////////////////////////////////////////
  // B、配置数据源  -> 开始
  /////////////////////////////////////////////////////////////////
  
  // 初始化数据源
  weakSelf.tableDataRefresh = [NSMutableArray array];
  
  // 广告横幅
  if (allBannerModels && 0 < allBannerModels.count) {
    [weakSelf.tableDataRefresh addObject:allBannerModels.mutableCopy];
  }
  
  // 开奖结果
  if (allDrawModels && 0 < allDrawModels.count) {
    [weakSelf.tableDataRefresh addObject:allDrawModels.mutableCopy];
  }
  
  // 通知公告
  if (allNoticeModels && 0 < allNoticeModels.count) {
    [weakSelf.tableDataRefresh addObject:allNoticeModels.mutableCopy];
  }
  
  // 工具列表
  if (allProjectModels && 0 < allProjectModels.count) {
    [weakSelf.tableDataRefresh addObject:allProjectModels.mutableCopy];
  }
  
  /////////////////////////////////////////////////////////////////
  // B、配置数据源  -> 结束
  /////////////////////////////////////////////////////////////////
  
  return weakSelf.tableDataRefresh;
}

#pragma mark 请求加载完数据后执行，每次刷新加载数据后都会执行
- (void)viewDidLoadAfterLoadNetworkDataOrCacheData
{
  // 悬浮按钮
  if (!self.touchAssistiveButton && !self.self.hasShowTouchAssistiveButton && self.touchButtonModel && self.touchButtonModel.isShow.boolValue) {
    WEAKSELF(weakSelf);
    CGFloat margin = CFC_AUTOSIZING_MARGIN(10.0f);
    CGFloat btnWidth = CFC_AUTOSIZING_WIDTH(60.0f);
    CGFloat btnHeight = CFC_AUTOSIZING_WIDTH(60.0f);
    CFCHomeMainAssistiveTouchButton *button = [[CFCHomeMainAssistiveTouchButton alloc] init];
    [button sd_setBackgroundImageWithURL:[NSURL URLWithString:self.touchButtonModel.imageUrl]
                                forState:UIControlStateNormal];
    [button sd_setBackgroundImageWithURL:[NSURL URLWithString:self.touchButtonModel.imageUrl]
                                forState:UIControlStateHighlighted];
    [button setFrame:CGRectMake(SCREEN_WIDTH-btnWidth-margin*0.5f,
                                SCREEN_HEIGHT-TAB_BAR_AND_DANGER_HEIGHT-btnHeight-margin*0.5f,
                                btnWidth, btnHeight)];
    [button setClickBlock:^{
      [weakSelf pressTouchAssistiveButtonActionOpen];
    }];
    [button setClickCloseBlock:^{
      [weakSelf.touchAssistiveButton removeFromSuperview];
      [weakSelf setTouchAssistiveButton:nil];
    }];
    [button setMoveEnable:YES];
    [self setTouchAssistiveButton:button];
    //
    UIWindow *window = [[UIApplication sharedApplication].delegate window];
    [window addSubview:button];
    //
    self.hasShowTouchAssistiveButton = YES;  // 控制只创建加载一次
  } else if (!self.touchButtonModel.isShow.boolValue) {
    [self.touchAssistiveButton removeFromSuperview];
    [self setTouchAssistiveButton:nil];
  }
}


#pragma mark -
#pragma mark 注册 UITableViewCell
- (void)tableViewRefreshRegisterClass:(UITableView *)tableView
{
  // 广告横幅
  [self.tableViewRefresh registerClass:[CFCHomeMainBannerTableViewCell class]
                forCellReuseIdentifier:CELL_IDENTIFIER_HOME_MAIN_BANNER_IDENTIFIER];
  
  // 开奖结果
  [self.tableViewRefresh registerClass:[CFCHomeMainDrawTableViewCell class]
                forCellReuseIdentifier:CELL_IDENTIFIER_HOME_MAIN_DRAW_IDENTIFIER];
  
  // 通知公告
  [self.tableViewRefresh registerClass:[CFCHomeMainNoticeTableViewCell class]
                forCellReuseIdentifier:CELL_IDENTIFIER_HOME_MAIN_NOTICE_IDENTIFIER];
  
  // 工具列表
  [self.tableViewRefresh registerClass:[CFCHomeMainProjectTableViewCell class]
                forCellReuseIdentifier:CELL_IDENTIFIER_HOME_MAIN_PROJECT_IDENTIFIER];
}


#pragma mark -
#pragma mark UITableViewDelegate UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0) {
    return self.tableDataRefresh.count;
  }
  return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0 && self.tableDataRefresh.count > section) {
    if ([self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
      NSMutableArray *group = self.tableDataRefresh[section];
      if ([group isKindOfClass:[NSArray class]]) {
        return group.count;
      }
    }
  }
  return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  // 判断对象的分组类型
  CFCHomeMainBaseModel *model = self.tableDataRefresh[indexPath.section][indexPath.row];
  
  // 根据类型来选择表格
  switch (model.sectionType) {
      // 广告横幅
    case CFCHomeMainTableSectionBanner: {
      CFCHomeMainBannerTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_HOME_MAIN_BANNER_IDENTIFIER];
      if (!cell) {
        cell = [[CFCHomeMainBannerTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_HOME_MAIN_BANNER_IDENTIFIER];
      }
      cell.delegate = self;
      cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
      cell.selectionStyle = UITableViewCellSelectionStyleNone;
      return cell;
    }
      // 开奖结果
    case CFCHomeMainTableSectionDrawresult: {
      CFCHomeMainDrawTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_HOME_MAIN_DRAW_IDENTIFIER];
      if (!cell) {
        cell = [[CFCHomeMainDrawTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_HOME_MAIN_DRAW_IDENTIFIER];
      }
      cell.delegate = self;
      cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
      cell.selectionStyle = UITableViewCellSelectionStyleNone;
      return cell;
    }
      // 通知公告
    case CFCHomeMainTableSectionNoticeMessage: {
      CFCHomeMainNoticeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_HOME_MAIN_NOTICE_IDENTIFIER];
      if (!cell) {
        cell = [[CFCHomeMainNoticeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_HOME_MAIN_NOTICE_IDENTIFIER];
      }
      cell.delegate = self;
      cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
      cell.selectionStyle = UITableViewCellSelectionStyleNone;
      return cell;
    }
      // 工具列表
    case CFCHomeMainTableSectionToolLists: {
      CFCHomeMainProjectTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_HOME_MAIN_PROJECT_IDENTIFIER];
      if (!cell) {
        cell = [[CFCHomeMainProjectTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_HOME_MAIN_PROJECT_IDENTIFIER];
      }
      cell.delegate = self;
      cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
      cell.selectionStyle = UITableViewCellSelectionStyleNone;
      return cell;
    }
      // 默认设置
    default: {
      UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_HOME_MAIN_DEFAULT_IDENTIFIER];
      if (!cell) {
        cell = [[CFCHomeMainProjectTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_HOME_MAIN_DEFAULT_IDENTIFIER];
      }
      cell.selectionStyle = UITableViewCellSelectionStyleNone;
      return cell;
    }
  }
  
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  // 判断对象的分组类型
  CFCHomeMainBaseModel *model = self.tableDataRefresh[indexPath.section][indexPath.row];
  
  // 根据类型来选择表格
  switch (model.sectionType) {
      // 广告横幅
    case CFCHomeMainTableSectionBanner: {
      return [self.tableViewRefresh fd_heightForCellWithIdentifier:CELL_IDENTIFIER_HOME_MAIN_BANNER_IDENTIFIER cacheByIndexPath:indexPath configuration:^(CFCHomeMainBannerTableViewCell *cell) {
        cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
      }];
    }
      // 开奖结果
    case CFCHomeMainTableSectionDrawresult: {
      return [self.tableViewRefresh fd_heightForCellWithIdentifier:CELL_IDENTIFIER_HOME_MAIN_DRAW_IDENTIFIER cacheByIndexPath:indexPath configuration:^(CFCHomeMainDrawTableViewCell *cell) {
        cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
      }];
    }
      // 通知公告
    case CFCHomeMainTableSectionNoticeMessage: {
      return [self.tableViewRefresh fd_heightForCellWithIdentifier:CELL_IDENTIFIER_HOME_MAIN_NOTICE_IDENTIFIER cacheByIndexPath:indexPath configuration:^(CFCHomeMainNoticeTableViewCell *cell) {
        cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
      }];
    }
      // 工具列表
    case CFCHomeMainTableSectionToolLists: {
      return [self.tableViewRefresh fd_heightForCellWithIdentifier:CELL_IDENTIFIER_HOME_MAIN_PROJECT_IDENTIFIER cacheByIndexPath:indexPath configuration:^(CFCHomeMainProjectTableViewCell *cell) {
        cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
      }];
    }
      // 默认设置
    default: {
      return FLOAT_MIN;
    }
  }
}



#pragma mark -
#pragma mark 监听网页加载的进度
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context
{
  if ([keyPath isEqualToString:@"isShowAppSharePage"]) {
    if (self.touchAssistiveButton) {
      if (APPINFORMATION.isShowAppSharePage) {
        [self.touchAssistiveButton setHidden:YES];
      } else {
        [self.touchAssistiveButton setHidden:NO];
      }
    }
  } else {
    [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
  }
}


#pragma mark -
#pragma mark Private
- (void)dealloc
{
  if (APPINFORMATION && self.hasShowTouchAssistiveButton) {
    [APPINFORMATION removeObserver:self forKeyPath:@"isShowAppSharePage"];
  }
}



@end

