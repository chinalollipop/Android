//
// 首页 - 比武擂台 - 分类列表
//

#import "CFCArticleListViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCBWLTClassifyListViewController : CFCArticleListViewController

@end

NS_ASSUME_NONNULL_END
