//
// 首页 - 六合高手
//

#import "CFCCollectionRefreshViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCProjectLHGSViewController : CFCCollectionRefreshViewController

@end

NS_ASSUME_NONNULL_END
