//
// 首页 - 六合高手 - 分类列表
//

#import "CFCTableRefreshViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCLHGSClassifyListViewController : CFCTableRefreshViewController

@property (nonnull, nonatomic, copy) NSString *classifyId;

@end

NS_ASSUME_NONNULL_END
