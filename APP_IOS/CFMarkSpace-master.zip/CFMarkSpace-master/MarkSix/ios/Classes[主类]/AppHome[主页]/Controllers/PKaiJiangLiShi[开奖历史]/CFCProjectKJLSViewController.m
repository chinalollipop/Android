//
// 首页 - 开奖历史
//

#import "CFCProjectKJLSViewController.h"
//
#import "CFCProjectKJLSDrawSectionHeader.h"
#import "CFCProjectKJLSDrawModel.h"
//
#import "CFCProjectKJLSTableViewCell.h"
#import "CFCProjectKJLSModel.h"
//
#import "CFCDrawResultPagerViewController.h"  // 开奖记录


@interface CFCProjectKJLSViewController () <CFCProjectKJLSTableViewCellDelegate, CFCProjectKJLSDrawSectionHeaderDelegate>

@property (nonatomic, strong) CFCProjectKJLSDrawModel *drawResultModel;

@end


@implementation CFCProjectKJLSViewController


#pragma mark -
#pragma mark 事件处理 - 最新开奖
- (void)didSelectAtProjectKJLSDrawSecionHeader:(CFCProjectKJLSDrawModel *)drawResultModel
{
  CFCDrawResultPagerViewController *viewController = [[CFCDrawResultPagerViewController alloc] init];
  [self.navigationController pushViewController:viewController animated:YES];
}

#pragma mark 事件处理 - 开奖历史
- (void)didSelectRowAtProjectKJLSModel:(CFCProjectKJLSModel *)model
{
  // TODO: 开奖历史详情
  
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    self.hasPage = YES;
    self.hasCacheData = YES;
    self.hasMultiRequestURL = YES;
  }
  return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  
}


#pragma mark -
#pragma mark 请求数据
- (NSArray<CFCBaseRequest *> *)getRequestArrayMultiple
{
  NSMutableArray<CFCBaseRequest *> *requestArray = [NSMutableArray<CFCBaseRequest *> array];
  
  // 请求地址与参数 -> 最新开奖
  {
    NSString *url = URL_API_LASTEST_CURRENT_DRAW;
    NSMutableDictionary *params = [CFCNetworkParamsUtil getLastestCurrentDrawParameters];
    CFCBaseRequest *request = [[CFCBaseRequest alloc] initWithRequestUrl:url parameters:params];
    request.animatingText = nil;
    request.isHideErrorMessage = YES;
    request.method = self.requestMethod;
    request.cacheTimeInSeconds = CACHE_TIME_IN_SECONDS_NONE;
    [requestArray addObject:request];
  }
  
  // 请求地址与参数 -> 开奖历史
  {
    NSString *url = URL_API_HOME_MAIN_PROJECT_KAIJIANGLISHI;
    NSMutableDictionary *params = [CFCNetworkParamsUtil getHomeMainProjectKaiJiangLiShiParameters];
    CFCBaseRequest *request = [[CFCBaseRequest alloc] initWithRequestUrl:url parameters:params];
    request.animatingText = nil;
    request.isHideErrorMessage = YES;
    request.method = self.requestMethod;
    request.cacheTimeInSeconds = CACHE_TIME_IN_SECONDS_NONE;
    [requestArray addObject:request];
  }

  return requestArray;
}

#pragma mark 请求网络数据或加载缓存
- (NSMutableArray *)loadNetworkDataOrCacheDataMultiple:(YTKBatchRequest * _Nonnull)batchRequest isCacheData:(BOOL)isCacheData
{
  WEAKSELF(weakSelf);
  
  // 获取所有数据
  __block NSInteger status = 0;
  __block NSMutableDictionary *data = [NSMutableDictionary dictionary];
  [batchRequest.requestArray enumerateObjectsUsingBlock:^(YTKRequest * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
    NSDictionary *response = (NSDictionary *)obj.responseJSONObject;
    NSDictionary *subdata = [response objectForKey:CFC_REQUEST_KEY_DATA];
    NSInteger subtatus = [[response objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
    if ([CFCSysUtil validateResultCodeIsSuccess:subtatus] && ![CFCSysUtil validateObjectIsNull:subdata]) {
      status = subtatus;
      [data addEntriesFromDictionary:subdata];
    }
  }];
  CFCLog(@"[开奖历史][%@] => %@\n", CFC_DATA_TYPE(isCacheData), data);
  
  // 请求成功，解析数据
  if (![CFCSysUtil validateResultCodeIsSuccess:status] || [CFCSysUtil validateObjectIsNull:data]) {
    weakSelf.tableDataRefresh = @[].mutableCopy;
    return weakSelf.tableDataRefresh;
  }
  
  /////////////////////////////////////////////////////////////////
  // A、组装数据 -> 开始
  /////////////////////////////////////////////////////////////////
  
  // 最新开奖
  [self setDrawResultModel:nil];
  if (![CFCSysUtil validateObjectIsNull:data[@"now"]]) {
    CFCHomeMainDrawNextModel *drawNextModel = [CFCHomeMainDrawNextModel mj_objectWithKeyValues:data[@"next"]];
    CFCHomeMainDrawCurrentModel *drawCurrentModel = [CFCHomeMainDrawCurrentModel mj_objectWithKeyValues:data[@"now"]];
    CFCProjectKJLSDrawModel *drawModel = [[CFCProjectKJLSDrawModel alloc] init];
    [drawModel setDrawNextModel:drawNextModel];
    [drawModel setDrawCurrentModel:drawCurrentModel];
    [self setDrawResultModel:drawModel];
  }
  
  // 开奖历史
  NSMutableArray<CFCProjectKJLSModel *> *allProjectKJLSItemModels = [NSMutableArray<CFCProjectKJLSModel *> array];
  [data[@"list"] enumerateObjectsUsingBlock:^(NSDictionary *  _Nonnull dict, NSUInteger idx, BOOL * _Nonnull stop) {
    CFCProjectKJLSModel *model = [CFCProjectKJLSModel mj_objectWithKeyValues:dict];
    [allProjectKJLSItemModels addObject:model];
  }];
  
  /////////////////////////////////////////////////////////////////
  // A、组装数据 -> 结束
  /////////////////////////////////////////////////////////////////
  
  
  /////////////////////////////////////////////////////////////////
  // B、配置数据源  -> 开始
  /////////////////////////////////////////////////////////////////
  
  if (0 == self.offset || isCacheData) {
    
    // 初始化数据源
    weakSelf.tableDataRefresh = [NSMutableArray array];
    
    // 开奖结果
    if (allProjectKJLSItemModels && 0 < allProjectKJLSItemModels.count) {
      [weakSelf.tableDataRefresh addObject:allProjectKJLSItemModels.mutableCopy];
    } else {
      [weakSelf.tableDataRefresh addObject:@[].mutableCopy];
    }
    
  } else {
    
    // 开奖结果
    if (allProjectKJLSItemModels && 0 < allProjectKJLSItemModels.count) {
      NSMutableArray *tableSectionItems = weakSelf.tableDataRefresh.firstObject;
      [tableSectionItems addObjectsFromArray:allProjectKJLSItemModels];
    }
    
  }

  /////////////////////////////////////////////////////////////////
  // B、配置数据源  -> 结束
  /////////////////////////////////////////////////////////////////
  
  return weakSelf.tableDataRefresh.firstObject;
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_PROJECT_KAIJIANGLISHI;
}


#pragma mark -
#pragma mark 设置 UITableView 表格类型
- (UITableViewStyle)tableViewRefreshStyle
{
  return UITableViewStylePlain;
}

#pragma mark 注册 UITableViewCell
- (void)tableViewRefreshRegisterClass:(UITableView *)tableView
{
  [self.tableViewRefresh registerClass:[CFCProjectKJLSTableViewCell class]
                forCellReuseIdentifier:CELL_IDENTIFIER_PROJECT_KAIJIANGLISHI_IDENTIFIER];
}


#pragma mark -
#pragma mark UITableViewDelegate UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0) {
    return self.tableDataRefresh.count;
  }
  return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0 && self.tableDataRefresh.count > section) {
    if ([self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
      NSMutableArray *group = self.tableDataRefresh[section];
      if ([group isKindOfClass:[NSArray class]]) {
        return group.count;
      }
    }
  }
  return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  CFCProjectKJLSTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_PROJECT_KAIJIANGLISHI_IDENTIFIER];
  if (!cell) {
    cell = [[CFCProjectKJLSTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_PROJECT_KAIJIANGLISHI_IDENTIFIER];
  }
  cell.delegate = self;
  cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
  cell.selectionStyle = UITableViewCellSelectionStyleNone;
  return cell;
  
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return [self.tableViewRefresh fd_heightForCellWithIdentifier:CELL_IDENTIFIER_PROJECT_KAIJIANGLISHI_IDENTIFIER cacheByIndexPath:indexPath configuration:^(CFCProjectKJLSTableViewCell *cell) {
    cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
  }];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  CGRect frameOfHeader = CGRectMake(0, 0, self.tableViewRefresh.width, CONST_PROJECT_KJLS_TABLE_SECTION_HEADER_HIGHT);
  CFCProjectKJLSDrawSectionHeader *headerView = [[CFCProjectKJLSDrawSectionHeader alloc] initWithFrame:frameOfHeader
                                                                                              delegate:self
                                                                                       drawResultModel:self.drawResultModel];
  return headerView;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableViewRefresh.frame.size.width, CFC_AUTOSIZING_MARGIN(MARGIN))];
  [footerView setBackgroundColor:COLOR_TABLEVIEW_FOOTER_VIEW_BACKGROUND_DEFAULT];
  return footerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return CFC_AUTOSIZING_WIDTH(CONST_PROJECT_KJLS_TABLE_SECTION_HEADER_HIGHT);
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return FLOAT_MIN;
}


@end



