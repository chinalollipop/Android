//
// 首页 - 比武擂台
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCProjectBWLTRNViewController : CFCBaseCommonViewController

@end

NS_ASSUME_NONNULL_END
