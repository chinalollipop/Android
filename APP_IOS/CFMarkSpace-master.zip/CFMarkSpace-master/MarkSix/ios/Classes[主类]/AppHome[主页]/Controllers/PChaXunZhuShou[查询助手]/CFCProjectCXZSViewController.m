//
// 首页 - 查询助手
//

#import "CFCProjectCXZSViewController.h"

@interface CFCProjectCXZSViewController ()

@end

@implementation CFCProjectCXZSViewController


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_PROJECT_CHAXUNZHUSHOU;
}


#pragma mark 事件处理 - 导航栏右侧按钮事件
- (void)pressNavigationBarRightButtonItem:(id)sender
{
  [self pressButtonWebViewRefreshAction];
}


#pragma mark 创建导航栏按钮控件CFCNavBarButtonItemTypeCustom
- (UIView *)createNavigationBarButtonItemTypeCustomTitle:(NSString *)title
                                        titleNormalColor:(UIColor *)normalColor
                                        titleSelectColor:(UIColor *)selectColor
                                               titleFont:(UIFont *)font
                                          iconNameNormal:(NSString *)iconNameNormal
                                          iconNameSelect:(NSString *)iconNameSelect
                                                  action:(SEL)action
{
  // 自定义按钮
  CGFloat imageSizeWith = CFC_AUTOSIZING_WIDTH(20.0f);
  CGFloat imageSizeHeight = CFC_AUTOSIZING_WIDTH(20.0f);
  CGRect btnFrame = CGRectMake(0, 0, CFC_AUTOSIZING_WIDTH(NAVIGATION_BAR_BUTTON_MAX_WIDTH), NAVIGATION_BAR_HEIGHT);
  UIButton *btn = [[UIButton alloc] initWithFrame:btnFrame];
  [btn setImage:[[UIImage imageNamed:iconNameNormal] imageByScalingProportionallyToSize:CGSizeMake(imageSizeWith, imageSizeHeight)]
       forState:UIControlStateNormal];
  [btn setImage:[[UIImage imageNamed:iconNameSelect] imageByScalingProportionallyToSize:CGSizeMake(imageSizeWith, imageSizeHeight)]
       forState:UIControlStateHighlighted];
  [btn addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
  
  return btn;
}


#pragma mark 设置导航栏右边按钮控件图标（正常）
- (NSString *)prefersNavigationBarRightButtonItemImageNormal
{
  return ICON_REFRESH;
}


#pragma mark 设置导航栏右边按钮控件图标（选中）
- (NSString *)prefersNavigationBarRightButtonItemImageSelect
{
  return ICON_REFRESH;
}


@end
