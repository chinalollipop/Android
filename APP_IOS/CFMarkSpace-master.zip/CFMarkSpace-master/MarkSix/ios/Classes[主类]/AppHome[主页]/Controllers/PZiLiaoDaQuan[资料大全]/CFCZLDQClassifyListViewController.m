//
// 首页 - 资料大全 - 分类列表
//

#import "CFCZLDQClassifyListViewController.h"

@interface CFCZLDQClassifyListViewController ()

@end

@implementation CFCZLDQClassifyListViewController


#pragma mark -
#pragma mark 设置导航栏右边按钮类型
- (CFCNavBarButtonItemType)prefersNavigationBarRightButtonItemType
{
  return CFCNavBarButtonItemTypeNone;
}


@end
