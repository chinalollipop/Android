//
// 用户中心
//

#import "CFCAppMeCenterMainViewController.h"
#import "CFCAppMeCenterMainUserTableViewCell.h"
#import "CFCAppMeCenterMainUserModel.h"
#import "CFCAppMeCenterMainTableViewCell.h"
#import "CFCAppMeCenterMainModel.h"

// 跳转
#import "CFCAppMeCenterSettingViewController.h"
#import "CFCMineArticleViewController.h"
#import "CFCMyMessageViewController.h"
#import "CFCMineAttentionViewController.h"



@interface CFCAppMeCenterMainViewController () <CFCAppMeCenterMainTableViewCellDelegate, CFCAppMeCenterMainUserTableViewCellDelegate, CFCAppMeCenterSettingViewControllerDelegate>

@end


@implementation CFCAppMeCenterMainViewController



#pragma mark -
#pragma mark 事件处理 - 根据标识处理相应事件
- (void)didSelectRowAtAppMeCenterMainModel:(CFCAppMeCenterMainModel *)model
{
  if (!model.isEdit) {
    return;
  }
  
  CFCBaseCommonViewController *viewController = nil;
  
  // 我的帖子
  if ([STR_MARKID_MOREINFO_MINE_CENTER_INVITATION isEqualToString:model.markId]) {
    viewController = [[CFCMineArticleViewController alloc] init];
  }
  // 我的关注
  else if ([STR_MARKID_MOREINFO_MINE_CENTER_ATTENTION isEqualToString:model.markId]) {
    viewController = [[CFCMineAttentionViewController alloc] init];
  }
  // 站内消息
  else if ([STR_MARKID_MOREINFO_MINE_CENTER_MESSAGEINFO isEqualToString:model.markId]) {
    viewController = [[CFCMyMessageViewController alloc] init];
  }
  
  // 跳转页面
  if (viewController) {
    [self.navigationController pushViewController:viewController animated:YES];
  } else {
    [self alertPromptMessage:@"开发中"];
  }
  
}


#pragma mark 事件处理 - 用户详细信息
- (void)didSelectRowAtAppMeCenterMainUserModel:(CFCAppMeCenterMainUserModel *)model
{
  CFCAppMeCenterSettingViewController *viewController = [[CFCAppMeCenterSettingViewController alloc] init];
  [viewController setDelegate:self];
  [viewController setUserInfoModel:model];
  [self.navigationController pushViewController:viewController animated:YES];
}


#pragma mark 事件处理 - 用户头像 - 修改成功刷新
- (void)didUpdateUserHeaderAtAppMeCenterMainUserModel:(CFCAppMeCenterMainUserModel *)userInfoModel
{
  NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
  [self.tableDataRefresh replaceObjectAtIndex:0 withObject:@[userInfoModel].mutableCopy];
  [self.tableViewRefresh reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    self.hasRefreshHeader = NO;
    self.hasRefreshFooter = NO;
  }
  return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
}


#pragma mark -
#pragma mark 请求地址
- (NSString *)getRequestURLString
{
  return URL_API_MINE_CENTER_USER_INFO;
}

#pragma mark 请求参数
- (NSMutableDictionary *)getRequestParamerter
{
  return [CFCNetworkParamsUtil getMineCenterUserInfoParameters];
}

#pragma mark 请求网络数据或加载缓存
- (NSMutableArray *)loadNetworkDataOrCacheDataSingle:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData
{
  WEAKSELF(weakSelf);
  
  NSDictionary *responseData = (NSDictionary *)responseDataOrCacheData;
  CFCLog(@"[用户信息][%@] => %@\n", CFC_DATA_TYPE(isCacheData), responseData);
  
  // 请求成功，解析数据
  NSDictionary *data = [responseData objectForKey:CFC_REQUEST_KEY_DATA];
  NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
  if (![CFCSysUtil validateResultCodeIsSuccess:status] || [CFCSysUtil validateObjectIsNull:data]) {
    return [NSMutableArray array];
  }
  
  
  /////////////////////////////////////////////////////////////////
  // A、组装数据 -> 开始
  /////////////////////////////////////////////////////////////////
  
  // 用户信息
  NSMutableArray<CFCAppMeCenterMainUserModel *> *allUserInfoModels = [NSMutableArray<CFCAppMeCenterMainUserModel *> array];
  if (![CFCSysUtil validateObjectIsNull:data[@"user"]]) {
    CFCAppMeCenterMainUserModel *itemModel = [CFCAppMeCenterMainUserModel mj_objectWithKeyValues:data[@"user"]];
    [allUserInfoModels addObject:itemModel];
  }

  /////////////////////////////////////////////////////////////////
  // A、组装数据 -> 结束
  /////////////////////////////////////////////////////////////////
  
  
  /////////////////////////////////////////////////////////////////
  // B、配置数据源  -> 开始
  /////////////////////////////////////////////////////////////////
  
  // 初始化数据源
  weakSelf.tableDataRefresh = [NSMutableArray array];
  if (allUserInfoModels && 0 < allUserInfoModels.count) {
    [weakSelf.tableDataRefresh addObject:allUserInfoModels.mutableCopy];
  } else {
    [weakSelf.tableDataRefresh addObject:@[].mutableCopy];
  }
  
  // 用户数据模型
  NSMutableArray<CFCAppMeCenterMainModel *> *allAppMoreInfoMainModels = [CFCAppMeCenterMainModel buildingDataModles];
  if (allAppMoreInfoMainModels && 0 < allAppMoreInfoMainModels.count) {
    [weakSelf.tableDataRefresh addObjectsFromArray:allAppMoreInfoMainModels];
  }

  /////////////////////////////////////////////////////////////////
  // B、配置数据源  -> 结束
  /////////////////////////////////////////////////////////////////
  
  return weakSelf.tableDataRefresh;
}




#pragma mark -
#pragma mark 注册 UITableViewCell
- (void)tableViewRefreshRegisterClass:(UITableView *)tableView
{
  [self.tableViewRefresh registerClass:[CFCAppMeCenterMainTableViewCell class]
                forCellReuseIdentifier:CELL_IDENTIFIER_APP_ME_CENTER_MAIN];
  
  [self.tableViewRefresh registerClass:[CFCAppMeCenterMainUserTableViewCell class]
                forCellReuseIdentifier:CELL_IDENTIFIER_APP_ME_CENTER_MAIN_USER];
}


#pragma mark -
#pragma mark UITableViewDelegate UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0) {
    return self.tableDataRefresh.count;
  }
  return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0 && self.tableDataRefresh.count > section) {
    if ([self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
      NSMutableArray *group = self.tableDataRefresh[section];
      if ([group isKindOfClass:[NSArray class]]) {
        return group.count;
      }
    }
  }
  return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  if (0 == indexPath.section) {
    CFCAppMeCenterMainUserTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_APP_ME_CENTER_MAIN_USER];
    if (!cell) {
      cell = [[CFCAppMeCenterMainUserTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_APP_ME_CENTER_MAIN_USER];
    }
    cell.delegate = self;
    cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
  } else {
    CFCAppMeCenterMainTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_APP_ME_CENTER_MAIN];
    if (!cell) {
      cell = [[CFCAppMeCenterMainTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_APP_ME_CENTER_MAIN];
    }
    cell.delegate = self;
    cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
  }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  if (0 == indexPath.section) {
    return [self.tableViewRefresh fd_heightForCellWithIdentifier:CELL_IDENTIFIER_APP_ME_CENTER_MAIN_USER cacheByIndexPath:indexPath configuration:^(CFCAppMeCenterMainUserTableViewCell *cell) {
      cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
    }];
  } else {
    return [self.tableViewRefresh fd_heightForCellWithIdentifier:CELL_IDENTIFIER_APP_ME_CENTER_MAIN cacheByIndexPath:indexPath configuration:^(CFCAppMeCenterMainTableViewCell *cell) {
      cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
    }];
  }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableViewRefresh.frame.size.width, CFC_AUTOSIZING_MARGIN(MARGIN))];
  [headerView setBackgroundColor:COLOR_TABLEVIEW_HEADER_VIEW_BACKGROUND_DEFAULT];
  return headerView;
}


- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableViewRefresh.frame.size.width, CFC_AUTOSIZING_MARGIN(MARGIN))];
  [footerView setBackgroundColor:COLOR_TABLEVIEW_FOOTER_VIEW_BACKGROUND_DEFAULT];
  return footerView;
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return FLOAT_MIN;
}


- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return CFC_AUTOSIZING_MARGIN(MARGIN);
}


@end

