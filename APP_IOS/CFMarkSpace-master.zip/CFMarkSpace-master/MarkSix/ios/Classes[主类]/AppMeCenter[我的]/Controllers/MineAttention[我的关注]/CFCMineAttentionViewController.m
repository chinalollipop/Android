//
// 用户中心 - 我的关注
//

#import "CFCMineAttentionViewController.h"
#import "CFCMineAttentionTableViewCell.h"
#import "CFCMineAttentionModel.h"
#import "CFCAppLoginViewController.h"

// 跳转
#import "CFCMineAttentionListViewController.h"


@interface CFCMineAttentionViewController () <CFCMineAttentionTableViewCellDelegate>

@end


@implementation CFCMineAttentionViewController


#pragma mark -
#pragma mark 事件处理 - 文章详情
- (void)didSelectRowAtMineAttentionModel:(CFCMineAttentionModel *)model indexPath:(NSIndexPath *)indexPath
{
  CFCMineAttentionListViewController *viewController = [[CFCMineAttentionListViewController alloc] init];
  [viewController setTitle:@"往期历史"];
  [viewController setUserId:model.uuid.stringValue];
  [self.navigationController pushViewController:viewController animated:YES];
}


#pragma mark 事件处理 - 取消关注
- (void)didAttentionButtonAtMineAttentionModel:(CFCMineAttentionModel *)model indexPath:(NSIndexPath *)indexPath
{
  // 验证是否登录
  if (!APPINFORMATION.loginStatus) {
    CFCAppLoginViewController *viewController = [[CFCAppLoginViewController alloc] init];
    [self.navigationController pushViewController:viewController animated:YES];
    return;
  }

  // 点赞文章
  NSString *url = URL_API_MINE_CENTER_ATTENTION_USER;
  NSMutableDictionary *params = [CFCNetworkParamsUtil getMineCenterAttentionUserParameters:model.uuid.stringValue];
  CFCLog(@"\n请求地址：%@ \n请求参数：%@", url, params);
  [CFCNetworkHTTPSessionUtil POST:url parameters:params headerField:params success:^(id responseObject) {
    NSDictionary *responseData = (NSDictionary *)responseObject;
    CFCLog(@"关注用户成功 = %@", responseData);

    BOOL followed = [responseData boolForKey:@"followed"];
    NSString *message = [responseData objectForKey:CFC_REQUEST_KEY_MESS];
    NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
    if ([CFCSysUtil validateResultCodeIsSuccess:status] && !followed) {
      [self doLogicRefreshTableViewWithMineAttentionModel:model indexPath:indexPath];
    } else {
      [self alertPromptInfoMessage:message];
    }

  } failure:^(NSError *error) {
    [self alertPromptInfoMessage:@"关注用户失败！"];
  } showMessage:@"操作中" showProgressHUD:YES showProgressView:self.view isHideErrorMessage:YES];
  
}


#pragma mark -
#pragma mark 逻辑处理 - 刷新表格
- (void)doLogicRefreshTableViewWithMineAttentionModel:(CFCMineAttentionModel *)model indexPath:(NSIndexPath *)indexPath
{
  __block NSMutableArray<CFCMineAttentionModel *> *allItemModels = [NSMutableArray<CFCMineAttentionModel *> array];
  [self.tableDataRefresh enumerateObjectsUsingBlock:^(NSMutableArray<CFCMineAttentionModel *> * _Nonnull section, NSUInteger secitonIdx, BOOL * _Nonnull sectionStop) {
    if (indexPath.section == secitonIdx) {
      [section enumerateObjectsUsingBlock:^(CFCMineAttentionModel *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if (idx != indexPath.row) {
          [allItemModels addObject:obj];
        }
      }];
    }
  }];
  
  self.tableDataRefresh = [NSMutableArray array];
  if (allItemModels && 0 < allItemModels.count) {
    [self.tableDataRefresh addObject:allItemModels.mutableCopy];
  } else {
    [self.tableDataRefresh addObject:@[].mutableCopy];
  }

  if (allItemModels.count > 0) {
    [self.tableViewRefresh deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];
  } else {
    [self.tableViewRefresh reloadData];
  }
  
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    self.hasPage = YES;
    self.hasCacheData = NO;
  }
  return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_MINE_CENTER_ATTENTION;
}


#pragma mark -
#pragma mark 请求地址
- (NSString *)getRequestURLString
{
  return URL_API_MINE_CENTER_MINE_ATTENTION;
}

#pragma mark 请求参数
- (NSMutableDictionary *)getRequestParamerter
{
  return [CFCNetworkParamsUtil getMineCenterMineAttentionParameters];
}

#pragma mark 请求网络数据或加载缓存
- (NSMutableArray *)loadNetworkDataOrCacheDataSingle:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData
{
  WEAKSELF(weakSelf);
  
  NSDictionary *responseData = (NSDictionary *)responseDataOrCacheData;
  CFCLog(@"[我的关注][%@] => %@\n", CFC_DATA_TYPE(isCacheData), responseData);
  
  // 请求成功，解析数据
  NSArray *data = [responseData objectForKey:CFC_REQUEST_KEY_DATA];
  NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
  if (![CFCSysUtil validateResultCodeIsSuccess:status] || [CFCSysUtil validateObjectIsNull:data]) {
    return [NSMutableArray array];
  }
  
  /////////////////////////////////////////////////////////////////
  // A、组装数据 -> 开始
  /////////////////////////////////////////////////////////////////
  
  // 开奖历史
  NSMutableArray<CFCMineAttentionModel *> *allItemModels = [NSMutableArray<CFCMineAttentionModel *> array];
  [data enumerateObjectsUsingBlock:^(NSDictionary *  _Nonnull dict, NSUInteger idx, BOOL * _Nonnull stop) {
    CFCMineAttentionModel *model = [CFCMineAttentionModel mj_objectWithKeyValues:dict];
    [allItemModels addObject:model];
  }];
  
  /////////////////////////////////////////////////////////////////
  // A、组装数据 -> 结束
  /////////////////////////////////////////////////////////////////
  
  
  /////////////////////////////////////////////////////////////////
  // B、配置数据源  -> 开始
  /////////////////////////////////////////////////////////////////
  
  if (0 == self.offset || isCacheData) {
    
    // 初始化数据源
    weakSelf.tableDataRefresh = [NSMutableArray array];
    
    // 开奖结果
    if (allItemModels && 0 < allItemModels.count) {
      [weakSelf.tableDataRefresh addObject:allItemModels.mutableCopy];
    } else {
      [weakSelf.tableDataRefresh addObject:@[].mutableCopy];
    }
    
  } else {
    
    // 开奖结果
    if (allItemModels && 0 < allItemModels.count) {
      NSMutableArray *tableSectionItems = weakSelf.tableDataRefresh.firstObject;
      [tableSectionItems addObjectsFromArray:allItemModels];
    }
    
  }
  
  /////////////////////////////////////////////////////////////////
  // B、配置数据源  -> 结束
  /////////////////////////////////////////////////////////////////
  
  return weakSelf.tableDataRefresh.firstObject;
}


#pragma mark -
#pragma mark 注册 UITableViewCell
- (void)tableViewRefreshRegisterClass:(UITableView *)tableView
{
  [self.tableViewRefresh registerClass:[CFCMineAttentionTableViewCell class]
                forCellReuseIdentifier:CELL_IDENTIFIER_MINE_ATTENTION_IDENTIFIER];
}


#pragma mark -
#pragma mark UITableViewDelegate UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0) {
    return self.tableDataRefresh.count;
  }
  return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0 && self.tableDataRefresh.count > section) {
    if ([self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
      NSMutableArray *group = self.tableDataRefresh[section];
      if ([group isKindOfClass:[NSArray class]]) {
        return group.count;
      }
    }
  }
  return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  CFCMineAttentionTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_MINE_ATTENTION_IDENTIFIER];
  if (!cell) {
    cell = [[CFCMineAttentionTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_MINE_ATTENTION_IDENTIFIER];
  }
  cell.delegate = self;
  cell.indexPath = indexPath;
  cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
  cell.selectionStyle = UITableViewCellSelectionStyleNone;
  return cell;
  
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return [self.tableViewRefresh fd_heightForCellWithIdentifier:CELL_IDENTIFIER_MINE_ATTENTION_IDENTIFIER cacheByIndexPath:indexPath configuration:^(CFCMineAttentionTableViewCell *cell) {
    cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
  }];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableViewRefresh.frame.size.width, CFC_AUTOSIZING_MARGIN(MARGIN))];
  [headerView setBackgroundColor:COLOR_TABLEVIEW_HEADER_VIEW_BACKGROUND_DEFAULT];
  return headerView;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableViewRefresh.frame.size.width, CFC_AUTOSIZING_MARGIN(MARGIN))];
  [footerView setBackgroundColor:COLOR_TABLEVIEW_FOOTER_VIEW_BACKGROUND_DEFAULT];
  return footerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return FLOAT_MIN;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return FLOAT_MIN;
}


@end

