//
// 用户中心 - 个人信息 - 修改密码
//

#import "CFCAppMeCenterPasswordViewController.h"

@interface CFCAppMeCenterPasswordViewController () <UITextFieldDelegate>
@property (nonatomic, strong) UITextField *passwordOldTextField;  // 原密码
@property (nonatomic, strong) UITextField *passwordNewTextField;  // 新密码
@property (nonatomic, strong) UITextField *passwordConfirmTextField;  // 确认新密码
@property (nonatomic, strong) UIButton *confirmButton;  // 确定
@end

@implementation CFCAppMeCenterPasswordViewController


#pragma mark -
#pragma mark 事件处理 - 确认事件
- (void)doConfirmButtonAction:(UIButton *)button
{
  // 原始密码
  NSString *oldPassword = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.passwordOldTextField.text];
  if ([CFCSysUtil validateStringEmpty:oldPassword]) {
    [self alertPromptInfoMessage:@"原始密码不能为空！"];
    return;
  }
  // 新密码
  NSString *newPassword = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.passwordNewTextField.text];
  if ([CFCSysUtil validateStringEmpty:newPassword]) {
    [self alertPromptInfoMessage:@"新密码不能为空！"];
    return;
  }

  // 确认新密码
  NSString *confirmPassword = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.passwordConfirmTextField.text];
  if ([CFCSysUtil validateStringEmpty:confirmPassword]) {
    [self alertPromptInfoMessage:@"确认新密码不能为空！"];
    return;
  }
  // 判断“新密码”与“确认新密码”是否相等
  if (![newPassword isEqualToString:confirmPassword]) {
    [self alertPromptInfoMessage:@"新密码与确认密码不一致！"];
    return;
  }
  
  // 注销第一响应
  [self.passwordOldTextField resignFirstResponder];
  [self.passwordNewTextField resignFirstResponder];
  [self.passwordConfirmTextField resignFirstResponder];
  
  // 修改密码请求
  [self doConfirmSubmitActionWithOldpassword:self.passwordOldTextField.text newPassword:self.passwordNewTextField.text surePassword:self.passwordConfirmTextField.text];
}


#pragma mark 事件处理 - 提交请求
- (void)doConfirmSubmitActionWithOldpassword:(NSString *)oldPassword newPassword:(NSString *)newPassword surePassword:(NSString *)surePassword
{
  NSString *url = URL_API_MINE_CENTER_USER_PASSWORD_UPDATE;
  NSMutableDictionary *params = [CFCNetworkParamsUtil getMineCenterUserPasswordUpdateParameters:oldPassword newPassword:newPassword surePassword:surePassword];
  CFCLog(@"\n请求地址：%@ \n请求参数：%@", url, params);
  [CFCNetworkHTTPSessionUtil POST:url parameters:params headerField:params success:^(id responseObject) {
    NSDictionary *responseData = (NSDictionary *)responseObject;
    CFCLog(@"[修改密码成功] => %@\n", responseData);
    NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
    if ([CFCSysUtil validateResultCodeIsSuccess:status]) {
      // 帐号密码
      APPINFORMATION.loginUserPassword = newPassword;
      //
      [self alertPromptMessage:@"修改密码成功！" okActionTitle:@"确定" okActionBlock:^(NSString *content) {
        [self.navigationController popViewControllerAnimated:YES];
      }];
    } else {
      NSString *message = [responseObject objectForKey:CFC_REQUEST_KEY_MESS];
      [self alertPromptErrorMessage:message];
    }
  } failure:^(NSError *error) {
    CFCLog(@"修改密码失败 = %@", error);
  } showMessage:nil showProgressHUD:YES showProgressView:self.view isHideErrorMessage:YES];
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    
  }
  return self;
}


#pragma mark 视图生命周期加载视图
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  [self.view setBackgroundColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT];
  
  // 创建界面
  [self createMainUIView];
}


#pragma mark 创建主界面
- (void)createMainUIView
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat textFieldHeight = CFC_AUTOSIZING_MARGIN(50.0f); // 输入框高度
  CGFloat textContainerHeight = CFC_AUTOSIZING_MARGIN(50.0f); // 输入框高度
  
  UIFont *textTitleFont = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)]; // 输入框标题字体
  UIColor *textTitleColor = [UIColor colorWithRed:0.43 green:0.43 blue:0.43 alpha:1.00]; // 输入框标题颜色
  UIFont *textFieldFont = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)]; // 输入框字体
  UIColor *textFieldColor = [UIColor colorWithRed:0.00 green:0.00 blue:0.00 alpha:1.00]; // 输入框文字颜色
  UIColor *textFieldPlaceholderColor = [UIColor colorWithRed:0.78 green:0.78 blue:0.78 alpha:1.00]; // 输入框暂位符颜色
  CGFloat titleLableWidth = [@"五个字标题" widthWithFont:textTitleFont constrainedToHeight:textFieldHeight]+margin*0.5f; // 标题头宽度
  
  // 根容器
  UIScrollView *rootScrollView = ({
    TPKeyboardAvoidingScrollView *scrollView = [[TPKeyboardAvoidingScrollView alloc] initWithFrame:self.view.bounds];
    [scrollView setShowsVerticalScrollIndicator:YES];
    [self.view addSubview:scrollView];
    
    [scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(self.view).with.offset(0.0);
      make.right.equalTo(self.view).with.offset(0.0);
      if (IS_IPHONE_X) {
        if (@available(iOS 11.0, *)) {
          make.top.equalTo(self.view.mas_safeAreaLayoutGuideTop).with.offset(0.0);
          make.bottom.equalTo(self.view.mas_safeAreaLayoutGuideBottom).offset(0.0);
        } else {
          make.top.equalTo(self.view.mas_top).with.offset(0.0f);
          make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0f);
        }
      } else {
        make.top.equalTo(self.view.mas_top).with.offset(0.0f);
        make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0f);
      }
    }];
    
    scrollView;
  });
  rootScrollView.mas_key = @"rootScrollView";
  
  
  // 主容器
  UIView *containerView = ({
    UIView *view = [[UIView alloc] init];
    [rootScrollView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.edges.equalTo(rootScrollView);
      make.width.equalTo(rootScrollView);
      if (IS_IPHONE_X) {
        make.height.mas_greaterThanOrEqualTo(SCREEN_HEIGHT-STATUS_NAVIGATION_BAR_HEIGHT-TAB_BAR_DANGER_HEIGHT+1.0);
      } else {
        make.height.mas_greaterThanOrEqualTo(SCREEN_HEIGHT-STATUS_NAVIGATION_BAR_HEIGHT+1.0);
      }
    }];
    view;
  });
  containerView.mas_key = @"containerView";
  
  
  // 原密码
  UIView *passwordOldView = ({
    // 容器
    UIView *view = [UIView new];
    [containerView addSubview:view];
    [view setBackgroundColor:[UIColor whiteColor]];
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(containerView.mas_top).offset(margin);
      make.left.equalTo(containerView.mas_left).offset(0.0);
      make.right.equalTo(containerView.mas_right).with.offset(0.0);
      make.height.equalTo(@(textContainerHeight));
    }];
    
    // 标题
    UILabel *label = [UILabel new];
    [view addSubview:label];
    [label setText:@"原    密    码"];
    [label setFont:textTitleFont];
    [label setTextColor:textTitleColor];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(view.mas_centerY).offset(0.0);
      make.left.equalTo(view.mas_left).offset(margin*1.5);
      make.size.mas_equalTo(CGSizeMake(titleLableWidth, textFieldHeight));
    }];
    
    // 输入框
    UITextField *textField = [UITextField new];
    [view addSubview:textField];
    [textField setTag:1000];
    [textField setDelegate:self];
    [textField setSecureTextEntry:YES];
    [textField setFont:textFieldFont];
    [textField setTextColor:textFieldColor];
    [textField setBorderStyle:UITextBorderStyleNone];
    [textField setClearButtonMode:UITextFieldViewModeWhileEditing];
    [textField setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
    [textField setAttributedPlaceholder:[[NSAttributedString alloc] initWithString:@"请输入原登录密码" attributes:@{ NSForegroundColorAttributeName : textFieldPlaceholderColor }]];
    [textField mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(view.mas_centerY).offset(0.0);
      make.left.equalTo(label.mas_right).offset(margin);
      make.right.equalTo(view.mas_right).with.offset(-margin);
      make.height.equalTo(@(textFieldHeight));
    }];
    self.passwordOldTextField = textField;
    
    // 底部横线
    UIView *separatorLineView = [[UIView alloc] init];
    [view addSubview:separatorLineView];
    [separatorLineView setBackgroundColor:[UIColor colorWithRed:0.94 green:0.94 blue:0.94 alpha:1.00]];
    [separatorLineView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(view.mas_bottom).offset(-1.0);
      make.left.equalTo(view.mas_left).offset(0.0);
      make.right.equalTo(view.mas_right).offset(0.0);
      make.height.equalTo(@(1.0));
    }];
    
    view;
  });
  
  
  // 新密码
  UIView *passwordNewView = ({
    // 容器
    UIView *view = [UIView new];
    [containerView addSubview:view];
    [view setBackgroundColor:[UIColor whiteColor]];
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(passwordOldView.mas_bottom).offset(margin);
      make.left.equalTo(containerView.mas_left).offset(0.0);
      make.right.equalTo(containerView.mas_right).with.offset(0.0);
      make.height.equalTo(@(textContainerHeight));
    }];
    
    // 标题
    UILabel *label = [UILabel new];
    [view addSubview:label];
    [label setText:@"新    密    码"];
    [label setFont:textTitleFont];
    [label setTextColor:textTitleColor];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(view.mas_centerY).offset(0.0);
      make.left.equalTo(view.mas_left).offset(margin*1.5);
      make.size.mas_equalTo(CGSizeMake(titleLableWidth, textFieldHeight));
    }];
    
    // 输入框
    UITextField *textField = [UITextField new];
    [view addSubview:textField];
    [textField setTag:1001];
    [textField setDelegate:self];
    [textField setSecureTextEntry:YES];
    [textField setFont:textFieldFont];
    [textField setTextColor:textFieldColor];
    [textField setBorderStyle:UITextBorderStyleNone];
    [textField setClearButtonMode:UITextFieldViewModeWhileEditing];
    [textField setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
    [textField setAttributedPlaceholder:[[NSAttributedString alloc] initWithString:@"请输入新登录密码" attributes:@{ NSForegroundColorAttributeName : textFieldPlaceholderColor }]];
    [textField mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(view.mas_centerY).offset(0.0);
      make.left.equalTo(label.mas_right).offset(margin);
      make.right.equalTo(view.mas_right).with.offset(-margin);
      make.height.equalTo(@(textFieldHeight));
    }];
    self.passwordNewTextField = textField;
    
    // 底部横线
    UIView *separatorLineView = [[UIView alloc] init];
    [view addSubview:separatorLineView];
    [separatorLineView setBackgroundColor:[UIColor colorWithRed:0.94 green:0.94 blue:0.94 alpha:1.00]];
    [separatorLineView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(view.mas_bottom).offset(-1.0);
      make.left.equalTo(view.mas_left).offset(0.0);
      make.right.equalTo(view.mas_right).offset(0.0);
      make.height.equalTo(@(1.0));
    }];
    
    view;
  });
  
  
  // 确认新密码
  UIView *passwordConfirmView = ({
    // 容器
    UIView *view = [UIView new];
    [containerView addSubview:view];
    [view setBackgroundColor:[UIColor whiteColor]];
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(passwordNewView.mas_bottom).offset(0.0);
      make.left.equalTo(containerView.mas_left).offset(0.0);
      make.right.equalTo(containerView.mas_right).with.offset(0.0);
      make.height.equalTo(@(textContainerHeight));
    }];
    
    // 标题
    UILabel *label = [UILabel new];
    [view addSubview:label];
    [label setText:@"确认新密码"];
    [label setFont:textTitleFont];
    [label setTextColor:textTitleColor];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(view.mas_centerY).offset(0.0);
      make.left.equalTo(view.mas_left).offset(margin*1.5);
      make.size.mas_equalTo(CGSizeMake(titleLableWidth, textFieldHeight));
    }];
    
    // 输入框
    UITextField *textField = [UITextField new];
    [view addSubview:textField];
    [textField setTag:1002];
    [textField setDelegate:self];
    [textField setSecureTextEntry:YES];
    [textField setFont:textFieldFont];
    [textField setTextColor:textFieldColor];
    [textField setBorderStyle:UITextBorderStyleNone];
    [textField setClearButtonMode:UITextFieldViewModeWhileEditing];
    [textField setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
    [textField setAttributedPlaceholder:[[NSAttributedString alloc] initWithString:@"请确认新登录密码" attributes:@{ NSForegroundColorAttributeName : textFieldPlaceholderColor }]];
    [textField mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(view.mas_centerY).offset(0.0);
      make.left.equalTo(label.mas_right).offset(margin);
      make.right.equalTo(view.mas_right).with.offset(-margin);
      make.height.equalTo(@(textFieldHeight));
    }];
    self.passwordConfirmTextField = textField;
    
    // 底部横线
    UIView *separatorLineView = [[UIView alloc] init];
    [view addSubview:separatorLineView];
    [separatorLineView setBackgroundColor:[UIColor colorWithRed:0.94 green:0.94 blue:0.94 alpha:1.00]];
    [separatorLineView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(view.mas_bottom).offset(-1.0);
      make.left.equalTo(view.mas_left).offset(0.0);
      make.right.equalTo(view.mas_right).offset(0.0);
      make.height.equalTo(@(1.0));
    }];
    
    view;
  });
  
  // 确认按钮
  UIButton *confirmButton = ({
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [containerView addSubview:button];
    [button setEnabled:NO];
    [button defaultStyleButton];
    [button.layer setBorderWidth:0.0f];
    [button setTitle:@"确认修改" forState:UIControlStateNormal];
    [button setBackgroundColor:[UIColor colorWithRed:0.87 green:0.87 blue:0.87 alpha:1.00]];
    [button addTarget:self action:@selector(doConfirmButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(passwordConfirmView.mas_bottom).offset(margin*3.5);
      make.left.equalTo(containerView.mas_left).offset(margin*2.0);
      make.right.equalTo(containerView.mas_right).with.offset(-margin*2.0);
      make.height.equalTo(@(CFC_AUTOSIZING_WIDTH(45.0f)));
    }];
    
    button;
  });
  self.confirmButton = confirmButton;
  self.confirmButton.mas_key = @"confirmButton";
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_ME_CENTER_PASSWORD;
}


#pragma mark -
#pragma mark UITextFieldDelegate
- (BOOL)textField:(UITextField*)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
  NSString *oldPasswordString = self.passwordOldTextField.text;
  NSString *newPasswordString = self.passwordNewTextField.text;
  NSString *cfmPasswordString = self.passwordConfirmTextField.text;
  
  // 输入框的内容
  NSString *textString = [textField.text stringByReplacingCharactersInRange:range withString:string];
  if (1000 == textField.tag) {
    oldPasswordString = textString;
  } else if (1001 == textField.tag) {
    newPasswordString = textString;
  } else if (1002 == textField.tag) {
    cfmPasswordString = textString;
  }
  
  [self setupWithConfirmButtonEnableWithOldPassword:oldPasswordString newPasswordString:newPasswordString cfmPasswordString:cfmPasswordString];
  
  return YES;
}

// 点击清除按钮时调用的函数，返回YES则可以清除，点击NO则不能清除
- (BOOL)textFieldShouldClear:(UITextField *)textField
{
  NSString *oldPasswordString = self.passwordOldTextField.text;
  NSString *newPasswordString = self.passwordNewTextField.text;
  NSString *cfmPasswordString = self.passwordConfirmTextField.text;
  
  // 输入框的内容
  NSString *textString = @"";
  if (1000 == textField.tag) {
    oldPasswordString = textString;
  } else if (1001 == textField.tag) {
    newPasswordString = textString;
  } else if (1002 == textField.tag) {
    cfmPasswordString = textString;
  }
  
  [self setupWithConfirmButtonEnableWithOldPassword:oldPasswordString newPasswordString:newPasswordString cfmPasswordString:cfmPasswordString];
  
  return YES;
}

#pragma mark 提现按钮是否可用
- (void)setupWithConfirmButtonEnableWithOldPassword:(NSString *)oldPasswordString newPasswordString:(NSString *)newPasswordString cfmPasswordString:(NSString *)cfmPasswordString
{
  BOOL isOldPassword = NO;
  BOOL isNewPassword = NO;
  BOOL isCfmPassword = NO;
  
  // 原始密码
  NSString *oldPassword = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:oldPasswordString];
  if (![CFCSysUtil validateStringEmpty:oldPassword]) {
    isOldPassword = YES;
  }
  
  // 新的密码
  NSString *newPassword = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:newPasswordString];
  if (![CFCSysUtil validateStringEmpty:newPassword]) {
    isNewPassword = YES;
  }
  
  // 确认密码
  NSString *cfmPassword = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:cfmPasswordString];
  if (![CFCSysUtil validateStringEmpty:cfmPassword]) {
    isCfmPassword = YES;
  }
  
  // 按钮是否可用
  if (isOldPassword && isNewPassword && isCfmPassword) {
    [self.confirmButton setEnabled:YES];
    [self.confirmButton setBackgroundColor:COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT];
  } else {
    [self.confirmButton setEnabled:NO];
    [self.confirmButton setBackgroundColor:[UIColor colorWithRed:0.87 green:0.87 blue:0.87 alpha:1.00]];
  }
}



@end
