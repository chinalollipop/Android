//
// 用户中心 - 个人信息 - 修改头像
//

#import "CFCAppMeCenterUserHeaderViewController.h"
#import "CFCAppMeUserHeaderCollectionViewCell.h"
#import "CFCAppMeUserHeaderModel.h"
#import "CFCAppMeCenterMainUserModel.h"


@interface CFCAppMeCenterUserHeaderViewController() <CFCAppMeUserHeaderCollectionViewCellDelegate>
@property (nonatomic, copy) NSString *selecredImageName;
@end


@implementation CFCAppMeCenterUserHeaderViewController


#pragma mark -
#pragma mark 事件处理 - 修改头像
- (void)pressNavigationBarRightButtonItem:(id)sender
{
  // 头像非空验证
  if ([CFCSysUtil validateStringEmpty:self.selecredImageName]) {
    [self alertPromptErrorMessage:@"请选择头像！"];
    return;
  }
  
  // 头像没有改变
  NSCharacterSet *characterSet = [NSCharacterSet characterSetWithCharactersInString:@"/"];
  NSArray<NSString *> *split = [self.userInfoModel.avatar componentsSeparatedByCharactersInSet:characterSet];
  if ([split.lastObject isEqualToString:self.selecredImageName]) {
    [self alertPromptMessage:@"修改用户头像成功！" okActionBlock:^(NSString *content) {
      [self.navigationController popViewControllerAnimated:YES];
    }];
    return;
  }
  
  // 修改用户头像
  NSString *url = URL_API_MINE_CENTER_USER_AVATAR_UPDATE;
  NSMutableDictionary *params = [CFCNetworkParamsUtil getMineCenterUserAvatarUpdateParameters:self.selecredImageName];
  CFCLog(@"\n请求地址：%@ \n请求参数：%@", url, params);
  [CFCNetworkHTTPSessionUtil POST:url parameters:params headerField:params success:^(id responseObject) {
    NSDictionary *responseData = (NSDictionary *)responseObject;
    CFCLog(@"[修改头像成功] => %@\n", responseData);
    NSDictionary *data = [responseData objectForKey:CFC_REQUEST_KEY_DATA];
    NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
    if ([CFCSysUtil validateResultCodeIsSuccess:status]) {
      // 登录成功设置
      CFCAppMeCenterMainUserModel *userInfoModel = [CFCAppMeCenterMainUserModel mj_objectWithKeyValues:data[@"user"]];
      if (self.delegate && [self.delegate respondsToSelector:@selector(didUpdateUserHeaderAtAppMeCenterMainUserModel:)]) {
        [self.delegate didUpdateUserHeaderAtAppMeCenterMainUserModel:userInfoModel];
      }
      //
      [self alertPromptMessage:@"修改头像成功！" okActionTitle:@"确定" okActionBlock:^(NSString *content) {
        [self.navigationController popViewControllerAnimated:YES];
      }];
    } else {
      NSString *message = [responseObject objectForKey:CFC_REQUEST_KEY_MESS];
      [self alertPromptErrorMessage:message];
    }
  } failure:^(NSError *error) {
    CFCLog(@"修改头像失败 = %@", error);
  } showMessage:nil showProgressHUD:YES showProgressView:self.view isHideErrorMessage:YES];
}


#pragma mark -
#pragma mark 事件处理 - 选择头像
- (void)didSelectRowAtAppMeUserHeaderModel:(CFCAppMeUserHeaderModel *)model
{
  __block NSMutableArray<NSIndexPath *> *indexPaths = [NSMutableArray<NSIndexPath *> array];
  [self.collectionViewDataRefresh enumerateObjectsUsingBlock:^(NSMutableArray<CFCAppMeUserHeaderModel *> * _Nonnull sectionModels, NSUInteger sectionIdex, BOOL * _Nonnull sectionStop) {
    [sectionModels enumerateObjectsUsingBlock:^(CFCAppMeUserHeaderModel * _Nonnull itemObj, NSUInteger itemIdx, BOOL * _Nonnull itemStop) {
      if ([itemObj.imageName isEqualToString:model.imageName]) {
        [self setSelecredImageName:itemObj.imageName];
        //
        NSIndexPath *itemIndexPath = [NSIndexPath indexPathForRow:itemIdx inSection:sectionIdex];
        [indexPaths addObject:itemIndexPath];
        [itemObj setIsSelected:YES];
      } else {
        if (itemObj.isSelected) {
          NSIndexPath *itemIndexPath = [NSIndexPath indexPathForRow:itemIdx inSection:sectionIdex];
          [indexPaths addObject:itemIndexPath];
          [itemObj setIsSelected:NO];
        }
      }
    }];
  }];
  [UIView performWithoutAnimation:^{
    [self.collectionViewRefresh reloadItemsAtIndexPaths:indexPaths];
  }];
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    self.isRequestNetwork = NO;
    self.hasRefreshHeader = NO;
    self.hasRefreshFooter = NO;
  }
  return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  // 已经选中头像
  NSCharacterSet *characterSet = [NSCharacterSet characterSetWithCharactersInString:@"/"];
  NSArray<NSString *> *split = [self.userInfoModel.avatar componentsSeparatedByCharactersInSet:characterSet];
  [self setSelecredImageName:split.lastObject];
  
  // 创建静态数据模型
  self.collectionViewDataRefresh = [NSMutableArray array];
  NSMutableArray<CFCAppMeUserHeaderModel *> *allItemHeaderModels = [CFCAppMeUserHeaderModel buildingDataModlesWithUserInfoModel:self.userInfoModel];
  if (allItemHeaderModels && 0 < allItemHeaderModels.count) {
    [self.collectionViewDataRefresh addObject:allItemHeaderModels.mutableCopy];
  }
  [self.collectionViewRefresh reloadData];
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_ME_CENTER_HEADER_UPDATE;
}

#pragma mark 导航栏右边按钮类型
- (CFCNavBarButtonItemType)prefersNavigationBarRightButtonItemType
{
  return CFCNavBarButtonItemTypeCustom;
}

#pragma mark 设置导航栏右边按钮控件标题
- (NSString *)prefersNavigationBarRightButtonItemTitle
{
  return @"确定";
}


#pragma mark -
#pragma mark 注册 UICollectionView
- (void)collectionViewRefreshRegisterClass:(UICollectionView *)collectionView
{
  [super collectionViewRefreshRegisterClass:collectionView];
  
  // 注册 CFCAppMeUserHeaderCollectionViewCell（必须）
  [self.collectionViewRefresh registerClass:[CFCAppMeUserHeaderCollectionViewCell class]
                 forCellWithReuseIdentifier:CELL_IDENTIFIER_ME_USER_HEADER_COLLECTION_VIEW_CELL];
}

#pragma mark 设置 CFCCollectionViewLayoutType 布局
- (UICollectionViewLayout *)collectionViewLayout
{
  CGFloat margin = CFC_AUTOSIZING_WIDTH(10.0f);
  CFCCollectionRefreshViewWaterFallLayout *flowLayout = [[CFCCollectionRefreshViewWaterFallLayout alloc] init];
  flowLayout.delegate = self;
  flowLayout.margin = CFC_AUTOSIZING_WIDTH(5.0f);
  flowLayout.sectionInset = UIEdgeInsetsMake(margin, margin, margin, margin);
  return flowLayout;
}


#pragma mark -
#pragma mark UICollectionViewDataSource UICollectionViewDelegate
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
  if (self.collectionViewDataRefresh && self.collectionViewDataRefresh.count > 0) {
    return self.collectionViewDataRefresh.count;
  }
  return 0;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
  if (self.collectionViewDataRefresh && self.collectionViewDataRefresh.count > 0 && self.collectionViewDataRefresh.count > section) {
    if ([self.collectionViewDataRefresh[section] isKindOfClass:[NSArray class]]) {
      NSMutableArray *group = self.collectionViewDataRefresh[section];
      if ([group isKindOfClass:[NSArray class]]) {
        return group.count;
      }
    }
  }
  return 0;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.collectionViewDataRefresh
      || self.collectionViewDataRefresh.count <= 0
      || self.collectionViewDataRefresh.count <= indexPath.section
      || ![self.collectionViewDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  CFCAppMeUserHeaderCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:CELL_IDENTIFIER_ME_USER_HEADER_COLLECTION_VIEW_CELL forIndexPath:indexPath];
  if (!cell) {
    cell = [[CFCAppMeUserHeaderCollectionViewCell alloc] init];
  }
  cell.delegate = self;
  cell.model = self.collectionViewDataRefresh[indexPath.section][indexPath.row];
  return cell;
}


#pragma mark -
#pragma mark CFCCollectionRefreshViewWaterFallLayoutDelegate

#pragma mark 自定义表格每一个分组的列数
- (NSInteger)numberOfColumnsInSectionForIndexPath:(NSIndexPath *)indexPath
{
  return 5;
}

#pragma mark 自定义表格每一行的高度
- (CGFloat)heightOfCellItemForCollectionViewAtIndexPath:(NSIndexPath *)indexPath
{
  NSInteger column = [self numberOfColumnsInSectionForIndexPath:indexPath];
  CFCCollectionRefreshViewWaterFallLayout *layout = (CFCCollectionRefreshViewWaterFallLayout *)self.collectionViewLayout;
  return ((self.collectionViewRefresh.width-layout.margin*(column-1))/column);
}


@end


