//
// 用户中心 - 个人信息
//

#import "CFCAppMeCenterSettingViewController.h"
#import "CFCAppMeCenterSettingUserTableViewCell.h"
#import "CFCAppMeCenterMainUserModel.h"
#import "CFCAppMeCenterSettingTableViewCell.h"
#import "CFCAppMeCenterSettingModel.h"
#import "CFCAppMeCenterSettingLoginOutTableViewCell.h"
#import "CFCAppMeCenterSettingModel.h"

// 跳转页面
#import "CFCAppMeCenterPasswordViewController.h"
#import "CFCAppMeCenterUserHeaderViewController.h"


@interface CFCAppMeCenterSettingViewController () <CFCAppMeCenterSettingUserTableViewCellDelegate, CFCAppMeCenterSettingTableViewCellDelegate, CFCAppMeCenterSettingLoginOutTableViewCellDelegate, CFCAppMeCenterUserHeaderViewControllerDelegate>

@end


@implementation CFCAppMeCenterSettingViewController


#pragma mark -
#pragma mark 事件处理 - 根据标识处理相应事件
- (void)didSelectRowAtAppMeCenterSettingModel:(CFCAppMeCenterSettingModel *)model
{
  if (!model.isEdit) {
    return;
  }
  
  // 手机号码
  if ([STR_MARKID_MOREINFO_MINE_CENTER_SETTING_PHONE isEqualToString:model.markId]) {
    
  }
  // 修改密码
  else if ([STR_MARKID_MOREINFO_MINE_CENTER_SETTING_PASSWORD isEqualToString:model.markId]) {
    CFCAppMeCenterPasswordViewController *viewController = [[CFCAppMeCenterPasswordViewController alloc] init];
    [self.navigationController pushViewController:viewController animated:YES];
  }
  
}

#pragma mark 事件处理 - 用户头像
- (void)didSelectRowAtAppMeCenterMainUserModel:(CFCAppMeCenterMainUserModel *)model
{
  CFCAppMeCenterUserHeaderViewController *viewController = [[CFCAppMeCenterUserHeaderViewController alloc] init];
  [viewController setDelegate:self];
  [viewController setUserInfoModel:model];
  [self.navigationController pushViewController:viewController animated:YES];
}

#pragma mark 事件处理 - 退出登录事件
- (void)didSelectRowAtLoginOutAppMeCenterSettingModel:(CFCAppMeCenterSettingModel *)model
{
  [self alertPrompTitle:nil message:@"确定退出登录？" cancleActionBlock:nil okActionBlock:^(NSString *content) {
    [self didSelectRowAtLoginOutAppMeCenterSettingLogic];
  }];
}


#pragma mark 事件处理 - 退出登录事件 - 逻辑处理
- (void)didSelectRowAtLoginOutAppMeCenterSettingLogic
{
  NSString *url = URL_API_MINE_CENTER_LOGIN_OUT;
  NSMutableDictionary *params = [CFCNetworkParamsUtil getMineCenterLoginOutParameters];
  CFCLog(@"\n请求地址：%@ \n请求参数：%@", url, params);
  [CFCNetworkHTTPSessionUtil POST:url parameters:params headerField:params success:^(id responseObject) {
    NSDictionary *responseData = (NSDictionary *)responseObject;
    CFCLog(@"[退出成功] => %@\n", responseData);
    NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
    if ([CFCSysUtil validateResultCodeIsSuccess:status]) {
      [CFCAppUtil applicationLoginOutSetting];
      [CFCAppUtil applicationSettingRootViewController:LOGIN_OUT_TAB_SELECTED_INDEX];
    } else {
      NSString *message = [responseObject objectForKey:CFC_REQUEST_KEY_MESS];
      [self alertPromptErrorMessage:message];
    }
  } failure:^(NSError *error) {
    CFCLog(@"退出失败 = %@", error);
    [CFCAppUtil applicationLoginOutSetting];
    [CFCAppUtil applicationSettingRootViewController:LOGIN_OUT_TAB_SELECTED_INDEX];
  } showMessage:nil showProgressHUD:YES showProgressView:self.view isHideErrorMessage:YES];
}


#pragma mark 事件处理 - 用户头像 - 修改成功刷新
- (void)didUpdateUserHeaderAtAppMeCenterMainUserModel:(CFCAppMeCenterMainUserModel *)userInfoModel
{
  // 刷新个人信息头像
  NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
  [self.tableDataRefresh replaceObjectAtIndex:0 withObject:@[userInfoModel].mutableCopy];
  [self.tableViewRefresh reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
  // 刷新个人中心头像
  if (self.delegate && [self.delegate respondsToSelector:@selector(didUpdateUserHeaderAtAppMeCenterMainUserModel:)]) {
    [self.delegate didUpdateUserHeaderAtAppMeCenterMainUserModel:userInfoModel];
  }
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    self.isRequestNetwork = NO;
    self.hasRefreshHeader = NO;
    self.hasRefreshFooter = NO;
  }
  return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  // 创建静态数据模型
  self.tableDataRefresh = [NSMutableArray array];
  if (self.userInfoModel) {
    [self.tableDataRefresh addObject:@[ self.userInfoModel ].mutableCopy];
  } else {
    [self.tableDataRefresh addObject:@[].mutableCopy];
  }
  NSMutableArray<CFCAppMeCenterSettingModel *> *allAppMoreInfoMainModels = [CFCAppMeCenterSettingModel buildingDataModlesWithUserInfoModel:self.userInfoModel];
  if (allAppMoreInfoMainModels && 0 < allAppMoreInfoMainModels.count) {
    [self.tableDataRefresh addObjectsFromArray:allAppMoreInfoMainModels];
  }
  [self.tableViewRefresh reloadData];
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_ME_CENTER_USERINFO;
}


#pragma mark -
#pragma mark 注册 UITableViewCell
- (void)tableViewRefreshRegisterClass:(UITableView *)tableView
{
  [self.tableViewRefresh registerClass:[CFCAppMeCenterSettingUserTableViewCell class]
                forCellReuseIdentifier:CELL_IDENTIFIER_APP_ME_CENTER_SETTING_USER];
  
  [self.tableViewRefresh registerClass:[CFCAppMeCenterSettingTableViewCell class]
                forCellReuseIdentifier:CELL_IDENTIFIER_APP_ME_CENTER_SETTING];
  
  [self.tableViewRefresh registerClass:[CFCAppMeCenterSettingLoginOutTableViewCell class]
                forCellReuseIdentifier:CELL_IDENTIFIER_ME_CENTER_SETTING_LOGIN_OUT];
}


#pragma mark -
#pragma mark UITableViewDelegate UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0) {
    return self.tableDataRefresh.count;
  }
  return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  if (self.tableDataRefresh && self.tableDataRefresh.count > 0 && self.tableDataRefresh.count > section) {
    if ([self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
      NSMutableArray *group = self.tableDataRefresh[section];
      if ([group isKindOfClass:[NSArray class]]) {
        return group.count;
      }
    }
  }
  return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  if (0 == indexPath.section) {
    CFCAppMeCenterSettingUserTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_APP_ME_CENTER_SETTING_USER];
    if (!cell) {
      cell = [[CFCAppMeCenterSettingUserTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_APP_ME_CENTER_SETTING_USER];
    }
    cell.delegate = self;
    cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
  } else if (1 == indexPath.section) {
    CFCAppMeCenterSettingTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_APP_ME_CENTER_SETTING];
    if (!cell) {
      cell = [[CFCAppMeCenterSettingTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_APP_ME_CENTER_SETTING];
    }
    cell.delegate = self;
    cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
  } else {
    CFCAppMeCenterSettingLoginOutTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_ME_CENTER_SETTING_LOGIN_OUT];
    if (!cell) {
      cell = [[CFCAppMeCenterSettingLoginOutTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_ME_CENTER_SETTING_LOGIN_OUT];
    }
    cell.delegate = self;
    cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
  }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= indexPath.section
      || ![self.tableDataRefresh[indexPath.section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  if (0 == indexPath.section) {
    return [self.tableViewRefresh fd_heightForCellWithIdentifier:CELL_IDENTIFIER_APP_ME_CENTER_SETTING_USER cacheByIndexPath:indexPath configuration:^(CFCAppMeCenterSettingUserTableViewCell *cell) {
      cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
    }];
  } else if (1 == indexPath.section) {
    return [self.tableViewRefresh fd_heightForCellWithIdentifier:CELL_IDENTIFIER_APP_ME_CENTER_SETTING cacheByIndexPath:indexPath configuration:^(CFCAppMeCenterSettingTableViewCell *cell) {
      cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
    }];
  } else {
    return [self.tableViewRefresh fd_heightForCellWithIdentifier:CELL_IDENTIFIER_ME_CENTER_SETTING_LOGIN_OUT cacheByIndexPath:indexPath configuration:^(CFCAppMeCenterSettingLoginOutTableViewCell *cell) {
      cell.model = self.tableDataRefresh[indexPath.section][indexPath.row];
    }];
  }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableViewRefresh.frame.size.width, CFC_AUTOSIZING_MARGIN(MARGIN))];
  [headerView setBackgroundColor:COLOR_TABLEVIEW_HEADER_VIEW_BACKGROUND_DEFAULT];
  return headerView;
}


- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return nil;
  }
  
  UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableViewRefresh.frame.size.width, CFC_AUTOSIZING_MARGIN(MARGIN))];
  [footerView setBackgroundColor:COLOR_TABLEVIEW_FOOTER_VIEW_BACKGROUND_DEFAULT];
  return footerView;
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return FLOAT_MIN;
}


- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
  // 判断对象是否为数组
  if (!self.tableDataRefresh
      || self.tableDataRefresh.count <= 0
      || self.tableDataRefresh.count <= section
      || ![self.tableDataRefresh[section] isKindOfClass:[NSArray class]]) {
    return FLOAT_MIN;
  }
  
  return CFC_AUTOSIZING_MARGIN(MARGIN);
}


@end

