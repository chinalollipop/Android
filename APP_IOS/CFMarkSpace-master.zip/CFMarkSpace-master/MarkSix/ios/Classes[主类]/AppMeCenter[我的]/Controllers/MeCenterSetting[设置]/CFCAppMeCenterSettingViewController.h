//
// 用户中心 - 个人信息
//

#import "CFCTableRefreshViewController.h"
@class CFCAppMeCenterMainUserModel;


NS_ASSUME_NONNULL_BEGIN

@protocol CFCAppMeCenterSettingViewControllerDelegate <NSObject>
@optional
- (void)didUpdateUserHeaderAtAppMeCenterMainUserModel:(CFCAppMeCenterMainUserModel *)userInfoModel;
@end


@interface CFCAppMeCenterSettingViewController : CFCTableRefreshViewController

@property (nonatomic, strong) CFCAppMeCenterMainUserModel *userInfoModel;

@property (nonatomic, weak) id<CFCAppMeCenterSettingViewControllerDelegate> delegate;

@end

NS_ASSUME_NONNULL_END

