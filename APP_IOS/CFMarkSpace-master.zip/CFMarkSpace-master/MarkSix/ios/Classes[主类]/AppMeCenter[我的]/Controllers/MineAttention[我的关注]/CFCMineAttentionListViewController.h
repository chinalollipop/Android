//
// 用户中心 - 我的关注 - 文章列表
//

#import "CFCArticleListViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCMineAttentionListViewController : CFCArticleListViewController

@property (nonnull, nonatomic, copy) NSString *userId;

@end

NS_ASSUME_NONNULL_END
