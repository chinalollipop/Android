//
// 用户中心 - 我的关注 - 文章列表
//

#import "CFCMineAttentionListViewController.h"


@interface CFCMineAttentionListViewController ()

@end


@implementation CFCMineAttentionListViewController


#pragma mark -
#pragma mark 设置导航栏右边按钮类型
- (CFCNavBarButtonItemType)prefersNavigationBarRightButtonItemType
{
  return CFCNavBarButtonItemTypeNone;
}


#pragma mark -
#pragma mark 请求地址
- (NSString *)getRequestURLString
{
  return URL_API_HOME_MAIN_PROJECT_ARTICLE_USER_UUID;
}


#pragma mark 请求参数
- (NSMutableDictionary *)getRequestParamerter
{
  return [CFCNetworkParamsUtil getHomeMainProjectArticleUserIdParameters:self.userId];
}


@end



