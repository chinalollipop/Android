//
// 登录
//

#import "CFCAppLoginViewController.h"
#import "CFCAppRegisterViewController.h"

@interface CFCAppLoginViewController ()

// 登录区域
@property (nonatomic, strong) UIView *loginNormalContainerView;
@property (nonatomic, strong) UITextField *userNameTextField;
@property (nonatomic, strong) UITextField *passwordTextField;
@property (nonatomic, strong) UITextField *verifyCodeTextField;

// 操作按钮
@property (nonatomic, strong) UIButton *loginButton;
@property (nonatomic, strong) UIButton *registerButton;
@property (nonatomic, strong) UIButton *retPasswordButton;

@end

@implementation CFCAppLoginViewController


#pragma mark -
#pragma mark 事件处理 - 登录
- (void)doLoginAction:(UIButton *)button
{
  // 用户名
  NSString *userName = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.userNameTextField.text];
  if ([CFCSysUtil validateStringEmpty:userName]) {
    [self alertPromptInfoMessage:@"用户名不能为空！"];
    return;
  }
  
  // 登录密码
  NSString *passWord = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.passwordTextField.text];
  if ([CFCSysUtil validateStringEmpty:passWord]) {
    [self alertPromptInfoMessage:@"登录密码不能为空！"];
    return;
  }
  
  // 关闭输入框焦点
  [self resignFirstResponderOfTextField];
  
  // 做登录相关操作
  [self doLoginWithUserName:userName password:passWord];
}


#pragma mark 事件处理 - 登录 - 逻辑处理
- (void)doLoginWithUserName:(NSString *)userName password:(NSString *)password
{
  NSString *url = URL_API_MINE_CENTER_LOIGN;
  NSMutableDictionary *params = [CFCNetworkParamsUtil getMineCenterLoginParameters:userName password:password];
  CFCLog(@"\n请求地址：%@ \n请求参数：%@", url, params);
  [CFCNetworkHTTPSessionUtil POST:url parameters:params success:^(id responseObject) {
    NSDictionary *responseData = (NSDictionary *)responseObject;
    CFCLog(@"[登录成功] => %@\n", responseData);
    NSDictionary *data = [responseData objectForKey:CFC_REQUEST_KEY_DATA];
    NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
    if ([CFCSysUtil validateResultCodeIsSuccess:status] && ![CFCSysUtil validateObjectIsNull:data]) {
      // 登录成功
      APPINFORMATION.loginStatus = YES;
      // 帐号密码
      APPINFORMATION.loginUserAccount = userName;
      APPINFORMATION.loginUserPassword = password;
      // 登录成功设置
      CFCUserInfoModel *userInfoModel = [CFCUserInfoModel mj_objectWithKeyValues:data];
      [CFCAppUtil applicationLoginRegisterSetting:userInfoModel];
      // 跳转个人中心
      [CFCAppUtil applicationSettingRootViewController:LOGIN_IN_TAB_SELECTED_INDEX];
    } else {
      NSString *message = [responseObject objectForKey:CFC_REQUEST_KEY_MESS];
      [self alertPromptErrorMessage:message];
    }
  } failure:^(NSError *error) {
    CFCLog(@"登录失败 = %@", error);
  } showMessage:nil showProgressHUD:YES showProgressView:self.view isHideErrorMessage:YES];
}

#pragma mark 事件处理 - 注册
- (void)doRegisterAction:(UIButton *)button
{
  [self resignFirstResponderOfTextField];
  
  CFCAppRegisterViewController *viewController = [[CFCAppRegisterViewController alloc] init];
  [self.navigationController pushViewController:viewController animated:YES];
}

#pragma mark 事件处理 - 忘记密码
- (void)doRetsetPasswordAction:(UIButton *)button
{
  [self resignFirstResponderOfTextField];
  
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
  self = [super init];
  if (self) {
    
  }
  return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  // 创建登录界面
  [self createLoginUIView];
}

#pragma mark 创建登录界面
- (void)createLoginUIView
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat buttonHeight = CFC_AUTOSIZING_WIDTH(SYSTEM_GLOBAL_BUTTON_HEIGHT); // 登录、快速注册按钮高度
  CGFloat textFieldHeight = CFC_AUTOSIZING_WIDTH(50.0f); // 用户名、密码输入框高度
  CGFloat textLeftImageSize = textFieldHeight*(22.0f/50.0f); // 图标大小
  CGFloat textContainerHeight = CFC_AUTOSIZING_WIDTH(70.0f); // 输入框容器高度
  
  UIFont *textFieldFont = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)]; // 输入框字体
  UIColor *textFieldColor = [UIColor colorWithRed:0.20 green:0.20 blue:0.20 alpha:1.00]; // 输入框文字颜色
  UIColor *textFieldPlaceholderColor = [UIColor colorWithRed:0.62 green:0.62 blue:0.62 alpha:1.00]; // 输入框暂位符颜色
  
  // 根容器
  UIScrollView *rootScrollView = ({
    TPKeyboardAvoidingScrollView *scrollView = [[TPKeyboardAvoidingScrollView alloc] init];
    [scrollView setShowsVerticalScrollIndicator:NO];
    [self.view addSubview:scrollView];
    
    [scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(self.view).with.offset(0.0);
      make.right.equalTo(self.view).with.offset(0.0);
      make.top.equalTo(self.view.mas_top).with.offset(0.0f);
      make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0f);
    }];
    
    scrollView;
  });
  
  
  // 主容器
  UIView *containerView = ({
    UIView *view = [[UIView alloc] init];
    [rootScrollView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.edges.equalTo(rootScrollView);
      make.width.equalTo(rootScrollView);
      make.height.mas_greaterThanOrEqualTo(SCREEN_HEIGHT-STATUS_NAVIGATION_BAR_HEIGHT-TAB_BAR_AND_DANGER_HEIGHT+1.0f);
    }];
    view;
  });
  
  
  // 登录区域
  {
    // 容器视图
    UIView *loginNormalContainerView = ({
      UIView *view = [[UIView alloc] init];
      [containerView addSubview:view];
      
      [view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(@0);
        make.right.equalTo(@0);
        make.top.equalTo(containerView.mas_top).offset(CFC_AUTOSIZING_HEIGTH(margin*5.0f));
      }];
      
      view;
    });
    self.loginNormalContainerView = loginNormalContainerView;
    
    
    // 用户账号
    UIView *userNameTextFieldView = ({
      // 容器
      UIView *view = [UIView new];
      [loginNormalContainerView addSubview:view];
      [view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(loginNormalContainerView.mas_top).offset(margin*0.8);
        make.left.equalTo(loginNormalContainerView.mas_left).offset(margin*2);
        make.right.equalTo(loginNormalContainerView.mas_right).with.offset(-margin*2);
        make.height.equalTo(@(textContainerHeight));
      }];
      
      // 图标
      UIImageView *leftImageView = [UIImageView new];
      [view addSubview:leftImageView];
      [leftImageView setImage:[[UIImage imageNamed:ICON_LOGIN_USERNAME]
                               imageByScalingProportionallyToSize:CGSizeMake(textLeftImageSize, textLeftImageSize)]];
      [leftImageView.layer setMasksToBounds:YES];
      [leftImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(view.mas_centerY).offset(0.0);
        make.left.equalTo(view.mas_left).offset(0.0);
        make.size.mas_equalTo(CGSizeMake(textLeftImageSize, textLeftImageSize));
      }];
      
      // 输入框
      UITextField *textField = [UITextField new];
      [view addSubview:textField];
      if (![CFCSysUtil validateStringEmpty:APPINFORMATION.loginUserAccount]) {
        [textField setText:APPINFORMATION.loginUserAccount];
      }
      [textField setFont:textFieldFont];
      [textField setTextColor:textFieldColor];
      [textField setBorderStyle:UITextBorderStyleNone];
      [textField setClearButtonMode:UITextFieldViewModeWhileEditing];
      [textField setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
      [textField setAttributedPlaceholder:[[NSAttributedString alloc] initWithString:@"请输入用户账号" attributes:@{ NSForegroundColorAttributeName : textFieldPlaceholderColor }]];
      [textField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(view.mas_centerY).offset(2.0);
        make.left.equalTo(leftImageView.mas_right).offset(margin);
        make.right.equalTo(view.mas_right).with.offset(0.0);
        make.height.equalTo(@(textFieldHeight));
      }];
      self.userNameTextField = textField;
      
      // 底部横线
      UIView *separatorLineView = [[UIView alloc] init];
      [view addSubview:separatorLineView];
      [separatorLineView setBackgroundColor:[UIColor colorWithRed:0.93 green:0.93 blue:0.93 alpha:1.00]];
      [separatorLineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(leftImageView.mas_bottom).offset(margin);
        make.left.equalTo(leftImageView.mas_left).offset(0.0f);
        make.right.equalTo(view.mas_right).offset(0.0);
        make.height.equalTo(@(1.0));
      }];
      
      view;
    });
    
    
    // 登录密码
    UIView *passwordTextFieldView = ({
      // 容器
      UIView *view = [UIView new];
      [loginNormalContainerView addSubview:view];
      [view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(userNameTextFieldView.mas_bottom).offset(margin*0.5f);
        make.left.equalTo(loginNormalContainerView.mas_left).offset(margin*2);
        make.right.equalTo(loginNormalContainerView.mas_right).with.offset(-margin*2);
        make.height.equalTo(@(textContainerHeight));
      }];
      
      // 图标
      UIImageView *leftImageView = [UIImageView new];
      [view addSubview:leftImageView];
      [leftImageView setImage:[[UIImage imageNamed:ICON_LOGIN_PASSWORD]
                               imageByScalingProportionallyToSize:CGSizeMake(textLeftImageSize, textLeftImageSize)]];
      [leftImageView.layer setMasksToBounds:YES];
      [leftImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(view.mas_centerY).offset(0.0);
        make.left.equalTo(view.mas_left).offset(0.0);
        make.size.mas_equalTo(CGSizeMake(textLeftImageSize, textLeftImageSize));
      }];
      
      // 输入框
      UITextField *textField = [UITextField new];
      [view addSubview:textField];
      if (![CFCSysUtil validateStringEmpty:APPINFORMATION.loginUserPassword]) {
        [textField setText:APPINFORMATION.loginUserPassword];
      }
      [textField setSecureTextEntry:YES];
      [textField setFont:textFieldFont];
      [textField setTextColor:textFieldColor];
      [textField setBorderStyle:UITextBorderStyleNone];
      [textField setClearButtonMode:UITextFieldViewModeWhileEditing];
      [textField setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
      [textField setAttributedPlaceholder:[[NSAttributedString alloc] initWithString:@"请输入登录密码" attributes:@{ NSForegroundColorAttributeName : textFieldPlaceholderColor }]];
      [textField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(view.mas_centerY).offset(2.0);
        make.left.equalTo(leftImageView.mas_right).offset(margin);
        make.right.equalTo(view.mas_right).with.offset(0.0);
        make.height.equalTo(@(textFieldHeight));
      }];
      self.passwordTextField = textField;
      
      // 底部横线
      UIView *separatorLineView = [[UIView alloc] init];
      [view addSubview:separatorLineView];
      [separatorLineView setBackgroundColor:[UIColor colorWithRed:0.93 green:0.93 blue:0.93 alpha:1.00]];
      [separatorLineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(leftImageView.mas_bottom).offset(margin);
        make.left.equalTo(leftImageView.mas_left).offset(0.0f);
        make.right.equalTo(view.mas_right).offset(0.0);
        make.height.equalTo(@(1.0));
      }];
      
      view;
    });
    
    
    // 忘记密码
    UIButton *retPasswordButton = ({
      UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
      [button retPasswordStyleButton];
      [button setTitle:@"忘记密码?" forState:UIControlStateNormal];
      [button addTarget:self action:@selector(doRetsetPasswordAction:) forControlEvents:UIControlEventTouchUpInside];
      [self.loginNormalContainerView addSubview:button];
      
      [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(passwordTextFieldView.mas_bottom).offset(margin*4.0);
        make.right.equalTo(self.loginNormalContainerView.mas_right).offset(-margin*2.0);
        make.width.equalTo(@(70));
        make.height.equalTo(@(25));
      }];
      
      button;
    });
    self.retPasswordButton = retPasswordButton;
    
    
    // 登录按钮
    UIButton *loginButton = ({
      UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
      [button loginStyleButton];
      [button setTitle:@"登 录" forState:UIControlStateNormal];
      [button addTarget:self action:@selector(doLoginAction:) forControlEvents:UIControlEventTouchUpInside];
      [loginNormalContainerView addSubview:button];
      
      [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(retPasswordButton.mas_bottom).offset(margin*1.0);
        make.left.equalTo(loginNormalContainerView.mas_left).offset(margin*2.0);
        make.right.equalTo(loginNormalContainerView.mas_right).with.offset(-margin*2.0);
        make.height.equalTo(@(buttonHeight));
      }];
      
      button;
    });
    self.loginButton = loginButton;
    
    
    // 注册
    UIButton *registerButton = ({
      UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
      [button registerStyleButton];
      [button setTitle:@"注册新帐号" forState:UIControlStateNormal];
      [button addTarget:self action:@selector(doRegisterAction:) forControlEvents:UIControlEventTouchUpInside];
      [loginNormalContainerView addSubview:button];
      
      [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(loginButton.mas_bottom).offset(margin);//(margin*2.0);
        make.left.equalTo(loginNormalContainerView.mas_left).offset(margin*2.0);
        make.right.equalTo(loginNormalContainerView.mas_right).with.offset(-margin*2.0);
        make.height.equalTo(@(buttonHeight));
      }];
      
      button;
    });
    self.registerButton = registerButton;
    
    
    // 约束的完整性
    [loginNormalContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.bottom.equalTo(registerButton.mas_bottom).offset(margin);
    }];
    
    
  } // 登录区域
  
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_USER_LOGIN;
}


#pragma mark -
#pragma mark 注销输入框响应事件
- (void)resignFirstResponderOfTextField
{
  [self.view endEditing:YES];
  [self.userNameTextField resignFirstResponder];
  [self.passwordTextField resignFirstResponder];
  [self.verifyCodeTextField resignFirstResponder];
}

#pragma mark 响应点击事件
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
  [self resignFirstResponderOfTextField];
}


@end


