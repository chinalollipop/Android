//
// 用户中心 - 站内消息
//

#import "CFCTableRefreshViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCMyMessageViewController : CFCTableRefreshViewController

@end

NS_ASSUME_NONNULL_END
