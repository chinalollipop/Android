//
// 用户中心 - 个人信息 - 修改头像
//

#import "CFCCollectionRefreshViewController.h"
@class CFCAppMeCenterMainUserModel;

NS_ASSUME_NONNULL_BEGIN

@protocol CFCAppMeCenterUserHeaderViewControllerDelegate <NSObject>
@optional
- (void)didUpdateUserHeaderAtAppMeCenterMainUserModel:(CFCAppMeCenterMainUserModel *)userInfoModel;
@end

@interface CFCAppMeCenterUserHeaderViewController : CFCCollectionRefreshViewController

@property (nonatomic, strong) CFCAppMeCenterMainUserModel *userInfoModel;

@property (nonatomic, weak) id<CFCAppMeCenterUserHeaderViewControllerDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
