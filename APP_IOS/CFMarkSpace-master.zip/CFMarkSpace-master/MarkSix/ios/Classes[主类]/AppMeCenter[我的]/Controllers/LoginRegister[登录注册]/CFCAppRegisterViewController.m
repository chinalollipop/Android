//
// 注册
//

#import "CFCAppRegisterViewController.h"
#import "CFCHtmlProtocolViewController.h"

@interface CFCAppRegisterViewController ()

@property (nonatomic, strong) UITextField *userNameTextField;  // 账号
@property (nonatomic, strong) UITextField *passwordTextField;  // 密码
@property (nonatomic, strong) UITextField *cfmPasswordTextField;  // 确认密码
@property (nonatomic, strong) UITextField *telephoneTextField;  // 手机号码
@property (nonatomic, strong) UITextField *identificationCodeTextField;  // 邀请编码

@property (nonatomic, strong) CFCCheckbox *protocolCheckbox;  // 协议Checkbox
@property (nonatomic, strong) UIButton *protocolButton;  // 协议按钮
@property (nonatomic, strong) UIButton *registerButton;  // 注册按钮
@property (nonatomic, strong) UIButton *loginBackButton;  // 登录按钮

@end


@implementation CFCAppRegisterViewController


#pragma mark -
#pragma mark 事件处理 - 注册
- (void)doRegisterAction:(UIButton *)button
{
  [self resignFirstResponderOfTextField];
  
  // 用户帐号
  NSString *userName = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.userNameTextField.text];
  if ([CFCSysUtil validateStringEmpty:userName]) {
    [self alertPromptInfoMessage:@"用户账号不能为空！"];
    return;
  }
  
  // 登录密码
  NSString *passWord = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.passwordTextField.text];
  if ([CFCSysUtil validateStringEmpty:passWord]) {
    [self alertPromptInfoMessage:@"登录密码不能为空！"];
    return;
  }
  
  // 确认密码
  NSString *makePassWord = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.cfmPasswordTextField.text];
  if ([CFCSysUtil validateStringEmpty:makePassWord]) {
    [self alertPromptInfoMessage:@"确认密码不能为空！"];
    return;
  }
  if (![passWord isEqualToString:makePassWord]) {
    [self alertPromptInfoMessage:@"登陆密码和确认密码不一致！"];
    return;
  }
  
  // 手机号码
  NSString *telephone = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.telephoneTextField.text];
  if (![telephone isMobileNumber]) {
    [self alertPromptInfoMessage:@"请输入正确的手机号码！"];
    return;
  }
  
  // 邀请编号
  NSString *invitationCode = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.identificationCodeTextField.text];
  if (![invitationCode isMobileNumber]) {
    [self alertPromptInfoMessage:@"请输入正确的邀请码！"];
    return;
  }
  
  // 注册操作
  [self doRegisterWithUserName:userName password:passWord telephone:telephone invitationCode:invitationCode];
}

#pragma mark 事件处理 - 注册 - 逻辑处理
- (void)doRegisterWithUserName:(NSString *)userName
                      password:(NSString *)password
                     telephone:(NSString *)telephone
                invitationCode:(NSString *)invitationCode
{
  NSString *url = URL_API_MINE_CENTER_REGISTER;
  NSMutableDictionary *params = [CFCNetworkParamsUtil getMineCenterRegisterParameters:userName password:password telephone:telephone invitationCode:invitationCode];
  CFCLog(@"\n请求地址：%@ \n请求参数：%@", url, params);
  [CFCNetworkHTTPSessionUtil POST:url parameters:params success:^(id responseObject) {
    NSDictionary *responseData = (NSDictionary *)responseObject;
    CFCLog(@"[注册成功] => %@\n", responseData);
    NSDictionary *data = [responseData objectForKey:CFC_REQUEST_KEY_DATA];
    NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
    if ([CFCSysUtil validateResultCodeIsSuccess:status] && ![CFCSysUtil validateObjectIsNull:data]) {
      // 登录成功
      APPINFORMATION.loginStatus = YES;
      // 帐号密码  
      APPINFORMATION.loginUserAccount = userName;
      APPINFORMATION.loginUserPassword = password;
      // 登录成功设置
      CFCUserInfoModel *userInfoModel = [CFCUserInfoModel mj_objectWithKeyValues:data];
      [CFCAppUtil applicationLoginRegisterSetting:userInfoModel];
      // 跳转个人中心
      [CFCAppUtil applicationSettingRootViewController:LOGIN_IN_TAB_SELECTED_INDEX];
    } else {
      NSString *message = [responseObject objectForKey:CFC_REQUEST_KEY_MESS];
      [self alertPromptErrorMessage:message];
    }
  } failure:^(NSError *error) {
    CFCLog(@"注册失败 = %@", error);
  } showMessage:nil showProgressHUD:YES showProgressView:self.view isHideErrorMessage:YES];
}

#pragma mark 事件处理 - 已有帐号，登录
- (void)doLoginBackAction:(UIButton *)button
{
  [self resignFirstResponderOfTextField];
  
  [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark 事件处理 - 阅读并接受协议
-(void)doCheckboxProtocolAction:(CFCCheckbox *)sender
{
  if (sender.checked) {
    // 同意协议后，注册按钮可用
    [self.registerButton setEnabled:YES];
    [self.registerButton setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BUTTON_DEFAULT];
  } else {
    // 未同意协议前不可用
    [self.registerButton setEnabled:NO];
    [self.registerButton setBackgroundColor:[UIColor colorWithRed:0.64 green:0.64 blue:0.64 alpha:1.00]];
  }
}

#pragma mark 事件处理 - 我已阅读并接受《注册协议》
-(void)doProtocolButtonAction:(UIButton *)sender
{
  [self resignFirstResponderOfTextField];
  
  CFCHtmlProtocolViewController *viewController = [[CFCHtmlProtocolViewController alloc] initWithLocalHTMLString:@"html_protocol"];
  [self.navigationController pushViewController:viewController animated:YES];
}


#pragma mark -
#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
  [super viewDidLoad];
  
  // 创建注册界面
  [self createRegisterUIView];
}

#pragma mark 视图生命周期（将要消失）
- (void)viewWillDisappear:(BOOL)animated
{
  [super viewWillDisappear:animated];
  
  [self resignFirstResponderOfTextField];
}

#pragma mark 创建注册界面
- (void)createRegisterUIView
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat buttonHeight = CFC_AUTOSIZING_WIDTH(SYSTEM_GLOBAL_BUTTON_HEIGHT); // 登录、快速注册按钮高度
  UIFont *textTitleFont = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]; // 输入框标题字体
  UIColor *textTitleColor = COLOR_HEXSTRING(@"#393939");  // 输入框标题颜色
  CGFloat textFieldHeight = CFC_AUTOSIZING_HEIGTH(50.0f); // 用户名、密码输入框高度
  CGFloat textContainerHeight = CFC_AUTOSIZING_HEIGTH(55.0); // 输入框容器高度
  CGFloat titleLableWidth = [@"四字标题" widthWithFont:textTitleFont constrainedToHeight:textFieldHeight] + margin*0.2f;  // 标题头宽度
  
  UIFont *textFieldFont = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]; // 输入框字体
  UIColor *textFieldColor = [UIColor colorWithRed:0.20 green:0.20 blue:0.20 alpha:1.00]; // 输入框文字颜色
  UIColor *textFieldPlaceholderColor = [UIColor colorWithRed:0.62 green:0.62 blue:0.62 alpha:1.00]; // 输入框暂位符颜色
  UIColor *textFieldLineColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.94 alpha:1.00]; // 输入框文字底部横线颜色
  UIColor *checkBoxColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;
  
  
  // 不自动滚动调整
  [self setAutomaticallyAdjustsScrollViewInsets:NO];

  
  // 根容器
  UIScrollView *rootScrollView = ({
    TPKeyboardAvoidingScrollView *scrollView = [[TPKeyboardAvoidingScrollView alloc] init];
    [scrollView setShowsVerticalScrollIndicator:NO];
    [self.view addSubview:scrollView];
    
    [scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(self.view).with.offset(0.0);
      make.right.equalTo(self.view).with.offset(0.0);
      make.top.equalTo(self.view.mas_top).with.offset(0.0f);
      make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0f);
    }];
    
    scrollView;
  });
  
  
  // 主容器
  UIView *containerView = ({
    UIView *view = [[UIView alloc] init];
    [rootScrollView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.edges.equalTo(rootScrollView);
      make.width.equalTo(rootScrollView);
      make.height.mas_greaterThanOrEqualTo(SCREEN_HEIGHT-STATUS_NAVIGATION_BAR_HEIGHT+1.0);
    }];
    
    view;
  });
  
  
  // 用户账号
  UIView *userNameTextFieldView = ({
    // 容器
    UIView *view = [UIView new];
    [containerView addSubview:view];
    [view setBackgroundColor:[UIColor whiteColor]];
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(containerView.mas_left).offset(margin*2.0f);
      make.right.equalTo(containerView.mas_right).with.offset(-margin*2.0f);
      make.height.equalTo(@(textContainerHeight));
      make.top.equalTo(containerView.mas_top).offset(CFC_AUTOSIZING_WIDTH(30.0f));
    }];
    
    // 标题
    UILabel *label = [UILabel new];
    [view addSubview:label];
    [label setText:@"用户账号"];
    [label setFont:textTitleFont];
    [label setTextColor:textTitleColor];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(view.mas_centerY);
      make.left.equalTo(view.mas_left).offset(0.0f);
      make.width.equalTo(@(titleLableWidth));
    }];
    
    // 左竖线
    UIView *leftSeparatorLineView = [[UIView alloc] init];
    [view addSubview:leftSeparatorLineView];
    [leftSeparatorLineView setBackgroundColor:textFieldLineColor];
    [leftSeparatorLineView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(label.mas_right).offset(margin);
      make.centerY.equalTo(label.mas_centerY);
      make.height.equalTo(view.mas_height).multipliedBy(0.4);
      make.width.equalTo(@(1.0));
    }];
    
    // 输入框
    UITextField *textField = [UITextField new];
    [view addSubview:textField];
    [textField setFont:textFieldFont];
    [textField setTextColor:textFieldColor];
    [textField setBorderStyle:UITextBorderStyleNone];
    [textField setClearButtonMode:UITextFieldViewModeWhileEditing];
    [textField setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
    [textField setAttributedPlaceholder:[[NSAttributedString alloc] initWithString:@"请输入用户帐号" attributes:@{ NSForegroundColorAttributeName : textFieldPlaceholderColor }]];
    [textField mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(label.mas_centerY).offset(0.0);
      make.left.equalTo(leftSeparatorLineView.mas_right).offset(margin);
      make.right.equalTo(view.mas_right).with.offset(0.0f);
      make.height.equalTo(@(textFieldHeight));
    }];
    self.userNameTextField = textField;
    
    // 底部横线
    UIView *separatorLineView = [[UIView alloc] init];
    [view addSubview:separatorLineView];
    [separatorLineView setBackgroundColor:textFieldLineColor];
    [separatorLineView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(view.mas_bottom).offset(-margin*0.5f);
      make.left.equalTo(view.mas_left).offset(0.0);
      make.right.equalTo(view.mas_right).offset(0.0);
      make.height.equalTo(@(1.0));
    }];
    
    view;
  });
  
  
  // 登录密码
  UIView *passwordTextFieldView = ({
    // 容器
    UIView *view = [UIView new];
    [containerView addSubview:view];
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(userNameTextFieldView.mas_bottom).offset(margin);
      make.left.equalTo(containerView.mas_left).offset(margin*2.0f);
      make.right.equalTo(containerView.mas_right).with.offset(-margin*2.0f);
      make.height.equalTo(@(textContainerHeight));
    }];
    
    // 标题
    UILabel *label = [UILabel new];
    [view addSubview:label];
    [label setText:@"登录密码"];
    [label setFont:textTitleFont];
    [label setTextColor:textTitleColor];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(view.mas_centerY);
      make.left.equalTo(view.mas_left).offset(0.0f);
      make.width.equalTo(@(titleLableWidth));
    }];
    
    // 左竖线
    UIView *leftSeparatorLineView = [[UIView alloc] init];
    [view addSubview:leftSeparatorLineView];
    [leftSeparatorLineView setBackgroundColor:textFieldLineColor];
    [leftSeparatorLineView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(label.mas_right).offset(margin);
      make.centerY.equalTo(label.mas_centerY);
      make.height.equalTo(view.mas_height).multipliedBy(0.4);
      make.width.equalTo(@(1.0));
    }];
    
    // 输入框
    UITextField *textField = [UITextField new];
    [view addSubview:textField];
    [textField setSecureTextEntry:YES];
    [textField setFont:textFieldFont];
    [textField setTextColor:textFieldColor];
    [textField setBorderStyle:UITextBorderStyleNone];
    [textField setClearButtonMode:UITextFieldViewModeWhileEditing];
    [textField setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
    [textField setAttributedPlaceholder:[[NSAttributedString alloc] initWithString:@"请输入登录密码" attributes:@{ NSForegroundColorAttributeName : textFieldPlaceholderColor }]];
    [textField mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(label.mas_centerY).offset(0.0);
      make.left.equalTo(leftSeparatorLineView.mas_right).offset(margin);
      make.right.equalTo(view.mas_right).with.offset(0.0f);
      make.height.equalTo(@(textFieldHeight));
    }];
    self.passwordTextField = textField;
    
    // 底部横线
    UIView *separatorLineView = [[UIView alloc] init];
    [view addSubview:separatorLineView];
    [separatorLineView setBackgroundColor:textFieldLineColor];
    [separatorLineView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(view.mas_bottom).offset(-margin*0.5f);
      make.left.equalTo(view.mas_left).offset(0.0);
      make.right.equalTo(view.mas_right).offset(0.0);
      make.height.equalTo(@(1.0));
    }];
    
    view;
  });
  
  
  // 确认密码
  UIView *cfmPasswordTextFieldView = ({
    // 容器
    UIView *view = [UIView new];
    [containerView addSubview:view];
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(passwordTextFieldView.mas_bottom).offset(margin);
      make.left.equalTo(containerView.mas_left).offset(margin*2.0f);
      make.right.equalTo(containerView.mas_right).with.offset(-margin*2.0f);
      make.height.equalTo(@(textContainerHeight));
    }];
    
    // 标题
    UILabel *label = [UILabel new];
    [view addSubview:label];
    [label setText:@"确认密码"];
    [label setFont:textTitleFont];
    [label setTextColor:textTitleColor];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(view.mas_centerY);
      make.left.equalTo(view.mas_left).offset(0.0f);
      make.width.equalTo(@(titleLableWidth));
    }];
    
    // 左竖线
    UIView *leftSeparatorLineView = [[UIView alloc] init];
    [view addSubview:leftSeparatorLineView];
    [leftSeparatorLineView setBackgroundColor:textFieldLineColor];
    [leftSeparatorLineView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(label.mas_right).offset(margin);
      make.centerY.equalTo(label.mas_centerY);
      make.height.equalTo(view.mas_height).multipliedBy(0.4);
      make.width.equalTo(@(1.0));
    }];
    
    // 输入框
    UITextField *textField = [UITextField new];
    [view addSubview:textField];
    [textField setSecureTextEntry:YES];
    [textField setFont:textFieldFont];
    [textField setTextColor:textFieldColor];
    [textField setBorderStyle:UITextBorderStyleNone];
    [textField setClearButtonMode:UITextFieldViewModeWhileEditing];
    [textField setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
    [textField setAttributedPlaceholder:[[NSAttributedString alloc] initWithString:@"请确认登录密码" attributes:@{ NSForegroundColorAttributeName : textFieldPlaceholderColor }]];
    [textField mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(label.mas_centerY).offset(0.0);
      make.left.equalTo(leftSeparatorLineView.mas_right).offset(margin);
      make.right.equalTo(view.mas_right).with.offset(0.0f);
      make.height.equalTo(@(textFieldHeight));
    }];
    self.cfmPasswordTextField = textField;
    
    // 底部横线
    UIView *separatorLineView = [[UIView alloc] init];
    [view addSubview:separatorLineView];
    [separatorLineView setBackgroundColor:textFieldLineColor];
    [separatorLineView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(view.mas_bottom).offset(-margin*0.5f);
      make.left.equalTo(view.mas_left).offset(0.0);
      make.right.equalTo(view.mas_right).offset(0.0);
      make.height.equalTo(@(1.0));
    }];
    
    view;
  });
  
  
  // 手机号码
  UIView *telephoneTextFieldView = ({
    // 容器
    UIView *view = [UIView new];
    [containerView addSubview:view];
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(cfmPasswordTextFieldView.mas_bottom).offset(margin);
      make.left.equalTo(containerView.mas_left).offset(margin*2.0f);
      make.right.equalTo(containerView.mas_right).with.offset(-margin*2.0f);
      make.height.equalTo(@(textContainerHeight));
    }];
    
    // 标题
    UILabel *label = [UILabel new];
    [view addSubview:label];
    [label setText:@"手机号码"];
    [label setFont:textTitleFont];
    [label setTextColor:textTitleColor];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(view.mas_centerY);
      make.left.equalTo(view.mas_left).offset(0.0f);
      make.width.equalTo(@(titleLableWidth));
    }];
    
    // 左竖线
    UIView *leftSeparatorLineView = [[UIView alloc] init];
    [view addSubview:leftSeparatorLineView];
    [leftSeparatorLineView setBackgroundColor:textFieldLineColor];
    [leftSeparatorLineView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(label.mas_right).offset(margin);
      make.centerY.equalTo(label.mas_centerY);
      make.height.equalTo(view.mas_height).multipliedBy(0.4);
      make.width.equalTo(@(1.0));
    }];
    
    // 输入框
    UITextField *textField = [UITextField new];
    [view addSubview:textField];
    [textField setFont:textFieldFont];
    [textField setTextColor:textFieldColor];
    [textField setBorderStyle:UITextBorderStyleNone];
    [textField setClearButtonMode:UITextFieldViewModeWhileEditing];
    [textField setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
    [textField setAttributedPlaceholder:[[NSAttributedString alloc] initWithString:@"请输入手机号码" attributes:@{ NSForegroundColorAttributeName : textFieldPlaceholderColor }]];
    [textField mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(label.mas_centerY).offset(0.0);
      make.left.equalTo(leftSeparatorLineView.mas_right).offset(margin);
      make.right.equalTo(view.mas_right).with.offset(0.0f);
      make.height.equalTo(@(textFieldHeight));
    }];
    self.telephoneTextField = textField;
    
    // 底部横线
    UIView *separatorLineView = [[UIView alloc] init];
    [view addSubview:separatorLineView];
    [separatorLineView setBackgroundColor:textFieldLineColor];
    [separatorLineView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(view.mas_bottom).offset(-margin*0.5f);
      make.left.equalTo(view.mas_left).offset(0.0);
      make.right.equalTo(view.mas_right).offset(0.0);
      make.height.equalTo(@(1.0));
    }];
    
    view;
  });
  
  
  // 识别码
  UIView *identificationCodeTextFieldView = ({
    // 容器
    UIView *view = [UIView new];
    [containerView addSubview:view];
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(telephoneTextFieldView.mas_bottom).offset(margin);
      make.left.equalTo(containerView.mas_left).offset(margin*2.0f);
      make.right.equalTo(containerView.mas_right).with.offset(-margin*2.0f);
      make.height.equalTo(@(textContainerHeight));
    }];
    
    // 标题
    UILabel *label = [UILabel new];
    [view addSubview:label];
    [label setText:@"邀  请  码"];
    [label setFont:textTitleFont];
    [label setTextColor:textTitleColor];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(view.mas_centerY);
      make.left.equalTo(view.mas_left).offset(0.0f);
      make.width.equalTo(@(titleLableWidth));
    }];
    
    // 左竖线
    UIView *leftSeparatorLineView = [[UIView alloc] init];
    [view addSubview:leftSeparatorLineView];
    [leftSeparatorLineView setBackgroundColor:textFieldLineColor];
    [leftSeparatorLineView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(label.mas_right).offset(margin);
      make.centerY.equalTo(label.mas_centerY);
      make.height.equalTo(view.mas_height).multipliedBy(0.4);
      make.width.equalTo(@(1.0));
    }];
    
    // 输入框
    UITextField *textField = [UITextField new];
    [view addSubview:textField];
    [textField setFont:textFieldFont];
    [textField setTextColor:textFieldColor];
    [textField setBorderStyle:UITextBorderStyleNone];
    [textField setClearButtonMode:UITextFieldViewModeWhileEditing];
    [textField setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
    [textField setAttributedPlaceholder:[[NSAttributedString alloc] initWithString:@"请输入邀请用户手机号（非必填）" attributes:@{ NSForegroundColorAttributeName : textFieldPlaceholderColor }]];
    [textField mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(label.mas_centerY).offset(0.0);
      make.left.equalTo(leftSeparatorLineView.mas_right).offset(margin);
      make.right.equalTo(view.mas_right).with.offset(0.0f);
      make.height.equalTo(@(textFieldHeight));
    }];
    self.identificationCodeTextField = textField;
    
    // 底部横线
    UIView *separatorLineView = [[UIView alloc] init];
    [view addSubview:separatorLineView];
    [separatorLineView setBackgroundColor:textFieldLineColor];
    [separatorLineView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(view.mas_bottom).offset(-margin*0.5f);
      make.left.equalTo(view.mas_left).offset(0.0);
      make.right.equalTo(view.mas_right).offset(0.0);
      make.height.equalTo(@(1.0));
    }];

    view;
  });
  
  
  // CFCCheckbox
  CFCCheckbox *protocolCheckbox = ({
    CGFloat checkboxSize = CFC_AUTOSIZING_HEIGTH(17.0f);
    CFCCheckbox *checkbox = [[CFCCheckbox alloc] initWithFrame:CGRectMake(0, 0, checkboxSize, checkboxSize)
                                                 selectBgColor:checkBoxColor
                                                 normalBgColor:COLOR_HEXSTRING(@"#FFFFFF")];
    [checkbox setChecked:YES];
    [checkbox addTarget:self action:@selector(doCheckboxProtocolAction:) forControlEvents:UIControlEventTouchUpInside];
    [containerView addSubview:checkbox];
    
    [checkbox mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(identificationCodeTextFieldView.mas_bottom).offset(margin*3.0f);
      make.left.equalTo(containerView.mas_left).offset(margin*2.0);
      make.size.mas_equalTo(CGSizeMake(checkboxSize, checkboxSize));
    }];
    
    checkbox;
  });
  protocolCheckbox.mas_key = @"protocolCheckbox";
  self.protocolCheckbox = protocolCheckbox;
  
  
  // 我已阅读并接受《注册协议》
  UIButton *protocolButton = ({
    NSString *title = @"我已阅读并接受《用户协议》";
    NSMutableAttributedString *attrString = [[NSMutableAttributedString alloc] initWithString:title];
    [attrString addAttribute:NSForegroundColorAttributeName
                       value:checkBoxColor
                       range:NSMakeRange(7,6)];
    UIFont *titleFont = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(14.0f)];
    CGSize titleSize = [title sizeWithAttributes:@{ NSFontAttributeName:titleFont }];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button defaultCommonButtonWithTitleColor:[UIColor colorWithRed:64.0/255.0 green:140.0/255.0 blue:226.0/255.0 alpha:1.0]
                              backgroundColor:[UIColor colorWithRed:1.00 green:1.00 blue:1.00 alpha:1.00]
                         backgroundImageColor:[UIColor colorWithRed:235/255.0 green:235/255.0 blue:235/255.0 alpha:1]
                                  borderColor:[UIColor whiteColor]
                                  borderWidth:0.0
                                 cornerRadius:0.0];
    [button.titleLabel setFont:titleFont];
    [button setAttributedTitle:attrString forState:UIControlStateNormal];
    [button setContentHorizontalAlignment:UIControlContentHorizontalAlignmentCenter];
    [button addTarget:self action :@selector(doProtocolButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [containerView addSubview:button];
    
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(protocolCheckbox.mas_top).offset(0.0);
      make.left.equalTo(protocolCheckbox.mas_right).offset(margin/2.0);
      make.bottom.equalTo(protocolCheckbox.mas_bottom).offset(0.0);
      make.width.mas_equalTo(titleSize.width+margin/3.0);
    }];
    
    button;
  });
  self.protocolButton = protocolButton;
  
  
  // 注册按钮
  UIButton *registerButton = ({
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button defaultStyleButton];
    [button.layer setBorderWidth:0.0f];
    [button setTitle:@"注 册" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(doRegisterAction:) forControlEvents:UIControlEventTouchUpInside];
    [containerView addSubview:button];
    
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(self.protocolCheckbox.mas_bottom).offset(margin*2.0f);
      make.left.equalTo(containerView.mas_left).offset(margin*2.0);
      make.right.equalTo(containerView.mas_right).with.offset(-margin*2.0);
      make.height.equalTo(@(buttonHeight));
    }];
    
    button;
  });
  self.registerButton = registerButton;
  
  
  // 已有帐号，登录
  UIButton *loginBackButton = ({
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button registerStyleButton];
    [button setTitle:@"已有帐号，登录" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(doLoginBackAction:) forControlEvents:UIControlEventTouchUpInside];
    [containerView addSubview:button];
    
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(registerButton.mas_bottom).offset(margin);
      make.left.equalTo(containerView.mas_left).offset(margin*2.0);
      make.right.equalTo(containerView.mas_right).with.offset(-margin*2.0);
      make.height.equalTo(@(buttonHeight));
    }];
    
    button;
  });
  self.loginBackButton = loginBackButton;
  
  
  // 说明介绍
  UILabel *introLabel = ({
    
    UIFont *textContentFont = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(14.0f)];
    UIColor *textContentColor = COLOR_HEXSTRING(@"#5F5F5F");
    
    // 标题
    UILabel *titleLabel = [UILabel new];
    [containerView addSubview:titleLabel];
    [titleLabel setText:@"为什么要使用手机号码注册？"];
    [titleLabel setFont:textTitleFont];
    [titleLabel setTextColor:textTitleColor];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(loginBackButton.mas_bottom).offset(margin*3.5f);
      make.left.equalTo(containerView.mas_left).offset(margin*2.0);
      make.right.equalTo(containerView.mas_right).with.offset(-margin*2.0);
    }];
    
    // 内容1
    UILabel *contentLabel1 = [UILabel new];
    [containerView addSubview:contentLabel1];
    [contentLabel1 setText:@"1、确保您是真实的用户;"];
    [contentLabel1 setFont:textContentFont];
    [contentLabel1 setTextColor:textContentColor];
    [contentLabel1 mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(titleLabel.mas_bottom).offset(margin*1.5f);
      make.left.equalTo(containerView.mas_left).offset(margin*2.0);
      make.right.equalTo(containerView.mas_right).with.offset(-margin*2.0);
    }];
    
    // 内容2
    UILabel *contentLabel2 = [UILabel new];
    [containerView addSubview:contentLabel2];
    [contentLabel2 setText:@"2、手机号码可用于登录;"];
    [contentLabel2 setFont:textContentFont];
    [contentLabel2 setTextColor:textContentColor];
    [contentLabel2 mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(contentLabel1.mas_bottom).offset(margin*0.75f);
      make.left.equalTo(containerView.mas_left).offset(margin*2.0);
      make.right.equalTo(containerView.mas_right).with.offset(-margin*2.0);
    }];
    
    // 内容3
    UILabel *contentLabel3 = [UILabel new];
    [containerView addSubview:contentLabel3];
    [contentLabel3 setText:@"3、忘记密码时可通过手机号码找回;"];
    [contentLabel3 setFont:textContentFont];
    [contentLabel3 setTextColor:textContentColor];
    [contentLabel3 mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(contentLabel2.mas_bottom).offset(margin*0.75f);
      make.left.equalTo(containerView.mas_left).offset(margin*2.0);
      make.right.equalTo(containerView.mas_right).with.offset(-margin*2.0);
    }];
    
    contentLabel3;
  });
  introLabel.mas_key = @"introLabel";

  
  // 约束完整
  [containerView mas_makeConstraints:^(MASConstraintMaker *make) {
    make.bottom.mas_greaterThanOrEqualTo(introLabel.mas_bottom).offset(margin*5.0f);
  }];
}


#pragma mark -
#pragma mark 设置导航栏标题文字
- (NSString *)prefersNavigationBarTitleViewTitle
{
  return STR_NAVIGATION_BAR_TITLE_USER_REGISTER;
}


#pragma mark - 注销输入框响应事件
- (void)resignFirstResponderOfTextField
{
  [self.userNameTextField resignFirstResponder];
  [self.passwordTextField resignFirstResponder];
  [self.identificationCodeTextField resignFirstResponder];
}


@end

