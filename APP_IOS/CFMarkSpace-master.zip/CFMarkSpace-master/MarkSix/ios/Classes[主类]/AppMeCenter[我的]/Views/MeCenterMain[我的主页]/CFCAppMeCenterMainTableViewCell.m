//
// 用户中心
//

#import "CFCAppMeCenterMainTableViewCell.h"
#import "CFCAppMeCenterMainModel.h"


// Cell Identifier
NSString * const CELL_IDENTIFIER_APP_ME_CENTER_MAIN = @"CFCAppMeCenterMainTableViewCellIdentifier";

@interface CFCAppMeCenterMainTableViewCell ()

@property (nonnull, nonatomic, strong) UIImageView *markImageView;  // 标识图片

@end


@implementation CFCAppMeCenterMainTableViewCell


#pragma mark - 创建子控件
- (void)createViewAtuoLayout
{
  [super createViewAtuoLayout];
  
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  
  // 图片
  UIImageView *markImageView = ({
    UIImageView *imageView = [UIImageView new];
    [self.publicContainerView addSubview:imageView];
    [imageView.layer setMasksToBounds:YES];
    [imageView setUserInteractionEnabled:YES];
    [imageView setContentMode:UIViewContentModeScaleAspectFit];
    
    CGSize imageSize = CGSizeMake(CFC_AUTOSIZING_WIDTH(22.0f), CFC_AUTOSIZING_WIDTH(22.0f));
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      //            make.top.equalTo(self.publicContainerView.mas_top).offset(margin*0.5);
      make.centerY.equalTo(self.publicContainerView.mas_centerY).offset(0.0f);
      make.left.equalTo(self.publicContainerView.mas_left).offset(margin * 1.5);
      make.size.mas_equalTo(imageSize);
    }];
    
    imageView;
  });
  self.markImageView = markImageView;
  self.markImageView.mas_key = [NSString stringWithFormat:@"markImageView"];
  
  // 标题
  [self.titleLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
    make.centerY.equalTo(markImageView.mas_centerY).offset(0.0);
    make.left.equalTo(markImageView.mas_right).offset(margin * 1.5);
  }];
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCAppMeCenterMainModel *)model
{
  [super setModel:model];
  
  // 类型安全检查
  if (![model isKindOfClass:[CFCAppMeCenterMainModel class]]) {
    return;
  }
  
  // 强击类型转换
  CFCAppMeCenterMainModel *model_original = (CFCAppMeCenterMainModel *)self.model;
  
  // 标识图片
  CGSize imageSize = CGSizeMake(CFC_AUTOSIZING_WIDTH(35.0f), CFC_AUTOSIZING_WIDTH(35.0f));
  [self.markImageView setImage:[[UIImage imageNamed:model_original.markImageUrl] imageByScalingProportionallyToSize:imageSize]];
  
}


#pragma mark - 触发操作事件
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture
{
  [super pressPublicItemView:gesture];
  
  // 强击类型转换
  CFCAppMeCenterMainModel *model_original = (CFCAppMeCenterMainModel *)self.model;
  id<CFCAppMeCenterMainTableViewCellDelegate> delegate_original = (id<CFCAppMeCenterMainTableViewCellDelegate>)self.delegate;
  
  if (delegate_original && [delegate_original respondsToSelector:@selector(didSelectRowAtAppMeCenterMainModel:)]) {
    [delegate_original didSelectRowAtAppMeCenterMainModel:model_original];
  }
  
}


@end
