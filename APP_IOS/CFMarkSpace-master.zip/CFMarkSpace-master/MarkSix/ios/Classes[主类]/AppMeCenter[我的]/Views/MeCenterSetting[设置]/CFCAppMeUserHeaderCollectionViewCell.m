//
// 寻宝 - 寻宝数据
//

#import "CFCAppMeUserHeaderCollectionViewCell.h"
#import "CFCAppMeUserHeaderModel.h"


// Cell Identifier
NSString * const CELL_IDENTIFIER_ME_USER_HEADER_COLLECTION_VIEW_CELL = @"CFCAppMeUserHeaderCollectionViewCellIdentifier";


@interface CFCAppMeUserHeaderCollectionViewCell ()
/**
 * 根容器组件
 */
@property (nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonatomic, strong) UIView *publicContainerView;
/**
 * 图标控件
 */
@property (nonnull, nonatomic, strong) UIImageView *iconImageView;

@end


@implementation CFCAppMeUserHeaderCollectionViewCell

- (instancetype)initWithFrame:(CGRect)frame
{
  self = [super initWithFrame:frame];
  if(self) {
    [self createViewAtuoLayout];
  }
  return self;
}

#pragma mark 创建子控件
- (void) createViewAtuoLayout
{
  // 定义变量
  CGFloat imageSize = self.width*0.95f;
  
  // 根容器
  UIView *rootContainerView = ({
    UIView *view = [[UIView alloc] init];
    [self.contentView insertSubview:view atIndex:0];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
    }];
    
    view;
  });
  self.rootContainerView = rootContainerView;
  self.rootContainerView.mas_key = @"rootContainerView";
  
  // 公共容器
  UIView *publicContainerView = ({
    UIView *view = [[UIView alloc] init];
    [rootContainerView addSubview:view];

    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressPublicItemView:)];
    [view addGestureRecognizer:tapGesture];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(rootContainerView.mas_left).offset(0.0f);
      make.top.equalTo(rootContainerView.mas_top).offset(0.0f);
      make.right.equalTo(rootContainerView.mas_right).offset(0.0f);
      make.bottom.equalTo(rootContainerView.mas_bottom).offset(0.0f);
    }];
    
    view;
  });
  self.publicContainerView = publicContainerView;
  self.publicContainerView.mas_key = @"publicContainerView";
  
  // 图标控件
  UIImageView *iconImageView = ({
    UIImageView *imageView = [UIImageView new];
    [publicContainerView addSubview:imageView];
    [imageView setUserInteractionEnabled:YES];
    [imageView setContentMode:UIViewContentModeScaleAspectFit];
    [imageView.layer setBorderWidth:2.0f];
    [imageView.layer setCornerRadius:imageSize*0.5f];

    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerX.equalTo(publicContainerView.mas_centerX);
      make.centerY.equalTo(publicContainerView.mas_centerY);
      make.size.mas_equalTo(CGSizeMake(imageSize, imageSize));
    }];
    
    imageView;
  });
  self.iconImageView = iconImageView;
  self.iconImageView.mas_key = @"iconImageView";
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCAppMeUserHeaderModel *)model
{
  // 类型安全检查
  if (![model isKindOfClass:[CFCAppMeUserHeaderModel class]]) {
    return;
  }
  
  // 数据赋值
  _model = (CFCAppMeUserHeaderModel *)model;
  
  // 图标控件
  [self.iconImageView setImage:[UIImage imageNamed:_model.imageName]];

  // 选中边框
  if (_model.isSelected) {
    [self.iconImageView.layer setBorderColor:COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT.CGColor];
  } else {
    [self.iconImageView.layer setBorderColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT.CGColor];
  }
}


#pragma mark - 操作事件 - 操作按钮
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture
{
  // 执行代理
  if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectRowAtAppMeUserHeaderModel:)]) {
    [self.delegate didSelectRowAtAppMeUserHeaderModel:self.model];
  }
}


@end

