//
// 用户中心 - 个人信息
//

#import "CFCSettingCoreTableViewCell.h"
@class CFCAppMeCenterSettingModel;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_APP_ME_CENTER_SETTING;

@protocol CFCAppMeCenterSettingTableViewCellDelegate <CFCSettingCoreTableViewCellDelegate>
@optional
- (void)didSelectRowAtAppMeCenterSettingModel:(CFCAppMeCenterSettingModel *)model;
@end

@interface CFCAppMeCenterSettingTableViewCell : CFCSettingCoreTableViewCell

@end

NS_ASSUME_NONNULL_END
