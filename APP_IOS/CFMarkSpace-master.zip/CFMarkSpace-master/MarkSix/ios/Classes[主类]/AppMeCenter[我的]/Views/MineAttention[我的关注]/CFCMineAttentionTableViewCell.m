//
// 用户中心 - 我的关注
//

#import "CFCMineAttentionTableViewCell.h"
#import "CFCMineAttentionModel.h"


// Cell Identifier
NSString * const CELL_IDENTIFIER_MINE_ATTENTION_IDENTIFIER = @"CFCMineAttentionTableViewCellIdentifier";


@interface CFCMineAttentionTableViewCell ()
/**
 * 根容器组件
 */
@property (nonnull, nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonnull, nonatomic, strong) UIView *publicContainerView;
/**
 * 头像控件
 */
@property (nonnull, nonatomic, strong) UIImageView *headerImageView;
/**
 * 编辑控件
 */
@property (nonnull, nonatomic, strong) UIImageView *editImageView;
/**
 * 标题控件
 */
@property (nonnull, nonatomic, strong) UILabel *titleLabel;
/**
 * 取消关注
 */
@property (nonatomic, strong) UIButton *attentionButton;
/**
 * 底部分割线
 */
@property (nonnull, nonatomic, strong) UIView *separatorLineView;


@end


@implementation CFCMineAttentionTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
  if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
    [self createViewAtuoLayout];
  }
  return self;
}

#pragma mark 创建子控件
- (void)createViewAtuoLayout
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat margin_top = margin*1.0f;
  CGFloat margin_left = margin*1.0f;
  CGFloat margin_bottom = margin*1.0f;
  CGFloat imageSize = SCREEN_WIDTH * 0.14f;
  

  // 根容器
  UIView *rootContainerView = ({
    UIView *view = [[UIView alloc] init];
    [self.contentView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
    }];
    
    view;
  });
  self.rootContainerView = rootContainerView;
  self.rootContainerView.mas_key = @"rootContainerView";
  
  
  // 公共容器
  UIView *publicContainerView = ({
    UIView *view = [[UIView alloc] init];
    [view.layer setMasksToBounds:YES];
    [view setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_DEFAULT];
    [rootContainerView addSubview:view];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressPublicItemView:)];
    [view addGestureRecognizer:tapGesture];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.bottom.equalTo(rootContainerView.mas_bottom);
    }];
    
    view;
  });
  self.publicContainerView = publicContainerView;
  self.publicContainerView.mas_key = @"publicContainerView";
  
  
  // 头像控件
  UIImageView *headerImageView = ({
    UIImageView *imageView = [UIImageView new];
    [self.publicContainerView addSubview:imageView];
    [imageView setUserInteractionEnabled:YES];
    [imageView setContentMode:UIViewContentModeScaleAspectFit];
    [imageView addCornerRadius:imageSize*0.5f];
    
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(publicContainerView.mas_top).offset(margin_top);
      make.left.equalTo(publicContainerView.mas_left).offset(margin_left);
      make.size.mas_equalTo(CGSizeMake(imageSize, imageSize));
    }];
    
    imageView;
  });
  self.headerImageView = headerImageView;
  self.headerImageView.mas_key = @"headerImageView";
  
  
  // 标题控件
  UILabel *titleLabel = ({
    UILabel *label = [UILabel new];
    [self.publicContainerView addSubview:label];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16)]];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    [label setTextAlignment:NSTextAlignmentLeft];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(headerImageView.mas_centerY);
      make.left.equalTo(self.headerImageView.mas_right).offset(margin*1.0f);
    }];
    
    label;
  });
  self.titleLabel = titleLabel;
  self.titleLabel.mas_key = @"titleLabel";
  
  
  // 编辑控件
  UIImageView *editImageView = ({
    CGFloat itemImage = imageSize*0.4f;
    UIImageView *imageView = [UIImageView new];
    [self.publicContainerView addSubview:imageView];
    [imageView setUserInteractionEnabled:YES];
    [imageView setContentMode:UIViewContentModeScaleAspectFit];
    [imageView setImage:[UIImage imageNamed:@"icon_attention_edit"]];
    
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(titleLabel.mas_centerY);
      make.left.equalTo(titleLabel.mas_right).offset(margin_left);
      make.size.mas_equalTo(CGSizeMake(itemImage, itemImage));
    }];
    
    imageView;
  });
  self.editImageView = editImageView;
  self.editImageView.mas_key = @"editImageView";
  
  
  // 取消关注
  UIButton *attentionButton = ({
    CGFloat buttonWidth = CFC_AUTOSIZING_WIDTH(100.0f);
    CGFloat buttonHeight = CFC_AUTOSIZING_WIDTH(40.0f);
    
    // 按钮
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.publicContainerView addSubview:button];
    [button defaultCommonButtonWithTitleColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT
                              backgroundColor:[UIColor whiteColor]
                         backgroundImageColor:[UIColor whiteColor]
                                  borderColor:[UIColor whiteColor]
                                  borderWidth:0.0f
                                 cornerRadius:0.0];
    [button setTitle:@"取消关注" forState:UIControlStateNormal];
    [button.titleLabel setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15)]];
    [button addTarget:self action:@selector(doAttentionButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
      make.centerY.equalTo(self.publicContainerView.mas_centerY);
      make.right.equalTo(self.publicContainerView.mas_right);
      make.width.equalTo(@(buttonWidth));
      make.height.equalTo(@(buttonHeight));
    }];
    
    button;
  });
  self.attentionButton = attentionButton;
  self.attentionButton.mas_key = @"attentionButton";
  
  
  // 灰色分割线
  UIView *separatorLineView = ({
    UIView *view = [[UIView alloc] init];
    [self.publicContainerView addSubview:view];
    [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(self.headerImageView.mas_bottom).offset(margin_bottom);
      make.left.equalTo(self.publicContainerView.mas_left);
      make.right.equalTo(self.publicContainerView.mas_right);
      make.height.equalTo(@(SEPARATOR_LINE_HEIGHT));
    }];
    
    view;
  });
  separatorLineView.mas_key = @"separatorLineView";
  
  
  // 约束的完整性
  [self.publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
    make.bottom.equalTo(separatorLineView.mas_bottom).priority(749);
  }];
  
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCMineAttentionModel *)model
{
  // 类型安全检查
  if (![model isKindOfClass:[CFCMineAttentionModel class]]) {
    return;
  }
  
  _model = model;
  
  // 标题控件
  [self.titleLabel setText:_model.name];
  
  // 头像控件
  WEAKSELF(weakSelf);
  __block UIActivityIndicatorView *activityIndicator = nil;
  [self.headerImageView sd_setImageWithURL:[NSURL URLWithString:_model.avatar] placeholderImage:nil options:0 progress:^(NSInteger receivedSize, NSInteger expectedSize, NSURL * _Nullable targetURL) {
    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
      if (!activityIndicator) {
        [weakSelf.headerImageView addSubview:activityIndicator = [UIActivityIndicatorView.alloc initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite]];
        [activityIndicator setColor:COLOR_ACTIVITY_INDICATOR_BACKGROUND];
        [activityIndicator setCenter:weakSelf.headerImageView.center];
        [activityIndicator startAnimating];
      }
    }];
  } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
    [activityIndicator removeFromSuperview];
    activityIndicator = nil;
  }];
  
}


#pragma mark - 操作事件 - 点击事件
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture
{
  if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectRowAtMineAttentionModel:indexPath:)]) {
    [self.delegate didSelectRowAtMineAttentionModel:self.model indexPath:self.indexPath];
  }
  
}

#pragma mark - 操作事件 - 取消关注
- (void)doAttentionButtonAction:(UIButton *)favouriteButton
{
  if (self.delegate && [self.delegate respondsToSelector:@selector(didAttentionButtonAtMineAttentionModel:indexPath:)]) {
    [self.delegate didAttentionButtonAtMineAttentionModel:self.model indexPath:self.indexPath];
  }
}


@end


