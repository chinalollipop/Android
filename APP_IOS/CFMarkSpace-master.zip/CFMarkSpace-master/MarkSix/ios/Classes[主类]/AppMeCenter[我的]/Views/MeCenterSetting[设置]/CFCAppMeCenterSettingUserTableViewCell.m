//
// 用户中心
//

#import "CFCAppMeCenterSettingUserTableViewCell.h"
#import "CFCAppMeCenterMainUserModel.h"

// Cell Identifier
NSString * const CELL_IDENTIFIER_APP_ME_CENTER_SETTING_USER = @"CFCAppMeCenterSettingUserTableViewCellIdentifier";


@interface CFCAppMeCenterSettingUserTableViewCell ()
/**
 * 根容器组件
 */
@property (nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonatomic, strong) UIView *publicContainerView;
/**
 * 头像控件
 */
@property (nonnull, nonatomic, strong) UIImageView *headImageView;
/**
 * 标题控件
 */
@property (nonatomic, strong) UILabel *titleLabel;

@end


@implementation CFCAppMeCenterSettingUserTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
  if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
    [self createViewAtuoLayout];
  }
  return self;
}


#pragma mark - 创建子控件
- (void)createViewAtuoLayout
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  
  // 根容器
  UIView *rootContainerView = ({
    UIView *view = [[UIView alloc] init];
    [self.contentView insertSubview:view atIndex:0];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
    }];
    
    view;
  });
  self.rootContainerView = rootContainerView;
  self.rootContainerView.mas_key = @"rootContainerView";
  
  // 公共容器
  UIView *publicContainerView = ({
    UIView *view = [[UIView alloc] init];
    [view.layer setMasksToBounds:YES];
    [rootContainerView addSubview:view];
    [rootContainerView setBackgroundColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressPublicItemView:)];
    tapGesture.numberOfTapsRequired = 1;
    tapGesture.numberOfTouchesRequired = 1;
    [view addGestureRecognizer:tapGesture];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(rootContainerView.mas_left).offset(0.0f);
      make.top.equalTo(rootContainerView.mas_top).offset(0.0f);
      make.right.equalTo(rootContainerView.mas_right).offset(0.0f);
      make.bottom.equalTo(rootContainerView.mas_bottom).offset(0.0f);
    }];
    
    view;
  });
  self.publicContainerView = publicContainerView;
  self.publicContainerView.mas_key = @"publicContainerView";
  
  // 图片
  UIImageView *headImageView = ({
    CGFloat size = CFC_AUTOSIZING_WIDTH(70.0f);
    UIImageView *imageView = [UIImageView new];
    [self.publicContainerView addSubview:imageView];
    [imageView addCornerRadius:size*0.5f];
    [imageView.layer setMasksToBounds:YES];
    [imageView setUserInteractionEnabled:YES];
    [imageView setContentMode:UIViewContentModeScaleAspectFit];

    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(self.publicContainerView.mas_top).offset(margin * 1.5f);
      make.centerX.equalTo(self.publicContainerView.mas_centerX);
      make.size.mas_equalTo(CGSizeMake(size, size));
    }];
    
    imageView;
  });
  self.headImageView = headImageView;
  self.headImageView.mas_key = @"headImageView";
  
  // 标题控件
  UILabel *titleLabel = ({
    UILabel *label = [UILabel new];
    [label setNumberOfLines:1];
    [label setUserInteractionEnabled:YES];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)]];
    [label setTextColor:COLOR_HEXSTRING(@"#101010")];
    [label setTextAlignment:NSTextAlignmentLeft];
    [publicContainerView addSubview:label];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(headImageView.mas_bottom).offset(margin * 1.5f);
      make.centerX.equalTo(headImageView.mas_centerX);
    }];
    
    label;
  });
  self.titleLabel = titleLabel;
  self.titleLabel.mas_key = @"titleLabel";
  

  // 约束的完整性
  [publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
    make.bottom.equalTo(titleLabel.mas_bottom).offset(margin * 1.5f).priority(749);
  }];
  
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCAppMeCenterMainUserModel *)model
{
  // 类型安全检查
  if (![model isKindOfClass:[CFCAppMeCenterMainUserModel class]]) {
    return;
  }
  
  // 数据赋值
  _model = model;
  
  // 标题
  [self.titleLabel setText:[NSString stringWithFormat:@"欢迎您，%@", _model.name]];
  
  // 头像
  WEAKSELF(weakSelf);
  __block UIActivityIndicatorView *activityIndicator = nil;
  [self.headImageView sd_setImageWithURL:[NSURL URLWithString:_model.avatar] placeholderImage:nil options:0 progress:^(NSInteger receivedSize, NSInteger expectedSize, NSURL * _Nullable targetURL) {
    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
      if (!activityIndicator) {
        [weakSelf.headImageView addSubview:activityIndicator = [UIActivityIndicatorView.alloc initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite]];
        [activityIndicator setColor:COLOR_ACTIVITY_INDICATOR_BACKGROUND];
        [activityIndicator setCenter:weakSelf.headImageView.center];
        [activityIndicator startAnimating];
      }
    }];
  } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
    [activityIndicator removeFromSuperview];
    activityIndicator = nil;
  }];
}


#pragma mark - 触发操作事件
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture
{
  if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectRowAtAppMeCenterMainUserModel:)]) {
    [self.delegate didSelectRowAtAppMeCenterMainUserModel:self.model];
  }
  
}


@end



