

#import "CFCAppMeCenterSettingLoginOutTableViewCell.h"
#import "CFCAppMeCenterSettingModel.h"

// Cell Identifier
NSString * const CELL_IDENTIFIER_ME_CENTER_SETTING_LOGIN_OUT = @"CFCAppMeCenterSettingLoginOutTableViewCellIdentifier";

@interface CFCAppMeCenterSettingLoginOutTableViewCell ()
/**
 * 根容器组件
 */
@property (nonnull, nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonnull, nonatomic, strong) UIView *publicContainerView;
/**
 * 标题控件
 */
@property (nonnull, nonatomic, strong) UILabel *titleLabel;
/**
 * 分割线控件
 */
@property (nonnull, nonatomic, strong) UIView *separatorLineView;

@end


@implementation CFCAppMeCenterSettingLoginOutTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createViewAtuoLayout];
    }
    return self;
}

#pragma make 创建子控件
- (void) createViewAtuoLayout
{
    WEAKSELF(weakSelf);
    
    CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
    self.backgroundColor = [UIColor clearColor];
    
    // 根容器
    UIView *rootContainerView = ({
        UIView *view = [[UIView alloc] init];
        [view setBackgroundColor:[UIColor clearColor]];
        [self.contentView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@0.0f);
            make.top.equalTo(@0.0f);
            make.right.equalTo(@0.0f);
            make.bottom.equalTo(weakSelf.contentView.mas_bottom).with.offset(0);
        }];
        
        view;
    });
    self.rootContainerView = rootContainerView;
    self.rootContainerView.mas_key = @"rootContainerView";
    
    // 公共容器
    UIView *publicContainerView = ({
        UIView *view = [[UIView alloc] init];
        [view.layer setMasksToBounds:YES];
        [view setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BUTTON_DEFAULT];
        [self.rootContainerView addSubview:view];
        
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressPublicItemView:)];
        tapGesture.numberOfTapsRequired = 1;
        tapGesture.numberOfTouchesRequired = 1;
        [view addGestureRecognizer:tapGesture];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(rootContainerView.mas_left).offset(margin*2.0f);
            make.top.equalTo(rootContainerView.mas_top).offset(margin);
            make.right.equalTo(rootContainerView.mas_right).offset(-margin*2.0f);
            make.bottom.equalTo(weakSelf.rootContainerView.mas_bottom).offset(0.0f);
        }];
        [view.layer setMasksToBounds:YES];
        [view.layer setCornerRadius:7.f];
        
        view;
    });
    self.publicContainerView = publicContainerView;
    self.publicContainerView.mas_key = @"publicContainerView";
    
    // 标题控件
    UILabel *titleLabel = ({
        UILabel *label = [UILabel new];
        [label setNumberOfLines:1];
        [label setUserInteractionEnabled:YES];
        [label setFont:[UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)]];
        [label setTextColor:COLOR_HEXSTRING(@"#FFFFFF")];
        [label setTextAlignment:NSTextAlignmentCenter];
        [publicContainerView addSubview:label];
        
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(publicContainerView.mas_top).offset(margin);
            make.left.equalTo(publicContainerView.mas_left).offset(margin);
            make.right.equalTo(publicContainerView.mas_right).offset(-margin);
        }];
        
        label;
    });
    self.titleLabel = titleLabel;
    self.titleLabel.mas_key = @"titleLabel";
    
    // 分割线
    UIView *separatorLineView = ({
        UIView *view = [[UIView alloc] init];
        [view setBackgroundColor:[UIColor clearColor]];
        [publicContainerView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(titleLabel.mas_bottom).offset(margin);
            make.left.equalTo(publicContainerView.mas_left).offset(0.0f);
            make.right.equalTo(publicContainerView.mas_right).offset(0.0f);
            make.height.equalTo(@(1.0f));
        }];
        
        view;
    });
    self.separatorLineView = separatorLineView;
    self.separatorLineView.mas_key = @"separatorLineView";
    
    // 约束的完整性
    [self.publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(separatorLineView.mas_bottom).offset(0.0f).priority(749);
    }];
    
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCAppMeCenterSettingModel *)model
{
    // 类型安全检查
    if (![model isKindOfClass:[CFCAppMeCenterSettingModel class]]) {
        return;
    }
    
    _model = model;
    
    // 标题
    [self.titleLabel setText:_model.title];
}


#pragma mark - 触发操作事件
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectRowAtLoginOutAppMeCenterSettingModel:)]) {
        [self.delegate didSelectRowAtLoginOutAppMeCenterSettingModel:self.model];
    }
}


@end





