//
// 用户中心 - 个人信息
//

#import "CFCAppMeCenterSettingTableViewCell.h"
#import "CFCAppMeCenterSettingModel.h"

// Cell Identifier
NSString * const CELL_IDENTIFIER_APP_ME_CENTER_SETTING = @"CFCAppMeCenterSettingTableViewCellIdentifier";


@implementation CFCAppMeCenterSettingTableViewCell

#pragma mark - 触发操作事件
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture
{
  [super pressPublicItemView:gesture];
  
  // 强击类型转换
  CFCAppMeCenterSettingModel *model_original = (CFCAppMeCenterSettingModel *)self.model;
  id<CFCAppMeCenterSettingTableViewCellDelegate> delegate_original = (id<CFCAppMeCenterSettingTableViewCellDelegate>)self.delegate;
  
  if (delegate_original && [delegate_original respondsToSelector:@selector(didSelectRowAtAppMeCenterSettingModel:)]) {
    [delegate_original didSelectRowAtAppMeCenterSettingModel:model_original];
  }
  
}


@end
