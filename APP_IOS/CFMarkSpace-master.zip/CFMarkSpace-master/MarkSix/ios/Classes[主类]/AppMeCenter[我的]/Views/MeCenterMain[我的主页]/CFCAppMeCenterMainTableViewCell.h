//
// 用户中心
//

#import "CFCSettingCoreTableViewCell.h"
@class CFCAppMeCenterMainModel;


NS_ASSUME_NONNULL_BEGIN


UIKIT_EXTERN NSString * const CELL_IDENTIFIER_APP_ME_CENTER_MAIN;


@protocol CFCAppMeCenterMainTableViewCellDelegate <CFCSettingCoreTableViewCellDelegate>
@optional
- (void)didSelectRowAtAppMeCenterMainModel:(CFCAppMeCenterMainModel *)model;
@end


@interface CFCAppMeCenterMainTableViewCell : CFCSettingCoreTableViewCell

@end


NS_ASSUME_NONNULL_END

