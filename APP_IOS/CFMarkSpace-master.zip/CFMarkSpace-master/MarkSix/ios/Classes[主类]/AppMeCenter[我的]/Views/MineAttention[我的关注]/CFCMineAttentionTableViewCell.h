//
// 用户中心 - 我的关注
//

#import <UIKit/UIKit.h>
@class CFCMineAttentionModel;


NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_MINE_ATTENTION_IDENTIFIER;

@protocol CFCMineAttentionTableViewCellDelegate <NSObject>
@optional
- (void)didSelectRowAtMineAttentionModel:(CFCMineAttentionModel *)model indexPath:(NSIndexPath *)indexPath;
- (void)didAttentionButtonAtMineAttentionModel:(CFCMineAttentionModel *)model indexPath:(NSIndexPath *)indexPath;
@end

@interface CFCMineAttentionTableViewCell : UITableViewCell

@property (nonatomic, strong) NSIndexPath *indexPath;

@property (nonatomic, strong) CFCMineAttentionModel *model;

@property (nonatomic, weak) id<CFCMineAttentionTableViewCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
