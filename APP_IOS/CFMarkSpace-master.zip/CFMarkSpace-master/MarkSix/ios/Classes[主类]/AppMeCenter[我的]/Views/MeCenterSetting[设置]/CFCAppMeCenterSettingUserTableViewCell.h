//
// 用户中心
//

#import <UIKit/UIKit.h>
@class CFCAppMeCenterMainUserModel;


NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_APP_ME_CENTER_SETTING_USER;


@protocol CFCAppMeCenterSettingUserTableViewCellDelegate <NSObject>
@optional
- (void)didSelectRowAtAppMeCenterMainUserModel:(CFCAppMeCenterMainUserModel *)model;
@end


@interface CFCAppMeCenterSettingUserTableViewCell : UITableViewCell
/**
 * 数据模型
 */
@property (nonatomic, strong) CFCAppMeCenterMainUserModel *model;

/**
 * 表格代理
 */
@property (nonatomic, weak) id<CFCAppMeCenterSettingUserTableViewCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
