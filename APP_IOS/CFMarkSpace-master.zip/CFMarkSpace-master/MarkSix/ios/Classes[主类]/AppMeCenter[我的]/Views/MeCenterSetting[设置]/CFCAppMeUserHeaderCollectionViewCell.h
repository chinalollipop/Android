//
// 寻宝 - 寻宝数据
//

#import <UIKit/UIKit.h>
@class CFCAppMeUserHeaderModel;


NS_ASSUME_NONNULL_BEGIN


UIKIT_EXTERN NSString * const CELL_IDENTIFIER_ME_USER_HEADER_COLLECTION_VIEW_CELL;


@protocol CFCAppMeUserHeaderCollectionViewCellDelegate <NSObject>
@optional
- (void)didSelectRowAtAppMeUserHeaderModel:(CFCAppMeUserHeaderModel *)model;
@end


@interface CFCAppMeUserHeaderCollectionViewCell : UICollectionViewCell
/**
 * 数据模型
 */
@property (nonatomic, strong) CFCAppMeUserHeaderModel *model;
/**
 * 表格代理
 */
@property (nonatomic, weak) id<CFCAppMeUserHeaderCollectionViewCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
