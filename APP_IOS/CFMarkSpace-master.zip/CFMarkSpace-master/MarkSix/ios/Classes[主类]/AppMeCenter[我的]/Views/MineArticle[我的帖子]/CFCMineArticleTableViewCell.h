//
// 用户中心 - 我的帖子
//

#import <UIKit/UIKit.h>
@class CFCMineArticleModel;


NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_MINE_ARTICLE_IDENTIFIER;

@protocol CFCMineArticleTableViewCellDelegate <NSObject>
@optional
- (void)didSelectRowAtMineArticleModel:(CFCMineArticleModel *)model indexPath:(NSIndexPath *)indexPath;
- (void)didFavouriteButtonAtMineArticleModel:(CFCMineArticleModel *)model indexPath:(NSIndexPath *)indexPath;
@end

@interface CFCMineArticleTableViewCell : UITableViewCell

@property (nonatomic, strong) NSIndexPath *indexPath;

@property (nonatomic, strong) CFCMineArticleModel *model;

@property (nonatomic, weak) id<CFCMineArticleTableViewCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
