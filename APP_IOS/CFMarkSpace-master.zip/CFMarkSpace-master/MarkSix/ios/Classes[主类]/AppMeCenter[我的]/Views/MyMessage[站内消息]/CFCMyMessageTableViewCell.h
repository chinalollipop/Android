//
// 用户中心 - 站内消息
//

#import <UIKit/UIKit.h>
@class CFCMyMessageModel;


NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_MINE_MESSAGE_IDENTIFIER;

@interface CFCMyMessageTableViewCell : UITableViewCell

@property (nonatomic, strong) NSIndexPath *indexPath;

@property (nonatomic, strong) CFCMyMessageModel *model;

@end

NS_ASSUME_NONNULL_END
