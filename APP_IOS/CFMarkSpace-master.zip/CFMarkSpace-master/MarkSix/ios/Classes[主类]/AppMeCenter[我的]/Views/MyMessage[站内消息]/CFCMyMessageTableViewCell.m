//
// 用户中心 - 站内消息
//

#import "CFCMyMessageTableViewCell.h"
#import "CFCMyMessageModel.h"


// Cell Identifier
NSString * const CELL_IDENTIFIER_MINE_MESSAGE_IDENTIFIER = @"CFCMyMessageTableViewCellIdentifier";


@interface CFCMyMessageTableViewCell ()
/**
 * 根容器组件
 */
@property (nonnull, nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonnull, nonatomic, strong) UIView *publicContainerView;
/**
 * 标题控件
 */
@property (nonnull, nonatomic, strong) UILabel *titleLabel;
/**
 * 内容控件
 */
@property (nonnull, nonatomic, strong) UILabel *contentLabel;
/**
 * 时间控件
 */
@property (nonnull, nonatomic, strong) UILabel *datetimeLabel;
/**
 * 底部分割线
 */
@property (nonnull, nonatomic, strong) UIView *separatorLineView;

@end


@implementation CFCMyMessageTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
  if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
    [self createViewAtuoLayout];
  }
  return self;
}

#pragma mark 创建子控件
- (void)createViewAtuoLayout
{
  CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
  CGFloat margin_top = margin*1.0f;
  CGFloat margin_left = margin*1.0f;
  CGFloat margin_right = margin*1.0f;
  CGFloat margin_bottom = margin*1.0f;
  
  
  // 根容器
  UIView *rootContainerView = ({
    UIView *view = [[UIView alloc] init];
    [self.contentView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
    }];
    
    view;
  });
  self.rootContainerView = rootContainerView;
  self.rootContainerView.mas_key = @"rootContainerView";
  
  
  // 公共容器
  UIView *publicContainerView = ({
    UIView *view = [[UIView alloc] init];
    [view.layer setMasksToBounds:YES];
    [view setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_DEFAULT];
    [rootContainerView addSubview:view];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.equalTo(@0.0f);
      make.top.equalTo(@0.0f);
      make.right.equalTo(@0.0f);
      make.bottom.equalTo(rootContainerView.mas_bottom);
    }];
    
    view;
  });
  self.publicContainerView = publicContainerView;
  self.publicContainerView.mas_key = @"publicContainerView";
  
  
  // 标题控件
  UILabel *titleLabel = ({
    UILabel *label = [UILabel new];
    [self.publicContainerView addSubview:label];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16)]];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_DEFAULT];
    [label setTextAlignment:NSTextAlignmentLeft];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(publicContainerView.mas_top).offset(margin_top);
      make.left.equalTo(publicContainerView.mas_left).offset(margin_left);
      make.right.equalTo(publicContainerView.mas_right).offset(-margin_right);
    }];
    
    label;
  });
  self.titleLabel = titleLabel;
  self.titleLabel.mas_key = @"titleLabel";

  
  // 时间控件
  UILabel *datetimeLabel = ({
    UILabel *label = [UILabel new];
    [self.publicContainerView addSubview:label];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(13)]];
    [label setTextColor:COLOR_SYSTEM_MAIN_FONT_ASSIST_DEFAULT];
    [label setTextAlignment:NSTextAlignmentLeft];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(self.titleLabel.mas_bottom).offset(margin*0.50f);
      make.left.equalTo(self.titleLabel.mas_left);
    }];
    
    label;
  });
  self.datetimeLabel = datetimeLabel;
  self.datetimeLabel.mas_key = @"datetimeLabel";
  
  
  // 内容
  UILabel *contentLabel = ({
    UILabel *label = [UILabel new];
    [self.publicContainerView addSubview:label];
    [label setUserInteractionEnabled:YES];
    [label setNumberOfLines:0];
    [label setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15)]];
    [label setTextColor:COLOR_HEXSTRING(@"#505773")];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(self.datetimeLabel.mas_bottom).offset(margin_left);
      make.left.equalTo(self.titleLabel.mas_left);
      make.right.equalTo(self.publicContainerView.mas_right).offset(-margin_right);
    }];
    
    label;
  });
  self.contentLabel = contentLabel;
  self.contentLabel.mas_key = @"contentLabel";
  
  
  // 灰色分割线
  UIView *separatorLineView = ({
    UIView *view = [[UIView alloc] init];
    [self.publicContainerView addSubview:view];
    [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
    
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
      make.top.equalTo(self.contentLabel.mas_bottom).offset(margin_bottom);
      make.left.equalTo(self.publicContainerView.mas_left);
      make.right.equalTo(self.publicContainerView.mas_right);
      make.height.equalTo(@(SEPARATOR_LINE_HEIGHT));
    }];
    
    view;
  });
  separatorLineView.mas_key = @"separatorLineView";
  
  
  // 约束的完整性
  [self.publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
    make.bottom.equalTo(separatorLineView.mas_bottom).priority(749);
  }];
  
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCMyMessageModel *)model
{
  // 类型安全检查
  if (![model isKindOfClass:[CFCMyMessageModel class]]) {
    return;
  }
  
  _model = model;
  
  // 标题控件
  [self.titleLabel setText:_model.title];

  // 内容控件
  [self.contentLabel setText:_model.content];
  
  // 时间控件
  NSDate *datetime = [CFCDateUtil secondToDate:self.model.dateline.doubleValue];
  NSString *dateTimeString = [CFCDateUtil dateFormattingWithDate:datetime toFormate:@"yyyy-MM-dd HH:mm:ss"];
  [self.datetimeLabel setText:dateTimeString];
  
}


@end


