
#import <UIKit/UIKit.h>
@class CFCAppMeCenterSettingModel;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_ME_CENTER_SETTING_LOGIN_OUT;

@protocol CFCAppMeCenterSettingLoginOutTableViewCellDelegate <NSObject>
@optional
- (void)didSelectRowAtLoginOutAppMeCenterSettingModel:(CFCAppMeCenterSettingModel *)model;
@end

@interface CFCAppMeCenterSettingLoginOutTableViewCell : UITableViewCell

/**
 * 数据模型
 */
@property (nonatomic, strong) CFCAppMeCenterSettingModel *model;

/**
 * 表格代理
 */
@property (nonatomic, weak) id<CFCAppMeCenterSettingLoginOutTableViewCellDelegate> delegate;


@end

NS_ASSUME_NONNULL_END
