//
// 用户中心 - 我的关注
//

#import "CFCMineAttentionModel.h"

@implementation CFCMineAttentionModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"uuid" : @"id",
           };
}

@end
