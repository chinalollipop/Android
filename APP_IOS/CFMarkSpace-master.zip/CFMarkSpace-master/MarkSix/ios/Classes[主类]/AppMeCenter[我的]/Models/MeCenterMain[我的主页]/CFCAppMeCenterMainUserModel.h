//
// 用户中心
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCAppMeCenterMainUserModel : NSObject

@property (nonatomic, strong) NSNumber *uuid;
@property (nonatomic, strong) NSNumber *follow;
@property (nonatomic, copy) NSString *phone;
@property (nonatomic, copy) NSString *created_at;
@property (nonatomic, copy) NSString *des;
@property (nonatomic, copy) NSString *avatar;
@property (nonatomic, copy) NSString *ip;
@property (nonatomic, copy) NSString *updated_at;
@property (nonatomic, strong) NSNumber *fans;
@property (nonatomic, strong) NSNumber *role_id;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *status;


@end

NS_ASSUME_NONNULL_END
