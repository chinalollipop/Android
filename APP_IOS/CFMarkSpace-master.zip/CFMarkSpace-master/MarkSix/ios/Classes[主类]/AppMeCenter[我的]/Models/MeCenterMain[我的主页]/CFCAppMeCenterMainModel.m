//
// 用户中心
//

#import "CFCAppMeCenterMainModel.h"

@implementation CFCAppMeCenterMainModel

+ (NSMutableArray *) buildingDataModles
{
  NSMutableArray<NSMutableArray *> *modelGroups = [NSMutableArray array];
  {
    NSArray *titles = @[
                        @[ @"我的帖子", @"我的关注", @"站内消息" ]
                        ];
    NSArray *contents = @[
                          @[ @"", @"", @"" ]
                          ];
    NSArray *markIds = @[
                         @[ STR_MARKID_MOREINFO_MINE_CENTER_INVITATION, STR_MARKID_MOREINFO_MINE_CENTER_ATTENTION, STR_MARKID_MOREINFO_MINE_CENTER_MESSAGEINFO ]
                         ];
    NSArray *markImages = @[
                            @[
                              @"icon_mine_center_invitation",
                              @"icon_mine_center_attention",
                              @"icon_mine_center_message"
                              ]
                            ];
    NSArray *isEdits = @[
                         @[ [NSNumber numberWithBool:YES], [NSNumber numberWithBool:YES], [NSNumber numberWithBool:YES] ]
                         ];
    NSArray *isSwitchs = @[ @[ [NSNumber numberWithBool:NO], [NSNumber numberWithBool:NO], [NSNumber numberWithBool:NO] ]
                            ];
    for (int index = 0; index < titles.count; index ++) {
      NSMutableArray<CFCAppMeCenterMainModel *> *models = [NSMutableArray array];
      NSArray *groupTitles = titles[index];
      NSArray *groupContents = contents[index];
      NSArray *groupMarkIds = markIds[index];
      NSArray *groupMarkImages = markImages[index];
      NSArray *groupEdits = isEdits[index];
      NSArray *groupSwitchs = isSwitchs[index];
      for (int k = 0; k < groupTitles.count; k ++) {
        CFCAppMeCenterMainModel *model = [[CFCAppMeCenterMainModel alloc] init];
        [model setMarkId:groupMarkIds[k]];
        [model setTitle:groupTitles[k]];
        [model setContent:groupContents[k]];
        [model setMarkImageUrl:groupMarkImages[k]];
        [model setIsEdit:[groupEdits[k] boolValue]];
        [model setIsSwitch:[groupSwitchs[k] boolValue]];
        [models addObject:model];
      }
      [modelGroups addObject:models];
    }
  }
  
  return modelGroups;
}

@end
