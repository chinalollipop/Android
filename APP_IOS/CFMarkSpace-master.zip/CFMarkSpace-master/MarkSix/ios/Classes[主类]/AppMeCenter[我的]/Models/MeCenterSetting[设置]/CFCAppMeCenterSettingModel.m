//
// 用户中心 - 个人信息
//

#import "CFCAppMeCenterSettingModel.h"
#import "CFCAppMeCenterMainUserModel.h"


@implementation CFCAppMeCenterSettingModel

+ (NSMutableArray *) buildingDataModlesWithUserInfoModel:(CFCAppMeCenterMainUserModel *)userInfoModel
{
  NSMutableArray<NSMutableArray *> *modelGroups = [NSMutableArray array];
  {
    NSArray *titles = @[
                        @[ @"手机号码", @"修改密码" ],
                        @[ @"退出当前帐号" ]
                        ];
    NSArray *contents = @[
                          @[ userInfoModel.phone, @"" ],
                          @[ @"" ]
                          ];
    NSArray *markIds = @[
                         @[ STR_MARKID_MOREINFO_MINE_CENTER_SETTING_PHONE, STR_MARKID_MOREINFO_MINE_CENTER_SETTING_PASSWORD ],
                         @[ STR_MARKID_MOREINFO_MINE_CENTER_SETTING_LOGIN_OUT ]
                         ];
    NSArray *isEdits = @[
                         @[ [NSNumber numberWithBool:NO], [NSNumber numberWithBool:YES] ],
                         @[ [NSNumber numberWithBool:NO] ]
                         ];
    NSArray *isSwitchs = @[ @[ [NSNumber numberWithBool:NO], [NSNumber numberWithBool:NO] ],
                            @[ [NSNumber numberWithBool:NO] ]
                            ];
    for (int index = 0; index < titles.count; index ++) {
      NSMutableArray<CFCAppMeCenterSettingModel *> *models = [NSMutableArray array];
      NSArray *groupTitles = titles[index];
      NSArray *groupContents = contents[index];
      NSArray *groupMarkIds = markIds[index];
      NSArray *groupEdits = isEdits[index];
      NSArray *groupSwitchs = isSwitchs[index];
      for (int k = 0; k < groupTitles.count; k ++) {
        CFCAppMeCenterSettingModel *model = [[CFCAppMeCenterSettingModel alloc] init];
        [model setMarkId:groupMarkIds[k]];
        [model setTitle:groupTitles[k]];
        [model setContent:groupContents[k]];
        [model setIsEdit:[groupEdits[k] boolValue]];
        [model setIsSwitch:[groupSwitchs[k] boolValue]];
        [models addObject:model];
      }
      [modelGroups addObject:models];
    }
  }
  
  return modelGroups;
}


@end

