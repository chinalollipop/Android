//
// 用户中心 - 个人信息 - 用户头像
//

#import <Foundation/Foundation.h>
@class CFCAppMeCenterMainUserModel;

NS_ASSUME_NONNULL_BEGIN

@interface CFCAppMeUserHeaderModel : NSObject

@property (nonatomic, assign) BOOL isSelected;
@property (nonatomic, copy) NSString *imageName;

+ (NSMutableArray<CFCAppMeUserHeaderModel *> *)buildingDataModlesWithUserInfoModel:(CFCAppMeCenterMainUserModel *)userInfoModel;

@end

NS_ASSUME_NONNULL_END
