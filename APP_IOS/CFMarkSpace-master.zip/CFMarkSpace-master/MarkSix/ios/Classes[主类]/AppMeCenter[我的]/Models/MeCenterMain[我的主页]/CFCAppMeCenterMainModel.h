//
// 用户中心
//

#import "CFCSettingCoreModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCAppMeCenterMainModel : CFCSettingCoreModel

@property (nonatomic, copy) NSString *markImageUrl; // 图标

+ (NSMutableArray *) buildingDataModles;

@end

NS_ASSUME_NONNULL_END
