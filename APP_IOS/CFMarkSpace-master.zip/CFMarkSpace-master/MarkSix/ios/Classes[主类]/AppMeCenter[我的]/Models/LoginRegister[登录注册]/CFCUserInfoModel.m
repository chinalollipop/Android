//
//  CFCUserInfoModel.m
//  MarkSix
//
//  Created by david on 2019/4/30.
//  Copyright © 2019年 Facebook. All rights reserved.
//

#import "CFCUserInfoModel.h"

@implementation CFCUserInfoModel

@end
