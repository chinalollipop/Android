//
// 用户中心 - 站内消息
//

#import "CFCMyMessageModel.h"

@implementation CFCMyMessageModel

@end
