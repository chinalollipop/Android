//
// 用户中心 - 我的帖子
//

#import "CFCMineArticleModel.h"

@implementation CFCMineArticleModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"uuid" : @"id",
           };
}

@end
