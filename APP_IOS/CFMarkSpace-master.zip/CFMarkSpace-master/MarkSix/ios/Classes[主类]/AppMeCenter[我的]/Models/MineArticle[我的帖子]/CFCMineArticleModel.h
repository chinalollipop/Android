//
// 用户中心 - 我的帖子
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCMineArticleModel : NSObject

@property (nonatomic, strong) NSNumber *uuid;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *avatar;
@property (nonatomic, strong) NSNumber *comments;
@property (nonatomic, copy) NSString *dateline;
@property (nonatomic, strong) NSNumber *good;

@end

NS_ASSUME_NONNULL_END
