//
// 用户中心
//

#import "CFCAppMeCenterMainUserModel.h"

@implementation CFCAppMeCenterMainUserModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
  return @{
           @"uuid" : @"id"
           };
}

@end
