//
// 用户中心 - 个人信息
//

#import "CFCSettingCoreModel.h"
@class CFCAppMeCenterMainUserModel;

NS_ASSUME_NONNULL_BEGIN

@interface CFCAppMeCenterSettingModel : CFCSettingCoreModel

+ (NSMutableArray *) buildingDataModlesWithUserInfoModel:(CFCAppMeCenterMainUserModel *)userInfoModel;

@end

NS_ASSUME_NONNULL_END
