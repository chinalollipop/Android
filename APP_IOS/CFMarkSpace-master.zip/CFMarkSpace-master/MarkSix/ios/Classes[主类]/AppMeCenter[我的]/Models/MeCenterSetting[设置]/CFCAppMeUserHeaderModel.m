//
// 用户中心 - 个人信息 - 用户头像
//

#import "CFCAppMeUserHeaderModel.h"
#import "CFCAppMeCenterMainUserModel.h"

@implementation CFCAppMeUserHeaderModel

+ (NSMutableArray<CFCAppMeUserHeaderModel *> *)buildingDataModlesWithUserInfoModel:(CFCAppMeCenterMainUserModel *)userInfoModel
{
  // 已经选中头像
  NSCharacterSet *characterSet = [NSCharacterSet characterSetWithCharactersInString:@"/"];
  NSArray<NSString *> *split = [userInfoModel.avatar componentsSeparatedByCharactersInSet:characterSet];
  NSString *defaultHeader = split.lastObject;
  // 设置选中头像
  NSMutableArray<CFCAppMeUserHeaderModel *> *models = [NSMutableArray array];
  {
    NSArray<NSString *> *images = @[ @"header1.png",
                                     @"header2.png",
                                     @"header3.png",
                                     @"header4.png",
                                     @"header5.png",
                                     @"header6.png",
                                     @"header7.png",
                                     @"header8.png" ];
    NSUInteger selectedIndex = 0;
    if ([images containsObject:defaultHeader]) {
      selectedIndex = [images containsObject:defaultHeader];
    }
    for (int index = 0; index < images.count; index ++) {
      CFCAppMeUserHeaderModel *model = [[CFCAppMeUserHeaderModel alloc] init];
      [model setImageName:images[index]];
      if (selectedIndex == index) {
        [model setIsSelected:YES];
      } else {
        [model setIsSelected:NO];
      }
      [models addObject:model];
    }
  }
  
  return models;
}

@end
