//
// 用户中心 - 站内消息
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCMyMessageModel : NSObject

@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *content;
@property (nonatomic, strong) NSNumber *dateline;

@end

NS_ASSUME_NONNULL_END
