

#ifndef _CFC_ASSETS_MACRO_H_
#define _CFC_ASSETS_MACRO_H_

#pragma mark -
#pragma mark 图标：标签栏按钮
#define ICON_TAB_BAR_ITEM_HOME_NORMAL                               @"icon_tabbar_item_home"
#define ICON_TAB_BAR_ITEM_HOME_SELECT                               @"icon_tabbar_item_home_select"
#define ICON_TAB_BAR_ITEM_DISCOVER_NORMAL                           @"icon_tabbar_item_discover"
#define ICON_TAB_BAR_ITEM_DISCOVER_SELECT                           @"icon_tabbar_item_discover_select"
#define ICON_TAB_BAR_ITEM_ME_CENTER_NORMAL                          @"icon_tabbar_item_mine"
#define ICON_TAB_BAR_ITEM_ME_CENTER_SELECT                          @"icon_tabbar_item_mine_select"
#define ICON_TAB_BAR_ITEM_MOREINFO_NORMAL                           @"icon_tabbar_item_moreinfo"
#define ICON_TAB_BAR_ITEM_MOREINFO_SELECT                           @"icon_tabbar_item_moreinfo_select"

#pragma mark -
#pragma mark 图标：导航栏按钮
#define ICON_NAVIGATION_BAR_BUTTON_BLACK_ARROW                      @"icon_navbar_arrow_black"
#define ICON_NAVIGATION_BAR_BUTTON_WHITE_ARROW                      @"icon_navbar_arrow_white"
#define ICON_NAVIGATION_BAR_BUTTON_MORE_POINT                       @"icon_navbar_more_point_white"
#define ICON_NAVIGATION_BAR_BUTTON_CLOSE_DEF                        @"icon_navbar_close_black"

#pragma mark -
#pragma mark 图标：空白占位符
#define ICON_SCROLLVIEW_EMPTY_DATASET_RESULT                        @"icon_empty_dataset_result"

#pragma mark -
#pragma mark 图标：公共图标库
#define ICON_APP_LOGO                                               @"icon_app_logo"
#define ICON_MARQUE                                                 @"icon_marque"
#define ICON_REFRESH                                                @"icon_refresh"
#define ICON_CALENDAR                                               @"icon_calendar"
#define ICON_TOUCH_CLOSE                                            @"icon_touch_close"
#define ICON_OPEN_RESULT_PLUS                                       @"icon_open_result_plus"
#define ICON_OPEN_RESULT_ARROW                                      @"icon_open_result_arrow"
#define ICON_OPEN_RESULT_BACKGROUND                                 @"icon_open_result_background"
#define ICON_OPEN_RESULT_NUM_BLUE                                   @"icon_open_result_num_blue"
#define ICON_OPEN_RESULT_NUM_GREEN                                  @"icon_open_result_num_green"
#define ICON_OPEN_RESULT_NUM_RED                                    @"icon_open_result_num_red"
#define ICON_OPEN_BACKGROUND_HEADER                                 @"icon_background_header"
#define ICON_CALENDAR_HEADER_TITLE                                  @"icon_calendar_header_title"
#define ICON_CALENDAR_HEADER_BACKGROUND                             @"icon_calendar_header_background"
#define ICON_CALENDAR_BUTTON_LAST_MOUNTH                            @"icon_arrow_left"
#define ICON_CALENDAR_BUTTON_NEXT_MOUNTH                            @"icon_arrow_right"
#define ICON_DISCOVER_XYYJ_RESULT_PLUS                              @"icon_discover_xyyj_plus"


#pragma mark 图标：登录注册
#define ICON_LOGIN_USERNAME                                         @"icon_login_username"
#define ICON_LOGIN_PASSWORD                                         @"icon_login_password"
#define ICON_SETTING_TABLE_ARROW                                    @"icon_setting_arrow"
#define ICON_SHENGXIAO_COVER                                        @"icon_shengxiao_cover"



#endif /* _CFC_ASSETS_MACRO_H_ */

