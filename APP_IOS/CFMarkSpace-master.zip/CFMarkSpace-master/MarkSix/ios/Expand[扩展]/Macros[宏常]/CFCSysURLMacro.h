

#ifndef _CFC_SYS_URL_MACRO_H_
#define _CFC_SYS_URL_MACRO_H_


#pragma mark -
#pragma mark 系统接口
#define URL_API_APPENDING(URL)                               [CFCNetworkHTTPSessionUtil makeRequestWithBaseURLString:URL_API_BASE URLString:URL]


#pragma mark -
#if DEBUG
// 测试环境
#define URL_API_BASE                                         @"http://128.14.157.84/api"
#elif RELEASE
// 生产环境
#define URL_API_BASE                                         @"http://128.14.157.84/api"
#else
// 其它环境
#define URL_API_BASE                                         @"http://128.14.157.84/api"
#endif


#pragma mark -
// 首页 - 获取主页数据
#define URL_API_HOME_MAIN                                    URL_API_APPENDING(@"/init")

// 首页 - 获取最新开奖
#define URL_API_LASTEST_CURRENT_DRAW                         URL_API_APPENDING(@"/open/current")

// 首页 - 开奖记录
#define URL_API_DRAW_RESULT_RECORD_LIST                      URL_API_APPENDING(@"/open/by/year")

// 首页 - 开奖记录 - 所有年份
#define URL_API_DRAW_RESULT_RECORD_YEARS                     URL_API_APPENDING(@"/years")

// 首页 - 开奖记录 - 详细信息
#define URL_API_DRAW_RESULT_RECORD_DETAIL                    URL_API_APPENDING(@"/current/info")

// 首页 - 开奖记录 - 开奖日期
#define URL_API_DRAW_RESULT_RECORD_DATETIEM                  URL_API_APPENDING(@"/open/date")

// 首页 - 项目工具 - 开奖历史
#define URL_API_HOME_MAIN_PROJECT_KAIJIANGLISHI              URL_API_APPENDING(@"/columns/open/history")

// 首页 - 项目工具 - 资料大全
#define URL_API_HOME_MAIN_PROJECT_ZILIAODAQUAN               URL_API_APPENDING(@"/columns/data/corpus")

// 首页 - 项目工具 - 六合高手
#define URL_API_HOME_MAIN_PROJECT_LIUHEGAOSHOU               URL_API_APPENDING(@"/columns/lh/master")

// 首页 - 项目工具 - 比武擂台
#define URL_API_HOME_MAIN_PROJECT_BIWULEITAI                 URL_API_APPENDING(@"/columns/competition/arena")

// 首页 - 文章列表 - 分类列表 - 分类标识
#define URL_API_HOME_MAIN_PROJECT_ARTICLE_CLASSIFY           URL_API_APPENDING(@"/article/list")

// 首页 - 文章列表 - 用户文章 - 用户标识
#define URL_API_HOME_MAIN_PROJECT_ARTICLE_USER_UUID          URL_API_APPENDING(@"/article/list/by/user")

// 首页 - 文章列表 - 点赞文章
#define URL_API_HOME_MAIN_PROJECT_ARTICLE_FAVOURITE          URL_API_APPENDING(@"/user/voted/article")

// 首页 - 文章列表 - 发布帖子
#define URL_API_HOME_MAIN_PROJECT_ARTICLE_EDIT_SUBMIT        URL_API_APPENDING(@"/user/publish/article")



// 寻宝 - 玄机锦囊 - 当前期号
#define URL_API_DISCOER_MAIN_XUANJIJINLANG_CURRENT          URL_API_APPENDING(@"/find/prompts/new")

// 寻宝 - 玄机锦囊 - 往期历史
#define URL_API_DISCOER_MAIN_XUANJIJINLANG_HISTORY          URL_API_APPENDING(@"/find/prompts/by/year")



// 个人中心 - 用户登录
#define URL_API_MINE_CENTER_LOIGN                            URL_API_APPENDING(@"/authorizations")

// 个人中心 - 用户退出
#define URL_API_MINE_CENTER_LOGIN_OUT                        URL_API_APPENDING(@"/authorizations/current")

// 个人中心 - 用户注册
#define URL_API_MINE_CENTER_REGISTER                         URL_API_APPENDING(@"/users")

// 个人中心 - 用户信息
#define URL_API_MINE_CENTER_USER_INFO                        URL_API_APPENDING(@"/user")

// 个人中心 - 修改密码
#define URL_API_MINE_CENTER_USER_PASSWORD_UPDATE             URL_API_APPENDING(@"/user/update/password")

// 个人中心 - 修改头像
#define URL_API_MINE_CENTER_USER_AVATAR_UPDATE               URL_API_APPENDING(@"/user/update/avatar")

// 个人中心 - 刷新令牌
#define URL_API_AUTHORIZATION_CURRENT_REFRESH                URL_API_APPENDING(@"/authorizations/current/refresh")

// 个人中心 - 我的帖子
#define URL_API_MINE_CENTER_MINE_ARTICLE                     URL_API_APPENDING(@"/user/articles")

// 个人中心 - 我的关注
#define URL_API_MINE_CENTER_MINE_ATTENTION                   URL_API_APPENDING(@"/user/follows")

// 个人中心 - 关注用户
#define URL_API_MINE_CENTER_ATTENTION_USER                   URL_API_APPENDING(@"/user/followed/user")

// 个人中心 - 站内消息
#define URL_API_MINE_CENTER_MINE_NOTIFICATIONS               URL_API_APPENDING(@"/user/notifications")


// 更多 -  联系我们
#define URL_API_MORE_INFO_CONTACT_US                         URL_API_APPENDING(@"/contact/us")

// 更多 -  意见反馈
#define URL_API_MORE_INFO_SUGGESTION                         URL_API_APPENDING(@"/feedback")


#endif /* _CFC_SYS_URL_MACRO_H_ */






