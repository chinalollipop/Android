

#ifndef _CFC_STRING_MACRO_H_
#define _CFC_STRING_MACRO_H_


#pragma mark - 导航栏按钮标题 - 返回/默认
#define STR_NAVIGATION_BAR_BUTTON_TITLE_EMPTY                                        @""
#define STR_NAVIGATION_BAR_BUTTON_TITLE_RETURN_BACK                                  @"返回"


#pragma mark -
#pragma mark 字符串常量 - 占位符
#define STR_APP_TEXT_PLACEHOLDER                                                     @"-----"
#define STR_APP_TEXT_EMPTY                                                           @""
#define STR_APP_TEXT_NULL                                                            @"空"
#define STR_APP_TEXT_ALL                                                             @"全部"


#pragma mark -
#pragma mark 字符串常量 - 弹出框标题
#define STR_ALERT_MESSAGE_TITLE_INFO                                                 @""


#pragma mark - 标签栏标题 - 六合社区/个人中心/工具宝箱/更多信息
#define STR_TAB_BAR_ITEM_NAME_HOME                                                   @"菜单"
#define STR_TAB_BAR_ITEM_NAME_ME_CENTER                                              @"我的"
#define STR_TAB_BAR_ITEM_NAME_DISCOVER                                               @"寻宝"
#define STR_TAB_BAR_ITEM_NAME_MORE_INFO                                              @"更多"


#pragma mark - 导航栏标题 - 六合社区/个人中心/工具宝箱/更多信息
#define STR_NAVIGATION_BAR_TITLE_HOME                                                @"六合社区"
#define STR_NAVIGATION_BAR_TITLE_ME_CENTER                                           @"个人中心"
#define STR_NAVIGATION_BAR_TITLE_DISCOVER                                            @"工具宝箱"
#define STR_NAVIGATION_BAR_TITLE_MORE_INFO                                           @"更多"


#pragma mark - 导航栏标题
#define STR_NAVIGATION_BAR_TITLE_PROJECT_KAIJIANGLISHI                               @"开奖历史"
#define STR_NAVIGATION_BAR_TITLE_PROJECT_CHAXUNZHUSHOU                               @"查询助手"
#define STR_NAVIGATION_BAR_TITLE_PROJECT_ZILIAODAQUAN                                @"资料大全"
#define STR_NAVIGATION_BAR_TITLE_PROJECT_LIUHEGAOSHOU                                @"六合高手"
#define STR_NAVIGATION_BAR_TITLE_PROJECT_BIWULEITAI                                  @"比武擂台"
#define STR_NAVIGATION_BAR_TITLE_DRAWRESULT_TAB_PAGER                                @"开奖记录"
#define STR_NAVIGATION_BAR_TITLE_DRAWRESULT_RECORD_DETAIL                            @"本期开奖查询"
#define STR_NAVIGATION_BAR_TITLE_ARTICLE_EDIT                                        @"发贴"
//
#define STR_NAVIGATION_BAR_TITLE_USER_LOGIN                                          @"登录"
#define STR_NAVIGATION_BAR_TITLE_USER_REGISTER                                       @"注册"
#define STR_NAVIGATION_BAR_TITLE_USER_PASSWORD_UPDATE                                @"忘记密码"
#define STR_NAVIGATION_BAR_TITLE_PROTOCOL                                            @"用户协议"
#define STR_NAVIGATION_BAR_TITLE_ME_CENTER_USERINFO                                  @"个人信息"
#define STR_NAVIGATION_BAR_TITLE_ME_CENTER_HEADER_UPDATE                             @"更换头像"
#define STR_NAVIGATION_BAR_TITLE_ME_CENTER_PASSWORD                                  @"修改登录密码"
//
#define STR_NAVIGATION_BAR_TITLE_APP_INTRO                                           @"应用简介"
#define STR_NAVIGATION_BAR_TITLE_ABOUT_US                                            @"关于我们"
#define STR_NAVIGATION_BAR_TITLE_SHARE_SMSC                                          @"短信分享"
#define STR_NAVIGATION_BAR_TITLE_SHARE_SOFTWARE                                      @"软件分享"
#define STR_NAVIGATION_BAR_TITLE_DECLAREATION                                        @"免费声明"
#define STR_NAVIGATION_BAR_TITLE_CONTACT_US                                          @"联系我们"
#define STR_NAVIGATION_BAR_TITLE_SUGGESTION                                          @"意见反馈"
//
#define STR_NAVIGATION_BAR_TITLE_DISCOVER_JIAOZHURIQI                                @"搅珠日期"
#define STR_NAVIGATION_BAR_TITLE_DISCOVER_LIANRENTEMA                                @"恋人特码"
#define STR_NAVIGATION_BAR_TITLE_DISCOVER_SHENGXIAOKA                                @"生肖卡牌"
#define STR_NAVIGATION_BAR_TITLE_DISCOVER_TIANJICESUAN                               @"天机测算"
#define STR_NAVIGATION_BAR_TITLE_DISCOVER_YAOYIYAO                                   @"摇一摇"
#define STR_NAVIGATION_BAR_TITLE_DISCOVER_BOXIAOZHUANPAN                             @"波肖转盘"
#define STR_NAVIGATION_BAR_TITLE_DISCOVER_XINGYUNYAOJIANG                            @"幸运摇奖"
#define STR_NAVIGATION_BAR_TITLE_DISCOVER_XUANJIJINLANG                              @"玄机锦囊"
#define STR_NAVIGATION_BAR_TITLE_DISCOVER_XUANJIJINLANG_HISTORY                      @"往期历史"
#define STR_NAVIGATION_BAR_TITLE_DISCOVER_TIAOMAZHUSHOU                              @"挑码助手"
//
#define STR_NAVIGATION_BAR_TITLE_MINE_CENTER_INVITATION                              @"我的帖子"
#define STR_NAVIGATION_BAR_TITLE_MINE_CENTER_ATTENTION                               @"我的关注"
#define STR_NAVIGATION_BAR_TITLE_MINE_CENTER_MESSAGEINFO                             @"站内消息"


#pragma mark - 字符标识常量 - 首页 - 工具列表
#define STR_MARKID_HOME_MAIN_PROJECT_KJLS                                            @"KJLS" // 开奖历史
#define STR_MARKID_HOME_MAIN_PROJECT_LHTK                                            @"LHTK" // 六合图库
#define STR_MARKID_HOME_MAIN_PROJECT_CXZS                                            @"CXZS" // 查询助手
#define STR_MARKID_HOME_MAIN_PROJECT_LHGS                                            @"LHGS" // 六合高手
#define STR_MARKID_HOME_MAIN_PROJECT_TJZX                                            @"TJZX" // 资讯统计
#define STR_MARKID_HOME_MAIN_PROJECT_ZLDQ                                            @"ZLDQ" // 资料大全
#define STR_MARKID_HOME_MAIN_PROJECT_BWLT                                            @"BWLT" // 比武擂台
#define STR_MARKID_HOME_MAIN_PROJECT_YMCC                                            @"YMCC" // 幽默猜猜
#define STR_MARKID_HOME_MAIN_PROJECT_XGGP                                            @"XGGP" // 香港挂牌
#define STR_MARKID_HOME_MAIN_PROJECT_SBXO                                            @"SBX"  // 四不像


#pragma mark - 字符标识常量 - 寻宝 - 工具宝箱
#define STR_MARKID_DISCOVER_MAIN_LIAN_REN                                            @"[MARKID_恋人特码]"
#define STR_MARKID_DISCOVER_MAIN_SHENG_XIAO                                          @"[MARKID_生肖卡牌]"
#define STR_MARKID_DISCOVER_MAIN_YAO_YI_YAO                                          @"[MARKID_摇一摇]"
#define STR_MARKID_DISCOVER_MAIN_XUANJIJINNANG                                       @"[MARKID_玄机锦囊]"
#define STR_MARKID_DISCOVER_MAIN_XINGYUNYAOJIANG                                     @"[MARKID_幸运摇奖]"
#define STR_MARKID_DISCOVER_MAIN_BOXIAOZHUANPAN                                      @"[MARKID_波肖转盘]"
#define STR_MARKID_DISCOVER_MAIN_JIAOZHURIQI                                         @"[MARKID_搅珠日期]"
#define STR_MARKID_DISCOVER_MAIN_TIANJICESUAN                                        @"[MARKID_天机测算]"
#define STR_MARKID_DISCOVER_MAIN_TIAOMAZHUSHOU                                       @"[MARKID_挑码助手]"


#pragma mark - 字符串常量 - 我的 - 个人中心
#define STR_MARKID_MOREINFO_MINE_CENTER_INVITATION                                   @"[MARKID_个人中心_我的帖子]"
#define STR_MARKID_MOREINFO_MINE_CENTER_ATTENTION                                    @"[MARKID_个人中心_我的关注]"
#define STR_MARKID_MOREINFO_MINE_CENTER_MESSAGEINFO                                  @"[MARKID_个人中心_站内消息]"
#pragma mark - 字符串常量 - 我的 - 个人信息
#define STR_MARKID_MOREINFO_MINE_CENTER_SETTING_PHONE                                @"[MARKID_个人中心_手机号码]"
#define STR_MARKID_MOREINFO_MINE_CENTER_SETTING_PASSWORD                             @"[MARKID_个人中心_修改密码]"
#define STR_MARKID_MOREINFO_MINE_CENTER_SETTING_LOGIN_OUT                            @"[MARKID_个人中心_个人信息]"


#pragma mark - 字符串常量 - 我的 - 更多
#define STR_MARKID_MOREINFO_SETTING_ABOUT_SOFTWARE                                   @"[MARKID_更多_关于应用]"
#define STR_MARKID_MOREINFO_SETTING_FREE_DECLARATION                                 @"[MARKID_更多_免费声明]"
#define STR_MARKID_MOREINFO_SETTING_SUGGESTION                                       @"[MARKID_更多_意见反馈]"
#define STR_MARKID_MOREINFO_SETTING_CONTACT_US                                       @"[MARKID_更多_联系我们]"
#define STR_MARKID_MOREINFO_SETTING_SOFTWARE_INTRO                                   @"[MARKID_更多_应用简介]"
#define STR_MARKID_MOREINFO_SETTING_ABOUT_US                                         @"[MARKID_更多_关于我们]"
#define STR_MARKID_MOREINFO_SETTING_SHARE_SMSC                                       @"[MARKID_更多_短信分享]"
#define STR_MARKID_MOREINFO_SETTING_SHARE_SOFTWARE                                   @"[MARKID_更多_软件分享]"



#pragma mark - 字符标识常量 - 开奖结果
#define SHENGXIAO_PLAY_CLASS_SHU                            @"鼠"
#define SHENGXIAO_PLAY_CLASS_NIU                            @"牛"
#define SHENGXIAO_PLAY_CLASS_HU                             @"虎"
#define SHENGXIAO_PLAY_CLASS_TU                             @"兔"
#define SHENGXIAO_PLAY_CLASS_LONG                           @"龙"
#define SHENGXIAO_PLAY_CLASS_SE                             @"蛇"
#define SHENGXIAO_PLAY_CLASS_MA                             @"马"
#define SHENGXIAO_PLAY_CLASS_YANG                           @"羊"
#define SHENGXIAO_PLAY_CLASS_HOU                            @"猴"
#define SHENGXIAO_PLAY_CLASS_JI                             @"鸡"
#define SHENGXIAO_PLAY_CLASS_GOU                            @"狗"
#define SHENGXIAO_PLAY_CLASS_ZHU                            @"猪"
#define SHENGXIAO_PLAY_CLASS_LIU_HE_CAI_ARRAY               @[ SHENGXIAO_PLAY_CLASS_SHU, SHENGXIAO_PLAY_CLASS_NIU,\
                                                               SHENGXIAO_PLAY_CLASS_HU,  SHENGXIAO_PLAY_CLASS_TU,\
                                                               SHENGXIAO_PLAY_CLASS_LONG, SHENGXIAO_PLAY_CLASS_SE,\
                                                               SHENGXIAO_PLAY_CLASS_MA, SHENGXIAO_PLAY_CLASS_YANG,\
                                                               SHENGXIAO_PLAY_CLASS_HOU, SHENGXIAO_PLAY_CLASS_JI,\
                                                               SHENGXIAO_PLAY_CLASS_GOU, SHENGXIAO_PLAY_CLASS_ZHU ]


#pragma mark - 彩票颜色 - 六合彩
#define IMAGE_LIU_HE_CAI_RED                     ICON_OPEN_RESULT_NUM_RED
#define IMAGE_LIU_HE_CAI_BLUE                    ICON_OPEN_RESULT_NUM_BLUE
#define IMAGE_LIU_HE_CAI_GREEN                   ICON_OPEN_RESULT_NUM_GREEN
#define IMAGE_LIU_HE_CAI_ARRAY                   @[ IMAGE_LIU_HE_CAI_RED,    IMAGE_LIU_HE_CAI_RED,\
                                                    IMAGE_LIU_HE_CAI_BLUE,   IMAGE_LIU_HE_CAI_BLUE,\
                                                    IMAGE_LIU_HE_CAI_GREEN,  IMAGE_LIU_HE_CAI_GREEN,\
                                                    IMAGE_LIU_HE_CAI_RED,    IMAGE_LIU_HE_CAI_RED,\
                                                    IMAGE_LIU_HE_CAI_BLUE,   IMAGE_LIU_HE_CAI_BLUE,\
                                                    IMAGE_LIU_HE_CAI_GREEN,  IMAGE_LIU_HE_CAI_RED,\
                                                    IMAGE_LIU_HE_CAI_RED,    IMAGE_LIU_HE_CAI_BLUE,\
                                                    IMAGE_LIU_HE_CAI_BLUE,   IMAGE_LIU_HE_CAI_GREEN,\
                                                    IMAGE_LIU_HE_CAI_GREEN,  IMAGE_LIU_HE_CAI_RED,\
                                                    IMAGE_LIU_HE_CAI_RED,    IMAGE_LIU_HE_CAI_BLUE,\
                                                    IMAGE_LIU_HE_CAI_GREEN,  IMAGE_LIU_HE_CAI_GREEN,\
                                                    IMAGE_LIU_HE_CAI_RED,    IMAGE_LIU_HE_CAI_RED,\
                                                    IMAGE_LIU_HE_CAI_BLUE,   IMAGE_LIU_HE_CAI_BLUE,\
                                                    IMAGE_LIU_HE_CAI_GREEN,  IMAGE_LIU_HE_CAI_GREEN,\
                                                    IMAGE_LIU_HE_CAI_RED,    IMAGE_LIU_HE_CAI_RED,\
                                                    IMAGE_LIU_HE_CAI_BLUE,   IMAGE_LIU_HE_CAI_GREEN,\
                                                    IMAGE_LIU_HE_CAI_GREEN,  IMAGE_LIU_HE_CAI_RED,\
                                                    IMAGE_LIU_HE_CAI_RED,    IMAGE_LIU_HE_CAI_BLUE,\
                                                    IMAGE_LIU_HE_CAI_BLUE,   IMAGE_LIU_HE_CAI_GREEN,\
                                                    IMAGE_LIU_HE_CAI_GREEN,  IMAGE_LIU_HE_CAI_RED,\
                                                    IMAGE_LIU_HE_CAI_BLUE,   IMAGE_LIU_HE_CAI_BLUE,\
                                                    IMAGE_LIU_HE_CAI_GREEN,  IMAGE_LIU_HE_CAI_GREEN,\
                                                    IMAGE_LIU_HE_CAI_RED,    IMAGE_LIU_HE_CAI_RED,\
                                                    IMAGE_LIU_HE_CAI_BLUE,   IMAGE_LIU_HE_CAI_BLUE,\
                                                    IMAGE_LIU_HE_CAI_GREEN ]


#endif /* _CFC_STRING_MACRO_H_ */

