
#import <UIKit/UIKit.h>

@interface UIColor (Extension)
+(UIColor*)colorWithHexString:(NSString*)stringToConvert;
@end
