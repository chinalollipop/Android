
#import <Foundation/Foundation.h>

@interface NSString (ContainString)

- (BOOL)hasContainString:(NSString*)subString;

@end
