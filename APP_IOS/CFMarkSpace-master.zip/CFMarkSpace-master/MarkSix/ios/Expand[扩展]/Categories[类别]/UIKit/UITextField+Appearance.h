
#import <UIKit/UIKit.h>

@interface UITextField (Appearance)

@property (nonatomic, strong) UIColor *placeholderColor;
@property (nonatomic, strong) UIFont *placeholderFont;

@end
