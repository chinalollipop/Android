
#import <UIKit/UIKit.h>

@interface UIImage (Filter)

- (UIImage *)filterGlaussianBlurWithRadius:(CGFloat)radius;

@end
