

#import "CFCBaseBatchRequest.h"

@implementation CFCBaseBatchRequest

@end
