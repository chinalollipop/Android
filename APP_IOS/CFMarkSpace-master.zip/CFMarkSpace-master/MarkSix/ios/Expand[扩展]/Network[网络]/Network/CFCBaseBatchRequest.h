
#if __has_include(<YTKNetwork/YTKNetwork.h>)
#import <YTKNetwork/YTKBatchRequest.h>
#else
#import "YTKBatchRequest.h"
#endif

@interface CFCBaseBatchRequest : YTKBatchRequest

@end
