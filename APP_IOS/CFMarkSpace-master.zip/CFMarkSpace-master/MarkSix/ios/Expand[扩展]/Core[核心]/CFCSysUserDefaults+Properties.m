
#import "CFCSysUserDefaults+Properties.h"

@implementation CFCSysUserDefaults (Properties)

@dynamic token;
@dynamic userId;
@dynamic userName;
@dynamic nickName;
@dynamic appversion;

@dynamic loginUserAccount;
@dynamic loginUserPassword;
@dynamic isShowAppSharePage;

@dynamic loginStatus;

@dynamic lianRenTeMaIssue;
@dynamic lianRenTeMaResult;

@dynamic shengXiaoKaIssue;
@dynamic shengXiaoKaResult;

@dynamic yaoYiYaoIssue;
@dynamic yaoYiYaoResult;

@dynamic boXiaoZhuanPanIssue;
@dynamic boXiaoZhuanPanResult;

@dynamic tianJiCeSuanIssue;
@dynamic tianJiCeSuanResult;


- (NSDictionary *)setupDefaults
{
    // 设置默认值
    return @{
                @"token": @"",
                @"userId": @"0",
                @"userName": @"user_name_default",
                @"nickName": @"nick_name_default",
                @"appversion": @"v 1.0.0",
                
                @"loginUserAccount": @"",
                @"loginUserPassword": @"",
                @"isShowAppSharePage": [NSNumber numberWithBool:NO],
                
                @"lianRenTeMaIssue": @"0",
                @"lianRenTeMaResult": @"",
                
                @"shengXiaoKaIssue": @"0",
                @"shengXiaoKaResult": @"",
                
                @"yaoYiYaoIssue": @"0",
                @"yaoYiYaoResult": @"",
                
                @"boXiaoZhuanPanIssue": @"0",
                @"boXiaoZhuanPanResult": @"",
                
                @"tianJiCeSuanIssue": @"0",
                @"tianJiCeSuanResult": @"",

                @"loginStatus": [NSNumber numberWithBool:NO]
             };
}

- (NSDictionary *)setupDefaultsOfProperties
{
    // 设置默认值
    return @{
             
             };
}

- (NSString *)suitName
{
    // 自定义分类存储文件名称，默认为 Bundle Identifier
    return @"cfc.module.devkit.userdefaults";
}

- (NSString *)transformKey:(NSString *)key
{
    // NSUserDefaults 中的键值是与你给的键值一样的，如果你需要加点前缀用以标注，用这个方法 transformKey: 即可
    key = [key stringByReplacingCharactersInRange:NSMakeRange(0,1) withString:[[key substringToIndex:1] uppercaseString]];
    return [NSString stringWithFormat:@"CFCUserDefault%@", key];
}


@end
