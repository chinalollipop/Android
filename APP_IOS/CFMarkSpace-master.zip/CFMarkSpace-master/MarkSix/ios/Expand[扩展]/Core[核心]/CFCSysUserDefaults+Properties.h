
#import "CFCSysUserDefaults.h"


NS_ASSUME_NONNULL_BEGIN


@interface CFCSysUserDefaults (Properties)

@property (nonatomic, weak) NSString *token;                  // 系统Token
@property (nonatomic, weak) NSString *userId;                 // 用户标识
@property (nonatomic, weak) NSString *userName;               // 用户帐号
@property (nonatomic, weak) NSString *nickName;               // 用户昵称
@property (nonatomic, weak) NSString *appversion;             // 系统版本

@property (nonatomic, weak) NSString *loginUserAccount;       // 用户登录帐号
@property (nonatomic, weak) NSString *loginUserPassword;      // 用户登录密码
@property (nonatomic, assign) BOOL isShowAppSharePage;        // 是否已经显示推广页面（悬浮按钮）

@property (nonatomic, assign) BOOL loginStatus;               // 登录状态

@property (nonatomic, weak) NSString *lianRenTeMaIssue;       // 恋人特码期号
@property (nonatomic, weak) NSString *lianRenTeMaResult;      // 恋人特码结果

@property (nonatomic, weak) NSString *shengXiaoKaIssue;       // 生肖卡牌期号
@property (nonatomic, weak) NSString *shengXiaoKaResult;      // 生肖卡牌结果

@property (nonatomic, weak) NSString *yaoYiYaoIssue;          // 摇一摇期号
@property (nonatomic, weak) NSString *yaoYiYaoResult;         // 摇一摇结果

@property (nonatomic, weak) NSString *boXiaoZhuanPanIssue;    // 波肖转盘期号
@property (nonatomic, weak) NSString *boXiaoZhuanPanResult;   // 波肖转盘结果

@property (nonatomic, weak) NSString *tianJiCeSuanIssue;      // 天机测算期号
@property (nonatomic, weak) NSString *tianJiCeSuanResult;     // 天机测算结果



@end


NS_ASSUME_NONNULL_END

