//
// 游戏 - 官网11选5 - 信用模式
//

#import "CFCGW11X5CreditViewController.h"

@interface CFCGW11X5CreditViewController ()

@end

@implementation CFCGW11X5CreditViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
