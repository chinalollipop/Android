//
// 游戏 - 官网分分彩 - 信用模式
//

#import "CFCSSCCreditViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCGWFFCCreditViewController : CFCSSCCreditViewController

@end

NS_ASSUME_NONNULL_END
