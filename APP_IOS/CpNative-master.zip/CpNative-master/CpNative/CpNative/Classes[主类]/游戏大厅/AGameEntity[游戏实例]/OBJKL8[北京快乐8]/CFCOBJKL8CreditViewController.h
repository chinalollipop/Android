//
// 游戏 - 北京快乐8 - 信用模式
//

#import "CFCBJKL8CreditViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCOBJKL8CreditViewController : CFCBJKL8CreditViewController

@end

NS_ASSUME_NONNULL_END
