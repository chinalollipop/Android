//
// 游戏 - 官网五分彩 - 官方模式
//

#import "CFCSSCOfficialViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCGW5FCOfficialViewController : CFCSSCOfficialViewController

@end

NS_ASSUME_NONNULL_END
