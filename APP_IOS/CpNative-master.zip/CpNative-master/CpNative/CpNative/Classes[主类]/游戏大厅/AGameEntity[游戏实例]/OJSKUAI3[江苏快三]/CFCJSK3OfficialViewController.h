//
// 游戏 - 江苏快3 - 官网模式
//

#import "CFCKuai3OfficialViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCJSK3OfficialViewController : CFCKuai3OfficialViewController

@end

NS_ASSUME_NONNULL_END
