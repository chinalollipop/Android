//
// 游戏 - 重庆时时彩 - 官方模式
//

#import "CFCSSCOfficialViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCCQSSCOfficialViewController : CFCSSCOfficialViewController

@end

NS_ASSUME_NONNULL_END
