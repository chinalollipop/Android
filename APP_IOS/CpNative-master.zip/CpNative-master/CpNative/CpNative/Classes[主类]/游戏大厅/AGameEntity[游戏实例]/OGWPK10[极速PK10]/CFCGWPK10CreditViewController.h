//
// 游戏 - 极速PK10 - 信用模式
//

#import "CFCPK10CreditViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCGWPK10CreditViewController : CFCPK10CreditViewController

@end

NS_ASSUME_NONNULL_END
