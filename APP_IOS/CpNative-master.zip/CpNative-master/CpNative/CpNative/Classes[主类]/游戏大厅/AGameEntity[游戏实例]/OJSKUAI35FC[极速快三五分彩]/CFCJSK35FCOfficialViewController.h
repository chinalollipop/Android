//
// 游戏 - 极速快三五分彩 - 官网模式
//

#import "CFCKuai3OfficialViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCJSK35FCOfficialViewController : CFCKuai3OfficialViewController

@end

NS_ASSUME_NONNULL_END
