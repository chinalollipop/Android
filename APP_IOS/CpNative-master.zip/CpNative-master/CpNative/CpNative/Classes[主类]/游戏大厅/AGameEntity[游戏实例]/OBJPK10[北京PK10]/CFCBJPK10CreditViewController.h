//
// 游戏 - 北京PK10 - 信用模式
//

#import "CFCPK10CreditViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCBJPK10CreditViewController : CFCPK10CreditViewController

@end

NS_ASSUME_NONNULL_END
