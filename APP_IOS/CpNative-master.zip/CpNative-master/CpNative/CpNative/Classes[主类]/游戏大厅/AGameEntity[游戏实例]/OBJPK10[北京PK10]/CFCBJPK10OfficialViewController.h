//
// 游戏 - 北京PK10 - 官方模式
//

#import "CFCPK10OfficialViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCBJPK10OfficialViewController : CFCPK10OfficialViewController

@end

NS_ASSUME_NONNULL_END
