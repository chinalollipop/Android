//
// 游戏 - 官网快3分分彩 - 信用模式
//

#import "CFCKuai3CreditViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCGWK3CreditViewController : CFCKuai3CreditViewController

@end

NS_ASSUME_NONNULL_END
