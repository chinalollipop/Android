//
// 游戏 - 重庆时时彩 - 信用模式
//


#import "CFCSSCCreditViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCCQSSCCreditViewController : CFCSSCCreditViewController

@end

NS_ASSUME_NONNULL_END
