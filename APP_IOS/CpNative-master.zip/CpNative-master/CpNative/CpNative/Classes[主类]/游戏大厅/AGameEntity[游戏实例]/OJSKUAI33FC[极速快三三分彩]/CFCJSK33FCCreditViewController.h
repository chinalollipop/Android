//
// 游戏 - 极速快三三分彩 - 信用模式
//

#import "CFCKuai3CreditViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCJSK33FCCreditViewController : CFCKuai3CreditViewController

@end

NS_ASSUME_NONNULL_END
