//
// 游戏 - 官网五分彩 - 信用模式
//

#import "CFCSSCCreditViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCGW5FCCreditViewController : CFCSSCCreditViewController

@end

NS_ASSUME_NONNULL_END
