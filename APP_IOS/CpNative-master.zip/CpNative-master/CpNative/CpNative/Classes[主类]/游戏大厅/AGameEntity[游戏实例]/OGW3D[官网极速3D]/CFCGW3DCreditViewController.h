//
// 游戏 - 官网极速3D - 信用模式
//

#import "CFCJS3DCreditViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCGW3DCreditViewController : CFCJS3DCreditViewController

@end

NS_ASSUME_NONNULL_END
