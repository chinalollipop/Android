//
// 游戏 - 北京PK10 - 官方模式
//

#import "CFCBJPK10OfficialViewController.h"

@interface CFCBJPK10OfficialViewController ()

@end

@implementation CFCBJPK10OfficialViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
