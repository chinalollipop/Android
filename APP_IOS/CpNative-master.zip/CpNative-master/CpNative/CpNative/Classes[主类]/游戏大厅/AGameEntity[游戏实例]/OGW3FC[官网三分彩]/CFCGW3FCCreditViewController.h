//
// 游戏 - 官网三分彩 - 信用模式
//

#import "CFCSSCCreditViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCGW3FCCreditViewController : CFCSSCCreditViewController

@end

NS_ASSUME_NONNULL_END
