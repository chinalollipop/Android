//
// 游戏 - 安徽快3 - 信用模式
//

#import "CFCKuai3CreditViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCAHK3CreditViewController : CFCKuai3CreditViewController

@end

NS_ASSUME_NONNULL_END
