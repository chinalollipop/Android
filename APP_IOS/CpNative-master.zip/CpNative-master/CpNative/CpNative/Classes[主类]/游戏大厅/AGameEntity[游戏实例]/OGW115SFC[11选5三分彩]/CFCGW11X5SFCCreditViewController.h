//
// 游戏 - 11选5三分彩 - 信用模式
//

#import "CFC11X5CreditViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCGW11X5SFCCreditViewController : CFC11X5CreditViewController

@end

NS_ASSUME_NONNULL_END
