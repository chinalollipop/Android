//
// 游戏 - 幸运飞艇 - 官方模式
//

#import "CFCPK10OfficialViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCXYFTOfficialViewController : CFCPK10OfficialViewController

@end

NS_ASSUME_NONNULL_END
