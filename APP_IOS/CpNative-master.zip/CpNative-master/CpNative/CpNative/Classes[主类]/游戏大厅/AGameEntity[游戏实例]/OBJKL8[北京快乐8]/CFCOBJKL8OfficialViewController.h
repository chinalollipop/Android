//
// 游戏 - 北京快乐8 - 官网模式
//

#import "CFCBJKL8OfficialViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCOBJKL8OfficialViewController : CFCBJKL8OfficialViewController

@end

NS_ASSUME_NONNULL_END
