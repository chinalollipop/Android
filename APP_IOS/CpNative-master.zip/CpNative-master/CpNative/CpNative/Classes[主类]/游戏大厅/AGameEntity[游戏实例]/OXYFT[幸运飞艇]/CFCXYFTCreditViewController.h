//
// 游戏 - 幸运飞艇 - 信用模式
//

#import "CFCPK10CreditViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCXYFTCreditViewController : CFCPK10CreditViewController

@end

NS_ASSUME_NONNULL_END
