//
// 游戏 - 极速PK10 - 官方模式
//

#import "CFCGWPK10OfficialViewController.h"

@interface CFCGWPK10OfficialViewController ()

@end

@implementation CFCGWPK10OfficialViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
