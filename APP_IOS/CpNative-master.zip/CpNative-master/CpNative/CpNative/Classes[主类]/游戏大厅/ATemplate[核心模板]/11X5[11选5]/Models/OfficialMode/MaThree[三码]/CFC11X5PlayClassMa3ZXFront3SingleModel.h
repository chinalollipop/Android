//
// 游戏 - 投注区 - 官方模式 - 11选5 - 三码 - 直选 - 前三直选单式
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFC11X5PlayClassMa3ZXFront3SingleModel : CFCGameBetPlayClassModel

+ (NSMutableArray *) buildingDataModlesForSection1;

@end


@interface CFC11X5PlayClassMa3ZXFront3SingleSectionModel : CFCGameBetPlayClassSectionModel

+ (NSMutableArray *) buildingDataModles;

@end

NS_ASSUME_NONNULL_END
