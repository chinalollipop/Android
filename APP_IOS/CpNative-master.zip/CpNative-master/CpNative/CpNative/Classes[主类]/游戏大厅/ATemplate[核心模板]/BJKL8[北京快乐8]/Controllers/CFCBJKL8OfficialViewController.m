//
// 游戏 - 投注区 - 官网模式 - 北京快乐8
//

#import "CFCBJKL8OfficialViewController.h"

@interface CFCBJKL8OfficialViewController ()

@end

@implementation CFCBJKL8OfficialViewController


#pragma mark -
#pragma mark 开奖结果 - 开奖类型
- (CFCGameBetDrawResultItemType)getDrawResultItemType
{
    return CFCGameBetDrawResultItemTypeOfficial06;
}


#pragma mark -
#pragma mark 玩法下标 - 返回默认选中的玩法标识
- (NSString *)getSelectedPlayCodeOfPlayClass
{
    return GAME_PLAY_CLASS_CODE_BJKL8_HEZHI_HZ_DANSHUANG;
}


#pragma mark -
#pragma mark 视图生命周期（初始化静态标签数据）
- (BOOL)viewDidLoadWithDataSource
{
    // 玩法标识
    self.tabClassCodes = @[
                           // 和值 -> 和值
                           GAME_PLAY_CLASS_CODE_BJKL8_HEZHI_HZ_DANSHUANG,
                           GAME_PLAY_CLASS_CODE_BJKL8_HEZHI_HZ_DAXIAO810,
                           GAME_PLAY_CLASS_CODE_BJKL8_HEZHI_HZ_WUXING,
                           
                           // 奇偶和 -> 奇偶和
                           GAME_PLAY_CLASS_CODE_BJKL8_JIOUHE_JIOUHE_MULTIPLE,
                           
                           // 上中下 -> 上中下
                           GAME_PLAY_CLASS_CODE_BJKL8_SHANGZHONGXIA_SZX_MULTIPLE,
                           
                           // 任选一 -> 任选一
                           GAME_PLAY_CLASS_CODE_BJKL8_RENXUAN1_RENXUAN1_MULTIPLE,
                           
                           // 任选二 -> 任选二
                           GAME_PLAY_CLASS_CODE_BJKL8_RENXUAN2_RENXUAN2_MULTIPLE,
                           
                           // 任选三 -> 任选三
                           GAME_PLAY_CLASS_CODE_BJKL8_RENXUAN3_RENXUAN3_MULTIPLE,
                           
                           // 任选四 -> 任选四
                           GAME_PLAY_CLASS_CODE_BJKL8_RENXUAN4_RENXUAN4_MULTIPLE,
                           
                           // 任选五 -> 任选五
                           GAME_PLAY_CLASS_CODE_BJKL8_RENXUAN5_RENXUAN5_MULTIPLE,
                           
                           // 任选六 -> 任选六
                           GAME_PLAY_CLASS_CODE_BJKL8_RENXUAN6_RENXUAN6_MULTIPLE,
                           
                           // 任选七 -> 任选七
                           GAME_PLAY_CLASS_CODE_BJKL8_RENXUAN7_RENXUAN7_MULTIPLE,
                           
                           ];
    
    // 玩法标题
    self.tabClassTitles = @[
                            // 和值 -> 和值
                            GAME_PLAY_CLASS_NAME_BJKL8_HEZHI_HZ_DANSHUANG,
                            GAME_PLAY_CLASS_NAME_BJKL8_HEZHI_HZ_DAXIAO810,
                            GAME_PLAY_CLASS_NAME_BJKL8_HEZHI_HZ_WUXING,
                            
                            // 奇偶和 -> 奇偶和
                            GAME_PLAY_CLASS_NAME_BJKL8_JIOUHE_JIOUHE_MULTIPLE,
                            
                            // 上中下 -> 上中下
                            GAME_PLAY_CLASS_NAME_BJKL8_SHANGZHONGXIA_SZX_MULTIPLE,
                            
                            // 任选一 -> 任选一
                            GAME_PLAY_CLASS_NAME_BJKL8_RENXUAN1_RENXUAN1_MULTIPLE,
                            
                            // 任选二 -> 任选二
                            GAME_PLAY_CLASS_NAME_BJKL8_RENXUAN2_RENXUAN2_MULTIPLE,
                            
                            // 任选三 -> 任选三
                            GAME_PLAY_CLASS_NAME_BJKL8_RENXUAN3_RENXUAN3_MULTIPLE,
                            
                            // 任选四 -> 任选四
                            GAME_PLAY_CLASS_NAME_BJKL8_RENXUAN4_RENXUAN4_MULTIPLE,
                            
                            // 任选五 -> 任选五
                            GAME_PLAY_CLASS_NAME_BJKL8_RENXUAN5_RENXUAN5_MULTIPLE,
                            
                            // 任选六 -> 任选六
                            GAME_PLAY_CLASS_NAME_BJKL8_RENXUAN6_RENXUAN6_MULTIPLE,
                            
                            // 任选七 -> 任选七
                            GAME_PLAY_CLASS_NAME_BJKL8_RENXUAN7_RENXUAN7_MULTIPLE,
                            
                            ];
    // 控件器名称
    self.tabClassViewControllers = @[
                                     // 和值 -> 和值
                                     @"CFCBJKL8PlayClassDanShuangViewController",
                                     @"CFCBJKL8PlayClassDaXiao810ViewController",
                                     @"CFCBJKL8PlayClassWuXingViewController",
                                     
                                     // 奇偶和 -> 奇偶和
                                     @"CFCBJKL8PlayClassJiOuHeViewController",
                                     
                                     // 上中下 -> 上中下
                                     @"CFCBJKL8PlayClassShangZhongXiaViewController",
                                     
                                     // 任选一 -> 任选一
                                     @"CFCBJKL8PlayClassRenXuan01ViewController",
                                     
                                     // 任选二 -> 任选二
                                     @"CFCBJKL8PlayClassRenXuan02ViewController",
                                     
                                     // 任选三 -> 任选三
                                     @"CFCBJKL8PlayClassRenXuan03ViewController",
                                     
                                     // 任选四 -> 任选四
                                     @"CFCBJKL8PlayClassRenXuan04ViewController",
                                     
                                     // 任选五 -> 任选五
                                     @"CFCBJKL8PlayClassRenXuan05ViewController",
                                     
                                     // 任选六 -> 任选六
                                     @"CFCBJKL8PlayClassRenXuan06ViewController",
                                     
                                     // 任选七 -> 任选七
                                     @"CFCBJKL8PlayClassRenXuan07ViewController",
                                     
                                     ];
    
    return YES;
}


@end

