//
// 游戏 - 投注区 - 官方模式 - 北京快乐8 - 任选五 - 任选五 - 复式
//

#import "CFCGameBetPlayClassModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCBJKL8PlayClassRenXuan05Model : CFCGameBetPlayClassModel

+ (NSMutableArray *) buildingDataModlesForSection1;

+ (NSMutableArray *) buildingDataModlesForSection2;

@end


@interface CFCBJKL8PlayClassRenXuan05SectionModel : CFCGameBetPlayClassSectionModel

+ (NSMutableArray *) buildingDataModles;

@end

NS_ASSUME_NONNULL_END
