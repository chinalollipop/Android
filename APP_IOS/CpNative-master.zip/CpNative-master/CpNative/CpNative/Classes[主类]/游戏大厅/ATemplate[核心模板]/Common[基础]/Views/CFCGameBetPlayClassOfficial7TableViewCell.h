//
//  游戏 - 官方玩法 -> 投注项目，无操作按钮 -> 如：北京PK拾、11选5官方玩法中<单式、混合组选>
//
//  说明：此类以 UITableViewCell 实现。如果不能满足你的要求，请另外实现。
//

#import <UIKit/UIKit.h>
@class CFCGameBetPlayClassModel, CFCGameBetPlayClassSectionModel, CFCGameBetPlayClassCheckButton, CFCTextView;
@protocol CFCGameBetPlayClassTableViewCellProtocol;


NS_ASSUME_NONNULL_BEGIN


UIKIT_EXTERN NSString * const CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_7_TABLE_VIEW_CELL;


@protocol CFCGameBetPlayClassOfficial7TableViewCellProtocol <CFCGameBetPlayClassTableViewCellProtocol>
@required
- (void)doPlayClassCheckButtonAction:(CFCGameBetPlayClassCheckButton *)button;
@end


@protocol CFCGameBetPlayClassOfficial7TableViewCellDelegate <NSObject>
@required
- (NSString *)itemNameOfMaxLengthInDataOfSectionModelArray:(CFCGameBetPlayClassModel *)model;
- (NSString *)itemOddsOfMaxLengthInDataOfSectionModelArray:(CFCGameBetPlayClassModel *)model;
@optional
- (void)didSelectPlayClassOfficial7TableViewCellRowAtIndexPath:(NSIndexPath *)indexPath
                                                    itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels
                                                    itemIndexs:(NSArray<NSNumber *> *)itemIndexs;
@end


@interface CFCGameBetPlayClassOfficial7TableViewCell : UITableViewCell <CFCGameBetPlayClassOfficial7TableViewCellProtocol>
/**
 * 根容器组件
 */
@property (nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonatomic, strong) UIView *publicContainerView;
/**
 * 输入控件
 */
@property (nonatomic, strong) CFCTextView *bettingTextView;
/**
 * 操作按钮
 */
@property (nonatomic, strong) NSMutableArray<CFCGameBetPlayClassCheckButton *> *operationButtonArray;
/**
 * 数据下标
 */
@property (nonatomic, strong) NSIndexPath *indexPath;
/**
 * 数据模型
 */
@property (nonatomic, strong) CFCGameBetPlayClassSectionModel *model;
/**
 * 表格代理
 */
@property (nonatomic, weak) id<CFCGameBetPlayClassOfficial7TableViewCellDelegate> delegate;


/**
 * 操作事件 - 操作按钮
 */
- (void)doPlayClassCheckButtonAction:(CFCGameBetPlayClassCheckButton *)button;

@end


NS_ASSUME_NONNULL_END
