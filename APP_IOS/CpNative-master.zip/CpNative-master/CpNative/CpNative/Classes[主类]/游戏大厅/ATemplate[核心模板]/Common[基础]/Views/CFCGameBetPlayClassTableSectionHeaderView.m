
#import "CFCGameBetPlayClassTableSectionHeaderView.h"


@interface CFCGameBetPlayClassTableSectionHeaderView ()

// 根容器组件
@property (nonnull, nonatomic, strong) UIView *rootContainerView;

// 标题
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, copy) NSString *title;

// 第N个Section
@property (nonatomic, assign) NSInteger tableSection;

@end


@implementation CFCGameBetPlayClassTableSectionHeaderView

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title tableSecion:(NSInteger)tableSection
{
    self = [super initWithFrame:frame];
    if (self) {
        _title = title;
        _tableSection = tableSection;
        [self createView];
        [self setViewAtuoLayout];
    }
    return self;
}

- (void)createView
{ 
    // 根容器
    self.rootContainerView = [[UIView alloc] init];
    [self addSubview:self.rootContainerView];
    
    // 标题
    self.titleLabel = [[UILabel alloc] init];
    [self.titleLabel setText:self.title];
    [self.titleLabel setTextAlignment:NSTextAlignmentCenter];
    [self.titleLabel setFont:GROUP_CREDIT_FONT_GAME_PLAY_ITEM_TITLE];
    [self.titleLabel setTextColor:GROUP_CREDIT_COLOR_GAME_PLAY_ITEM_TITLE];
    [self.rootContainerView addSubview:self.titleLabel];
}

- (void)setViewAtuoLayout
{
    CGFloat magin = CFC_AUTOSIZING_MARGIN(MARGIN);
    
    // 根容器组件
    [self.rootContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(@0);
    }];
    
    // 分组标题
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.mas_centerX);
        make.bottom.equalTo(self.mas_bottom).offset(-magin*0.5f);
    }];
}


@end



