
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCGameSliderTimer : NSObject

/**
 *  定时器单例
 */
+ (instancetype)sharedGameSliderTimer;

/**
 *  每秒走一次，回调block
 */
- (void)countDownWithBlock:(void (^)(void))block timer:(CGFloat)second;

/**
 *  销毁定时器
 */
- (void)destoryTimer;

@end

NS_ASSUME_NONNULL_END
