//
// 游戏 - 开奖结果 - 北京快乐8
//

#import "CFCGameBetDrawResultModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCBJKL8DrawResultModel : CFCGameBetDrawResultModel

/**
 * 开奖结果 - 动态数据 - 头部区域
 */
+ (CFCGameBetDrawResultModel *) buildingDataModleForHeaderArea:(CFCGameBetDrawResultModel *)dataModel
                                                      itemType:(CFCGameBetDrawResultItemType)itemType
                                                        itemId:(NSString *)itemId;
/**
 * 开奖结果 - 动态数据 - 动态表格
 */
+ (NSMutableArray<CFCBJKL8DrawResultModel *> *) buildingDataModles:(NSMutableArray<CFCBJKL8DrawResultModel *> *)dataModels
                                                          itemType:(CFCGameBetDrawResultItemType)itemType
                                                            itemId:(NSString *)itemId;

/**
 * 开奖结果 -工具方法 - 开奖号码
 */
+ (NSArray<NSString *> *)buildingBJKL8WinnerResultNumbers:(NSArray<NSString *> *)winnerNumbers;

@end

NS_ASSUME_NONNULL_END
