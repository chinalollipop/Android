//
// 游戏 - 投注区 - 官方模式 - 11选5 - 三码 - 直选 - 前三直选复式
//

#import "CFCGameBetPlayClassModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFC11X5PlayClassMa3ZXFront3MultipleModel : CFCGameBetPlayClassModel

+ (NSMutableArray *) buildingDataModlesForSection1;

+ (NSMutableArray *) buildingDataModlesForSection2;

+ (NSMutableArray *) buildingDataModlesForSection3;

@end


@interface CFC11X5PlayClassMa3ZXFront3MultipleSectionModel : CFCGameBetPlayClassSectionModel

+ (NSMutableArray *) buildingDataModles;

@end

NS_ASSUME_NONNULL_END
