//
//  游戏 - 每一个具体玩法的基类 - 默认为空
//
//  说明：此类以 UITableViewCell 实现。如果不能满足你的要求，请另外实现。
//

#import <UIKit/UIKit.h>
@class CFCGameBetPlayClassSectionModel;


NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_DEFAULT_TABLE_VIEW_CELL;


@interface CFCGameBetPlayClassDefaultTableViewCell : UITableViewCell

/**
 * 数据下标
 */
@property (nonatomic, strong) NSIndexPath *indexPath;
/**
 * 数据模型
 */
@property (nonatomic, strong) CFCGameBetPlayClassSectionModel *model;


@end

NS_ASSUME_NONNULL_END
