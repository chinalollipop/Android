//
//  游戏 - 信用玩法 -> 投注项目，常规 -> 如：时时彩信用玩法中<双面、跨度>
//
//  说明：此类以 UICollectionView 实现。如果不能满足你的要求，请另外实现。
//

#import <UIKit/UIKit.h>
@class CFCGameBetPlayClassModel, CFCGameBetPlayClassSectionModel;


NS_ASSUME_NONNULL_BEGIN


UIKIT_EXTERN NSString * const CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_CREDIT_1_COLLECTION_VIEW_CELL;


@protocol CFCGameBetPlayClassCollectionViewCellProtocol <NSObject>
@required
- (void)createViewAtuoLayout;
- (void)setModel:(CFCGameBetPlayClassSectionModel *)model;
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture;
+ (CGFloat)heightForCellAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model;
@end

@protocol CFCGameBetPlayClassCredit1CollectionViewCellProtocol <CFCGameBetPlayClassCollectionViewCellProtocol>
@end


@protocol CFCGameBetPlayClassCredit1CollectionViewCellDelegate <NSObject>
@required
- (NSString *)itemNameOfMaxLengthInDataOfSectionModelArray:(CFCGameBetPlayClassModel *)model;
- (NSString *)itemOddsOfMaxLengthInDataOfSectionModelArray:(CFCGameBetPlayClassModel *)model;
@optional
- (void)didSelectPlayClassCredit1CollectionViewCellRowAtIndexPath:(NSIndexPath *)indexPath
                                                       itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels
                                                       itemIndexs:(NSArray<NSNumber *> *)itemIndexs;
@end


@interface CFCGameBetPlayClassCredit1CollectionViewCell : UICollectionViewCell <CFCGameBetPlayClassCredit1CollectionViewCellProtocol>

/**
 * 数据下标
 */
@property (nonatomic, strong) NSIndexPath *indexPath;
/**
 * 数据模型
 */
@property (nonatomic, strong) CFCGameBetPlayClassModel *model;
/**
 * 表格代理
 */
@property (nonatomic, weak) id<CFCGameBetPlayClassCredit1CollectionViewCellDelegate> delegate;


/**
 * 操作事件 - 投注按钮
 */
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture;
/**
 * 投注表格 - 表格行高
 */
+ (CGFloat)heightForCellAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model;


@end

NS_ASSUME_NONNULL_END

