

#import <UIKit/UIKit.h>

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_COLLECTION_SECTION_NULL_HEADER;

@interface CFCGameBetPlayClassCollectionSectionNULLHeaderView : UICollectionReusableView

@end
