

#import <UIKit/UIKit.h>

typedef void (^CFCCountTimerCompleteBlock)(void);

typedef NS_ENUM(NSInteger, CFCCountTimerVerticalAlignment) {
    CFCCountTimerVerticalAlignmentTop,
    CFCCountTimerVerticalAlignmentCenter,
    CFCCountTimerVerticalAlignmentBottom
};

@protocol CFCCountTimerViewDelegate <NSObject>
@optional
- (void)doAfterCountDownTimerComplete;
@end

@interface CFCCountTimerVerticallyAlignedLabel : UILabel
@property (nonatomic, assign) CFCCountTimerVerticalAlignment verticalAlignment;
@end

@interface CFCCountTimerView : UIView
@property (nonatomic, strong) NSDate *finishDate;
@property (nonatomic, strong) UIFont *textFont;
@property (nonatomic, strong) UIColor *textColor;
@property (nonatomic, strong) UIFont *colonFont;
@property (nonatomic, strong) UIColor *colonColor;
@property (nonatomic, strong) UIColor *textBackColor;
@property (nonatomic, weak) id<CFCCountTimerViewDelegate> delegate;
@property (nonatomic, copy) CFCCountTimerCompleteBlock countDownTimerCompleteBlock;

- (void)setFinishDate:(NSDate *)finishDate
         andBeginDate:(NSDate *)finishDate
               gameId:(NSString *)gameId
             gameName:(NSString *)gameName
       gameIdentifier:(NSString *)gameIdentifier;

- (void)timer_cancel;

@end
