//
//  游戏 - 信用玩法 -> 投注项目，常规 -> 如：时时彩信用玩法中<双面、跨度>
//
//  说明：此类以 UICollectionView 实现。如果不能满足你的要求，请另外实现。
//

#import "CFCGameBetPlayClassCredit1CollectionViewCell.h"
#import "CFCGameBetPlayClassModel.h"


// Cell Identifier
NSString * const CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_CREDIT_1_COLLECTION_VIEW_CELL = @"CFCGameBetPlayClassCredit1CollectionViewCellIdentifier";


@interface CFCGameBetPlayClassCredit1CollectionViewCell ()
/**
 * 根容器组件
 */
@property (nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonatomic, strong) UIView *publicContainerView;
/**
 * 标题控件
 */
@property (nonnull, nonatomic, strong) UILabel *nameLabel;
/**
 * 赔率控件
 */
@property (nonnull, nonatomic, strong) UILabel *oddsLabel;

@end


@implementation CFCGameBetPlayClassCredit1CollectionViewCell


-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self) {
        [self createViewAtuoLayout];
    }
    return self;
}

#pragma mark 创建子控件
- (void) createViewAtuoLayout
{
    // 根容器
    UIView *rootContainerView = ({
        UIView *view = [[UIView alloc] init];
        [self.contentView insertSubview:view atIndex:0];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@0.0f);
            make.top.equalTo(@0.0f);
            make.right.equalTo(@0.0f);
            make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
        }];
        
        view;
    });
    self.rootContainerView = rootContainerView;
    self.rootContainerView.mas_key = @"rootContainerView";
    
    // 公共容器
    UIView *publicContainerView = ({
        UIView *view = [[UIView alloc] init];
        [view setBackgroundColor:COLOR_GAME_BET_MAINAREA_BACKGROUND_DEFAULT];
        [rootContainerView addSubview:view];
        
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressPublicItemView:)];
        tapGesture.numberOfTapsRequired = 1;
        tapGesture.numberOfTouchesRequired = 1;
        [view addGestureRecognizer:tapGesture];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(rootContainerView.mas_left).offset(0.0f);
            make.top.equalTo(rootContainerView.mas_top).offset(0.0f);
            make.right.equalTo(rootContainerView.mas_right).offset(0.0f);
            make.bottom.equalTo(rootContainerView.mas_bottom).offset(0.0f);
        }];
        
        view;
    });
    self.publicContainerView = publicContainerView;
    self.publicContainerView.mas_key = @"publicContainerView";
    
    // 名称控件
    UILabel *nameLabel = ({
        UILabel *label = [UILabel new];
        [label setText:STR_APP_TEXT_PLACEHOLDER];
        [label setTextAlignment:NSTextAlignmentCenter];
        [label setLineBreakMode:NSLineBreakByClipping];
        [publicContainerView addSubview:label];
        
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(publicContainerView.mas_centerY);
        }];
        
        label;
    });
    self.nameLabel = nameLabel;
    self.nameLabel.mas_key = @"nameLabel";
    
    // 赔率控件
    UILabel *oddsLabel = ({
        UILabel *label = [UILabel new];
        [label setText:STR_APP_TEXT_PLACEHOLDER];
        [label setTextAlignment:NSTextAlignmentCenter];
        [label setLineBreakMode:NSLineBreakByClipping];
        [publicContainerView addSubview:label];
        
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(nameLabel.mas_right);
        }];
        
        label;
    });
    self.oddsLabel = oddsLabel;
    self.oddsLabel.mas_key = @"oddsLabel";
    
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCGameBetPlayClassModel *)model
{
    // 类型安全检查
    if (![model isKindOfClass:[CFCGameBetPlayClassModel class]]) {
        return;
    }
    
    // 数据赋值
    _model = (CFCGameBetPlayClassModel *)model;
    
    //
    CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
    
    // 字体颜色
    UIColor *backgroundColor = _model.isSelected ? GAME_PLAY_ITEM_COLOR_BACKGROUND_SELECT : GAME_PLAY_ITEM_COLOR_BACKGROUND_NORMAL;
    UIColor *nameColor = _model.isSelected ? _model.nameSelectColor : _model.nameNormalColor;
    UIColor *oddsColor = _model.isSelected ? _model.oddsSelectColor : _model.oddsNormalColor;
    UIFont *nameFont = _model.isSelected ? _model.nameSelectFont : _model.nameNormalFont;
    UIFont *oddsFont = _model.isSelected ?  _model.oddsSelectFont : _model.oddsNormalFont;
    
    // 设置内容
    {
        // 标题
        NSString *name = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:_model.name];
        NSDictionary *attributesName = @{ NSFontAttributeName:nameFont, NSForegroundColorAttributeName:nameColor};
        NSAttributedString *attributedNameString = [CFCSysUtil attributedString:@[ [NSString stringWithFormat:@"%@", name] ]
                                                                 attributeArray:@[ attributesName ] ];
        [self.nameLabel setAttributedText:attributedNameString];
        
        // 赔率
        NSString *odds = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:_model.odds];
        NSString *oddsMaxString = [CFCGameUtil getOddsValue:odds radixPoint:GAME_PLAY_MODEL_ODDS_NUMBE_POINT_LEN];
        NSDictionary *attributesOdds = @{ NSFontAttributeName:oddsFont, NSForegroundColorAttributeName:oddsColor};
        NSAttributedString *attributedOddsString = [CFCSysUtil attributedString:@[ [NSString stringWithFormat:@"%@", oddsMaxString] ]
                                                                 attributeArray:@[ attributesOdds]];
        [self.oddsLabel setAttributedText:attributedOddsString];
        
        // 标题 - 宽高
        CGFloat nameWidth = FLOAT_MIN;
        CGFloat nameHeight = FLOAT_MIN;
        if (_model.isShowName) {
            NSString *itemMaxName = model.name;
            CGFloat nameWidthGap =  GAME_PLAY_MODEL_NAME_NUMBE_WIDTH_GAP;
            CGFloat nameHeightGap =  GAME_PLAY_MODEL_NAME_NUMBE_HEIGHT_GAP;
            if (self.delegate && [self.delegate respondsToSelector:@selector(itemNameOfMaxLengthInDataOfSectionModelArray:)]) {
                itemMaxName = [self.delegate itemNameOfMaxLengthInDataOfSectionModelArray:_model];
            }
            nameWidth = [itemMaxName widthWithFont:nameFont constrainedToHeight:self.height] + nameWidthGap;
            nameHeight = [itemMaxName heightWithFont:nameFont constrainedToWidth:self.width] + nameHeightGap;
            if (CFCGameBetPlayClassItemType01 == model.type) { // 项目类型1
                nameWidth = [itemMaxName widthWithFont:nameFont constrainedToHeight:self.height] + nameWidthGap;
                nameHeight = [itemMaxName heightWithFont:nameFont constrainedToWidth:self.width] + nameHeightGap;
            } else if (CFCGameBetPlayClassItemType02 == model.type) { // 项目类型2
                if ([CFCStringMathsUtil validateNumberCharacters:model.name]) {
                    // 数字
                    nameWidth = [GAME_PLAY_MODEL_NAME_NUMBE_WIDTH_STR widthWithFont:nameFont constrainedToHeight:self.height] + nameWidthGap;
                    nameHeight = [GAME_PLAY_MODEL_NAME_NUMBE_WIDTH_STR heightWithFont:nameFont constrainedToWidth:self.width] + nameHeightGap;
                } else {
                    // 汉字
                    nameWidth = [GAME_PLAY_MODEL_NAME_CHINA_WIDTH_STR widthWithFont:nameFont constrainedToHeight:self.height] + GAME_PLAY_MODEL_NAME_CHINA_WIDTH_GAP;
                    nameHeight = [GAME_PLAY_MODEL_NAME_CHINA_WIDTH_STR heightWithFont:nameFont constrainedToWidth:self.width] + GAME_PLAY_MODEL_NAME_CHINA_HEIGHT_GAP;
                }
            }
        }
        
        // 赔率 - 宽高
        CGFloat oddsWidth = FLOAT_MIN;
        CGFloat oddsHeight = FLOAT_MIN;
        if (_model.isShowOdds) {
            NSString *itemMaxOdds = oddsMaxString;
            if (self.delegate && [self.delegate respondsToSelector:@selector(itemOddsOfMaxLengthInDataOfSectionModelArray:)]) {
                itemMaxOdds = [self.delegate itemOddsOfMaxLengthInDataOfSectionModelArray:_model];
            }
            oddsWidth = [itemMaxOdds widthWithFont:oddsFont constrainedToHeight:self.height];
            oddsHeight = [itemMaxOdds heightWithFont:oddsFont constrainedToWidth:self.width];
        }
        
        // 计算位置
        CGFloat itemNameOddsWidth = nameWidth + oddsWidth;
        CGFloat itemNameOddsMagin = ((self.width - itemNameOddsWidth) >= margin) ? margin : (self.width - itemNameOddsWidth);
        CGFloat offsetX = (nameWidth + oddsWidth + itemNameOddsMagin) / 2.0f;
        CGFloat offsetY = (nameHeight - oddsHeight) / 2.0f - 1.0;
        [self.nameLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self.publicContainerView.mas_centerY);
            make.left.equalTo(self.publicContainerView.mas_centerX).offset(-offsetX);
            if ([CFCStringMathsUtil validateNumberCharacters:model.name]) {
                make.width.mas_equalTo(nameWidth);
                make.height.mas_equalTo(nameWidth);
            } else {
                make.width.mas_equalTo(nameWidth);
                make.height.mas_equalTo(nameHeight);
            }
        }];
        [self.oddsLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.nameLabel.mas_right).offset(itemNameOddsMagin*0.8f);
            make.centerY.equalTo(self.publicContainerView.mas_centerY).offset(offsetY);
            make.width.mas_equalTo(oddsWidth);
            make.height.mas_equalTo(oddsHeight);
        }];
        
        // 项目类型1
        if (CFCGameBetPlayClassItemType01 == model.type) {
            [self.nameLabel addCornerRadius:0.0f];
            [self.nameLabel setBackgroundColor:model.nameBackgroundColor];
            [self.nameLabel addBorderWithColor:GAME_PLAY_ITEM_BORDER_COLOR_DEFAULT cornerRadius:0.0f andWidth:0.0f];
            [self.nameLabel.layer setMasksToBounds:YES];
        }
        // 项目类型2
        else if (CFCGameBetPlayClassItemType02 == model.type) {
            NSString *name = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:_model.name];
            NSDictionary *attributesName = @{ NSFontAttributeName:nameFont, NSForegroundColorAttributeName:_model.nameSelectColor};
            NSAttributedString *attributedNameString = [CFCSysUtil attributedString:@[ [NSString stringWithFormat:@"%@", name] ]
                                                                     attributeArray:@[ attributesName ] ];
            [self.nameLabel setAttributedText:attributedNameString];
            [self.nameLabel setBackgroundColor:model.nameBackgroundColor];
            if ([CFCStringMathsUtil validateNumberCharacters:model.name]) {
                [self.nameLabel addBorderWithColor:GAME_PLAY_ITEM_BORDER_COLOR_DEFAULT cornerRadius:nameWidth/2.0f andWidth:0.0f];
            } else {
                [self.nameLabel addBorderWithColor:GAME_PLAY_ITEM_BORDER_COLOR_DEFAULT cornerRadius:nameHeight/2.0f andWidth:0.0f];
            }
            [self.nameLabel.layer setMasksToBounds:YES];
        }
        
        // 背景
        [self.publicContainerView setBackgroundColor:backgroundColor];
    }
    
}

#pragma mark - 表格行高
+ (CGFloat)heightForCellAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model
{
    return GAME_PLAY_COLLECTION_ITEM_HEIGHT_DEFAULT;
}


#pragma mark - 操作事件 - 操作按钮
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture
{
    // 执行代理
    if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectPlayClassCredit1CollectionViewCellRowAtIndexPath:itemModels:itemIndexs:)]) {
        [self.delegate didSelectPlayClassCredit1CollectionViewCellRowAtIndexPath:self.indexPath
                                                                      itemModels:@[self.model]
                                                                      itemIndexs:@[[NSNumber numberWithInteger:self.indexPath.row]] ];
    }
}


@end








