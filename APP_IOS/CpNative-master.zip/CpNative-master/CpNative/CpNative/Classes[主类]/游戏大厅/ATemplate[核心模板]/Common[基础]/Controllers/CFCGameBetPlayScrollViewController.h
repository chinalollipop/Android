//
// 游戏 - 投注区 - 抽象基类
//

#import "CFCGameBetBaseViewController.h"
#import "CFCGameBetDrawResultModel.h"
@class CFCGameBetRecordModel, CFCGameBetDrawResultModel;
@protocol CFCGameBetPlayScrollClassDelegate;
@protocol CFCGameBetPlayScrollClassDataSource;
@protocol CFCGameBetPlayScrollViewControllerProtocol;
@protocol CFCGameBetPlayScrollToGameCoreViewControllerProtocol;
@protocol CFCGameBetPlayScrollToPlayClassViewControllerProtocol;
@protocol CFCGameBetPlayScrollToPlayScrollViewHeaderProtocol;


NS_ASSUME_NONNULL_BEGIN

@protocol CFCGameBetPlayScrollViewControllerProtocol <NSObject>
@required
// 界面元素 - 滑动菜单栏控件高度
- (CGFloat)heightOfScrollSegmentView;
// 界面元素 - 底部区域的视图高度
- (CGFloat)heightOfBottomAreaMainView;
// 界面元素 - 表格头部的视图高度
- (CGFloat)heightOfTableHeaderView;
// 界面元素 - 表格头部信息的视图
- (UIView *)viewOfTableHeaderView;
// 界面元素 - 表格的位置宽高大小
- (CGRect)frameOfScrollTableView;
// 界面元素 - 投注内容的宽高大小
- (CGRect)frameOfScrollContentView:(BOOL)isFirst;

// 开奖结果 - 开奖类型
- (CFCGameBetDrawResultItemType)getDrawResultItemType;

// 投注总数 - 在主页面更新用户的投注总数 - CFCGameBetPlayClassViewControllerDelegate
- (BOOL)changeSumNumberOfBettingForMainGameBetViewController:(NSInteger)number;

// 清空操作 - 清空按钮事件传递至叶子结点页面 - CFCGameBetPlayScrollToPlayClassViewControllerProtocol
- (void)doClearButtonActionForPlayClassViewController;
// 投注操作 - 投注按钮事件传递至叶子结点页面 - CFCGameBetPlayScrollToPlayClassViewControllerProtocol
- (void)doBettingButtonActionForPlayClassViewController;

@end


@interface CFCGameBetPlayScrollViewController : CFCGameBetBaseViewController <CFCGameBetPlayScrollViewControllerProtocol, CFCGameBetCoreToPlayScrollViewHeaderProtocol>
@property (nonatomic, weak) id<CFCGameBetPlayScrollClassDelegate> delegate;
@property (nonatomic, weak) id<CFCGameBetPlayScrollClassDataSource> dataSource;
@property (nonatomic, weak) id<CFCGameBetPlayScrollToGameCoreViewControllerProtocol> delegate_betting_core;
@property (nonatomic, weak) id<CFCGameBetPlayScrollToPlayClassViewControllerProtocol> delegate_betting_playclass;
@property (nonatomic, weak) id<CFCGameBetPlayScrollToPlayScrollViewHeaderProtocol> delegate_betting_header;

@property (strong, nonatomic) NSDictionary *allResponseDataOrCacheData; // 主页面接口的所有数据
@property (strong, nonatomic) NSDictionary *playClassVCData; // 叶子页面数据


#pragma mark -
#pragma mark 重新加载刷新页面
- (void)reloadData;
#pragma mark 在切换具体玩法页面后保存选中的具体玩法下标 selectedIndexOfPlayClass
- (void)doChangeSelectedIndexOfPlayClassForPlayScrollViewController:(NSInteger)selectedIndex;


#pragma mark -
#pragma mark 主页数据 - 刷新加载数据
- (void)loadDataForPlayClassViewController;
#pragma mark 主页数据 - 加载更多数据
- (void)loadMoreDataForPlayClassViewController;
#pragma mark 主页数据 - 请求网络数据
- (void)loadPlayClassViewControllerNetworkDataThen:(void (^)(BOOL success, NSUInteger count))then;
#pragma mark 主页数据 - 加载网络或缓存数据
- (NSDictionary *)loadPlayClassViewControllerNetworkDataOrCacheData:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData;
#pragma mark 主页数据 - 加载完数据前操作，每次刷新加载数据前都会执行
- (void)viewDidLoadBeforeLoadPlayClassViewControllerNetworkDataOrCacheData;
#pragma mark 主页数据 - 加载完数据后操作，每次刷新加载数据后都会执行
- (void)viewDidLoadAfterLoadPlayClassViewControllerNetworkDataOrCacheData;


#pragma mark -
#pragma mark 事件处理 - 切换玩法 - 验证玩法的页面是否存在 - CFCGameBetPlayScrollViewHeaderDelegate
- (BOOL)canSelectedPlayClassViewController:(NSString *)classCode
                    selectedGameIdentifier:(NSString *)selectedGameIdentifier
                    selectedTypeIdentifier:(NSString *)selectedTypeIdentifier
                   selectedGroupIdentifier:(NSString *)selectedGroupIdentifier
                   selectedClassIdentifier:(NSString *)selectedClassIdentifier
                    selectedClassTitleName:(NSString *)selectedClassTitleName;
#pragma mark 事件处理 - 切换玩法 - 玩法页面存在则切换 - CFCGameBetPlayScrollViewHeaderDelegate
- (void)didSelectedPlayClassViewController:(NSString *)classCode
                    selectedGameIdentifier:(NSString *)selectedGameIdentifier
                    selectedTypeIdentifier:(NSString *)selectedTypeIdentifier
                   selectedGroupIdentifier:(NSString *)selectedGroupIdentifier
                   selectedClassIdentifier:(NSString *)selectedClassIdentifier
                    selectedClassTitleName:(NSString *)selectedClassTitleName
                     selectedPlayTypeModel:(CFCGameBetPlayTypeModel *)selectedGameBetPlayTypeModel
                selectedPlayTypeGroupModel:(CFCGameBetPlayTypeGroupModel *)selectedGameBetPlayTypeGroupModel
                selectedPlayTypeClassModel:(CFCGameBetPlayTypeClassModel *)selectedGameBetPlayTypeClassModel;
#pragma mark 倒计时间 - 在倒计时间结束后是否可以弹提示信息框
- (BOOL)canAlertTipInfoDialogAfterCounting;

@end


#pragma mark -
#pragma mark 协议 - 作用：获取叶子结点控制器[CFCGameBetPlayClassViewController]的相关操作代理
@protocol CFCGameBetPlayScrollClassDelegate <NSObject>
@end


#pragma mark -
#pragma mark 协议 - 作用：获取叶子结点控制器[CFCGameBetPlayClassViewController]的数据源代理
@protocol CFCGameBetPlayScrollClassDataSource <NSObject>
@required
- (NSInteger)numberOfViewControllers;
- (NSString *)titleForTabAtIndex:(NSInteger)index;
- (NSString *)titleCodeForTabAtIndex:(NSInteger)index;
- (UIViewController *)viewControllerForIndex:(NSInteger)index;
@end


#pragma mark 协议 - 作用：更新[CFCGameCoreViewController]主界面的相关数据
@protocol CFCGameBetPlayScrollToGameCoreViewControllerProtocol <NSObject>
@required
// 投注标识 - 获取已保存的具体玩法投注标识(选中或不选中)
- (NSArray *)selectedDataMarkOfBettingFromMainGameCoreViewController:(NSString *)dataMarkCode;
// 投注标识 - 在主页面更新具体玩法投注标识(选中或不选中)
- (BOOL)changeSelectedDataMarkOfBettingForMainGameCoreViewController:(NSArray *)selectedDataMark dataMarkCode:(NSString *)dataMarkCode;

// 投注备注 - 获取已保存的具体玩法投注备注
- (NSArray *)selectedDataRemarkOfBettingFromMainGameCoreViewController:(NSString *)dataMarkCode;
// 投注备注 - 在主页面更新具体玩法投注备注
- (BOOL)changeSelectedDataRemarkOfBettingForMainGameCoreViewController:(NSArray *)selectedDataRemark dataMarkCode:(NSString *)dataMarkCode;

// 玩法下标 - 获取已保存的具体玩法下标 selectedIndexOfPlayClass
- (NSInteger)selectedIndexOfPlayClassFromMainGameCoreViewController:(NSString *)tabMarkCode;
// 玩法下标 - 在主页面更新具体玩法下标 selectedIndexOfPlayClass
- (BOOL)changeSelectedIndexOfPlayClassForMainGameCoreViewController:(NSInteger)selectedIndex tabMarkCode:(NSString *)tabMarkCode;
// 玩法标识 - 获取已保存的具体玩法标识 selectedPlayCodeOfPlayClass
- (NSString *)selectedPlayCodeOfPlayClassFromMainGameCoreViewController:(NSString *)tabMarkCode;
// 玩法标识 - 在主页面更新具体玩法标识 selectedPlayCodeOfPlayClass
- (BOOL)changeSelectedPlayCodeOfPlayClassForMainGameCoreViewController:(NSString *)selectedPlayCodeOfPlayClass tabMarkCode:(NSString *)tabMarkCode;
// 玩法标识 - 获取当前页面具体玩法标识 currentSelectedPlayCodeOfPlayClass
- (NSString *)currentSelectedPlayCodeOfPlayClassFromMainGameCoreViewController;

// 玩法标识 - 获取已保存的玩法弹出框标识 selectedPlayTypeDictionary
- (NSMutableDictionary<NSString *, NSString *> *)selectedPlayTypeDictionaryFromMainGameCoreViewController;
// 玩法标识 - 在主页面更新玩法弹出框标识 selectedPlayTypeDictionary
- (BOOL)changeSelectedPlayTypeDictionaryForMainGameCoreViewController:(NSString *)playTypeValue playTypeKey:(NSString *)playTypeKey;

// 游戏类型 - 获取当前游戏类型主页面加载的次数
- (NSInteger)numberHasLoadOfGameBetPlayScrollFromMainGameCoreViewController;

// 玩法模式 - 获取当前主页面的玩法模式 currentPlayModeClass
- (CFCGameCorePlayModeClass)currentPlayModeClassForMainGameCoreViewController;

// 倒计时间 - 在倒计时间结束后是否可以弹提示信息框
- (BOOL)canAlertTipInfoDialogAfterCounting;

@end


#pragma mark 协议 - 作用：更新[CFCGameBetPlayClassViewController]叶子结点页面的相关数据
@protocol CFCGameBetPlayScrollToPlayClassViewControllerProtocol <NSObject>
@required
// 清空操作 - 清空按钮事件传递至叶子结点页面
- (void)doClearButtonActionForPlayClassViewController;
// 投注操作 - 投注按钮事件传递至叶子结点页面
- (void)doBettingButtonActionForPlayClassViewController;
// 投注赔率 - 加载刷新赔率数据至叶子结点页面
- (void)doRefreshRequestOddsDataForPlayClassViewController:(NSDictionary *)responseData;

// 投注结果 - 从叶子结点页面获取投注结果数据
- (NSArray<CFCGameBetRecordModel *> *)bettingRecordModelsFromPlayClassViewController:(NSDictionary *)dictOfBetSetting;

@end


#pragma mark 协议 - 作用：更新[CFCGameBetPlayScrollViewHeader]头部开奖结果倒计时区域数据
@protocol CFCGameBetPlayScrollToPlayScrollViewHeaderProtocol <NSObject>
@required

// 主页数据 - 更新开奖结果数据至开奖结果倒计时区域
- (void)doRefreshRequestDataForPlayScrollViewHeader:(NSDictionary *)responseData;
// 投注期号 - 当前盘口投注期号
- (NSString *)currentBettingIssueNumberFromPlayScrollViewHeader;
// 释放资源 - 切换游戏释放资源
- (void)doDestoryTimerForPlayScrollViewHeader:(NSString *)gameId gameName:(NSString *)gameName gameIdentifier:(NSString *)gameIdentifier;


@end


NS_ASSUME_NONNULL_END
