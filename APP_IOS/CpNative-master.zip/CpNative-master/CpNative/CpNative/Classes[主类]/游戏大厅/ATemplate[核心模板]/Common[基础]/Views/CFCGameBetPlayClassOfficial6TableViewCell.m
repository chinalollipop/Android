//
//  游戏 - 官方玩法 -> 投注项目，无操作按钮 -> 如：时时彩、极速3D官方玩法中<单式、混合组选>
//
//  说明：此类以 UITableViewCell 实现。如果不能满足你的要求，请另外实现。
//

#import "CFCGameBetPlayClassOfficial6TableViewCell.h"
#import "CFCGameBetPlayClassModel.h"
#import "CFCTextView.h"


// Cell Identifier
NSString * const CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_6_TABLE_VIEW_CELL = @"CFCGameBetPlayClassOfficial6TableViewCellIdentifier";


@interface CFCGameBetPlayClassOfficial6TableViewCell () <UITextViewDelegate>

@end


@implementation CFCGameBetPlayClassOfficial6TableViewCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createViewAtuoLayout];
    }
    return self;
}


#pragma mark 创建子控件
- (void) createViewAtuoLayout
{
    // 根容器
    UIView *rootContainerView = ({
        UIView *view = [[UIView alloc] init];
        [self.contentView insertSubview:view atIndex:0];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@0.0f);
            make.top.equalTo(@0.0f);
            make.right.equalTo(@0.0f);
            make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
        }];
        
        view;
    });
    self.rootContainerView = rootContainerView;
    self.rootContainerView.mas_key = @"rootContainerView";
    
    // 公共容器
    UIView *publicContainerView = ({
        UIView *view = [[UIView alloc] init];
        [view setBackgroundColor:COLOR_GAME_BET_MAINAREA_BACKGROUND_DEFAULT];
        [rootContainerView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(rootContainerView.mas_left).offset(0.0f);
            make.top.equalTo(rootContainerView.mas_top).offset(0.0f);
            make.right.equalTo(rootContainerView.mas_right).offset(0.0f);
            make.bottom.equalTo(rootContainerView.mas_bottom).offset(0.0f);
        }];
        
        view;
    });
    self.publicContainerView = publicContainerView;
    self.publicContainerView.mas_key = @"publicContainerView";
    
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCGameBetPlayClassSectionModel *)model
{
    // 类型安全检查
    if (![model isKindOfClass:[CFCGameBetPlayClassSectionModel class]]) {
        return;
    }
    
    // 数据赋值
    _model = (CFCGameBetPlayClassSectionModel *)model;
    
    // 删除控件
    [self.publicContainerView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    // 创建控件
    {
        // 大小间距
        CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
        CGFloat margin_top = margin * 2.25f;
        CGFloat margin_left = margin * 1.50f;
        CGFloat margin_right = margin * 1.50f;
        CGFloat margin_bottom = margin * 2.00f;
        CGFloat text_view_height = SCREEN_WIDTH * 0.48f;
        UIFont *text_font = [UIFont fontWithName:@"NotoMono" size:CFC_AUTOSIZING_FONT(17)];
        // 操作按钮
        NSArray<NSString *> *operationButtonTitle = @[ GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_FILTER, GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_CLEAR ];
        CGFloat btn_size_width = SCREEN_WIDTH * 0.30f;
        CGFloat btn_size_height = btn_size_width * 0.40f;
        CGFloat btn_margin_horizontal = margin * 2.0f;
        CGFloat btn_margin_vertical = margin * 0.5f;
        
        // 输入内容
        NSString *bettingTextValue = @"";
        if (self.model.list.count > 0 && [self isSingleSectionModel]) {
            CFCGameBetPlayClassModel *classModel = self.model.list[0];
            bettingTextValue = classModel.classRemark;
            CGFloat height = [bettingTextValue heightWithFont:text_font constrainedToWidth:SCREEN_WIDTH-margin_left-margin_right];
            text_view_height = (height > text_view_height ? height : text_view_height);
        }
        
        // 输入控件
        CFCTextView *bettingTextView = ({
            CFCTextView *bettingTextView = [CFCTextView textView];
            [bettingTextView setDelegate:self];
            [bettingTextView setFont:text_font];
            [bettingTextView setBorderWidth:0.5f];
            [bettingTextView setCornerRadius:5.0f];
            [bettingTextView setText:bettingTextValue];
            [bettingTextView setBorderColor:UIColor.lightGrayColor];
            [bettingTextView setBackgroundColor:COLOR_HEXSTRING(@"#F0F1F2")];
            [bettingTextView setTranslatesAutoresizingMaskIntoConstraints:NO];
            [bettingTextView setPlaceholderFont:[UIFont fontWithName:@"NotoMono" size:CFC_AUTOSIZING_FONT(15)]];
            [bettingTextView setPlaceholderColor:COLOR_HEXSTRING(@"#9B9B9B")];
            [bettingTextView setPlaceholder:@"说明：\n1.每一注号码之间的间隔符支持如下符号：\n  回车[r] 空格[] 逗号[,] 分号[;] 竖杠[|]\n2.有疑问请咨询客服"];
            [self.publicContainerView addSubview:bettingTextView];
            
            [self.publicContainerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"H:|-%f-[bettingTextView]-%f-|", margin_left, margin_right]
                                                                                             options:kNilOptions
                                                                                             metrics:nil
                                                                                               views:NSDictionaryOfVariableBindings(bettingTextView)]];
            [self.publicContainerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"V:|-%f-[bettingTextView(==%f)]", margin_top, text_view_height]
                                                                                             options:kNilOptions
                                                                                             metrics:nil
                                                                                               views:NSDictionaryOfVariableBindings(bettingTextView)]];
            
            bettingTextView;
        });
        self.bettingTextView = bettingTextView;
        self.bettingTextView.mas_key = @"bettingTextView";
        
        // 操作按钮
        CFCGameBetPlayClassCheckButton *lastOperationButton = nil;
        self.operationButtonArray = @[].mutableCopy;
        for (int i = 0; i < operationButtonTitle.count; i ++) {
            
            CFCGameBetPlayClassCheckButton *itemButton = ({
                CFCGameBetPlayClassCheckButton *itemCheckButton = [[CFCGameBetPlayClassCheckButton alloc] init];
                [self.publicContainerView addSubview:itemCheckButton];
                [itemCheckButton setText:operationButtonTitle[i]];
                [itemCheckButton.layer setBorderWidth:GAME_PLAY_ITEM_BORDER_WIDTH_DEFAULT];
                [itemCheckButton.layer setBorderColor:GAME_PLAY_ITEM_BORDER_COLOR_DEFAULT.CGColor];
                [itemCheckButton.layer setCornerRadius:margin*0.5f];
                [itemCheckButton.layer setMasksToBounds:YES];
                [itemCheckButton setNormalBgColor:GAME_PLAY_OFFICI_BUTTON_BACKGROUND_SINGLE_COLOR_NORMAL];
                [itemCheckButton setSelectBgColor:GAME_PLAY_OFFICI_BUTTON_BACKGROUND_SINGLE_COLOR_SELECT];
                [itemCheckButton setChecked:NO];
                // 正常状态
                NSDictionary *normalAttributesName = @{ NSFontAttributeName:GAME_PLAY_OFFICI_BUTTON_TITLE_SINGLE_FONT_NORMAL,
                                                        NSForegroundColorAttributeName:GAME_PLAY_OFFICI_BUTTON_TITLE_SINGLE_COLOR_NORMAL};
                NSAttributedString *normalAttributedString = [CFCSysUtil attributedString:@[ operationButtonTitle[i] ]
                                                                           attributeArray:@[ normalAttributesName ]];
                [itemCheckButton setNormalAttributedText:normalAttributedString];
                // 选中状态
                NSDictionary *selectAttributesName = @{ NSFontAttributeName:GAME_PLAY_OFFICI_BUTTON_TITLE_SINGLE_FONT_SELECT,
                                                        NSForegroundColorAttributeName:GAME_PLAY_OFFICI_BUTTON_TITLE_SINGLE_COLOR_SELECT};
                NSAttributedString *selectAttributedString = [CFCSysUtil attributedString:@[ operationButtonTitle[i] ]
                                                                           attributeArray:@[ selectAttributesName ]];
                [itemCheckButton setSelectAttributedText:selectAttributedString];
                // 按钮事件
                [itemCheckButton addTarget:self action:@selector(doPlayClassCheckButtonAction:) forControlEvents:UIControlEventTouchUpInside];
                
                [itemCheckButton mas_remakeConstraints:^(MASConstraintMaker *make) {
                    make.width.equalTo(@(btn_size_width));
                    make.height.equalTo(@(btn_size_height));
                    
                    if (!lastOperationButton) {
                        make.top.equalTo(bettingTextView.mas_bottom).offset(margin*2.5f);
                        make.left.equalTo(self.publicContainerView.mas_centerX).offset(-btn_size_width-btn_margin_horizontal/2.0f);
                    } else {
                        if (i % 2 == 0) {
                            make.top.equalTo(lastOperationButton.mas_bottom).offset(btn_margin_vertical);
                            make.left.equalTo(self.publicContainerView.mas_centerX).offset(-btn_size_width-btn_margin_horizontal/2.0f);
                        } else {
                            make.top.equalTo(lastOperationButton.mas_top).offset(0);
                            make.left.equalTo(lastOperationButton.mas_right).offset(btn_margin_horizontal);
                        }
                    }
                }];
                itemCheckButton.mas_key = [NSString stringWithFormat:@"itemContainerView%d",i];
                
                itemCheckButton;
            });
            [self.operationButtonArray addObject:itemButton];
            
            lastOperationButton = itemButton;
        }
        
        // 分割线
        UIView *separatorLineView = ({
            UIView *view = [[UIView alloc] init];
            [self.publicContainerView addSubview:view];
            [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
            
            [view mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.equalTo(self.publicContainerView.mas_left).offset(0.0f);
                make.right.equalTo(self.publicContainerView.mas_right).offset(0.0f);
                make.height.equalTo(@(SEPARATOR_LINE_HEIGHT));
                make.top.equalTo(lastOperationButton.mas_bottom).offset(margin_bottom);
            }];
            
            view;
        });
        separatorLineView.mas_key = @"separatorLineView";
        
        // 约束的完整性
        [self.publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(separatorLineView.mas_bottom).offset(0.0f).priority(749);
        }];
    }
    
    // 选中按钮
    {
        // 根据选中的操作按钮标题，设置按钮背景
        [self.operationButtonArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassCheckButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([self.model.selectedOptBtnTitle isEqualToString:obj.text]) {
                // 按钮选中状态
                [obj setChecked:YES];
            } else {
                // 按钮正常状态
                [obj setChecked:NO];
            }
        }];
    }
    
}


#pragma mark - 操作事件 - 操作按钮
- (void)doPlayClassCheckButtonAction:(CFCGameBetPlayClassCheckButton *)button
{
    // 按钮的标题
    [self.model setSelectedOptBtnTitle:(button.text)];
    
    // 选中的项目
    __block NSMutableArray<NSNumber *> *selectedIndexs = [NSMutableArray array];
    __block NSMutableArray<CFCGameBetPlayClassModel *> *selectedModels = [NSMutableArray array];
    
    // 筛选号码
    if ([GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_FILTER isEqualToString:button.text]) {
        [self.model.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            [obj setIsSelected:NO]; // 选中代表筛选号码
            [obj setName:GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_FILTER];
            [selectedModels addObject:obj];
            [selectedIndexs addObject:[NSNumber numberWithInteger:idx]];
        }];
    }
    // 清空文本
    else if ([GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_CLEAR isEqualToString:button.text]) {
        [self.model.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            [obj setIsSelected:YES]; // 不选代表清空文本
            [obj setClassRemark:REMARK_STRI_GAME_PLAY_MODEL_EMPTY];
            [obj setName:GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_CLEAR];
            [selectedModels addObject:obj];
            [selectedIndexs addObject:[NSNumber numberWithInteger:idx]];
        }];
    }
    
    // 执行代理
    if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectPlayClassOfficial6TableViewCellRowAtIndexPath:itemModels:itemIndexs:)]) {
        [self.delegate didSelectPlayClassOfficial6TableViewCellRowAtIndexPath:self.indexPath
                                                                   itemModels:[NSArray arrayWithArray:selectedModels]
                                                                   itemIndexs:[NSArray arrayWithArray:selectedIndexs]];
    }
}

#pragma mark - 逻辑处理 - 操作按钮
- (void)doLogicPlayClassRefresh
{
    // 执行代理
    if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectPlayClassOfficial6TableViewCellRowAtIndexPath:itemModels:itemIndexs:)]) {
        [self.delegate didSelectPlayClassOfficial6TableViewCellRowAtIndexPath:self.indexPath itemModels:@[] itemIndexs:@[]];
    }
}


#pragma mark - UITextViewDelegate
#pragma mark 文本输入框 - 将要开始编辑
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
    if (self.model.list.count > 0 && [self isSingleSectionModel]) {
        CFCGameBetPlayClassModel *classModel = self.model.list[0];
        [classModel setName:STR_APP_TEXT_EMPTY];
    }
    
    IQKeyboardManager *keyboardManager = [IQKeyboardManager sharedManager]; // 获取类库的单例变量
    keyboardManager.shouldShowToolbarPlaceholder = NO; // 是否显示占位文字
    return YES;
}

#pragma mark 文本输入框 - 将要结束编辑
- (BOOL)textViewShouldEndEditing:(UITextView *)textView
{
    IQKeyboardManager *keyboardManager = [IQKeyboardManager sharedManager]; // 获取类库的单例变量
    keyboardManager.shouldShowToolbarPlaceholder = YES; // 是否显示占位文字
    return YES;
}

#pragma mark 文本输入框 - 文本将要改变
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    NSCharacterSet *characterSet = [[NSCharacterSet characterSetWithCharactersInString:STR_BETTING_DANSHI_CHARACHTERSET] invertedSet];
    NSString *filtered = [[text componentsSeparatedByCharactersInSet:characterSet] componentsJoinedByString:@""];
    BOOL basicTest = [text isEqualToString:filtered];
    if (!basicTest) {
        CFCGameRootViewController *topViewController = (CFCGameRootViewController *)[CFCAppUtil getTopViewController];
        [TSMessage showNotificationInViewController:(topViewController.centerViewController?topViewController.centerViewController:topViewController)
                                              title:NSLocalizedString(STR_ALERT_MESSAGE_TITLE_INFO, nil)
                                           subtitle:NSLocalizedString(@"提示：只能输入数字、回车、空格、逗号、分号、竖杠！", nil)
                                               type:TSMessageNotificationTypeMessage
                                           duration:ALERT_MESSAGE_DURATION];
        return NO;
    }
    
    return YES;
}

#pragma mark 文本输入框 - 文本发生改变
- (void)textViewDidChange:(UITextView *)textView
{
    // 保存备注
    if (self.model.list.count > 0 && [self isSingleSectionModel]) {
        NSString *textValue = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:textView.text];
        CFCGameBetPlayClassModel *classModel = self.model.list[0];
        [classModel setClassRemark:textValue];
    }
    
    // 更新数据
    [self doLogicPlayClassRefresh];
}

#pragma mark 文本输入框 - 结束文本编辑
- (void)textViewDidEndEditing:(UITextView *)textView
{
    // 保存备注
    if (self.model.list.count > 0 && [self isSingleSectionModel]) {
        NSString *textValue = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:textView.text];
        CFCGameBetPlayClassModel *classModel = self.model.list[0];
        [classModel setClassRemark:textValue];
    }
    
    // 更新数据
    [self doLogicPlayClassRefresh];
}

#pragma mark 分组内容是否是单式号码
- (BOOL)isSingleSectionModel
{
    // 投注项目，有操作按钮 -> 如：时时彩、极速3D官方玩法中<单式、混合组选>
    // 投注项目，有操作按钮 -> 如：北京PK拾、11选5官方玩法中<单式、混合组选>
    if (CFCGameBetPlayClassSectionTypeOfficial6 == self.model.type
        || CFCGameBetPlayClassSectionTypeOfficial7 == self.model.type) {
        return YES;
    }
    return NO;
}


@end

