//
//  游戏 - 投注页面头部区域 - 玩法选择 - 二级分类
//

#import "CFCPlayTypeContentSecondModel.h"

@implementation CFCPlayTypeContentSecondModel

@end
