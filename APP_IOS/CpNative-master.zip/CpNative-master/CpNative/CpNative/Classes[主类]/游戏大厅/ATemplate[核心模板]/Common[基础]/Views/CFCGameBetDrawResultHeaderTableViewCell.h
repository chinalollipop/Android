//
// 游戏 - 投注区 - 开奖结果 - 表格头
//


#import "YHSDropDownMenuBasedCell.h"
@class CFCGameBetDrawResultModel;

NS_ASSUME_NONNULL_BEGIN

@interface CFCGameBetDrawResultHeaderTableViewCell : YHSDropDownMenuBasedCell
/**
 * 根容器组件
 */
@property (nonnull, nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器组件
 */
@property (nonnull, nonatomic, strong) UIView *publicContainerView;
/**
 * 左边开奖期号
 */
@property (nonatomic, strong) UILabel *leftIssueNumberLabel;
/**
 * 右边开奖标题
 */
@property (nonatomic, strong) UILabel *rightWinnerLabel;
/**
 * 分割线控件
 */
@property (nonatomic, strong) UIView *separatorLineView;

@end

NS_ASSUME_NONNULL_END
