//
//  游戏 - 官方玩法 -> 投注项目，有操作按钮 -> 如：北京快乐八官方玩法中<任选一、任选二>
//
//  说明：此类以 UITableViewCell 实现。如果不能满足你的要求，请另外实现。
//

#import <UIKit/UIKit.h>
@class CFCGameBetPlayClassModel, CFCGameBetPlayClassSectionModel, CFCGameBetPlayClassCheckButton;

NS_ASSUME_NONNULL_BEGIN


UIKIT_EXTERN NSString * const CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_5_TABLE_VIEW_CELL;


@protocol CFCGameBetPlayClassOfficial5TableViewCellProtocol <CFCGameBetPlayClassTableViewCellProtocol>
@required
- (void)pressItemButtonViewAction:(UITapGestureRecognizer *)gesture;
- (void)doPlayClassCheckButtonAction:(CFCGameBetPlayClassCheckButton *)button;
- (BOOL)checkOperationButtonAll:(CFCGameBetPlayClassSectionModel *)model;
- (BOOL)checkOperationButtonDA:(CFCGameBetPlayClassSectionModel *)model;
- (BOOL)checkOperationButtonXIAO:(CFCGameBetPlayClassSectionModel *)model;
- (BOOL)checkOperationButtonJI:(CFCGameBetPlayClassSectionModel *)model;
- (BOOL)checkOperationButtonOU:(CFCGameBetPlayClassSectionModel *)model;
@end


@protocol CFCGameBetPlayClassOfficial5TableViewCellDelegate <NSObject>
@required
- (NSString *)itemNameOfMaxLengthInDataOfSectionModelArray:(CFCGameBetPlayClassModel *)model;
- (NSString *)itemOddsOfMaxLengthInDataOfSectionModelArray:(CFCGameBetPlayClassModel *)model;
@optional
- (void)didSelectPlayClassOfficial5TableViewCellRowAtIndexPath:(NSIndexPath *)indexPath
                                                    itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels
                                                    itemIndexs:(NSArray<NSNumber *> *)itemIndexs;
@end


@interface CFCGameBetPlayClassOfficial5TableViewCell : UITableViewCell <CFCGameBetPlayClassOfficial5TableViewCellProtocol>
/**
 * 根容器组件
 */
@property (nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonatomic, strong) UIView *publicContainerView;
/**
 * 分组标题
 */
@property (nonatomic, strong) UILabel *sectionTitleLabel;
/**
 * 投注按钮
 */
@property (nonatomic, strong) NSMutableArray<UILabel *> *bettingButtonArray;
/**
 * 操作按钮
 */
@property (nonatomic, strong) NSMutableArray<CFCGameBetPlayClassCheckButton *> *operationButtonArray;
/**
 * 数据下标
 */
@property (nonatomic, strong) NSIndexPath *indexPath;
/**
 * 数据模型
 */
@property (nonatomic, strong) CFCGameBetPlayClassSectionModel *model;
/**
 * 表格代理
 */
@property (nonatomic, weak) id<CFCGameBetPlayClassOfficial5TableViewCellDelegate> delegate;


/**
 * 操作事件 - 投注按钮
 */
- (void)pressItemButtonViewAction:(UITapGestureRecognizer *)gesture;
/**
 * 操作事件 - 操作按钮
 */
- (void)doPlayClassCheckButtonAction:(CFCGameBetPlayClassCheckButton *)button;
/**
 * 计算操作按钮状态 - 全
 */
- (BOOL)checkOperationButtonAll:(CFCGameBetPlayClassSectionModel *)model;
/**
 * 计算操作按钮状态 - 大
 */
- (BOOL)checkOperationButtonDA:(CFCGameBetPlayClassSectionModel *)model;
/**
 * 计算操作按钮状态 - 小
 */
- (BOOL)checkOperationButtonXIAO:(CFCGameBetPlayClassSectionModel *)model;
/**
 * 计算操作按钮状态 - 单
 */
- (BOOL)checkOperationButtonJI:(CFCGameBetPlayClassSectionModel *)model;
/**
 * 计算操作按钮状态 - 双
 */
- (BOOL)checkOperationButtonOU:(CFCGameBetPlayClassSectionModel *)model;


@end


NS_ASSUME_NONNULL_END

