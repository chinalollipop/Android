
#import "CFCGameSliderTimer.h"


@interface CFCGameSliderTimer ()

@property(nonatomic, assign) CGFloat second;

@property(nonatomic, retain) dispatch_source_t timer;

@end


@implementation CFCGameSliderTimer

#pragma mark -
#pragma mark 定时器单例
+ (instancetype)sharedGameSliderTimer
{
    static CFCGameSliderTimer *_singetonInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken,^{
        if (nil == _singetonInstance) {
            // 网络请求管理单例
            _singetonInstance = [[super allocWithZone:NULL] init];
        }
    });
    return _singetonInstance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone
{
    return [[self class] sharedGameSliderTimer];
}

- (id)copyWithZone:(struct _NSZone *)zone
{
    return [[self class] sharedGameSliderTimer];
}


#pragma mark -
#pragma mark 每秒走一次，回调block
- (void)countDownWithBlock:(void (^)(void))block timer:(CGFloat)second
{
    // 如果切换了，则释放旧定时器
    if ([CFCGameSliderTimer sharedGameSliderTimer].second != second && second > 0) {
        [[CFCGameSliderTimer sharedGameSliderTimer] destoryTimer];
        [[CFCGameSliderTimer sharedGameSliderTimer] setSecond:second];
    }
    
    // 定时器为空，则创建新定时器
    if ([CFCGameSliderTimer sharedGameSliderTimer].timer == nil) {
        if (second <= 0) {
            second = 1.0f;
        }
        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
        [CFCGameSliderTimer sharedGameSliderTimer].timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
        dispatch_source_set_timer([CFCGameSliderTimer sharedGameSliderTimer].timer, dispatch_walltime(NULL, 0), second*NSEC_PER_SEC, 0); // 每0.1秒执行
        dispatch_source_set_event_handler([CFCGameSliderTimer sharedGameSliderTimer].timer, ^{
            dispatch_async(dispatch_get_main_queue(), ^{
                block();
            });
        });
        dispatch_resume([CFCGameSliderTimer sharedGameSliderTimer].timer);
    }
}


#pragma mark 销毁定时器
- (void)destoryTimer
{
    if ([CFCGameSliderTimer sharedGameSliderTimer].timer) {
        dispatch_source_cancel([CFCGameSliderTimer sharedGameSliderTimer].timer);
        [CFCGameSliderTimer sharedGameSliderTimer].timer = nil;
    }
}


@end

