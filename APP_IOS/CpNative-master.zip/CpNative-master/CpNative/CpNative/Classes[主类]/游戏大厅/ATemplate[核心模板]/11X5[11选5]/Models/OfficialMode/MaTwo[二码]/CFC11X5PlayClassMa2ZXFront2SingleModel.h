//
// 游戏 - 投注区 - 官方模式 - 11选5 - 二码 - 直选 - 前二直选单式
//

#import "CFCGameBetPlayClassModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFC11X5PlayClassMa2ZXFront2SingleModel : CFCGameBetPlayClassModel

+ (NSMutableArray *) buildingDataModlesForSection1;

@end


@interface CFC11X5PlayClassMa2ZXFront2SingleSectionModel : CFCGameBetPlayClassSectionModel

+ (NSMutableArray *) buildingDataModles;

@end

NS_ASSUME_NONNULL_END
