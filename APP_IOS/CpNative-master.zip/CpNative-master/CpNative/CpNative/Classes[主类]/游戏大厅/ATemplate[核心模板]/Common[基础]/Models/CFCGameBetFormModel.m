//
// 游戏 - 投注区 - 投注数据模型
//


#import "CFCGameBetFormModel.h"


@implementation CFCGameBetRecordModel

- (instancetype)init
{
    self = [super init];
    if (self) {
        _jsId = @"0";
        _extra = [NSDictionary<NSString *, NSString *> dictionary];
    }
    return self;
}

+ (CFCGameBetRecordModel *) buildingDataModleForBettingRecords
{
    CFCGameBetRecordModel *model = [[CFCGameBetRecordModel alloc] init];
    return model;
}

@end


@implementation CFCGameBetFormModel

- (instancetype)init
{
    self = [super init];
    if (self) {
        _isTrace = @"0";
        _traceWinStop = @"1";
        _traceStopValue = @"1";
    }
    return self;
}

+ (CFCGameBetFormModel *) buildingDataModleForBettingForms
{
    CFCGameBetFormModel *model = [[CFCGameBetFormModel alloc] init];
    return model;
}


@end

