//
//  游戏 - 提示信息框 - 投注失败
//

#import "CFCBettingFailurePopNoticeView.h"
#import "CFCCountDownObject.h"


@interface CFCBettingFailurePopNoticeView()
@property (nonatomic, strong) UIImageView *markImageView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *contentLabel;
@property (nonatomic, strong) UIButton *confirmButton;
@property (nonatomic, strong) UILabel *timeLabel;
@property (nonatomic, strong) UIView *contentView;
@property (nonatomic, strong) UIButton *coverAlphaButton;
@property (nonatomic, strong) CFCCountDownObject *countDownObject;
@end


@implementation CFCBettingFailurePopNoticeView

+ (instancetype)sharePopNoticeView
{
    static CFCBettingFailurePopNoticeView *_singetonInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _singetonInstance = [[super allocWithZone:NULL] initWithFrame:[UIScreen mainScreen].bounds];
    });
    return _singetonInstance;
}

#pragma mark - 系统方法
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self initViewControls];
        [self makeViewConstraints];
    }
    return self;
}

/** 添加控件 */
- (void)initViewControls
{
    [self addSubview:self.coverAlphaButton];
    [self addSubview:self.contentView];
    [self.contentView addSubview:self.markImageView];
    [self.contentView addSubview:self.titleLabel];
    [self.contentView addSubview:self.contentLabel];
    [self.contentView addSubview:self.confirmButton];
    [self.contentView addSubview:self.timeLabel];
}

/** 添加约束 */
- (void)makeViewConstraints
{
    CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
    CGFloat content_width = SCREEN_WIDTH * 0.54f;
    CGFloat content_height = content_width*0.80f;
    CGFloat image_size = content_width*0.24f;
    CGFloat button_width = content_width * 0.45f;
    CGFloat button_height = button_width * 0.30f;
    
    [self.coverAlphaButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0.0f);
        make.centerY.mas_equalTo(0.0f);
        make.width.mas_equalTo(content_width);
        make.height.mas_equalTo(content_height);
    }];
    
    [self.markImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.size.mas_equalTo(CGSizeMake(image_size, image_size));
        make.top.equalTo(self.contentView.mas_top).offset(margin*1.0f);
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.top.equalTo(self.markImageView.mas_bottom).offset(margin*1.0f);
        make.left.equalTo(self.contentView.mas_left).offset(margin*1.0f);
        make.right.equalTo(self.contentView.mas_right).offset(-margin*1.0f);
    }];
    
    [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.top.equalTo(self.titleLabel.mas_bottom).offset(margin*0.5f);
        make.left.equalTo(self.contentView.mas_left).offset(margin*1.0f);
        make.right.equalTo(self.contentView.mas_right).offset(-margin*1.0f);
    }];
    
    [self.confirmButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.width.mas_equalTo(button_width);
        make.height.mas_equalTo(button_height);
        make.bottom.equalTo(self.contentView.mas_bottom).offset(-margin*1.2f);
    }];
    
    [self.timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.confirmButton.mas_centerY);
        make.right.equalTo(self.confirmButton.mas_right).offset(-button_height/2.5f);
    }];
}

- (void)show
{
    _isShow = YES;
    
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    [window addSubview:self];
}

- (void)dismiss
{
    [self.countDownObject destoryTimer];
    
    [self removeFromSuperview];
    
    if (_isShow && self.afterDismissBlock) {
        self.afterDismissBlock();
    }
    
    _isShow = NO;
}

- (void)coverAlphaButtonClickAction
{
    // [self dismiss];
}

- (void)pressConfirmButtonAction
{
    [self dismiss];
}


#pragma mark - 懒加载
- (UIButton *)coverAlphaButton
{
    if(!_coverAlphaButton) {
        _coverAlphaButton = [[UIButton alloc] init];
        [_coverAlphaButton setAlpha:0.6f];
        [_coverAlphaButton setEnabled:YES];
        [_coverAlphaButton setBackgroundColor:[UIColor blackColor]];
        [_coverAlphaButton addTarget:self action:@selector(coverAlphaButtonClickAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _coverAlphaButton;
}

- (UIView *)contentView
{
    if(!_contentView) {
        _contentView = [[UIView alloc] init];
        _contentView.backgroundColor =[UIColor whiteColor];
        [_contentView addBorderWithColor:[UIColor whiteColor] cornerRadius:5.0f andWidth:1.0];
    }
    return _contentView;
}

- (UIImageView *)markImageView
{
    if(!_markImageView) {
        _markImageView = [[UIImageView alloc] init];
        [_markImageView setImage:[UIImage imageNamed:ICON_BET_FAILURE]];
    }
    return _markImageView;
}

- (UILabel *)titleLabel
{
    if(!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.text = @"投注失败";
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        _titleLabel.font = [UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(18.0f)];
        _titleLabel.textColor = COLOR_HEXSTRING(@"#3A3A3A");
    }
    return _titleLabel;
}

- (UILabel *)contentLabel
{
    if(!_contentLabel) {
        _contentLabel = [[UILabel alloc] init];
        _contentLabel.text = @"投注失败";
        _contentLabel.textAlignment = NSTextAlignmentCenter;
        _contentLabel.font = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)];
        _contentLabel.textColor = COLOR_HEXSTRING(@"#3A3A3A");
    }
    return _contentLabel;
}

- (UIButton *)confirmButton
{
    if(!_confirmButton) {
        _confirmButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_confirmButton setTitle:@"关  闭" forState:UIControlStateNormal];
        [_confirmButton setTitle:@"关  闭" forState:UIControlStateHighlighted];
        [_confirmButton setTitleColor:COLOR_HEXSTRING(@"#3A3A3A") forState:UIControlStateNormal];
        [_confirmButton setTitleColor:COLOR_HEXSTRING(@"#3A3A3A") forState:UIControlStateHighlighted];
        [_confirmButton.titleLabel setFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
        [_confirmButton setBackgroundColor:COLOR_HEXSTRING(@"#F1F1F1")];
        [_confirmButton addBorderWithColor:COLOR_HEXSTRING(@"#E4E4E4") cornerRadius:5.0f andWidth:1.25f];
        [_confirmButton addTarget:self action:@selector(pressConfirmButtonAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _confirmButton;
}

- (UILabel *)timeLabel
{
    if(!_timeLabel) {
        _timeLabel = [[UILabel alloc] init];
        _timeLabel.text = @"0";
        _timeLabel.hidden = YES;
        _timeLabel.userInteractionEnabled = YES;
        _timeLabel.textAlignment = NSTextAlignmentCenter;
        _timeLabel.font = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)];
        _timeLabel.textColor = COLOR_HEXSTRING(@"#3A3A3A");
    }
    return _timeLabel;
}


- (void)setContent:(NSString *)content
{
    _content = content;
    [_contentLabel setText:content];
}

- (void)setCount:(NSInteger)count
{
    _count = count;
    
    // 更新时间提示信息
    [self setTimeLabelValue:count];
    
    // 倒计时
    {
        // 销毁旧定时器
        [self.countDownObject destoryTimer];
        // 创建新定时器
        long long currentDateSecond = [CFCDateUtil getCurrentDateSecond];
        [self.countDownObject countDownWithStratDate:[[NSDate alloc] initWithTimeIntervalSince1970:currentDateSecond]
                                          finishDate:[[NSDate alloc] initWithTimeIntervalSince1970:currentDateSecond + count]
                                       completeBlock:^(NSInteger timeInterval, NSInteger day, NSInteger hour, NSInteger minute, NSInteger second) {
                                           if (0 >= second) {
                                               [self setTimeLabelValue:second];
                                               long long currentDateSecond = [CFCDateUtil getCurrentDateSecond];
                                               [self.countDownObject countDownWithStratDate:[[NSDate alloc] initWithTimeIntervalSince1970:currentDateSecond]
                                                                                 finishDate:[[NSDate alloc] initWithTimeIntervalSince1970:currentDateSecond + 1]
                                                                              completeBlock:^(NSInteger timeInterval, NSInteger day, NSInteger hour, NSInteger minute, NSInteger second) {
                                                                                  if (0 >= second) {
                                                                                      [self dismiss];
                                                                                  }
                                                                              }];
                                           } else {
                                               [self setTimeLabelValue:second];
                                           }
                                       }];
    }
}

- (CFCCountDownObject *)countDownObject
{
    if(!_countDownObject) {
        _countDownObject = [[CFCCountDownObject alloc] init];
    }
    return _countDownObject;
}

- (void)setTimeLabelValue:(NSInteger)count
{
    [_timeLabel setHidden:NO];
    [_timeLabel setText:[NSString stringWithFormat:@"%ld", count]];
}

@end


