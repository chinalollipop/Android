//
// 游戏 - 投注区 - 官方模式 - 11选5 - 二码 - 直选 - 前二直选单式
//

#import "CFC11X5PlayClassBaseOfficialViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFC11X5PlayClassMa2ZXFront2SingleViewController : CFC11X5PlayClassBaseOfficialViewController

@end

NS_ASSUME_NONNULL_END
