//
// 游戏 - 投注区 - 官方模式 - 11选5 - 任选复式 - 任选复式 - 任选二中二复式
//

#import "CFC11X5PlayClassRXFSRenXuan02ViewController.h"
#import "CFC11X5PlayClassRXFSRenXuan02Model.h"


@interface CFC11X5PlayClassRXFSRenXuan02ViewController ()

@end


@implementation CFC11X5PlayClassRXFSRenXuan02ViewController


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.className = GAME_PLAY_CLASS_NAME_11X5_RENXUANFUSHI_RXFS_RENXUAN02;
        self.classCode = GAME_PLAY_CLASS_CODE_11X5_RENXUANFUSHI_RXFS_RENXUAN02;
    }
    return self;
}


#pragma mark -
#pragma mark 数据模型 - 静态数据模型
- (NSArray<CFCGameBetPlayClassSectionModel *> *)dataOfPlayClassModelsForBettingRecords
{
    return [CFC11X5PlayClassRXFSRenXuan02SectionModel buildingDataModles];
}


#pragma mark 投注总数 - 计算投注总数
- (NSInteger)numberOfBettingRecords
{
    return [self numberOfBettingRecordsForCombination:2];
}


#pragma mark 投注结果 - 官方模式
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsOfficial:(NSDictionary *)dictOfBetSetting
{
    return [self bettingResultModelsForBettingRecordsTemplateN01:dictOfBetSetting];
}



@end
