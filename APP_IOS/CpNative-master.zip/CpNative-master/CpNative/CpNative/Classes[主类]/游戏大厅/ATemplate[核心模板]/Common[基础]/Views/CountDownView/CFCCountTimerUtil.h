

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCCountTimerUtil : NSObject

/**
 *  定时器单例
 */
+ (instancetype)sharedCountTimerUtil;

/**
 *  定时回调块
 */
- (void)countDownWithBeginDate:(NSDate *)beginDate
                    finishDate:(NSDate *)finishDate
                        gameId:(NSString *)gameId
                      gameName:(NSString *)gameName
                gameIdentifier:(NSString *)gameIdentifier
                     hourLabel:(UILabel *)hourLabel
                   minuteLabel:(UILabel *)minuteLabel
                   secondLabel:(UILabel *)secondLabel
                         block:(void (^)(NSInteger timeInterval, NSInteger day, NSInteger hour, NSInteger minute, NSInteger second))block;

/**
 *  销毁定时器
 */
- (void)destoryTimer;

@end

NS_ASSUME_NONNULL_END
