//
//  游戏 - 信用玩法 - 投注页面头部区域
//

#import "CFCGameBetPlayScrollViewHeader.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCGameBetPlayScrollViewCreditHeader : CFCGameBetPlayScrollViewHeader

@end

NS_ASSUME_NONNULL_END
