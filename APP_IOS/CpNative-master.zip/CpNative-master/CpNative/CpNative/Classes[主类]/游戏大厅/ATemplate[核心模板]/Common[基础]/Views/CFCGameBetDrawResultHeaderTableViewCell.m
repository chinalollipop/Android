//
// 游戏 - 投注区 - 开奖结果 - 表格头
//


#import "CFCGameBetDrawResultHeaderTableViewCell.h"
#import "CFCGameBetDrawResultModel.h"

@implementation CFCGameBetDrawResultHeaderTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createViewAtuoLayout];
    }
    return self;
}

#pragma mark 创建子控件
- (void)createViewAtuoLayout
{
    CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
    UIColor *color_background = COLOR_HEXSTRING(@"#F1F4F7");
    UIColor *color_separator_line = COLOR_HEXSTRING(@"#E5E5E5");
    
    // 根容器
    UIView *rootContainerView = ({
        UIView *view = [[UIView alloc] init];
        [self.contentView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@0.0f);
            make.top.equalTo(@0.0f);
            make.right.equalTo(@0.0f);
            make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
        }];
        
        view;
    });
    self.rootContainerView = rootContainerView;
    self.rootContainerView.mas_key = @"rootContainerView";
    
    // 公共容器
    UIView *publicContainerView = ({
        UIView *view = [[UIView alloc] init];
        [view.layer setMasksToBounds:YES];
        [view setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_WHITE];
        [rootContainerView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@0.0f);
            make.top.equalTo(@0.0f);
            make.right.equalTo(@0.0f);
            make.bottom.equalTo(rootContainerView.mas_bottom).offset(0.0f);
        }];
        
        view;
    });
    self.publicContainerView = publicContainerView;
    self.publicContainerView.mas_key = @"publicContainerView";
    
    // 开奖期号
    UILabel *leftIssueNumberLabel = ({

        NSDictionary *attributesText = @{ NSFontAttributeName:FONT_GAME_DRAW_RESULT_ISSUE_CHINESE,
                                          NSForegroundColorAttributeName:COLOR_GAME_DRAW_RESULT_ISSUE_CHINESE };
        NSAttributedString *attributedString = [CFCSysUtil attributedString:@[ @"期数" ] attributeArray:@[ attributesText ]];

        UILabel *label = [UILabel new];
        [publicContainerView addSubview:label];
        [label setAttributedText:attributedString];
        [label setTextAlignment:NSTextAlignmentCenter];
        [label setBackgroundColor:color_background];
        
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(publicContainerView.mas_left).offset(0.0f);
            make.top.equalTo(publicContainerView.mas_top).offset(0.0f);
            make.bottom.equalTo(publicContainerView.mas_bottom).offset(0.0f);
        }];
        
        label;
    });
    self.leftIssueNumberLabel = leftIssueNumberLabel;
    self.leftIssueNumberLabel.mas_key = @"leftIssueNumberLabel";
    
    // 右边容器
    UIView *rightWinnerContainerView = ({
        UIView *view = [[UIView alloc] init];
        [publicContainerView addSubview:view];
        [view setBackgroundColor:color_background];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(leftIssueNumberLabel.mas_right).offset(0.0f);
            make.top.equalTo(publicContainerView.mas_top).offset(0.0f);
            make.right.equalTo(publicContainerView.mas_right).offset(0.0f);
            make.bottom.equalTo(publicContainerView.mas_bottom).offset(0.0f);
        }];
        
        view;
    });
    rightWinnerContainerView.mas_key = @"rightWinnerContainerView";
    
    // 开奖号码
    UILabel *rightWinnerLabel = ({
        NSDictionary *attributesText = @{ NSFontAttributeName:FONT_GAME_DRAW_RESULT_ISSUE_CHINESE,
                                          NSForegroundColorAttributeName:COLOR_GAME_DRAW_RESULT_ISSUE_CHINESE };
        NSAttributedString *attributedString = [CFCSysUtil attributedString:@[ @"开奖号码" ] attributeArray:@[ attributesText ]];
        
        UILabel *label = [[UILabel alloc] init];
        [label.layer setMasksToBounds:YES];
        [label setTextAlignment:NSTextAlignmentLeft];
        [label setAttributedText:attributedString];
        [rightWinnerContainerView addSubview:label];
        
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(rightWinnerContainerView.mas_centerX);
            make.centerY.equalTo(rightWinnerContainerView.mas_centerY);
        }];
        
        label;
    });
    self.rightWinnerLabel = rightWinnerLabel;
    self.rightWinnerLabel.mas_key = [NSString stringWithFormat:@"rightWinnerLabel"];
    
    // 分割线
    UIView *separatorLineView = ({
        UIView *view = [[UIView alloc] init];
        [view setBackgroundColor:color_separator_line];
        [publicContainerView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(rightWinnerLabel.mas_bottom).offset(margin*0.85f).priority(749);
            make.left.equalTo(publicContainerView.mas_left).offset(0.0f);
            make.right.equalTo(publicContainerView.mas_right).offset(0.0f);
            make.height.equalTo(@(1.0f));
        }];
        
        view;
    });
    self.separatorLineView = separatorLineView;
    self.separatorLineView.mas_key = @"separatorLineView";
    
    // 约束完整性
    [self.publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(separatorLineView.mas_bottom).offset(0.0).priority(749);
    }];
    
}


#pragma mark - 设置数据模型
- (void)setMenuModel:(CFCGameBetDrawResultModel *)menuModel
{
    // 类型安全检查
    if (![menuModel isKindOfClass:[CFCGameBetDrawResultModel class]]) {
        return;
    }
    
    // 数据赋值
    _menuModel = menuModel;
    CFCGameBetDrawResultModel *model_original = (CFCGameBetDrawResultModel *)menuModel;
    
    // 开奖期号 - 左边大小
    CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
    CGFloat leftChinaWidth = [GAME_DRAW_RESULT_ISSUE_CHINA_WIDTH_STR widthWithFont:FONT_GAME_DRAW_RESULT_ISSUE_CHINESE
                                                               constrainedToHeight:MAXFLOAT] + margin*0.5f;
    CGFloat leftNumberWidth = [model_original.issueNumber widthWithFont:FONT_GAME_DRAW_RESULT_ISSUE_NUMBER
                                                    constrainedToHeight:MAXFLOAT] + margin*0.5f;
    CGFloat leftIssueWidth = leftChinaWidth + leftNumberWidth;
    [self.leftIssueNumberLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@(leftIssueWidth));
    }];

}


@end








