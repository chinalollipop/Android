//
//  游戏 - 投注页面头部区域 - 玩法选择 - 二级分类
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCPlayTypeContentSecondModel : NSObject

@property (nonatomic, copy) NSString *maxLengthNameString;

@property (nonatomic, strong) CFCGameBetPlayTypeGroupModel *menuGroupModel;

@end

NS_ASSUME_NONNULL_END
