//
// 游戏 - 投注区 - 官方模式 - 11选5 - 详情页面
//

#import "CFCGameBetPlayClassTableViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFC11X5PlayClassBaseOfficialViewController : CFCGameBetPlayClassTableViewController

/**
 * 最后一个选择的胆码下标
 * 键值对 <key = 标识码、标识码、标识码 value = 0,1,2...>
 */
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSNumber *> *lastSelectedIndexOfDanMaDictionary;


#pragma mark 事件处理 - 点击投注表格后处理数据 - 胆拖玩法
- (NSArray<NSIndexPath *> *)doRefreshDanTuoPlayClassCellRowAtIndexPath:(NSIndexPath *)indexPath
                                                            itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels
                                                            itemIndexs:(NSArray<NSNumber *> *)itemIndexs
                                                           danTuoCount:(NSInteger)count;

@end

NS_ASSUME_NONNULL_END
