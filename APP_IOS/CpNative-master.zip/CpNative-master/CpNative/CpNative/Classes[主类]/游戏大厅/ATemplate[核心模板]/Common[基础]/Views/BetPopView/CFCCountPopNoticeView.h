//
//  游戏 - 盘口倒计时结束提示框
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^CFCCountPopNoticeViewDismissBlock)(void);

@interface CFCCountPopNoticeView : UIView

@property(nonatomic, copy) NSString *content;

@property(nonatomic, assign) NSInteger count;

@property (nonatomic, copy) CFCCountPopNoticeViewDismissBlock afterDismissBlock;

+ (instancetype)sharePopNoticeView;

- (void)show;

- (void)dismiss;

@end

NS_ASSUME_NONNULL_END
