

#import "CFCGameBetPlayClassSectionNameView.h"

@interface CFCGameBetPlayClassSectionNameView ()
{
    UIImage      *_image;
    CALayer      *_contentLayer;
    CAShapeLayer *_maskLayer;
    UIColor      *_backgroundColor;
}
@end


@implementation CFCGameBetPlayClassSectionNameView


- (instancetype)initWithFrame:(CGRect)frame backgroundColor:(UIColor *)backgroundColor
{
    self = [super initWithFrame:frame];
    if (self) {
        _backgroundColor = backgroundColor;
        [self createViewAtuoLayout];
    }
    return self;
}


- (void)createViewAtuoLayout
{
    //construct your path
    CGMutablePathRef bubblePath = CGPathCreateMutable();
    CGPoint origin = self.bounds.origin;
    CGFloat width = CGRectGetWidth(self.bounds);
    CGFloat height = CGRectGetHeight(self.bounds);
    
    CGPathMoveToPoint(bubblePath, NULL, origin.x, origin.y);
    CGPathAddLineToPoint(bubblePath, NULL, origin.x + width - height/3.0f, origin.y);
    CGPathAddLineToPoint(bubblePath, NULL, origin.x + width, origin.y + height/2.0f);
    
    CGPathAddLineToPoint(bubblePath, NULL, origin.x + width - height/3.0f, origin.y + height);
    CGPathAddLineToPoint(bubblePath, NULL, origin.x, origin.y + height);
    CGPathAddLineToPoint(bubblePath, NULL, origin.x, origin.y);
    
    _maskLayer = [CAShapeLayer layer];
    _maskLayer.fillColor = [UIColor blackColor].CGColor;
    _maskLayer.strokeColor = [UIColor clearColor].CGColor;
    _maskLayer.frame = self.bounds;
    _maskLayer.contentsCenter = CGRectMake(0.5, 0.5, 0.1, 0.1);
    
    /*!
     * 非常关键设置自动拉伸的效果且不变形
     */
    _maskLayer.contentsScale = [UIScreen mainScreen].scale;
    
    _maskLayer.path = bubblePath;
    CGPathRelease(bubblePath);
    
    UIImage *image = [self imageFromColor:_backgroundColor rect:self.frame];
    
    _contentLayer = [CALayer layer];
    _contentLayer.mask = _maskLayer;
    _contentLayer.frame = self.bounds;
    _contentLayer.contents = (id)image.CGImage;
    [self.layer addSublayer:_contentLayer];
}

/**
 * 生成图片
 */
- (UIImage *)imageFromColor:(UIColor *)color rect:(CGRect)frame
{
    CGRect rect = CGRectMake(0, 0, frame.size.width, frame.size.height);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return img;
}


@end

