//
// 游戏 - 投注区 - 官方模式 - 北京快乐8 - 和值 - 和值 - 大小810
//

#import "CFCBJKL8PlayClassDaXiao810ViewController.h"
#import "CFCBJKL8PlayClassDaXiao810Model.h"


@interface CFCBJKL8PlayClassDaXiao810ViewController ()

@end


@implementation CFCBJKL8PlayClassDaXiao810ViewController


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.className = GAME_PLAY_CLASS_NAME_BJKL8_HEZHI_HZ_DAXIAO810;
        self.classCode = GAME_PLAY_CLASS_CODE_BJKL8_HEZHI_HZ_DAXIAO810;
    }
    return self;
}


#pragma mark -
#pragma mark 数据模型 - 静态数据模型
- (NSArray<CFCGameBetPlayClassSectionModel *> *)dataOfPlayClassModelsForBettingRecords
{
    return [CFCBJKL8PlayClassDaXiao810SectionModel buildingDataModles];
}


#pragma mark 投注结果 - 官方模式
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsOfficial:(NSDictionary *)dictOfBetSetting
{
    return [self bettingResultModelsForBettingRecordsTemplateN03:dictOfBetSetting];
}


@end

