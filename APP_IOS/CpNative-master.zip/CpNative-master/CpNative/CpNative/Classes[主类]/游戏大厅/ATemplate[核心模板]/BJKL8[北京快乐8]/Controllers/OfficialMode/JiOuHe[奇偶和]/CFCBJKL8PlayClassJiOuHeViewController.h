//
// 游戏 - 投注区 - 官方模式 - 北京快乐8 - 奇偶和 - 奇偶和 - 奇偶和
//

#import "CFCBJKL8PlayClassBaseOfficialViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCBJKL8PlayClassJiOuHeViewController : CFCBJKL8PlayClassBaseOfficialViewController

@end

NS_ASSUME_NONNULL_END
