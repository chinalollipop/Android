//
// 游戏 - 投注区 - 官方模式 - 11选5 - 任选复式 - 任选复式 - 任选六中五复式
//

#import "CFC11X5PlayClassRXFSRenXuan06Model.h"

@implementation CFC11X5PlayClassRXFSRenXuan06Model

+ (NSMutableArray *) buildingDataModlesForSection1
{
    NSMutableArray<CFC11X5PlayClassRXFSRenXuan06Model *> *models = [NSMutableArray array];
    {
        NSArray<NSString *> *names = @[ STR_NUMBER_01, STR_NUMBER_02, STR_NUMBER_03, STR_NUMBER_04, STR_NUMBER_05,
                                        STR_NUMBER_06, STR_NUMBER_07, STR_NUMBER_08, STR_NUMBER_09, STR_NUMBER_10,
                                        STR_NUMBER_11 ];
        NSArray<NSString *> *classNumbers = @[ STR_NUMDATA_01, STR_NUMDATA_02, STR_NUMDATA_03, STR_NUMDATA_04, STR_NUMDATA_05,
                                               STR_NUMDATA_06, STR_NUMDATA_07, STR_NUMDATA_08, STR_NUMDATA_09, STR_NUMDATA_10,
                                               STR_NUMDATA_11 ];
        for (int index = 0; index < names.count; index ++) {
            CFC11X5PlayClassRXFSRenXuan06Model *model = [[CFC11X5PlayClassRXFSRenXuan06Model alloc] init];
            // 名称
            [model setName:names[index]];
            [model setNameNormalFont:NAME_FONT_GAME_PLAY_MODEL_NUMBER_NORMAL];
            [model setNameSelectFont:NAME_FONT_GAME_PLAY_MODEL_NUMBER_SELECT];
            [model setNameNormalColor:NAME_COLOR_GAME_PLAY_MODEL_NORMAL];
            [model setNameSelectColor:NAME_COLOR_GAME_PLAY_MODEL_SELECT];
            [model setNameBackgroundColor:NAME_COLOR_GAME_PLAY_BACKGROUND_DEFAULT];
            // 赔率
            [model setOdds:ODDS_STRI_GAME_PLAY_MODEL_DEFAULT];
            [model setOddsNormalFont:ODDS_FONT_GAME_PLAY_MODEL_NORMAL];
            [model setOddsSelectFont:ODDS_FONT_GAME_PLAY_MODEL_SELECT];
            [model setOddsNormalColor:ODDS_COLOR_GAME_PLAY_MODEL_NORMAL];
            [model setOddsSelectColor:ODDS_COLOR_GAME_PLAY_MODEL_SELECT];
            [model setOddsBackgroundColor:ODDS_COLOR_GAME_PLAY_BACKGROUND_DEFAULT];
            // 号码
            [model setClassNumber:classNumbers[index]];
            [model setClassRemark:REMARK_STRI_GAME_PLAY_MODEL_DEFAULT];
            // 其它
            [model setType:CFCGameBetPlayClassItemType01];
            [model setIsSelected:GAME_PLAY_MODEL_SELECTED_DEFAULT];
            //
            [models addObject:model];
        }
    }
    return models;
}

@end


@implementation CFC11X5PlayClassRXFSRenXuan06SectionModel

+ (NSMutableArray *) buildingDataModles
{
    NSMutableArray<CFC11X5PlayClassRXFSRenXuan06SectionModel *> *models = [NSMutableArray array];
    {
        // 第一个分组
        CFC11X5PlayClassRXFSRenXuan06SectionModel *model1 = [[CFC11X5PlayClassRXFSRenXuan06SectionModel alloc] init];
        [model1 setTitle:@"选六中五"];
        [model1 setType:CFCGameBetPlayClassSectionTypeOfficial1];
        [model1 setColumnsCount:GAME_PLAY_MODEL_SECTION_COLUMN_N005];
        [model1 setIsShowHeader:GAME_PLAY_MODEL_SECTION_HEADER_SHOW_NO];
        [model1 setIsShowFooter:GAME_PLAY_MODEL_SECTION_FOOTER_SHOW_NO];
        [model1 setList:[CFC11X5PlayClassRXFSRenXuan06Model buildingDataModlesForSection1]];
        [models addObject:model1];
    }
    return models;
}

@end



