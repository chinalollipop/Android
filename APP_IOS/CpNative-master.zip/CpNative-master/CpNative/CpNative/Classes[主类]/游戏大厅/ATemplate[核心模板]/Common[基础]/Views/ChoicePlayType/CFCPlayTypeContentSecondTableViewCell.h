//
//  游戏 - 投注页面头部区域 - 玩法选择 - 二级分类
//

#import <UIKit/UIKit.h>
@class CFCPlayTypeContentSecondModel;

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_GAME_PLAY_TYPE_CONTENT_SECOND_TABLE_VIEW_CELL;

@protocol CFCPlayTypeContentSecondTableViewCellDelegate <NSObject>
@required
- (void)didSelectPlayTypeContentSecondModelAtIndexPath:(NSIndexPath *)indexPath
                                    playTypeClassIndex:(NSInteger)playTypeClassIndex
                                    playTypeClassModel:(CFCGameBetPlayTypeClassModel *)playTypeClassModel;
@end

@interface CFCPlayTypeContentSecondTableViewCell : UITableViewCell

@property (nonatomic, strong) NSIndexPath *indexPath;

@property (nonatomic, strong) CFCPlayTypeContentSecondModel *model;

@property (nonatomic, weak) id<CFCPlayTypeContentSecondTableViewCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
