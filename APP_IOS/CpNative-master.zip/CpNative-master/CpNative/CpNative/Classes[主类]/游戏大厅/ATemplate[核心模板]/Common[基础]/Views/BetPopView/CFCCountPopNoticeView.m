//
//  游戏 - 盘口倒计时结束提示框
//

#import "CFCCountPopNoticeView.h"
#import "CFCCountDownObject.h"


@interface CFCCountPopNoticeView()
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *noticeLabel;
@property (nonatomic, strong) UILabel *contentLabel;
@property (nonatomic, strong) UIView *contentView;
@property (nonatomic, strong) UIButton *coverAlphaButton;
@property (nonatomic, strong) CFCCountDownObject *countDownObject;
@end


@implementation CFCCountPopNoticeView

+ (instancetype)sharePopNoticeView
{
    static CFCCountPopNoticeView *_singetonInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _singetonInstance = [[super allocWithZone:NULL] initWithFrame:[UIScreen mainScreen].bounds];
    });
    return _singetonInstance;
}

#pragma mark - 系统方法
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self initViewControls];
        [self makeViewConstraints];
    }
    return self;
}

/** 添加控件 */
- (void)initViewControls
{
    [self addSubview:self.coverAlphaButton];
    [self addSubview:self.contentView];
    [self.contentView addSubview:self.titleLabel];
    [self.contentView addSubview:self.contentLabel];
    [self.contentView addSubview:self.noticeLabel];
}

/** 添加约束 */
- (void)makeViewConstraints
{
    CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
    CGFloat imageWidth = SCREEN_WIDTH * 0.55f;
    
    [self.coverAlphaButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0.0f);
        make.centerY.mas_equalTo(0.0f);
        make.width.mas_equalTo(imageWidth);
        make.height.mas_equalTo(imageWidth*0.7f);
    }];
    
    [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.centerY.mas_equalTo(0);
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.bottom.equalTo(self.contentLabel.mas_top).offset(-margin*1.5f);
    }];
    
    [self.noticeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.top.equalTo(self.contentLabel.mas_bottom).offset(margin*1.5f);
    }];
}

- (void)show
{
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    [window addSubview:self];
}

- (void)dismiss
{
    [self.countDownObject destoryTimer];
    
    [self removeFromSuperview];
 
    if (self.afterDismissBlock) {
        self.afterDismissBlock();
    }
}

- (void)coverAlphaButtonClickAction
{
    // [self dismiss];
}


#pragma mark - 懒加载
- (UIButton *)coverAlphaButton
{
    if(!_coverAlphaButton) {
        _coverAlphaButton = [[UIButton alloc] init];
        [_coverAlphaButton setAlpha:0.6f];
        [_coverAlphaButton setEnabled:YES];
        [_coverAlphaButton setBackgroundColor:[UIColor blackColor]];
        [_coverAlphaButton addTarget:self action:@selector(coverAlphaButtonClickAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _coverAlphaButton;
}

- (UIView *)contentView
{
    if(!_contentView) {
        _contentView = [[UIView alloc] init];
        _contentView.backgroundColor =[UIColor whiteColor];
        [_contentView addBorderWithColor:[UIColor whiteColor] cornerRadius:5.0f andWidth:1.0];
    }
    return _contentView;
}

- (UILabel *)titleLabel
{
    if(!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.text = @"当前已进入第";
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        _titleLabel.font = [UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)];
        _titleLabel.textColor = COLOR_HEXSTRING(@"#3A3A3A");
    }
    return _titleLabel;
}

- (UILabel *)noticeLabel
{
    if(!_noticeLabel) {
        _noticeLabel = [[UILabel alloc] init];
        _noticeLabel.text = @"请留意期号变化[0]";
        _noticeLabel.textAlignment = NSTextAlignmentCenter;
        _noticeLabel.font = [UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)];
        _noticeLabel.textColor = COLOR_HEXSTRING(@"#3A3A3A");
    }
    return _noticeLabel;
}

- (UILabel *)contentLabel
{
    if(!_contentLabel) {
        _contentLabel = [[UILabel alloc] init];
        [self setContent:@"0000000000"];
    }
    return _contentLabel;
}

- (void)setContent:(NSString *)content
{
    _content = content;
    
    if ([CFCSysUtil validateStringEmpty:content]) {
        _content = @"0000000000";
    }
    
    NSDictionary *attributesText = @{ NSFontAttributeName:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(18.0f)],
                                      NSForegroundColorAttributeName:COLOR_SYSTEM_MAIN_FONT_ASSIST_RED_DEFAULT };
    NSDictionary *attributesNumber = @{ NSFontAttributeName:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(20.0f)],
                                        NSForegroundColorAttributeName:COLOR_SYSTEM_MAIN_FONT_ASSIST_RED_DEFAULT };
    NSAttributedString *attributedString = [CFCSysUtil attributedString:@[ _content, @" 期" ]
                                                         attributeArray:@[ attributesNumber, attributesText]];
    [_contentLabel setAttributedText:attributedString];
}

- (void)setCount:(NSInteger)count
{
    _count = count;
    
    // 更新时间提示信息
    [self setNoticeLabelValue:count];
    
    // 倒计时
    {
        // 销毁旧定时器
        [self.countDownObject destoryTimer];
        // 创建新定时器
        long long currentDateSecond = [CFCDateUtil getCurrentDateSecond];
        [self.countDownObject countDownWithStratDate:[[NSDate alloc] initWithTimeIntervalSince1970:currentDateSecond]
                                          finishDate:[[NSDate alloc] initWithTimeIntervalSince1970:currentDateSecond + count]
                                       completeBlock:^(NSInteger timeInterval, NSInteger day, NSInteger hour, NSInteger minute, NSInteger second) {
                                           if (0 >= second) {
                                               [self setNoticeLabelValue:second];
                                               long long currentDateSecond = [CFCDateUtil getCurrentDateSecond];
                                               [self.countDownObject countDownWithStratDate:[[NSDate alloc] initWithTimeIntervalSince1970:currentDateSecond]
                                                                                 finishDate:[[NSDate alloc] initWithTimeIntervalSince1970:currentDateSecond + 1]
                                                                              completeBlock:^(NSInteger timeInterval, NSInteger day, NSInteger hour, NSInteger minute, NSInteger second) {
                                                                                  if (0 >= second) {
                                                                                      [self dismiss];
                                                                                  }
                                               }];
                                           } else {
                                               [self setNoticeLabelValue:second];
                                           }
                                       }];
    }
}

- (CFCCountDownObject *)countDownObject
{
    if(!_countDownObject) {
        _countDownObject = [[CFCCountDownObject alloc] init];
    }
    return _countDownObject;
}

- (void)setNoticeLabelValue:(NSInteger)count
{
    NSDictionary *attributesText = @{ NSFontAttributeName:[UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)],
                                      NSForegroundColorAttributeName:COLOR_HEXSTRING(@"#3A3A3A") };
    NSDictionary *attributesNumber = @{ NSFontAttributeName:[UIFont fontWithName:@"NotoMono" size:CFC_AUTOSIZING_FONT(17)],
                                        NSForegroundColorAttributeName:COLOR_HEXSTRING(@"#3A3A3A") };
    NSAttributedString *attributedString = [CFCSysUtil attributedString:@[ @"请留意期号变化", [NSString stringWithFormat:@"[%ld]", count] ]
                                                         attributeArray:@[ attributesText, attributesNumber ]];
    [_noticeLabel setAttributedText:attributedString];
}

@end

