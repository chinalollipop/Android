//
//  游戏 - 官方玩法 -> 投注项目，有操作按钮 -> 如：时时彩官方玩法中<五星、四星>
//
//  说明：此类以 UITableViewCell 实现。如果不能满足你的要求，请另外实现。
//

#import <UIKit/UIKit.h>
@class CFCGameBetPlayClassModel, CFCGameBetPlayClassSectionModel, CFCGameBetPlayClassCheckButton;

NS_ASSUME_NONNULL_BEGIN


UIKIT_EXTERN NSString * const CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_1_TABLE_VIEW_CELL;


@protocol CFCGameBetPlayClassTableViewCellProtocol <NSObject>
@required
- (void)createViewAtuoLayout;
- (void)setModel:(CFCGameBetPlayClassSectionModel *)model;
@end


@protocol CFCGameBetPlayClassOfficial1TableViewCellProtocol <CFCGameBetPlayClassTableViewCellProtocol>
@required
- (void)pressItemButtonViewAction:(UITapGestureRecognizer *)gesture;
- (void)doPlayClassCheckButtonAction:(CFCGameBetPlayClassCheckButton *)button;
- (BOOL)checkOperationButtonAll:(CFCGameBetPlayClassSectionModel *)model;
- (BOOL)checkOperationButtonDA:(CFCGameBetPlayClassSectionModel *)model;
- (BOOL)checkOperationButtonXIAO:(CFCGameBetPlayClassSectionModel *)model;
- (BOOL)checkOperationButtonJI:(CFCGameBetPlayClassSectionModel *)model;
- (BOOL)checkOperationButtonOU:(CFCGameBetPlayClassSectionModel *)model;
@end


@protocol CFCGameBetPlayClassOfficial1TableViewCellDelegate <NSObject>
@required
- (NSString *)itemNameOfMaxLengthInDataOfSectionModelArray:(CFCGameBetPlayClassModel *)model;
- (NSString *)itemOddsOfMaxLengthInDataOfSectionModelArray:(CFCGameBetPlayClassModel *)model;
@optional
- (void)didSelectPlayClassOfficial1TableViewCellRowAtIndexPath:(NSIndexPath *)indexPath
                                                    itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels
                                                    itemIndexs:(NSArray<NSNumber *> *)itemIndexs;
@end


@interface CFCGameBetPlayClassOfficial1TableViewCell : UITableViewCell <CFCGameBetPlayClassOfficial1TableViewCellProtocol>
/**
 * 根容器组件
 */
@property (nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonatomic, strong) UIView *publicContainerView;
/**
 * 分组标题
 */
@property (nonatomic, strong) UILabel *sectionTitleLabel;
/**
 * 投注按钮
 */
@property (nonatomic, strong) NSMutableArray<UILabel *> *bettingButtonArray;
/**
 * 操作按钮
 */
@property (nonatomic, strong) NSMutableArray<CFCGameBetPlayClassCheckButton *> *operationButtonArray;
/**
 * 数据下标
 */
@property (nonatomic, strong) NSIndexPath *indexPath;
/**
 * 数据模型
 */
@property (nonatomic, strong) CFCGameBetPlayClassSectionModel *model;
/**
 * 表格代理
 */
@property (nonatomic, weak) id<CFCGameBetPlayClassOfficial1TableViewCellDelegate> delegate;


/**
 * 操作事件 - 投注按钮
 */
- (void)pressItemButtonViewAction:(UITapGestureRecognizer *)gesture;
/**
 * 操作事件 - 操作按钮
 */
- (void)doPlayClassCheckButtonAction:(CFCGameBetPlayClassCheckButton *)button;
/**
 * 计算操作按钮状态 - 全
 */
- (BOOL)checkOperationButtonAll:(CFCGameBetPlayClassSectionModel *)model;
/**
 * 计算操作按钮状态 - 大
 */
- (BOOL)checkOperationButtonDA:(CFCGameBetPlayClassSectionModel *)model;
/**
 * 计算操作按钮状态 - 小
 */
- (BOOL)checkOperationButtonXIAO:(CFCGameBetPlayClassSectionModel *)model;
/**
 * 计算操作按钮状态 - 单
 */
- (BOOL)checkOperationButtonJI:(CFCGameBetPlayClassSectionModel *)model;
/**
 * 计算操作按钮状态 - 双
 */
- (BOOL)checkOperationButtonOU:(CFCGameBetPlayClassSectionModel *)model;


@end


NS_ASSUME_NONNULL_END

