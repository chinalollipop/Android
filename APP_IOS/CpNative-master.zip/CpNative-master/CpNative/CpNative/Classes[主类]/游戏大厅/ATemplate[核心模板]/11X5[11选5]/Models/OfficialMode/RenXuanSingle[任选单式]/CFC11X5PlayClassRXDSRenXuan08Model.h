//
// 游戏 - 投注区 - 官方模式 - 11选5 - 任选单式 - 任选单式 - 任选八中五单式
//

#import "CFCGameBetPlayClassModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFC11X5PlayClassRXDSRenXuan08Model : CFCGameBetPlayClassModel

+ (NSMutableArray *) buildingDataModlesForSection1;

@end


@interface CFC11X5PlayClassRXDSRenXuan08SectionModel : CFCGameBetPlayClassSectionModel

+ (NSMutableArray *) buildingDataModles;

@end

NS_ASSUME_NONNULL_END
