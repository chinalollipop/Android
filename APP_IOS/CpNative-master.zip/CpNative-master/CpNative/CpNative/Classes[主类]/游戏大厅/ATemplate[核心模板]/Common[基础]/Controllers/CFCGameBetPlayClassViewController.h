//
// 游戏 - 投注区 - 选注页面
//

#import "CFCBaseCommonViewController.h"

NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CFCGameBetPlayClassParentTableViewDidLeaveFromTopNotification;

// 投注表格刷新模式
typedef NS_ENUM(NSInteger, CFCPlayClassAfterSelectedItemOfRefreshMode) {
    CFCPlayClassAfterSelectedItemOfRefreshModeRows       = 1,
    CFCPlayClassAfterSelectedItemOfRefreshModeSections   = 2,
    CFCPlayClassAfterSelectedItemOfRefreshModeAll        = 3
};

@protocol CFCGameBetPlayClassDataComputeProtocol <NSObject>
@required
// 投注总数 - 在具体的子控制器中必须实现
- (NSInteger)numberOfBettingRecords;
// 投注内容 - 在具体的子控制器中必须实现
- (NSArray<NSString *> *)contentOfBettingRecords;
// 投注标识 - 在具体的子控制器中必须实现
- (NSArray *)selectedDataMarkOfBettingRecords;
// 投注备注 - 在具体的子控制器中必须实现
- (NSArray *)selectedDataRemarkOfBettingRecords;
// 赔率键值 - 在具体的子控制器中必须实现
- (NSArray<NSString *> *)keyOfOddsForBettingRecords;
// 数据模型 - 在具体的子控制器中必须实现
- (NSArray<CFCGameBetPlayClassSectionModel *> *)dataOfPlayClassModelsForBettingRecords;
// 投注结果 - 在具体的子控制器中必须实现
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecords:(NSDictionary *)dictOfBetSetting;
@end


@protocol CFCGameBetPlayClassViewControllerDelegate <NSObject>
@required
// 滑动处理 - 用于处理子控制器的滚动
- (void)scrollViewIsScrolling:(UIScrollView *)scrollView;
// 投注总数 - 在主页面更新用户的投注总数
- (BOOL)changeSumNumberOfBettingForMainGameBetViewController:(NSInteger)number;
// 投注内容 - 在主页面更新用户的投注内容
- (BOOL)changeContentsOfBettingForMainGameCoreViewController:(NSArray<NSString *> *)contents;
// 投注标识 - 获取已保存的具体玩法投注标识(选中或不选中)
- (NSArray *)selectedDataMarkOfBettingFromMainGameCoreViewController:(NSString *)tabClassCode;
// 投注标识 - 在主页面更新具体玩法投注标识(选中或不选中)
- (BOOL)changeSelectedDataMarkOfBettingForMainGameCoreViewController:(NSArray *)selectedDataMark tabClassCode:(NSString *)tabClassCode;
// 投注备注 - 获取已保存的具体玩法投注备注
- (NSArray *)selectedDataRemarkOfBettingFromMainGameCoreViewController:(NSString *)tabClassCode;
// 投注备注 - 在主页面更新具体玩法投注备注
- (BOOL)changeSelectedDataRemarkOfBettingForMainGameCoreViewController:(NSArray *)selectedDataRemark tabClassCode:(NSString *)tabClassCode;
// 玩法标识 - 获取当前页面具体玩法标识 currentSelectedPlayCodeOfPlayClass
- (NSString *)currentSelectedPlayCodeOfPlayClassFromMainGameCoreViewController;
// 玩法模式 - 获取当前主页面的玩法模式 currentPlayModeClass
- (CFCGameCorePlayModeClass)currentPlayModeClassForMainGameCoreViewController;

// 投注赔率 - 在主页面请求加载投注赔率数据
- (void)doLoadRefreshOddsDataFromPlayScrollViewController;

@end


@interface CFCGameBetPlayClassViewController : CFCBaseCommonViewController <ZJScrollPageViewChildVcDelegate, CFCGameBetPlayClassDataComputeProtocol, CFCGameBetPlayScrollToPlayClassViewControllerProtocol>

@property (nonatomic, strong) NSMutableArray<CFCGameBetPlayClassSectionModel *> *dataOfSectionModelArray; // 数据源

@property (strong, nonatomic) NSDictionary *allResponseDataOrCacheData; // 主页面请求网络数据

@property (nonatomic, weak) id<CFCGameBetPlayClassViewControllerDelegate> delegate; // 父控制器代理

@property (nonatomic, strong) UIScrollView *scrollView; // 子控制器的 ScrollView、TableView、CollectionView

@property (nonatomic, assign) CGSize scrollViewSize; // 根容器高度（UITableView、UICollectionView、UIScrollView）

@property (nonatomic, copy) NSString *tabClassTitle; // 具体玩法的标签 - 如：直选复式、直选单式

@property (nonatomic, copy) NSString *tabClassCode; // 具体玩法的标识 - 如：与标签（直选复式、直选单式）对应的标识码

@property (nonatomic, copy) NSString *className; // 具体玩法的名称 - 如：直选复式、直选单式

@property (nonatomic, copy) NSString *classCode; // 具体玩法标识码 - 如：与名称与（直选复式、直选单式）对应的标识码


#pragma mark 刷新界面表格
- (void)reloadRefreshViewData;
#pragma mark 创建界面表格
- (void)createUIRefreshView:(BOOL)force;


#pragma mark 必须实现 - 投注结果 - 官方模式
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsOfficial:(NSDictionary *)dictOfBetSetting;
#pragma mark 必须实现 - 投注结果 - 信用模式
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsCredit:(NSDictionary *)dictOfBetSetting;
#pragma mark 必须实现 - 投注结果 - 组合结果
- (CFCGameBetRecordModel *)buildindBettingResultModelForBettingRecordsOfCompose:(NSDictionary *)dictOfBetSetting;


#pragma mark 加载数据 - 加载完数据后操作
- (void)doBeforeBuildingStaticDataModlesOrNetworkData;
#pragma mark 加载数据 - 加载完数据后操作
- (void)doAfterBuildingStaticDataModlesOrNetworkData;
#pragma mark 加载数据 - 加载请求数据
- (void)buildingStaticDataModles:(NSDictionary<NSString *, NSObject *> *)responseData then:(void (^)(NSArray *dataModles))then;


#pragma mark 数据处理 - 返回当前长度最大的名称
- (NSString *)itemNameOfMaxLengthInDataOfSectionModelArray:(CFCGameBetPlayClassModel *)model;
#pragma mark 数据处理 - 返回当前长度最大的赔率
- (NSString *)itemOddsOfMaxLengthInDataOfSectionModelArray:(CFCGameBetPlayClassModel *)model;


#pragma mark 事件处理 - 点击投注表格操作事件
- (void)didSelectPlayClassCellRowAtIndexPath:(NSIndexPath *)indexPath
                                  itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels
                                  itemIndexs:(NSArray<NSNumber *> *)itemIndexs
                                  itemReload:(BOOL)itemReload;
#pragma mark 事件处理 - 点击投注表格后处理数据
- (NSArray<NSIndexPath *> *)doUpdatePlayClassCellModelsAtIndexPath:(NSIndexPath *)indexPath
                                                        itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels
                                                        itemIndexs:(NSArray<NSNumber *> *)itemIndexs;
#pragma mark 事件处理 - 点击投注表格后刷新表格
- (void)doReloadPlayClassSectionModelRowsAtIndexPaths:(NSArray<NSIndexPath *> *)indexPaths;
#pragma mark 事件处理 - 点击投注表格后刷新表格 - 刷新类型模式
- (CFCPlayClassAfterSelectedItemOfRefreshMode)doReloadPlayClassAfterSelectedItemOfRefreshMode;
#pragma mark 事件处理 - 点击投注表格后刷新主页
- (void)doRefreshMainUIOfGameBetViewControllerWithChangeBetNumber:(BOOL)changeBetNumber
                                                   changeContents:(BOOL)changeContents
                                          changeSelectedDataMarks:(BOOL)changeSelectedDataMarks
                                        changeSelectedDataRemarks:(BOOL)changeSelectedDataRemarks;


@end


NS_ASSUME_NONNULL_END

