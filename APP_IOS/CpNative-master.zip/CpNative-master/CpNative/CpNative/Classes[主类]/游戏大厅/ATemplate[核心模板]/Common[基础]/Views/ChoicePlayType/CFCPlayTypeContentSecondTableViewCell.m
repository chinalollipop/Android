//
//  游戏 - 投注页面头部区域 - 玩法选择 - 二级分类
//

#import "CFCPlayTypeContentSecondTableViewCell.h"
#import "CFCPlayTypeContentSecondModel.h"

CGFloat const LEFT_TITLE_PERCENT = 0.225f;

// Cell Identifier
NSString * const CELL_IDENTIFIER_GAME_PLAY_TYPE_CONTENT_SECOND_TABLE_VIEW_CELL = @"CFCPlayTypeContentSecondTableViewCellIdentifier";


@interface CFCPlayTypeContentSecondTableViewCell ()
/**
 * 根容器组件
 */
@property (nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonatomic, strong) UIView *publicContainerView;
/**
 * 左边容器
 */
@property (nonatomic, strong) UIView *leftContainerView;
/**
 * 右边容器
 */
@property (nonatomic, strong) UIView *rightContainerView;
/**
 * 左边标题
 */
@property (nonatomic, strong) UILabel *leftTitleLabel;
/**
 * 标签按钮
 */
@property (nonatomic, strong) NSMutableArray<UILabel *> *itemButtonArray;

@end


@implementation CFCPlayTypeContentSecondTableViewCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createViewAtuoLayout];
    }
    return self;
}


#pragma mark 创建子控件
- (void) createViewAtuoLayout
{
    // 根容器
    UIView *rootContainerView = ({
        UIView *view = [[UIView alloc] init];
        [self.contentView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@0.0f);
            make.top.equalTo(@0.0f);
            make.right.equalTo(@0.0f);
            make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
        }];
        
        view;
    });
    self.rootContainerView = rootContainerView;
    self.rootContainerView.mas_key = @"rootContainerView";
    
    // 公共容器
    UIView *publicContainerView = ({
        UIView *view = [[UIView alloc] init];
        [view.layer setMasksToBounds:YES];
        [view setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_WHITE];
        [rootContainerView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@0.0f);
            make.top.equalTo(@0.0f);
            make.right.equalTo(@0.0f);
            make.bottom.equalTo(rootContainerView.mas_bottom).offset(0.0f);
        }];
        
        view;
    });
    self.publicContainerView = publicContainerView;
    self.publicContainerView.mas_key = @"publicContainerView";
    
    // 左边容器
    UIView *leftContainerView = ({
        UIView *view = [[UIView alloc] init];
        [publicContainerView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(publicContainerView.mas_left).offset(0.0f);
            make.top.equalTo(publicContainerView.mas_top).offset(0.0f);
            make.bottom.equalTo(publicContainerView.mas_bottom).offset(0.0f);
            make.width.equalTo(@(self.frame.size.width*LEFT_TITLE_PERCENT));
        }];
        
        view;
    });
    self.leftContainerView = leftContainerView;
    self.leftContainerView.mas_key = @"leftContainerView";
    
    // 左边标题
    UILabel *leftTitleLabel = ({
        UILabel *label = [[UILabel alloc] init];
        [label setTextAlignment:NSTextAlignmentCenter];
        [leftContainerView addSubview:label];
        
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
            CGFloat height = [@"占位符" heightWithFont:FONT_GAME_PLAY_TYPE_TITLE constrainedToWidth:MAXFLOAT] + margin*1.2f;
            make.top.equalTo(leftContainerView.mas_top).offset(margin*1.0f);
            make.left.equalTo(leftContainerView.mas_left).offset(0.0f);
            make.right.equalTo(leftContainerView.mas_right).offset(0.0f);
            make.height.mas_equalTo(height);
        }];
        
        label;
    });
    self.leftTitleLabel = leftTitleLabel;
    self.leftTitleLabel.mas_key = @"leftTitleLabel";
    
    // 右边容器
    UIView *rightContainerView = ({
        UIView *view = [[UIView alloc] init];
        [publicContainerView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(leftContainerView.mas_right).offset(0.0f);
            make.top.equalTo(publicContainerView.mas_top).offset(0.0f);
            make.right.equalTo(publicContainerView.mas_right).offset(0.0f);
            make.bottom.equalTo(publicContainerView.mas_bottom).offset(0.0f);
        }];
        
        view;
    });
    self.rightContainerView = rightContainerView;
    self.rightContainerView.mas_key = @"rightContainerView";
    
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCPlayTypeContentSecondModel *)model
{
    // 类型安全检查
    if (![model isKindOfClass:[CFCPlayTypeContentSecondModel class]]) {
        return;
    }
    
    // 数据赋值
    _model = model;
    
    // 删除控件
    [self.rightContainerView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    // 计算变量
    CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
    CGFloat leftContainerWidth = SCREEN_WIDTH*LEFT_TITLE_PERCENT;
    
    // 左边标题
    {
        // 赋值标题
        NSString *name = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:model.menuGroupModel.name];
        NSDictionary *attributesName = @{ NSFontAttributeName:FONT_GAME_PLAY_TYPE_TITLE,
                                          NSForegroundColorAttributeName:COLOR_GAME_PLAY_TYPE_TITLE};
        NSAttributedString *attributedString = [CFCSysUtil attributedString:@[[NSString stringWithFormat:@"%@",name]]
                                                             attributeArray:@[attributesName]];
        [self.leftTitleLabel setAttributedText:attributedString];
        
        // 计算宽度
        CGFloat leftTitleWidth = [model.maxLengthNameString widthWithFont:FONT_GAME_PLAY_TYPE_TITLE constrainedToHeight:MAXFLOAT] + margin*2.0f;
        if (leftTitleWidth > leftContainerWidth) {
            leftContainerWidth = leftTitleWidth;
        }
        [self.leftContainerView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.width.equalTo(@(leftContainerWidth));
        }];
    }
    
    // 创建控件
    {
        // 字体颜色
        UIColor *nameColor = COLOR_GAME_PLAY_TYPE_TAG_TITLE_NORMAL;
        UIColor *borderColor = COLOR_GAME_PLAY_TYPE_BORDER_NORMAL;
        UIColor *backgroundColor = COLOR_GAME_PLAY_TYPE_BACKGROUND_NORMAL;
        UIFont *nameFont = FONT_GAME_PLAY_TYPE_TAG_TITLE_NORMAL;
        
        // 大小间距
        CGFloat item_gap_top = margin * 1.0f;
        CGFloat item_gap_bottom = margin * 1.0f;
        CGFloat item_gap_left_right = margin * 0.0f;
        CGFloat item_gap_vertical = margin * 0.6f;
        CGFloat item_gap_horizontal = margin * 0.6f;
        CGFloat itemRadius = margin*0.5f;
        CGFloat itemBorderWidth = 1.0f;
        CGFloat itemSizeWidth = 0.0f;
        CGFloat itemSizeHeight = [@"占位符" heightWithFont:nameFont constrainedToWidth:MAXFLOAT] + margin*1.2f;
        __block CGFloat itemLineWidth = item_gap_left_right;
        
        UILabel *lastItemButton = nil;
        self.itemButtonArray = @[].mutableCopy;
        for (int i = 0; i < model.menuGroupModel.childrenClass.count; i ++) {
            
            CFCGameBetPlayTypeClassModel *itemModel = model.menuGroupModel.childrenClass[i];
            
            nameColor = itemModel.isSelected ? COLOR_GAME_PLAY_TYPE_TAG_TITLE_SELECT : COLOR_GAME_PLAY_TYPE_TAG_TITLE_NORMAL;
            borderColor = itemModel.isSelected ? COLOR_GAME_PLAY_TYPE_BORDER_SELECT : COLOR_GAME_PLAY_TYPE_BORDER_NORMAL;
            backgroundColor = itemModel.isSelected ? COLOR_GAME_PLAY_TYPE_BACKGROUND_SELECT : COLOR_GAME_PLAY_TYPE_BACKGROUND_NORMAL;
            nameFont = itemModel.isSelected ? FONT_GAME_PLAY_TYPE_TAG_TITLE_SELECT : FONT_GAME_PLAY_TYPE_TAG_TITLE_NORMAL;
            
            UILabel *itemButton = ({
                UILabel *itemLabel = [[UILabel alloc] init];
                [itemLabel setTag:8000+i];
                [itemLabel.layer setMasksToBounds:YES];
                [itemLabel.layer setCornerRadius:itemRadius];
                [itemLabel.layer setBorderWidth:itemBorderWidth];
                [itemLabel.layer setBorderColor:borderColor.CGColor];
                [itemLabel setTextAlignment:NSTextAlignmentCenter];
                [itemLabel setUserInteractionEnabled:YES];
                [self.rightContainerView addSubview:itemLabel];
                
                NSString *name = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:itemModel.name];
                NSDictionary *attributesName = @{ NSFontAttributeName:nameFont, NSForegroundColorAttributeName:nameColor};
                NSAttributedString *attributedString = [CFCSysUtil attributedString:@[[NSString stringWithFormat:@"%@",name]]
                                                                     attributeArray:@[attributesName]];
                [itemLabel setAttributedText:attributedString];
                [itemLabel setBackgroundColor:backgroundColor];
                
                UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressItemButtonViewAction:)];
                [itemLabel addGestureRecognizer:tapGesture];
                
                itemSizeWidth = [itemModel.name widthWithFont:nameFont constrainedToHeight:MAXFLOAT] + margin*1.7f;
                itemLineWidth = itemLineWidth + itemSizeWidth + item_gap_horizontal;
                
                [itemLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
                    make.width.equalTo(@(itemSizeWidth));
                    make.height.equalTo(@(itemSizeHeight));
                    
                    if (!lastItemButton) {
                        make.top.equalTo(self.rightContainerView.mas_top).offset(item_gap_top);
                        make.left.equalTo(self.rightContainerView.mas_left).offset(item_gap_left_right);
                    } else {
                        if (itemLineWidth > (SCREEN_WIDTH - leftContainerWidth)) {
                            itemLineWidth = item_gap_left_right + itemSizeWidth + item_gap_horizontal;
                            make.top.equalTo(lastItemButton.mas_bottom).offset(item_gap_vertical);
                            make.left.equalTo(self.rightContainerView.mas_left).offset(item_gap_left_right);
                        } else {
                            make.top.equalTo(lastItemButton.mas_top).offset(0);
                            make.left.equalTo(lastItemButton.mas_right).offset(item_gap_horizontal);
                        }
                    }
                }];
                itemLabel.mas_key = [NSString stringWithFormat:@"itemContainerView%d",i];
                
                itemLabel;
            });
            [self.itemButtonArray addObject:itemButton];
            
            lastItemButton = itemButton;
        }
        
        // 分割线
        UIView *separatorLineView = ({
            UIView *view = [[UIView alloc] init];
            [self.publicContainerView addSubview:view];
            [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_LIGHTGRAY];
            
            [view mas_makeConstraints:^(MASConstraintMaker *make) {
                if (!lastItemButton) {
                    make.top.equalTo(self.publicContainerView.mas_top).offset(0.0f);
                } else {
                    make.top.equalTo(lastItemButton.mas_bottom).offset(item_gap_bottom);
                }
                make.left.equalTo(self.publicContainerView.mas_left).offset(0.0f);
                make.right.equalTo(self.publicContainerView.mas_right).offset(0.0f);
                make.height.equalTo(@(1.0f));
            }];
            
            view;
        });
        separatorLineView.mas_key = @"separatorLineView";
        
        // 约束的完整性
        [self.rightContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(separatorLineView.mas_bottom).offset(0.0f).priority(749);
        }];
    }
}


#pragma mark - 触发操作事件 - 投注按钮
- (void)pressItemButtonViewAction:(UITapGestureRecognizer *)gesture
{
    UILabel *itemView = (UILabel*)gesture.view;
    
    NSUInteger index = itemView.tag - 8000;
    
    CFCPlayTypeContentSecondModel *model = (CFCPlayTypeContentSecondModel *)self.model;
    
    if (index >= model.menuGroupModel.childrenClass.count) {
        CFCLog(@"数组越界，请检测代码。");
        return;
    }
    
    // 更新数据
    CFCGameBetPlayTypeClassModel *itemModel = model.menuGroupModel.childrenClass[index];
    [self.model.menuGroupModel.childrenClass enumerateObjectsUsingBlock:^(CFCGameBetPlayTypeClassModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        obj.isSelected = NO;
    }];
    itemModel.isSelected = YES;
    
    // 执行代理
    if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectPlayTypeContentSecondModelAtIndexPath:playTypeClassIndex:playTypeClassModel:)]) {
        [self.delegate didSelectPlayTypeContentSecondModelAtIndexPath:self.indexPath playTypeClassIndex:index playTypeClassModel:itemModel];
    }
}




@end

