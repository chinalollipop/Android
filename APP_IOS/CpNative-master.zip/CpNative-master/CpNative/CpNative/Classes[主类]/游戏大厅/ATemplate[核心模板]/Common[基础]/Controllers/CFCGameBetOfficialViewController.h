//
// 游戏 - 投注区 - 官方模式
//

#import "CFCGameBetViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCGameBetOfficialViewController : CFCGameBetViewController

@end

NS_ASSUME_NONNULL_END
