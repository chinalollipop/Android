//
// 游戏 - 投注区 - 开奖结果头部区域
//

#import "CFCGameBetDrawResultDefaultTopAreaView.h"
#import "CFCGameBetDrawResultModel.h"
#import "CFCScrollStringLabel.h"


@interface CFCGameBetDrawResultDefaultTopAreaView ()
@property (nonatomic, retain) dispatch_source_t timer;
@property (nonatomic, copy) NSString *maxWidthIssueNumberString;
@end


@implementation CFCGameBetDrawResultDefaultTopAreaView

- (instancetype)initWithFrame:(CGRect)frame
                       gameId:(NSString *)gameId
                     gameName:(NSString *)gameName
               gameIdentifier:(NSString *)gameIdentifier
                     playMode:(CFCGameCorePlayModeClass)playModeClass
             drawResultsModel:(CFCGameBetDrawResultModel *)drawResultModel
{
    self = [super initWithFrame:frame];
    if (self) {
        // 游戏信息
        _gameId = gameId;
        _gameName = gameName;
        _gameIdentifier = gameIdentifier;
        _playModeClass = playModeClass;
        
        // 开奖结果动画
        _isStartWinnerAnimation = NO;
        // 开奖结果数据
        _drawResultModel = drawResultModel;
        
        // 重新加载视图
        [self reloadDrawResult];
    }
    return self;
}

#pragma mark 重新加载
- (void)reloadDrawResult
{
    [self reloadDrawResult:self.drawResultModel];
}

#pragma mark 重新加载
- (void)reloadDrawResult:(CFCGameBetDrawResultModel *)drawResultModel
{
    // 赋值开奖的数据
    _drawResultModel = drawResultModel;
    
    // 删除所有子元素
    [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    // 开奖结果容器
    {
        CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
        
        // 开奖期号
        UILabel *rightIssueNumberLabel = ({
            UILabel *label = [UILabel new];
            [self addSubview:label];
            [label setUserInteractionEnabled:YES];
            [label setTextAlignment:NSTextAlignmentRight];
            
            [label mas_makeConstraints:^(MASConstraintMaker *make) {
                make.centerY.equalTo(self.mas_centerY).offset(0.0f);
                make.right.equalTo(self.mas_right).offset(-margin*0.5f);
            }];
            
            label;
        });
        self.rightIssueNumberLabel = rightIssueNumberLabel;
        self.rightIssueNumberLabel.mas_key = @"rightIssueNumberLabel";
        
        // 号码容器
        UIView *leftWinnerContainerView = ({
            UIView *view = [[UIView alloc] init];
            [self addSubview:view];
            
            [view mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.equalTo(self.mas_left).offset(0.0f);
                make.top.equalTo(self.mas_top).offset(0.0f);
                make.right.equalTo(rightIssueNumberLabel.mas_left).offset(0.0f);
                make.bottom.equalTo(self.mas_bottom).offset(0.0f);
            }];
            
            view;
        });
        self.leftWinnerContainerView = leftWinnerContainerView;
        self.leftWinnerContainerView.mas_key = @"leftWinnerContainerView";
    }
    
    // 开奖结果详情
    [self createViewAtuoLayout];
}


#pragma mark 创建子控件
- (void) createViewAtuoLayout
{
    // 类型安全检查
    if (![self.drawResultModel isKindOfClass:[CFCGameBetDrawResultModel class]]) {
        return;
    }
    
    
    // 开奖期号 - 容器宽度
    NSString *leftMaxIssueString = [self maxWidthOfIssueNumberString];
    if (leftMaxIssueString.length < GAME_DRAW_RESULT_WINNER_NUMBE_WIDTH_TOP_STR_DEF.length) {
        leftMaxIssueString = GAME_DRAW_RESULT_WINNER_NUMBE_WIDTH_TOP_STR_DEF;
    }
    CGFloat rightChinaWidth = [GAME_DRAW_RESULT_ISSUE_CHINA_WIDTH_STR widthWithFont:FONT_GAME_DRAW_RESULT_ISSUE_CHINESE
                                                                constrainedToHeight:MAXFLOAT];
    CGFloat rightNumberWidth = [leftMaxIssueString widthWithFont:FONT_GAME_DRAW_RESULT_ISSUE_NUMBER
                                             constrainedToHeight:MAXFLOAT];
    CGFloat rightIssueWidth = rightChinaWidth + rightNumberWidth;
    [self.rightIssueNumberLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@(rightIssueWidth));
    }];
    
    
    // 开奖期号 - 数据赋值
    NSString *shortIssueString = self.drawResultModel.issueNumber;
    NSString *shortIssueMaxString = [self maxWidthOfIssueNumberString];
    if (self.drawResultModel.issueNumber.length > shortIssueMaxString.length) {
        shortIssueString = [self.drawResultModel.issueNumber substringFromIndex:self.drawResultModel.issueNumber.length-shortIssueMaxString.length];
    }
    if (shortIssueString.length < GAME_DRAW_RESULT_WINNER_NUMBE_WIDTH_TOP_STR_DEF.length) {
        shortIssueString = [NSString stringWithFormat:@"%03ld", shortIssueString.integerValue];
    }
    NSDictionary *attributesText = @{ NSFontAttributeName:FONT_GAME_DRAW_RESULT_ISSUE_CHINESE,
                                      NSForegroundColorAttributeName:COLOR_GAME_DRAW_RESULT_ISSUE_CHINESE };
    NSDictionary *attributesNumber = @{ NSFontAttributeName:FONT_GAME_DRAW_RESULT_ISSUE_NUMBER,
                                        NSForegroundColorAttributeName:COLOR_GAME_DRAW_RESULT_ISSUE_NUMBER };
    NSAttributedString *attributedString = [CFCSysUtil attributedString:@[ @"第", shortIssueString, @"期" ]
                                                         attributeArray:@[ attributesText, attributesNumber, attributesText ]];
    [self.rightIssueNumberLabel setAttributedText:attributedString];
    
    
    // 开奖号码 - 删除控件
    [self.leftWinnerContainerView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    
    // 开奖号码 - 开奖状态
    if (self.drawResultModel.isDrawed) {

        // 判断动画类型
        switch ([self animationOfDrawResultAnimationType]) {
                // 动画类型1 -> 文字开奖中
            case CFCGameBetDrawResultAnimationType1: {
                
                // 开奖号码区域
                [self createWinnerViewAtuoLayout:rightIssueWidth];
                
                break;
            }
                // 动画类型2 -> 开奖号动画
            case CFCGameBetDrawResultAnimationType2: {
                
                // 开奖号码区域
                [self createWinnerViewAtuoLayout:rightIssueWidth];
                
                // 停止开奖动画
                [self endAnimationForDrawResultWinnerNumber:self.drawResultModel];
                
                break;
            }
            default: {
                break;
            }
        }
        
    } else {
        
        // 判断动画类型
        switch ([self animationOfDrawResultAnimationType]) {
                // 动画类型1 -> 文字开奖中
            case CFCGameBetDrawResultAnimationType1: {
                
                // 正在开奖
                UILabel *statusLabel = ({
                    
                    NSDictionary *attributesText = @{ NSFontAttributeName:FONT_GAME_DRAW_RESULT_BUTTON_TITLE,
                                                      NSForegroundColorAttributeName:COLOR_GAME_DRAW_RESULT_BUTTON_TITLE };
                    NSAttributedString *attributedString = [CFCSysUtil attributedString:@[ @"开奖中..." ]
                                                                         attributeArray:@[ attributesText ]];
                    
                    UILabel *itemLabel = [[UILabel alloc] init];
                    [itemLabel.layer setMasksToBounds:YES];
                    [itemLabel setUserInteractionEnabled:YES];
                    [itemLabel setTextAlignment:NSTextAlignmentCenter];
                    [itemLabel setAttributedText:attributedString];
                    [self.leftWinnerContainerView addSubview:itemLabel];
                    
                    [itemLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
                        make.top.equalTo(self.leftWinnerContainerView.mas_top);
                        make.left.equalTo(self.leftWinnerContainerView.mas_left);
                        make.right.equalTo(self.rightIssueNumberLabel.mas_left);
                        make.bottom.equalTo(self.leftWinnerContainerView.mas_bottom);
                    }];
                    
                    itemLabel;
                });
                statusLabel.mas_key = [NSString stringWithFormat:@"statusLabel"];
                
                break;
            }
                // 动画类型2 -> 开奖号动画
            case CFCGameBetDrawResultAnimationType2: {
                
                // 开奖号码区域
                [self createWinnerViewAtuoLayout:rightIssueWidth];
                
                // 开启开奖动画
                [self startAnimationForDrawResultWinnerNumber:self.drawResultModel];
                
                break;
            }
            default: {
                break;
            }
        } // switch
        
    }
    
}

#pragma mark 创建开奖控件
- (void) createWinnerViewAtuoLayout:(CGFloat)rightIssueWidth
{
    // 号码列数
    if (self.drawResultModel.winnerNumberArray.count > 0 && self.drawResultModel.winnerNumberArray.count <= GAME_DRAW_RESULT_WINNER_NUMBER_COLUMN_HEADER) {
        
        // 大小间距
        CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
        CGFloat itemContainerHeight = [[self class] heightForHeaderDrawResultsAreaWithModel:self.drawResultModel];
        NSInteger column = (self.drawResultModel.winnerNumberArray.count > 0 ? self.drawResultModel.winnerNumberArray.count : GAME_DRAW_RESULT_WINNER_NUMBER_COLUMN_HEADER);
        CGSize itemSize = [self itemSizeOfWinnerNumber];
        CGFloat itemSizeWidth = itemSize.width;
        CGFloat itemSizeHeight = itemSize.height;
        CGFloat top_margin = GAME_DRAW_RESULT_WINNER_NUMBER_TOP_MARGIN;
        CGFloat item_margin = GAME_DRAW_RESULT_WINNER_NUMBER_ITEM_MARGIN;
        CGFloat left_margin = (self.frame.size.width - rightIssueWidth - item_margin * (column-1) - itemSizeWidth * column) / 2.0f;
        if (left_margin < 0) {
            left_margin = 0;
        }
        
        // 开奖号码
        CFCScrollStringLabel *lastItemLabel = nil;
        self.leftWinnerLabelArray = @[].mutableCopy;
        for (int i = 0; i < self.drawResultModel.winnerNumberArray.count; i ++) {
            
            // 字体设置
            UIFont *itemNameFont = self.drawResultModel.winnerNumberFontArray[i];
            UIColor *itemNameColor = self.drawResultModel.winnerNumberColorArray[i];
            UIColor *itemBackgroundColor = self.drawResultModel.winnerNumberBackgroundColorArray[i];
            CFCGameBetDrawResultWinNumberType winNumberType = self.drawResultModel.winnerNumberTypeArray[i].integerValue;
            
            // 开奖号码
            NSString *itemName = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.drawResultModel.winnerNumberArray[i]];
            
            // 描述控件
            CFCScrollStringLabel *itemLabel = ({
                CFCScrollStringLabel *itemLabel = [[CFCScrollStringLabel alloc] init];
                [self.leftWinnerContainerView addSubview:itemLabel];
                
                // 类型1 -> 开奖号码类型 -> 如：开奖号码背景圆形边框
                if (CFCGameBetDrawResultWinNumberType1 == winNumberType) {
                    [itemLabel addCornerRadius:itemSizeWidth/2.0f];
                }
                // 类型2 -> 开奖号码类型 -> 如：开奖号码背景方形边框
                else if (CFCGameBetDrawResultWinNumberType2 == winNumberType) {
                    [itemLabel addBorderWithColor:COLOR_GAME_DRAW_RESULT_ITEM_BORDER_COLOR_BLACK cornerRadius:margin*0.50f andWidth:1.0f];
                }
                
                // 计算位置大小（注意：此处不能使用Maonry）
                CGRect frame = CGRectZero;
                if (!lastItemLabel) {
                    frame = CGRectMake(left_margin, top_margin, itemSizeWidth, itemSizeHeight);
                    if (self.drawResultModel.winnerNumberArray.count <= column) {
                        frame = CGRectMake(left_margin, (itemContainerHeight-itemSizeHeight)/2.0f, itemSizeWidth, itemSizeHeight);
                    }
                } else {
                    if (0 == i % column) {
                        frame = CGRectMake(left_margin, CGRectGetMaxY(lastItemLabel.frame)+item_margin, itemSizeWidth, itemSizeHeight);
                    } else {
                        frame = CGRectMake(CGRectGetMaxX(lastItemLabel.frame)+item_margin,
                                           CGRectGetMinY(lastItemLabel.frame),
                                           itemSizeWidth,
                                           itemSizeHeight);
                    }
                }
                [itemLabel setFrame:frame];
                [itemLabel setFont:itemNameFont];
                [itemLabel setTextColor:itemNameColor];
                [itemLabel setTextAlignment:NSTextAlignmentCenter];
                [itemLabel setBackgroundColor:itemBackgroundColor];
                [itemLabel.layer setMasksToBounds:YES];
                [itemLabel setScrollDirection:CFCScrollDirectionUp];
                [itemLabel setAnimateDuration:CFC_GAME_PLAY_WINNER_NUMBER_ANIMATE_DURATION];
                [itemLabel setText:itemName];
                
                itemLabel;
            });
            [self.leftWinnerLabelArray addObject:itemLabel];
            
            lastItemLabel = itemLabel;
            
        }
        
    } else {
        
        // 点击查看
        UILabel *buttonLabel = ({
            
            NSDictionary *attributesText = @{ NSFontAttributeName:FONT_GAME_DRAW_RESULT_BUTTON_TITLE,
                                              NSForegroundColorAttributeName:COLOR_GAME_DRAW_RESULT_BUTTON_TITLE };
            NSAttributedString *attributedString = [CFCSysUtil attributedString:@[ @"点击查看开奖结果" ]
                                                                 attributeArray:@[ attributesText ]];
            
            UILabel *itemLabel = [[UILabel alloc] init];
            [itemLabel.layer setMasksToBounds:YES];
            [itemLabel setUserInteractionEnabled:YES];
            [itemLabel setTextAlignment:NSTextAlignmentCenter];
            [itemLabel setAttributedText:attributedString];
            [self.leftWinnerContainerView addSubview:itemLabel];
            
            [itemLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(self.leftWinnerContainerView.mas_top);
                make.left.equalTo(self.leftWinnerContainerView.mas_left);
                make.right.equalTo(self.rightIssueNumberLabel.mas_left);
                make.bottom.equalTo(self.leftWinnerContainerView.mas_bottom);
            }];
            
            itemLabel;
        });
        buttonLabel.mas_key = [NSString stringWithFormat:@"buttonLabel"];
        
    }
}

#pragma mark 开奖号码大小
- (CGSize)itemSizeOfWinnerNumber
{
    return [CFCGameUtil getDrawResultsItemSizeOfWinnerNumber];
}

#pragma mark 开奖结果期号大小
- (NSString *)maxWidthOfIssueNumberString
{
    return [CFCGameUtil getMaxWidthOfIssueNumberStringByTypeID:self.gameIdentifier];
}

#pragma mark 开奖结果区域高度
+ (CGFloat)heightForHeaderDrawResultsAreaWithModel:(CFCGameBetDrawResultModel *)drawResultModel
{
    return CFC_GAME_PLAY_OFFICIAL_SCROLL_TABLEVIEW_HEADER_DRAW_RESULTS_HEIGHT;
}

#pragma mark 开奖结果动画效果 - 动画类型
- (CFCGameBetDrawResultAnimationType)animationOfDrawResultAnimationType
{
    return CFCGameBetDrawResultAnimationType1;
}

#pragma mark 开奖结果动画效果 - 开始动画
- (void)startAnimationForDrawResultWinnerNumber:(CFCGameBetDrawResultModel *)drawResultModel
{
    // 开奖结果数据
    _drawResultModel = drawResultModel;
    
    // 开奖动画的开启状态值
    [self setIsStartWinnerAnimation:YES];
    
    // 判断动画类型
    switch ([self animationOfDrawResultAnimationType]) {
            // 动画类型1 -> 文字开奖中
        case CFCGameBetDrawResultAnimationType1: {
            
            // 重绘开奖界面
            [self createViewAtuoLayout];
            
            break;
        }
            // 动画类型2 -> 开奖号动画
        case CFCGameBetDrawResultAnimationType2: {

            // 开启定时器进行倒计时
            if (_timer == nil) {
                WEAKSELF(weakSelf);
                if (self.isStartWinnerAnimation) {
                    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
                    _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
                    dispatch_source_set_timer(_timer, dispatch_walltime(NULL, 0), CFC_GAME_PLAY_WINNER_NUMBER_ANIMATE_DURATION*NSEC_PER_SEC, 0);
                    dispatch_source_set_event_handler(_timer, ^{
                        if(!weakSelf.isStartWinnerAnimation) {
                            dispatch_source_cancel(_timer);
                            _timer = nil;
                        } else {
                            dispatch_async(dispatch_get_main_queue(), ^{
                                [weakSelf animationWithDrawResultWinnerNumber:drawResultModel];
                            });
                        }
                    });
                    dispatch_resume(_timer);
                }
            }
            
            // 开奖期号
            NSString *shortIssueString = drawResultModel.issueNumber;
            NSString *shortIssueMaxString = [self maxWidthOfIssueNumberString];
            if (drawResultModel.issueNumber.length > shortIssueMaxString.length) {
                shortIssueString = [drawResultModel.issueNumber substringFromIndex:drawResultModel.issueNumber.length-shortIssueMaxString.length];
            }
            if (shortIssueString.length < GAME_DRAW_RESULT_WINNER_NUMBE_WIDTH_TOP_STR_DEF.length) {
                shortIssueString = [NSString stringWithFormat:@"%03ld", shortIssueString.integerValue];
            }
            NSDictionary *attributesText = @{ NSFontAttributeName:FONT_GAME_DRAW_RESULT_ISSUE_CHINESE,
                                              NSForegroundColorAttributeName:COLOR_GAME_DRAW_RESULT_ISSUE_CHINESE };
            NSDictionary *attributesNumber = @{ NSFontAttributeName:FONT_GAME_DRAW_RESULT_ISSUE_NUMBER,
                                                NSForegroundColorAttributeName:COLOR_GAME_DRAW_RESULT_ISSUE_NUMBER };
            NSAttributedString *attributedString = [CFCSysUtil attributedString:@[ @"第", shortIssueString, @"期" ]
                                                                 attributeArray:@[ attributesText, attributesNumber, attributesText ]];
            [self.rightIssueNumberLabel setAttributedText:attributedString];
            
            break;
        }
        default: {
            break;
        }
    }
}


#pragma mark 开奖结果动画效果 - 结束动画
- (void)endAnimationForDrawResultWinnerNumber:(CFCGameBetDrawResultModel *)drawResultModel
{
    // 开奖结果数据
    _drawResultModel = drawResultModel;
    
    // 开奖动画的开启状态值
    [self setIsStartWinnerAnimation:NO];
    
    // 判断动画类型
    switch ([self animationOfDrawResultAnimationType]) {
            // 动画类型1 -> 文字开奖中
        case CFCGameBetDrawResultAnimationType1: {
            
            // 重绘开奖界面
            [self createViewAtuoLayout];
            
            break;
        }
            // 动画类型2 -> 开奖号动画
        case CFCGameBetDrawResultAnimationType2: {

            // 释放定时器的内存资源
            if (_timer) {
                dispatch_source_cancel(_timer);
                _timer = nil;
            }
            
            break;
        }
        default: {
            break;
        }
    }
}

#pragma mark 开奖结果动画效果 - 动画过程
- (void)animationWithDrawResultWinnerNumber:(CFCGameBetDrawResultModel *)drawResultModel
{
    // 开奖动画的开启状态值
    if(!self.isStartWinnerAnimation) {
        return;
    }
    
    // TODO: 动画转动号码
    
}


@end





