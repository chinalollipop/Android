

#import "CFCCountTimerUtil.h"


@interface CFCCountTimerUtil ()

@property (nonatomic, copy) NSString *gameId; // 游戏主键
@property (nonatomic, copy) NSString *gameName; // 游戏名称
@property (nonatomic, copy) NSString *gameIdentifier; // 游戏标识

@property (nonatomic, strong) UILabel *hourLabel;
@property (nonatomic, strong) UILabel *minuteLabel;
@property (nonatomic, strong) UILabel *secondLabel;

@property(nonatomic, retain) dispatch_source_t timer; // 定时器
@property (nonatomic, assign) NSInteger timer_timeout; // 倒计时长

@end


@implementation CFCCountTimerUtil


#pragma mark -
#pragma mark 定时器单例
+ (instancetype)sharedCountTimerUtil
{
    static CFCCountTimerUtil *_singetonInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken,^{
        if (nil == _singetonInstance) {
            _singetonInstance = [[super allocWithZone:NULL] init];
        }
    });
    return _singetonInstance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone
{
    return [[self class] sharedCountTimerUtil];
}

- (id)copyWithZone:(struct _NSZone *)zone
{
    return [[self class] sharedCountTimerUtil];
}


#pragma mark -
#pragma mark 根据日期 NSDate 类型倒计时
- (void)countDownWithBeginDate:(NSDate *)beginDate
                    finishDate:(NSDate *)finishDate
                        gameId:(NSString *)gameId
                      gameName:(NSString *)gameName
                gameIdentifier:(NSString *)gameIdentifier
                     hourLabel:(UILabel *)hourLabel
                   minuteLabel:(UILabel *)minuteLabel
                   secondLabel:(UILabel *)secondLabel
                         block:(void (^)(NSInteger timeInterval, NSInteger day, NSInteger hour, NSInteger minute, NSInteger second))block
{
    // 切换了则释放旧定时器
    if (![gameId isEqualToString:[CFCCountTimerUtil sharedCountTimerUtil].gameId]
        || ![gameIdentifier isEqualToString:[CFCCountTimerUtil sharedCountTimerUtil].gameIdentifier]) {
        [[CFCCountTimerUtil sharedCountTimerUtil] destoryTimer];
        //
        [CFCCountTimerUtil sharedCountTimerUtil].gameId = gameId;
        [CFCCountTimerUtil sharedCountTimerUtil].gameName = gameName;
        [CFCCountTimerUtil sharedCountTimerUtil].gameIdentifier = gameIdentifier;
    }
    
    // 切换保存计时控件更新
    {
        [CFCCountTimerUtil sharedCountTimerUtil].hourLabel = hourLabel;
        [CFCCountTimerUtil sharedCountTimerUtil].minuteLabel = minuteLabel;
        [CFCCountTimerUtil sharedCountTimerUtil].secondLabel = secondLabel;
    }
    
    // 判断截止日期是否合法
    NSTimeInterval timeInterval = [finishDate timeIntervalSinceDate:beginDate];
    if (timeInterval <= 0.0) {
        // 释放定时器资源
        [[CFCCountTimerUtil sharedCountTimerUtil] destoryTimer];
        // 倒计时结束操作
        dispatch_async(dispatch_get_main_queue(), ^{
            [[CFCCountTimerUtil sharedCountTimerUtil] refreshUIHour:0 minute:0 second:0];
            if (block) {
                block(0, 0, 0, 0, 0);
            }
        });
        return;
    }
    
    // 定时器为空，则创建新定时器
    if (APPINFORMATION.isCountTimerEnable) {
        if ([CFCCountTimerUtil sharedCountTimerUtil].timer == nil) {
            [CFCCountTimerUtil sharedCountTimerUtil].timer_timeout = (NSInteger)timeInterval;
            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
            [CFCCountTimerUtil sharedCountTimerUtil].timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
            dispatch_source_set_timer([CFCCountTimerUtil sharedCountTimerUtil].timer, dispatch_walltime(NULL, 0), 1.0*NSEC_PER_SEC, 0); // 每秒执行
            dispatch_source_set_event_handler([CFCCountTimerUtil sharedCountTimerUtil].timer, ^{
                if ([CFCCountTimerUtil sharedCountTimerUtil].timer_timeout <= 0) {
                    // 释放定时器资源
                    [[CFCCountTimerUtil sharedCountTimerUtil] destoryTimer];
                    // 倒计时结束操作
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [[CFCCountTimerUtil sharedCountTimerUtil] refreshUIHour:0 minute:0 second:0];
                        if (block) {
                            block(0, 0, 0, 0, 0);
                        }
                    });
                } else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        NSInteger days = (NSInteger)([CFCCountTimerUtil sharedCountTimerUtil].timer_timeout/(3600*24));
                        NSInteger hours = (NSInteger)(([CFCCountTimerUtil sharedCountTimerUtil].timer_timeout-days*24*3600)/3600);
                        NSInteger minute = (NSInteger)(([CFCCountTimerUtil sharedCountTimerUtil].timer_timeout-days*24*3600-hours*3600)/60);
                        NSInteger second = (NSInteger)([CFCCountTimerUtil sharedCountTimerUtil].timer_timeout-days*24*3600-hours*3600-minute*60);
                        [[CFCCountTimerUtil sharedCountTimerUtil] refreshUIHour:hours minute:minute second:second];
                        if (block) {
                            block([CFCCountTimerUtil sharedCountTimerUtil].timer_timeout, days, hours, minute, second);
                        }
                    });
                    [CFCCountTimerUtil sharedCountTimerUtil].timer_timeout --;
                }
            });
            dispatch_resume([CFCCountTimerUtil sharedCountTimerUtil].timer);
        } else {
            [CFCCountTimerUtil sharedCountTimerUtil].timer_timeout = (NSInteger)timeInterval;
        }
    } else {
        [[CFCCountTimerUtil sharedCountTimerUtil] destoryTimer];
    }
    
}

- (void)refreshUIHour:(NSInteger)hour minute:(NSInteger)minute second:(NSInteger)second
{
    // 时
    NSString *hour_value = @"00";
    if (hour <= 0) {
        hour_value = @"00";
    } else if (hour < 10) {
        hour_value = [NSString stringWithFormat:@"0%ld",(long)hour];
    } else {
        hour_value = [NSString stringWithFormat:@"%ld",(long)hour];
    }
    [CFCCountTimerUtil sharedCountTimerUtil].hourLabel.text = hour_value;
    
    // 分
    NSString *minute_value = @"00";
    if (minute <= 0) {
        minute_value = @"00";
    } else if (minute < 10) {
        minute_value = [NSString stringWithFormat:@"0%ld",(long)minute];
    } else {
        minute_value = [NSString stringWithFormat:@"%ld",(long)minute];
    }
    [CFCCountTimerUtil sharedCountTimerUtil].minuteLabel.text = minute_value;
    
    // 秒
    NSString *second_value = @"00";
    if (second <= 0) {
        second_value = @"00";
    } else if (second < 10) {
        second_value = [NSString stringWithFormat:@"0%ld",(long)second];
    } else {
        second_value = [NSString stringWithFormat:@"%ld",(long)second];
    }
    [CFCCountTimerUtil sharedCountTimerUtil].secondLabel.text = second_value;
    
    /*
    // 打印日志
    CFCLog(@"盘口倒计时 => [%@-%@-%@] => 时间 %@:%@:%@",
           [CFCCountTimerUtil sharedCountTimerUtil].gameId,
           [CFCCountTimerUtil sharedCountTimerUtil].gameIdentifier,
           [CFCCountTimerUtil sharedCountTimerUtil].gameName,
           hour_value, minute_value, second_value);
    */
}

#pragma mark 销毁定时器
- (void)destoryTimer
{
    if ([CFCCountTimerUtil sharedCountTimerUtil].timer) {
        CFCLog(@"释放定时器[盘口倒计时][%@-%@-%@]",
               [CFCCountTimerUtil sharedCountTimerUtil].gameId,
               [CFCCountTimerUtil sharedCountTimerUtil].gameIdentifier,
               [CFCCountTimerUtil sharedCountTimerUtil].gameName);
        dispatch_source_cancel([CFCCountTimerUtil sharedCountTimerUtil].timer);
        [CFCCountTimerUtil sharedCountTimerUtil].timer = nil;
    }
}

@end

