//
// 游戏 - 投注区 - 官方模式 - 11选5 - 定位胆 - 定位胆 - 定位胆
//

#import "CFC11X5PlayClassDWDDingWeiDanViewController.h"
#import "CFC11X5PlayClassDWDDingWeiDanModel.h"


@interface CFC11X5PlayClassDWDDingWeiDanViewController ()

@end


@implementation CFC11X5PlayClassDWDDingWeiDanViewController


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.className = GAME_PLAY_CLASS_NAME_11X5_DINGWEIDAN_DWD_DINGWEIDAN;
        self.classCode = GAME_PLAY_CLASS_CODE_11X5_DINGWEIDAN_DWD_DINGWEIDAN;
    }
    return self;
}


#pragma mark -
#pragma mark 数据模型 - 静态数据模型
- (NSArray<CFCGameBetPlayClassSectionModel *> *)dataOfPlayClassModelsForBettingRecords
{
    return [CFC11X5PlayClassDWDDingWeiDanSectionModel buildingDataModles];
}


#pragma mark 投注结果 - 官方模式
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsOfficial:(NSDictionary *)dictOfBetSetting
{
    return [self bettingResultModelsForBettingRecordsTemplateN01:dictOfBetSetting];
}


@end
