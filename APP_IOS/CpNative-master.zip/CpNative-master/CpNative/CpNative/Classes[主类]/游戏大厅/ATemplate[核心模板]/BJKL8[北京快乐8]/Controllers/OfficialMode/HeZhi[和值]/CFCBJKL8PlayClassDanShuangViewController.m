//
// 游戏 - 投注区 - 官方模式 - 北京快乐8 - 和值 - 和值 - 单双
//

#import "CFCBJKL8PlayClassDanShuangViewController.h"
#import "CFCBJKL8PlayClassDanShuangModel.h"


@interface CFCBJKL8PlayClassDanShuangViewController ()

@end


@implementation CFCBJKL8PlayClassDanShuangViewController


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.className = GAME_PLAY_CLASS_NAME_BJKL8_HEZHI_HZ_DANSHUANG;
        self.classCode = GAME_PLAY_CLASS_CODE_BJKL8_HEZHI_HZ_DANSHUANG;
    }
    return self;
}


#pragma mark -
#pragma mark 数据模型 - 静态数据模型
- (NSArray<CFCGameBetPlayClassSectionModel *> *)dataOfPlayClassModelsForBettingRecords
{
    return [CFCBJKL8PlayClassDanShuangSectionModel buildingDataModles];
}


#pragma mark 投注结果 - 官方模式
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsOfficial:(NSDictionary *)dictOfBetSetting
{
    return [self bettingResultModelsForBettingRecordsTemplateN03:dictOfBetSetting];
}


@end

