//
//  游戏 - 提示信息框 - 投注成功
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^CFCBettingSuccessPopNoticeViewDismissBlock)(void);

@interface CFCBettingSuccessPopNoticeView : UIView

@property (nonatomic, assign) BOOL isShow;

@property (nonatomic, copy) NSString *content;

@property (nonatomic, assign) NSInteger count;

@property (nonatomic, copy) CFCBettingSuccessPopNoticeViewDismissBlock afterDismissBlock;

+ (instancetype)sharePopNoticeView;

- (void)show;

- (void)dismiss;

@end

NS_ASSUME_NONNULL_END
