

#import <UIKit/UIKit.h>

@interface CFCTrackView : UIView

/*
 *** 设置起点
 */
@property (nonatomic, assign) CGPoint startPoint;

/*
 *** 设置终点
 */
@property (nonatomic, assign) CGPoint endPoint;

/*
 *** 设置颜色区间
 */
@property (nonatomic, retain) NSArray *colors;


@end
