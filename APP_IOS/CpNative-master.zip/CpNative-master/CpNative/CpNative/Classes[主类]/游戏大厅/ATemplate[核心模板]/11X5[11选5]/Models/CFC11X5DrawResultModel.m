//
// 游戏 - 开奖结果 - 11X5
//

#import "CFC11X5DrawResultModel.h"

@implementation CFC11X5DrawResultModel

/**
 * 开奖结果 - 动态数据 - 头部区域
 */
+ (CFCGameBetDrawResultModel *) buildingDataModleForHeaderArea:(CFCGameBetDrawResultModel *)dataModel
                                                      itemType:(CFCGameBetDrawResultItemType)itemType
                                                        itemId:(NSString *)itemId
{
    return [super buildingDataModleForHeaderArea:dataModel itemType:itemType itemId:itemId];
}

#pragma mark 开奖结果 - 动态数据 - 动态表格
+ (NSMutableArray<CFC11X5DrawResultModel *> *) buildingDataModles:(NSMutableArray<CFC11X5DrawResultModel *> *)dataModels
                                                         itemType:(CFCGameBetDrawResultItemType)itemType
                                                           itemId:(NSString *)itemId
{
    NSMutableArray<CFC11X5DrawResultModel *> *models = [NSMutableArray array];
    {
        for (int index = 0; index < dataModels.count; index ++) {
            CFC11X5DrawResultModel *model_original = [dataModels objectAtIndex:index];
            // 空处理 - 开奖期号
            if ([CFCSysUtil validateStringEmpty:model_original.issueNumber]) {
                [model_original setIssue:GAME_DRAW_RESULT_ISSUE_NUMBER(itemId)];
                [model_original setIssueNumber:GAME_DRAW_RESULT_ISSUE_NUMBER(itemId)];
            }
            // 空处理 - 开奖号码
            if ([CFCSysUtil validateStringEmpty:model_original.winnerNumber]) {
                [model_original setWinnum:GAME_DRAW_RESULT_WINNER_NUMBER(itemId)];
                [model_original setWinnerNumber:GAME_DRAW_RESULT_WINNER_NUMBER(itemId)];
            }
            // 已开奖
            CFC11X5DrawResultModel *model_building = [[CFC11X5DrawResultModel alloc] init];
            NSString *shortIssueString = model_original.issueNumber;
            if (model_original.issueNumber.length > GAME_DRAW_RESULT_ISSUE_NUMBER(itemId).length) {
                shortIssueString = [model_original.issueNumber substringFromIndex:model_original.issueNumber.length-GAME_DRAW_RESULT_ISSUE_NUMBER(itemId).length];
            }
            [model_building setType:itemType]; // 开奖结果类型
            [model_building setIsDrawed:GAME_DRAW_RESULT_STATUS(itemId,model_original.winnerNumber)];
            [model_building setIssue:model_original.issue]; // 开奖期号 - 后台完整
            [model_building setWinnum:model_original.winnum]; // 开奖号码 - 后台完整
            [model_building setIssueNumber:shortIssueString]; // 开奖期号 - 界面显示
            [model_building setWinnerNumber:model_original.winnerNumber]; // 开奖号码 - 界面显示
            
            // 开奖号码
            NSArray<NSString *> *winnerNumbers = [model_building.winnerNumber split:GAME_DRAW_RESULT_SPLIT_SYMBOL_COMMA];
            
            // 字体颜色背景
            {
                NSArray<NSString *> *winnerNumberArray = [[self class] building11X5WinnerResultNumbers:winnerNumbers];  // 开奖号码
                NSMutableArray<UIFont *> *winnerNumberFontArray = @[].mutableCopy;  // 开奖号码字体
                NSMutableArray<UIColor *> *winnerNumberColorArray = @[].mutableCopy; // 开奖号码颜色
                NSMutableArray<UIColor *> *winnerNumberBackgroundColorArray = @[].mutableCopy; // 开奖号码背景颜色
                NSMutableArray<NSNumber *> *winnerNumberTypeArray = @[].mutableCopy; // 开奖号码类型列表
                // 开奖号码
                for (int idx = 0; idx < winnerNumbers.count; idx ++) {
                    [winnerNumberFontArray addObject:FONT_GAME_DRAW_RESULT_WINNER_NUMBER];
                    [winnerNumberColorArray addObject:COLOR_GAME_DRAW_RESULT_WINNER_NUMBER];
                    [winnerNumberBackgroundColorArray addObject:COLOR_GAME_DRAW_RESULT_WINNER_BACKGROUND_RED];
                    [winnerNumberTypeArray addObject:[NSNumber numberWithInt:CFCGameBetDrawResultWinNumberType1]];
                }
                // 特殊处理
                for (NSInteger idx = winnerNumbers.count; idx < winnerNumberArray.count; idx ++) {
                    [winnerNumberFontArray addObject:FONT_GAME_DRAW_RESULT_WINNER_CHINESE];
                    [winnerNumberColorArray addObject:COLOR_GAME_DRAW_RESULT_WINNER_CHINESE];
                    [winnerNumberBackgroundColorArray addObject:COLOR_GAME_DRAW_RESULT_WINNER_BACKGROUND_LIGHT];
                    [winnerNumberTypeArray addObject:[NSNumber numberWithInt:CFCGameBetDrawResultWinNumberType2]];
                }
                [model_building setWinnerNumberArray:winnerNumberArray];
                [model_building setWinnerNumberFontArray:winnerNumberFontArray];
                [model_building setWinnerNumberColorArray:winnerNumberColorArray];
                [model_building setWinnerNumberBackgroundColorArray:winnerNumberBackgroundColorArray];
                [model_building setWinnerNumberTypeArray:winnerNumberTypeArray];
            }
            [models addObject:model_building];
        }
    }
    return models;
}

#pragma mark - 工具方法 - 开奖号码
+ (NSArray<NSString *> *)building11X5WinnerResultNumbers:(NSArray<NSString *> *)winnerNumbers
{
    // 安全验证
    if (winnerNumbers.count < 5) {
        return winnerNumbers;
    }
    
    NSMutableArray<NSString *> *winnerNumberArray = [NSMutableArray arrayWithArray:winnerNumbers];
    
    return [NSArray arrayWithArray:winnerNumberArray];
}

@end

