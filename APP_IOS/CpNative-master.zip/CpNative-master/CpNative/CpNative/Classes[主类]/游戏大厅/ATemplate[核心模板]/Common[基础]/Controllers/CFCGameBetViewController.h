//
// 游戏 - 投注区 - 抽象基类（公共逻辑）
//

#import "CFCGameBetPlayViewController.h"

NS_ASSUME_NONNULL_BEGIN


UIKIT_EXTERN NSInteger const INIT_SETTING_SELECTED_INDEX_OF_PLAY_CLASS;
UIKIT_EXTERN NSString * const INIT_SETTING_SELECTED_PLAY_CODE_OF_PLAY_CLASS;


@interface CFCGameBetViewController : CFCGameBetPlayViewController

/**
 * 投注单位（元1.0, 角0.5）
 */
@property (nonatomic, strong) NSString *bettingUnitValue;
/**
 * 投注倍数
 */
@property (nonatomic, strong) NSString *bettingMultipleValue;
/**
 * 投注总数
 */
@property (nonatomic, strong) NSString *bettingNumberValue;
/**
 * 投注总额
 */
@property (nonatomic, strong) NSString *bettingAmountValue;


/**
 * 投注类型
 */
@property (nonatomic, strong) NSString *bettingTypeValue;
/**
 * 投注外键
 */
@property (nonatomic, strong) NSString *bettingPidValue;
/**
 * 服务主键
 */
@property (nonatomic, strong) NSString *bettingPSeriesWayIdValue;
/**
 * 单价金额
 */
@property (nonatomic, strong) NSString *bettingPriceValue;
/**
 * 奖金分组
 */
@property (nonatomic, strong) NSString *bettingPrizeValue;
/**
 * 投注方式
 */
@property (nonatomic, strong) NSString *bettingBasicMethodsValue;
/**
 * 投注倍数（最小值）
 */
@property (nonatomic, strong) NSString *bettingMultipleMinValue;
/**
 * 投注倍数（最大值）
 */
@property (nonatomic, strong) NSString *bettingMultipleMaxValue;


/**
 * 返点赔率 - 滑条控件
 */
@property (nonatomic, strong) NSString *bettingSliderRateValue;
/**
 * 奖金分组 - 滑条控件
 */
@property (nonatomic, strong) NSString *bettingSliderPrizeValue;


#pragma mark -
#pragma mark 玩法下标 - 返回默认选中的玩法标识
- (NSString *)getSelectedPlayCodeOfPlayClass;
#pragma mark 玩法下标 - 设置默认选中的玩法下标
- (NSDictionary<NSString *, NSNumber *> *)settingSelectedIndexOfPlayClassDictionary;
#pragma mark 玩法标识 - 设置默认选中的玩法标识
- (NSDictionary<NSString *, NSString *> *)settingSelectedPlayCodeOfPlayClassDictionary;


@end


NS_ASSUME_NONNULL_END
