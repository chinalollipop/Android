//
// 游戏 - 开奖结果 - 11X5
//

#import "CFCGameBetDrawResultDefaultTableViewCell.h"
@class CFC11X5DrawResultModel;

NS_ASSUME_NONNULL_BEGIN

@protocol CFC11X5OfficialDrawResultTableViewCellDelegate <CFCGameBetDrawResultDefaultTableViewCellDelegate>
@optional
- (void)didSelectRowAt11X5DrawResultModel:(CFC11X5DrawResultModel *)model;
@end

@interface CFC11X5OfficialDrawResultTableViewCell : CFCGameBetDrawResultDefaultTableViewCell

@end

NS_ASSUME_NONNULL_END
