//
// 游戏 - 投注区 - 开奖结果
//


#import "YHSDropDownMenuBasedCell.h"
@class CFCGameBetDrawResultModel;

NS_ASSUME_NONNULL_BEGIN

@protocol CFCGameBetDrawResultDefaultTableViewCellProtocol <NSObject>
@required
- (void)createViewAtuoLayout;
- (void)setMenuModel:(CFCGameBetDrawResultModel *)menuModel;
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture;
@end

@protocol CFCGameBetDrawResultDefaultTableViewCellDelegate <NSObject>
@optional
- (void)didSelectRowAtGameBetDrawResultModel:(CFCGameBetDrawResultModel *)model;
@end

@interface CFCGameBetDrawResultDefaultTableViewCell : YHSDropDownMenuBasedCell <CFCGameBetDrawResultDefaultTableViewCellProtocol>
/**
 * 根容器组件
 */
@property (nonnull, nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器组件
 */
@property (nonnull, nonatomic, strong) UIView *publicContainerView;
/**
 * 左边开奖期号
 */
@property (nonatomic, strong) UILabel *leftIssueNumberLabel;
/**
 * 右边开奖结果
 */
@property (nonatomic, strong) UIView *rightWinnerContainerView;
/**
 * 分割线控件
 */
@property (nonatomic, strong) UIView *separatorLineView;
/**
 * 表格代理
 */
@property (nonatomic, weak) id<CFCGameBetDrawResultDefaultTableViewCellDelegate> delegate;

/**
 * 开奖号码大小
 */
- (CGSize)itemSizeOfWinnerNumber;
/**
 * 开奖结果列表高度 - 未开奖
 */
+ (CGFloat)heightForDrawResultTableViewCellWithModel:(CFCGameBetDrawResultModel *)model;

@end

NS_ASSUME_NONNULL_END
