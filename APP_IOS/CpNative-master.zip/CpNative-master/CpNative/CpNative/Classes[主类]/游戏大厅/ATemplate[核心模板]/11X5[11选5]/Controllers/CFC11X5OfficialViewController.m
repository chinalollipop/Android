//
// 游戏 - 投注区 - 官方模式 - 11选5
//

#import "CFC11X5OfficialViewController.h"

@interface CFC11X5OfficialViewController ()

@end

@implementation CFC11X5OfficialViewController


#pragma mark -
#pragma mark 开奖结果 - 开奖类型
- (CFCGameBetDrawResultItemType)getDrawResultItemType
{
    return CFCGameBetDrawResultItemTypeOfficial02;
}


#pragma mark -
#pragma mark 玩法下标 - 返回默认选中的玩法标识
- (NSString *)getSelectedPlayCodeOfPlayClass
{
    return GAME_PLAY_CLASS_CODE_11X5_MA3_ZX_FRONT_3_MULTIPLE;
}


#pragma mark -
#pragma mark 视图生命周期（初始化静态标签数据）
- (BOOL)viewDidLoadWithDataSource
{
    // 玩法标识
    self.tabClassCodes = @[
                           // 三码 -> 直选
                           GAME_PLAY_CLASS_CODE_11X5_MA3_ZX_FRONT_3_MULTIPLE,
                           GAME_PLAY_CLASS_CODE_11X5_MA3_ZX_FRONT_3_SINGLE,
                           // 三码 -> 组选
                           GAME_PLAY_CLASS_CODE_11X5_MA3_GX_FRONT_3_MULTIPLE,
                           GAME_PLAY_CLASS_CODE_11X5_MA3_GX_FRONT_3_SINGLE,
                           GAME_PLAY_CLASS_CODE_11X5_MA3_GX_FRONT_3_DANTUO,
                           
                           // 二码 -> 直选
                           GAME_PLAY_CLASS_CODE_11X5_MA2_ZX_FRONT_2_MULTIPLE,
                           GAME_PLAY_CLASS_CODE_11X5_MA2_ZX_FRONT_2_SINGLE,
                           // 二码 -> 组选
                           GAME_PLAY_CLASS_CODE_11X5_MA2_GX_FRONT_2_MULTIPLE,
                           GAME_PLAY_CLASS_CODE_11X5_MA2_GX_FRONT_2_SINGLE,
                           GAME_PLAY_CLASS_CODE_11X5_MA2_GX_FRONT_2_DANTUO,
                           
                           // 不定位 -> 不定位
                           GAME_PLAY_CLASS_CODE_11X5_BUDINGWEI_BDW_FRONT3_BUDINGWEI,
                           
                           // 趣味型 -> 趣味型
                           GAME_PLAY_CLASS_CODE_11X5_QUWEIXING_QWX_DINGDANSHUANG,
                           GAME_PLAY_CLASS_CODE_11X5_QUWEIXING_QWX_CAIZHONGWEI,
                           
                           // 定位胆 -> 定位胆
                           GAME_PLAY_CLASS_CODE_11X5_DINGWEIDAN_DWD_DINGWEIDAN,
                           
                           // 任选复式 -> 任选复式
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANFUSHI_RXFS_RENXUAN01,
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANFUSHI_RXFS_RENXUAN02,
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANFUSHI_RXFS_RENXUAN03,
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANFUSHI_RXFS_RENXUAN04,
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANFUSHI_RXFS_RENXUAN05,
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANFUSHI_RXFS_RENXUAN06,
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANFUSHI_RXFS_RENXUAN07,
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANFUSHI_RXFS_RENXUAN08,
                           
                           // 任选单式 -> 任选单式
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANDANSHI_RXDS_RENXUAN01,
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANDANSHI_RXDS_RENXUAN02,
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANDANSHI_RXDS_RENXUAN03,
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANDANSHI_RXDS_RENXUAN04,
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANDANSHI_RXDS_RENXUAN05,
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANDANSHI_RXDS_RENXUAN06,
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANDANSHI_RXDS_RENXUAN07,
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANDANSHI_RXDS_RENXUAN08,
                           
                           // 任选胆拖 -> 任选胆拖
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANDANTUO_RXDT_RENXUAN02,
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANDANTUO_RXDT_RENXUAN03,
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANDANTUO_RXDT_RENXUAN04,
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANDANTUO_RXDT_RENXUAN05,
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANDANTUO_RXDT_RENXUAN06,
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANDANTUO_RXDT_RENXUAN07,
                           GAME_PLAY_CLASS_CODE_11X5_RENXUANDANTUO_RXDT_RENXUAN08,
                           
                           ];
    
    // 玩法标题
    self.tabClassTitles = @[
                            // 三码 -> 直选
                            GAME_PLAY_CLASS_NAME_11X5_MA3_ZX_FRONT_3_MULTIPLE,
                            GAME_PLAY_CLASS_NAME_11X5_MA3_ZX_FRONT_3_SINGLE,
                            // 三码 -> 组选
                            GAME_PLAY_CLASS_NAME_11X5_MA3_GX_FRONT_3_MULTIPLE,
                            GAME_PLAY_CLASS_NAME_11X5_MA3_GX_FRONT_3_SINGLE,
                            GAME_PLAY_CLASS_NAME_11X5_MA3_GX_FRONT_3_DANTUO,
                            
                            // 二码 -> 直选
                            GAME_PLAY_CLASS_NAME_11X5_MA2_ZX_FRONT_2_MULTIPLE,
                            GAME_PLAY_CLASS_NAME_11X5_MA2_ZX_FRONT_2_SINGLE,
                            // 二码 -> 组选
                            GAME_PLAY_CLASS_NAME_11X5_MA2_GX_FRONT_2_MULTIPLE,
                            GAME_PLAY_CLASS_NAME_11X5_MA2_GX_FRONT_2_SINGLE,
                            GAME_PLAY_CLASS_NAME_11X5_MA2_GX_FRONT_2_DANTUO,
                            
                            // 不定位 -> 不定位
                            GAME_PLAY_CLASS_NAME_11X5_BUDINGWEI_BDW_FRONT3_BUDINGWEI,
                            
                            // 趣味型 -> 趣味型
                            GAME_PLAY_CLASS_NAME_11X5_QUWEIXING_QWX_DINGDANSHUANG,
                            GAME_PLAY_CLASS_NAME_11X5_QUWEIXING_QWX_CAIZHONGWEI,
                            
                            // 定位胆 -> 定位胆
                            GAME_PLAY_CLASS_NAME_11X5_DINGWEIDAN_DWD_DINGWEIDAN,
                            
                            // 任选复式 -> 任选复式
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANFUSHI_RXFS_RENXUAN01,
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANFUSHI_RXFS_RENXUAN02,
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANFUSHI_RXFS_RENXUAN03,
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANFUSHI_RXFS_RENXUAN04,
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANFUSHI_RXFS_RENXUAN05,
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANFUSHI_RXFS_RENXUAN06,
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANFUSHI_RXFS_RENXUAN07,
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANFUSHI_RXFS_RENXUAN08,
                            
                            // 任选单式 -> 任选单式
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANDANSHI_RXDS_RENXUAN01,
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANDANSHI_RXDS_RENXUAN02,
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANDANSHI_RXDS_RENXUAN03,
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANDANSHI_RXDS_RENXUAN04,
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANDANSHI_RXDS_RENXUAN05,
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANDANSHI_RXDS_RENXUAN06,
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANDANSHI_RXDS_RENXUAN07,
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANDANSHI_RXDS_RENXUAN08,
                            
                            // 任选胆拖 -> 任选胆拖
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANDANTUO_RXDT_RENXUAN02,
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANDANTUO_RXDT_RENXUAN03,
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANDANTUO_RXDT_RENXUAN04,
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANDANTUO_RXDT_RENXUAN05,
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANDANTUO_RXDT_RENXUAN06,
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANDANTUO_RXDT_RENXUAN07,
                            GAME_PLAY_CLASS_NAME_11X5_RENXUANDANTUO_RXDT_RENXUAN08,
                            
                            ];
    // 控件器名称
    self.tabClassViewControllers = @[
                                     // 三码 -> 直选
                                     @"CFC11X5PlayClassMa3ZXFront3MultipleViewController",
                                     @"CFC11X5PlayClassMa3ZXFront3SingleViewController",
                                     // 三码 -> 组选
                                     @"CFC11X5PlayClassMa3GXFront3MultipleViewController",
                                     @"CFC11X5PlayClassMa3GXFront3SingleViewController",
                                     @"CFC11X5PlayClassMa3GXFront3DanTuoViewController",
                                     
                                     // 二码 -> 直选
                                     @"CFC11X5PlayClassMa2ZXFront2MultipleViewController",
                                     @"CFC11X5PlayClassMa2ZXFront2SingleViewController",
                                     // 二码 -> 组选
                                     @"CFC11X5PlayClassMa2GXFront2MultipleViewController",
                                     @"CFC11X5PlayClassMa2GXFront2SingleViewController",
                                     @"CFC11X5PlayClassMa2GXFront2DanTuoViewController",
                                     
                                     // 不定位 -> 不定位
                                     @"CFC11X5PlayClassBuDingWeiFront3ViewController",
                                     
                                     // 趣味型 -> 趣味型
                                     @"CFC11X5PlayClassQWXDingDanShuangViewController",
                                     @"CFC11X5PlayClassQWXCaiZhongWeiViewController",
                                     
                                     // 定位胆 -> 定位胆
                                     @"CFC11X5PlayClassDWDDingWeiDanViewController",
                                     
                                     // 任选复式 -> 任选复式
                                     @"CFC11X5PlayClassRXFSRenXuan01ViewController",
                                     @"CFC11X5PlayClassRXFSRenXuan02ViewController",
                                     @"CFC11X5PlayClassRXFSRenXuan03ViewController",
                                     @"CFC11X5PlayClassRXFSRenXuan04ViewController",
                                     @"CFC11X5PlayClassRXFSRenXuan05ViewController",
                                     @"CFC11X5PlayClassRXFSRenXuan06ViewController",
                                     @"CFC11X5PlayClassRXFSRenXuan07ViewController",
                                     @"CFC11X5PlayClassRXFSRenXuan08ViewController",
                                     
                                     // 任选单式 -> 任选单式
                                     @"CFC11X5PlayClassRXDSRenXuan01ViewController",
                                     @"CFC11X5PlayClassRXDSRenXuan02ViewController",
                                     @"CFC11X5PlayClassRXDSRenXuan03ViewController",
                                     @"CFC11X5PlayClassRXDSRenXuan04ViewController",
                                     @"CFC11X5PlayClassRXDSRenXuan05ViewController",
                                     @"CFC11X5PlayClassRXDSRenXuan06ViewController",
                                     @"CFC11X5PlayClassRXDSRenXuan07ViewController",
                                     @"CFC11X5PlayClassRXDSRenXuan08ViewController",
                                     
                                     // 任选胆拖 -> 任选胆拖
                                     @"CFC11X5PlayClassRXDTRenXuan02ViewController",
                                     @"CFC11X5PlayClassRXDTRenXuan03ViewController",
                                     @"CFC11X5PlayClassRXDTRenXuan04ViewController",
                                     @"CFC11X5PlayClassRXDTRenXuan05ViewController",
                                     @"CFC11X5PlayClassRXDTRenXuan06ViewController",
                                     @"CFC11X5PlayClassRXDTRenXuan07ViewController",
                                     @"CFC11X5PlayClassRXDTRenXuan08ViewController",
                                     
                                     ];
    
    return YES;
}


@end

