//
//  游戏 - 每一个具体玩法的基类 - 默认为空
//
//  说明：此类以 UITableViewCell 实现。如果不能满足你的要求，请另外实现。
//

#import "CFCGameBetPlayClassDefaultTableViewCell.h"
#import "CFCGameBetPlayClassModel.h"


// Cell Identifier
NSString * const CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_DEFAULT_TABLE_VIEW_CELL = @"CFCGameBetPlayClassDefaultTableViewCellIdentifier";


@interface CFCGameBetPlayClassDefaultTableViewCell ()
/**
 * 根容器组件
 */
@property (nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonatomic, strong) UIView *publicContainerView;

@end


@implementation CFCGameBetPlayClassDefaultTableViewCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createViewAtuoLayout];
    }
    return self;
}


#pragma mark 创建子控件
- (void) createViewAtuoLayout
{
    // 根容器
    UIView *rootContainerView = ({
        UIView *view = [[UIView alloc] init];
        [self.contentView insertSubview:view atIndex:0];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@0.0f);
            make.top.equalTo(@0.0f);
            make.right.equalTo(@0.0f);
            make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
        }];
        
        view;
    });
    self.rootContainerView = rootContainerView;
    self.rootContainerView.mas_key = @"rootContainerView";
    
    // 公共容器
    UIView *publicContainerView = ({
        UIView *view = [[UIView alloc] init];
        [view setBackgroundColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT];
        [rootContainerView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(rootContainerView.mas_left).offset(0.0f);
            make.top.equalTo(rootContainerView.mas_top).offset(0.0f);
            make.right.equalTo(rootContainerView.mas_right).offset(0.0f);
            make.bottom.equalTo(rootContainerView.mas_bottom).offset(0.0f);
        }];
        
        view;
    });
    self.publicContainerView = publicContainerView;
    self.publicContainerView.mas_key = @"publicContainerView";
    
    // 分割线
    UIView *separatorLineView = ({
        UIView *view = [[UIView alloc] init];
        [publicContainerView addSubview:view];
        [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(publicContainerView.mas_left).offset(0.0f);
            make.top.equalTo(publicContainerView.mas_top).offset(0.0f);
            make.right.equalTo(publicContainerView.mas_right).offset(0.0f);
            make.height.equalTo(@(0.5f));
        }];
        
        view;
    });
    separatorLineView.mas_key = @"separatorLineView";
    
    // 约束的完整性
    [self.publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(separatorLineView.mas_bottom).offset(0.0f).priority(749);
    }];
    
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCGameBetPlayClassSectionModel *)model
{
    // 类型安全检查
    if (![model isKindOfClass:[CFCGameBetPlayClassSectionModel class]]) {
        return;
    }
    
    // 数据赋值
    _model = (CFCGameBetPlayClassSectionModel *)model;
    
}


@end

