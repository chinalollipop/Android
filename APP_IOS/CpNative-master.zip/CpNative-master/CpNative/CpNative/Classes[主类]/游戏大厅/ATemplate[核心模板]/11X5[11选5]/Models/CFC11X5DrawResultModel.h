//
// 游戏 - 开奖结果 - 11X5
//

#import "CFCGameBetDrawResultModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFC11X5DrawResultModel : CFCGameBetDrawResultModel

/**
 * 开奖结果 - 动态数据 - 头部区域
 */
+ (CFCGameBetDrawResultModel *) buildingDataModleForHeaderArea:(CFCGameBetDrawResultModel *)dataModel
                                                      itemType:(CFCGameBetDrawResultItemType)itemType
                                                        itemId:(NSString *)itemId;
/**
 * 开奖结果 - 动态数据 - 动态表格
 */
+ (NSMutableArray<CFC11X5DrawResultModel *> *) buildingDataModles:(NSMutableArray<CFC11X5DrawResultModel *> *)dataModels
                                                         itemType:(CFCGameBetDrawResultItemType)itemType
                                                           itemId:(NSString *)itemId;

/**
 * 开奖结果 -工具方法 - 开奖号码
 */
+ (NSArray<NSString *> *)building11X5WinnerResultNumbers:(NSArray<NSString *> *)winnerNumbers;

@end

NS_ASSUME_NONNULL_END

