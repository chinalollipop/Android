

#import <UIKit/UIKit.h>

@interface CFCGameBetPlayClassTableSectionFooterView : UIView

- (instancetype)initWithFrame:(CGRect)frame tableSecion:(NSInteger)tableSection;

@end
