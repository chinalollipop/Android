//
//  游戏 - 信用玩法 -> 投注项目，生肖 -> 如：六合彩信用玩法中<半波、特肖>
//
//  说明：此类以 UICollectionView 实现。如果不能满足你的要求，请另外实现。
//

#import <UIKit/UIKit.h>
@class CFCGameBetPlayClassModel, CFCGameBetPlayClassSectionModel;
@protocol CFCGameBetPlayClassCollectionViewCellProtocol;


NS_ASSUME_NONNULL_BEGIN


UIKIT_EXTERN NSString * const CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_CREDIT_2_COLLECTION_VIEW_CELL;


@protocol CFCGameBetPlayClassCredit2CollectionViewCellProtocol <CFCGameBetPlayClassCollectionViewCellProtocol>
@end

@protocol CFCGameBetPlayClassCredit2CollectionViewCellDelegate <NSObject>
@required
- (NSString *)itemNameOfMaxLengthInDataOfSectionModelArray:(CFCGameBetPlayClassModel *)model;
- (NSString *)itemOddsOfMaxLengthInDataOfSectionModelArray:(CFCGameBetPlayClassModel *)model;
@optional
- (void)didSelectPlayClassCredit2CollectionViewCellRowAtIndexPath:(NSIndexPath *)indexPath
                                                       itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels
                                                       itemIndexs:(NSArray<NSNumber *> *)itemIndexs;
@end

@interface CFCGameBetPlayClassCredit2CollectionViewCell : UICollectionViewCell <CFCGameBetPlayClassCredit2CollectionViewCellProtocol>

/**
 * 数据下标
 */
@property (nonatomic, strong) NSIndexPath *indexPath;
/**
 * 数据模型
 */
@property (nonatomic, strong) CFCGameBetPlayClassModel *model;
/**
 * 表格代理
 */
@property (nonatomic, weak) id<CFCGameBetPlayClassCredit2CollectionViewCellDelegate> delegate;


/**
 * 操作事件 - 投注按钮
 */
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture;
/**
 * 投注表格 - 表格列数
 */
+ (NSInteger)numberOfColumnsAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassModel *)model;
/**
 * 投注表格 - 表格行高
 */
+ (CGFloat)heightForCellAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model;


@end



NS_ASSUME_NONNULL_END

