//
//  游戏 - 信用玩法 - 投注页面头部区域
//

#import "CFCGameBetPlayScrollViewCreditHeader.h"

@interface CFCGameBetPlayScrollViewCreditHeader ()

@end

@implementation CFCGameBetPlayScrollViewCreditHeader

@end
