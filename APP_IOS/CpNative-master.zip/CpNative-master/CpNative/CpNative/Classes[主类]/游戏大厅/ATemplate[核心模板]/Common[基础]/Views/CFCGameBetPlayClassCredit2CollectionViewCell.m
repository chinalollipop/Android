//
//  游戏 - 信用玩法 -> 投注项目，生肖 -> 如：六合彩信用玩法中<半波、特肖>
//
//  说明：此类以 UICollectionView 实现。如果不能满足你的要求，请另外实现。
//

#import "CFCGameBetPlayClassCredit2CollectionViewCell.h"
#import "CFCGameBetPlayClassModel.h"


CGFloat const LEFT_VIEW_PERCENT = 0.36f;


// Cell Identifier
NSString * const CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_CREDIT_2_COLLECTION_VIEW_CELL = @"CFCGameBetPlayClassCredit2CollectionViewCellIdentifier";


@interface CFCGameBetPlayClassCredit2CollectionViewCell ()
/**
 * 根容器组件
 */
@property (nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonatomic, strong) UIView *publicContainerView;
/**
 * 左边容器
 */
@property (nonatomic, strong) UIView *leftContainerView;
/**
 * 右边容器
 */
@property (nonatomic, strong) UIView *rightContainerView;
/**
 * 标题控件
 */
@property (nonnull, nonatomic, strong) UILabel *nameLabel;
/**
 * 赔率控件
 */
@property (nonnull, nonatomic, strong) UILabel *oddsLabel;

@end


@implementation CFCGameBetPlayClassCredit2CollectionViewCell


-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self) {
        [self createViewAtuoLayout];
    }
    return self;
}

#pragma mark 创建子控件
- (void) createViewAtuoLayout
{
    // 根容器
    UIView *rootContainerView = ({
        UIView *view = [[UIView alloc] init];
        [self.contentView insertSubview:view atIndex:0];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@0.0f);
            make.top.equalTo(@0.0f);
            make.right.equalTo(@0.0f);
            make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
        }];
        
        view;
    });
    self.rootContainerView = rootContainerView;
    self.rootContainerView.mas_key = @"rootContainerView";
    
    // 公共容器
    UIView *publicContainerView = ({
        UIView *view = [[UIView alloc] init];
        [view setBackgroundColor:COLOR_GAME_BET_MAINAREA_BACKGROUND_DEFAULT];
        [rootContainerView addSubview:view];
        
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressPublicItemView:)];
        tapGesture.numberOfTapsRequired = 1;
        tapGesture.numberOfTouchesRequired = 1;
        [view addGestureRecognizer:tapGesture];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(rootContainerView.mas_left).offset(0.0f);
            make.top.equalTo(rootContainerView.mas_top).offset(0.0f);
            make.right.equalTo(rootContainerView.mas_right).offset(0.0f);
            make.bottom.equalTo(rootContainerView.mas_bottom).offset(0.0f);
        }];
        
        view;
    });
    self.publicContainerView = publicContainerView;
    self.publicContainerView.mas_key = @"publicContainerView";
    
    // 左边容器
    UIView *leftContainerView = ({
        UIView *view = [[UIView alloc] init];
        [publicContainerView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(publicContainerView.mas_left).offset(0.0f);
            make.top.equalTo(publicContainerView.mas_top).offset(0.0f);
            make.bottom.equalTo(publicContainerView.mas_bottom).offset(0.0f);
            make.width.equalTo(@(self.frame.size.width*LEFT_VIEW_PERCENT));
        }];
        
        view;
    });
    self.leftContainerView = leftContainerView;
    self.leftContainerView.mas_key = @"leftContainerView";
    
    // 右边容器
    UIView *rightContainerView = ({
        UIView *view = [[UIView alloc] init];
        [publicContainerView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(leftContainerView.mas_right).offset(GAME_PLAY_COLLECTION_ITEM_MARGIN);
            make.top.equalTo(publicContainerView.mas_top).offset(0.0f);
            make.right.equalTo(publicContainerView.mas_right).offset(0.0f);
            make.bottom.equalTo(publicContainerView.mas_bottom).offset(0.0f);
        }];
        
        view;
    });
    self.rightContainerView = rightContainerView;
    self.rightContainerView.mas_key = @"rightContainerView";
    
    // 名称控件
    UILabel *nameLabel = ({
        UILabel *label = [UILabel new];
        [label setText:STR_APP_TEXT_PLACEHOLDER];
        [label setTextAlignment:NSTextAlignmentCenter];
        [label setLineBreakMode:NSLineBreakByClipping];
        [leftContainerView addSubview:label];
        
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self.mas_centerY);
        }];
        
        label;
    });
    self.nameLabel = nameLabel;
    self.nameLabel.mas_key = @"nameLabel";
    
    // 赔率控件
    UILabel *oddsLabel = ({
        UILabel *label = [UILabel new];
        [label setText:STR_APP_TEXT_PLACEHOLDER];
        [label setTextAlignment:NSTextAlignmentCenter];
        [label setLineBreakMode:NSLineBreakByClipping];
        [leftContainerView addSubview:label];
        
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(nameLabel.mas_right);
        }];
        
        label;
    });
    self.oddsLabel = oddsLabel;
    self.oddsLabel.mas_key = @"oddsLabel";
    
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCGameBetPlayClassModel *)model
{
    // 类型安全检查
    if (![model isKindOfClass:[CFCGameBetPlayClassModel class]]) {
        return;
    }
    
    // 数据赋值
    _model = (CFCGameBetPlayClassModel *)model;
    
    // 字体颜色
    CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
    UIColor *backgroundColor = _model.isSelected ? GAME_PLAY_ITEM_COLOR_BACKGROUND_SELECT : GAME_PLAY_ITEM_COLOR_BACKGROUND_NORMAL;
    UIColor *nameColor = _model.isSelected ? _model.nameSelectColor : _model.nameNormalColor;
    UIColor *oddsColor = _model.isSelected ? _model.oddsSelectColor : _model.oddsNormalColor;
    UIFont *nameFont = _model.isSelected ? _model.nameSelectFont : _model.nameNormalFont;
    UIFont *oddsFont = _model.isSelected ?  _model.oddsSelectFont : _model.oddsNormalFont;
    
    // 设置内容
    {
        // 标题
        NSString *name = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:_model.name];
        NSDictionary *attributesName = @{ NSFontAttributeName:nameFont, NSForegroundColorAttributeName:nameColor};
        NSAttributedString *attributedNameString = [CFCSysUtil attributedString:@[ [NSString stringWithFormat:@"%@", name] ]
                                                                 attributeArray:@[ attributesName ] ];
        [self.nameLabel setAttributedText:attributedNameString];
        
        // 赔率
        NSString *odds = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:_model.odds];
        NSString *oddsMaxString = [CFCGameUtil getOddsValue:odds radixPoint:GAME_PLAY_MODEL_ODDS_NUMBE_POINT_LEN];
        NSDictionary *attributesOdds = @{ NSFontAttributeName:oddsFont, NSForegroundColorAttributeName:oddsColor};
        NSAttributedString *attributedOddsString = [CFCSysUtil attributedString:@[ [NSString stringWithFormat:@"%@", oddsMaxString] ]
                                                                 attributeArray:@[ attributesOdds]];
        [self.oddsLabel setAttributedText:attributedOddsString];
        
        // 标题 - 宽高
        CGFloat nameWidth = FLOAT_MIN;
        CGFloat nameHeight = FLOAT_MIN;
        if (_model.isShowName) {
            NSString *itemMaxName = model.name;
            CGFloat nameWidthGap =  GAME_PLAY_MODEL_NAME_NUMBE_WIDTH_GAP;
            CGFloat nameHeightGap =  GAME_PLAY_MODEL_NAME_NUMBE_HEIGHT_GAP;
            if (self.delegate && [self.delegate respondsToSelector:@selector(itemNameOfMaxLengthInDataOfSectionModelArray:)]) {
                itemMaxName = [self.delegate itemNameOfMaxLengthInDataOfSectionModelArray:_model];
            }
            nameWidth = [itemMaxName widthWithFont:nameFont constrainedToHeight:self.height] + nameWidthGap;
            nameHeight = [itemMaxName heightWithFont:nameFont constrainedToWidth:self.width] + nameHeightGap;
            if (CFCGameBetPlayClassItemType01 == model.type) { // 项目类型1
                nameWidth = [itemMaxName widthWithFont:nameFont constrainedToHeight:self.height] + nameWidthGap;
                nameHeight = [itemMaxName heightWithFont:nameFont constrainedToWidth:self.width] + nameHeightGap;
            } else if (CFCGameBetPlayClassItemType02 == model.type) { // 项目类型2
                if ([CFCStringMathsUtil validateNumberCharacters:model.name]) {
                    // 数字
                    nameWidth = [GAME_PLAY_MODEL_NAME_NUMBE_WIDTH_STR widthWithFont:nameFont constrainedToHeight:self.height] + nameWidthGap;
                    nameHeight = [GAME_PLAY_MODEL_NAME_NUMBE_WIDTH_STR heightWithFont:nameFont constrainedToWidth:self.width] + nameHeightGap;
                } else {
                    // 汉字
                    nameWidth = [GAME_PLAY_MODEL_NAME_CHINA_WIDTH_STR widthWithFont:nameFont constrainedToHeight:self.height] + GAME_PLAY_MODEL_NAME_CHINA_WIDTH_GAP;
                    nameHeight = [GAME_PLAY_MODEL_NAME_CHINA_WIDTH_STR heightWithFont:nameFont constrainedToWidth:self.width] + GAME_PLAY_MODEL_NAME_CHINA_HEIGHT_GAP;
                }
            }
        }
        
        // 赔率 - 宽高
        CGFloat oddsWidth = FLOAT_MIN;
        CGFloat oddsHeight = FLOAT_MIN;
        if (_model.isShowOdds) {
            NSString *itemMaxOdds = oddsMaxString;
            if (self.delegate && [self.delegate respondsToSelector:@selector(itemOddsOfMaxLengthInDataOfSectionModelArray:)]) {
                itemMaxOdds = [self.delegate itemOddsOfMaxLengthInDataOfSectionModelArray:_model];
            }
            oddsWidth = [itemMaxOdds widthWithFont:oddsFont constrainedToHeight:self.height];
            oddsHeight = [itemMaxOdds heightWithFont:oddsFont constrainedToWidth:self.width];
        }
        
        // 计算位置
        CGFloat itemNameOddsWidth = nameWidth + oddsWidth;
        CGFloat itemNameOddsMagin = ((self.width - itemNameOddsWidth) >= margin) ? margin : (self.width - itemNameOddsWidth);
        CGFloat offsetX = (nameWidth + oddsWidth + itemNameOddsMagin) / 2.0f;
        CGFloat offsetY = (nameHeight - oddsHeight) / 2.0f - 1.0;
        [self.nameLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self.leftContainerView.mas_centerY);
            make.left.equalTo(self.leftContainerView.mas_centerX).offset(-offsetX);
            if ([CFCStringMathsUtil validateNumberCharacters:model.name]) {
                make.width.mas_equalTo(nameWidth);
                make.height.mas_equalTo(nameWidth);
            } else {
                make.width.mas_equalTo(nameWidth);
                make.height.mas_equalTo(nameHeight);
            }
        }];
        [self.oddsLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.nameLabel.mas_right).offset(itemNameOddsMagin*0.8f);
            make.centerY.equalTo(self.leftContainerView.mas_centerY).offset(offsetY);
            make.width.mas_equalTo(oddsWidth);
            make.height.mas_equalTo(oddsHeight);
        }];
        
        // 项目类型1
        if (CFCGameBetPlayClassItemType01 == model.type) {
            [self.nameLabel addCornerRadius:0.0f];
            [self.nameLabel setBackgroundColor:model.nameBackgroundColor];
            [self.nameLabel addBorderWithColor:GAME_PLAY_ITEM_BORDER_COLOR_DEFAULT cornerRadius:0.0f andWidth:0.0f];
            [self.nameLabel.layer setMasksToBounds:YES];
        }
        // 项目类型2
        else if (CFCGameBetPlayClassItemType02 == model.type) {
            NSString *name = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:_model.name];
            NSDictionary *attributesName = @{ NSFontAttributeName:nameFont, NSForegroundColorAttributeName:_model.nameSelectColor};
            NSAttributedString *attributedNameString = [CFCSysUtil attributedString:@[ [NSString stringWithFormat:@"%@", name] ]
                                                                     attributeArray:@[ attributesName ] ];
            [self.nameLabel setAttributedText:attributedNameString];
            [self.nameLabel setBackgroundColor:model.nameBackgroundColor];
            if ([CFCStringMathsUtil validateNumberCharacters:model.name]) {
                [self.nameLabel addBorderWithColor:GAME_PLAY_ITEM_BORDER_COLOR_DEFAULT cornerRadius:nameWidth/2.0f andWidth:0.0f];
            } else {
                [self.nameLabel addBorderWithColor:GAME_PLAY_ITEM_BORDER_COLOR_DEFAULT cornerRadius:nameHeight/2.0f andWidth:0.0f];
            }
            [self.nameLabel.layer setMasksToBounds:YES];
        }
        
        // 背景
        [self.leftContainerView setBackgroundColor:backgroundColor];
        [self.rightContainerView setBackgroundColor:backgroundColor];
    }
    
    // 右边描述信息
    {
        // 删除控件
        [self.rightContainerView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
        
        // 大小间距
        NSInteger column = [[self class] numberOfColumnsAtIndexPath:self.indexPath cellModel:self.model];
        CGFloat top_margin = GAME_PLAY_ITEM_DESC_TOP_MARGIN;
        CGFloat bottom_margin = GAME_PLAY_ITEM_DESC_BOTTOM_MARGIN;
        CGFloat left_margin = GAME_PLAY_ITEM_DESC_LEFT_MARGIN;
        CGFloat right_margin = GAME_PLAY_ITEM_DESC_RIGHT_MARGIN;
        CGFloat item_margin = GAME_PLAY_ITEM_DESC_ITEM_MARGIN;
        CGFloat item_container_width = (SCREEN_WIDTH - GAME_PLAY_COLLECTION_EDGEINSET * 2.0) * (1 - LEFT_VIEW_PERCENT) - GAME_PLAY_COLLECTION_ITEM_MARGIN;
        
        // 描述信息
        UILabel *lastItemLabel = nil;
        for (int i = 0; i < self.model.descArray.count; i ++) {
            
            // 字体设置
            UIFont *itemNameFont = self.model.descSelectFontArray[i];
            UIColor *itemNameColor = self.model.descSelectColorArray[i];
            UIColor *itemBackgroundColor = self.model.descBackgroundColorArray[i];
            
            // 描述信息
            NSString *itemName = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.model.descArray[i]];
            CGFloat nameWidthGap =  GAME_PLAY_MODEL_NAME_NUMBE_WIDTH_DESC_GAP;
            CGFloat itemNameWidth = [GAME_PLAY_MODEL_NAME_NUMBE_WIDTH_STR widthWithFont:itemNameFont constrainedToHeight:MAXFLOAT] + nameWidthGap;
            NSDictionary *attributesName = @{ NSFontAttributeName:itemNameFont, NSForegroundColorAttributeName:itemNameColor};
            NSAttributedString *attributedNameString = [CFCSysUtil attributedString:@[ [NSString stringWithFormat:@"%@", itemName] ]
                                                                     attributeArray:@[ attributesName ] ];
            CGFloat itemTotalWidth = itemNameWidth * self.model.descArray.count + item_margin * (self.model.descArray.count - 1) + left_margin + right_margin;
            
            // 描述控件
            UILabel *itemLabel = ({
                UILabel *itemLabel = [[UILabel alloc] init];
                [itemLabel.layer setMasksToBounds:YES];
                [itemLabel setHidden:!_model.isShowDesc];
                [itemLabel setTextAlignment:NSTextAlignmentCenter];
                [itemLabel setAttributedText:attributedNameString];
                [itemLabel setBackgroundColor:itemBackgroundColor];
                [itemLabel addBorderWithColor:GAME_PLAY_ITEM_BORDER_COLOR_DEFAULT cornerRadius:itemNameWidth/2.0f andWidth:0.0f];
                [self.rightContainerView addSubview:itemLabel];
                
                [itemLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
                    make.width.mas_equalTo(itemNameWidth);
                    make.height.mas_equalTo(itemNameWidth);
                    
                    if (itemTotalWidth <= item_container_width) {
                        make.centerY.equalTo(self.rightContainerView.mas_centerY);
                        if (!lastItemLabel) {
                            make.left.equalTo(self.rightContainerView.mas_left).offset(left_margin);
                        } else {
                            make.left.equalTo(lastItemLabel.mas_right).offset(item_margin);
                        }
                    } else {
                        if (!lastItemLabel) {
                            make.top.equalTo(self.rightContainerView.mas_top).offset(top_margin);
                            make.left.equalTo(self.rightContainerView.mas_left).offset(left_margin);
                        } else {
                            if (0 == i % column) {
                                make.top.equalTo(lastItemLabel.mas_bottom).offset(item_margin);
                                make.left.equalTo(self.rightContainerView.mas_left).offset(left_margin);
                            } else {
                                make.top.equalTo(lastItemLabel.mas_top).offset(0);
                                make.left.equalTo(lastItemLabel.mas_right).offset(item_margin);
                            }
                        }
                    }
                    
                }];
                itemLabel.mas_key = [NSString stringWithFormat:@"itemLabel%d",i];
                
                itemLabel;
            });
            
            lastItemLabel = itemLabel;
        }
        
        // 约束的完整性
        [self.rightContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(lastItemLabel.mas_bottom).offset(bottom_margin).priority(749);
        }];
    }
    
}

#pragma mark - 表格列数
+ (NSInteger)numberOfColumnsAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassModel *)model
{
    NSInteger columns = 5.0;
    CGFloat nameWidthGap =  GAME_PLAY_MODEL_NAME_NUMBE_WIDTH_GAP;
    CGFloat left_margin = GAME_PLAY_ITEM_DESC_LEFT_MARGIN;
    CGFloat right_margin = GAME_PLAY_ITEM_DESC_RIGHT_MARGIN;
    CGFloat item_margin = GAME_PLAY_ITEM_DESC_ITEM_MARGIN;
    CGFloat item_container_width = (SCREEN_WIDTH - GAME_PLAY_COLLECTION_EDGEINSET * 2.0) * (1 - LEFT_VIEW_PERCENT) - GAME_PLAY_COLLECTION_ITEM_MARGIN;
    for (int i = 0; i < model.descArray.count; i ++) {
        UIFont *itemNameFont = model.descSelectFontArray[i];
        CGFloat itemNameWidth = [GAME_PLAY_MODEL_NAME_NUMBE_WIDTH_STR widthWithFont:itemNameFont constrainedToHeight:MAXFLOAT] + nameWidthGap;
        CGFloat totalWidth = itemNameWidth * (i+1) + item_margin * i + left_margin + right_margin;
        if (totalWidth > item_container_width) {
            return i;
        }
    }
    columns = (columns > model.descArray.count) ? columns : model.descArray.count;
    
    return columns;
}

#pragma mark - 表格行高
+ (CGFloat)heightForCellAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model
{
    CFCGameBetPlayClassModel *classModel = model.list[indexPath.row];
    if (classModel.descArray && classModel.descArray.count > 0) {
        NSInteger column = [[self class] numberOfColumnsAtIndexPath:indexPath cellModel:classModel];
        NSInteger rows = (0 == classModel.descArray.count % column) ? (classModel.descArray.count / column) : (classModel.descArray.count / column + 1);
        CGFloat top_margin = GAME_PLAY_ITEM_DESC_TOP_MARGIN;
        CGFloat bottom_margin = GAME_PLAY_ITEM_DESC_BOTTOM_MARGIN;
        CGFloat item_margin = GAME_PLAY_ITEM_DESC_ITEM_MARGIN;
        //
        CGFloat nameWidthGap =  GAME_PLAY_MODEL_NAME_NUMBE_WIDTH_GAP;
        UIFont *itemNameFont = classModel.descSelectFontArray[0];
        CGFloat itemNameWidth = [GAME_PLAY_MODEL_NAME_NUMBE_WIDTH_STR widthWithFont:itemNameFont constrainedToHeight:MAXFLOAT] + nameWidthGap;
        return top_margin + itemNameWidth * rows + item_margin * (rows - 1) + bottom_margin;
    }
    
    return GAME_PLAY_COLLECTION_ITEM_HEIGHT_DEFAULT;
}


#pragma mark - 操作事件 - 操作按钮
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture
{
    // 执行代理
    if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectPlayClassCredit2CollectionViewCellRowAtIndexPath:itemModels:itemIndexs:)]) {
        [self.delegate didSelectPlayClassCredit2CollectionViewCellRowAtIndexPath:self.indexPath
                                                                      itemModels:@[self.model]
                                                                      itemIndexs:@[[NSNumber numberWithInteger:self.indexPath.row]] ];
    }
}


@end








