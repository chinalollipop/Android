//
//  游戏 - 投注页面头部区域 - 玩法选择
//

#import <UIKit/UIKit.h>
@class CFCGameBetPlayTypeModel, CFCGameBetPlayTypeGroupModel, CFCGameBetPlayTypeClassModel;

NS_ASSUME_NONNULL_BEGIN

// 定义一个菜单的block
typedef void(^CFCGameBetPlayTypePopViewDismissBlock)(void);

@protocol CFCGameBetPlayTypePopViewDelegate <NSObject>
@required
// 验证玩法的页面是否存在
- (BOOL)canSelectedGameIdentifier:(NSString *)selectedGameIdentifier
           selectedTypeIdentifier:(NSString *)selectedTypeIdentifier
          selectedGroupIdentifier:(NSString *)selectedGroupIdentifier
          selectedClassIdentifier:(NSString *)selectedClassIdentifier
          selectedClassTitleName:(NSString *)selectedClassTitleName;
// 玩法页面存在则切换切换
- (void)didSelectedGameIdentifier:(NSString *)selectedGameIdentifier
           selectedTypeIdentifier:(NSString *)selectedTypeIdentifier
          selectedGroupIdentifier:(NSString *)selectedGroupIdentifier
          selectedClassIdentifier:(NSString *)selectedClassIdentifier
           selectedClassTitleName:(NSString *)selectedClassTitleName
            selectedPlayTypeModel:(CFCGameBetPlayTypeModel *)selectedGameBetPlayTypeModel
       selectedPlayTypeGroupModel:(CFCGameBetPlayTypeGroupModel *)selectedGameBetPlayTypeGroupModel
       selectedPlayTypeClassModel:(CFCGameBetPlayTypeClassModel *)selectedGameBetPlayTypeClassModel;
@end

@interface CFCGameBetPlayTypePopView : UIView

@property (nonatomic, strong) NSArray<CFCGameBetPlayTypeModel *> *playTypeModels;

@property (nonatomic, copy) CFCGameBetPlayTypePopViewDismissBlock afterDismissBlock;

@property (nonatomic, copy) NSString *selectedGameIdentifier; // 游戏标题

@property (nonatomic, copy) NSString *selectedTypeIdentifier; // 五星、四星

@property (nonatomic, copy) NSString *selectedGroupIdentifier; // 直选、组选

@property (nonatomic, copy) NSString *selectedClassIdentifier; // 直选复式、组选120

@property (nonatomic, copy) NSString *selectedClassTitleName; // 直选复式、组选120

@property (nonatomic, weak) id<CFCGameBetPlayTypePopViewDelegate> delegate;

@property (nonatomic, assign) CGFloat heightOfBottomAreaMainView; // 底部工具条高度

+ (instancetype)shareGamePlayTypePopView:(CGFloat)heightOfBottomAreaMainView;

- (void)show;

- (void)dismiss;

@end

NS_ASSUME_NONNULL_END
