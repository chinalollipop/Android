//
// 游戏 - 投注区 - 官方模式 - 11选5 - 详情页面
//

#import "CFC11X5PlayClassBaseOfficialViewController.h"


@interface CFC11X5PlayClassBaseOfficialViewController ()

@end


@implementation CFC11X5PlayClassBaseOfficialViewController


#pragma mark -
#pragma mark 事件处理 - 点击投注表格后处理数据 - 胆拖玩法
- (NSArray<NSIndexPath *> *)doRefreshDanTuoPlayClassCellRowAtIndexPath:(NSIndexPath *)indexPath
                                                            itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels
                                                            itemIndexs:(NSArray<NSNumber *> *)itemIndexs
                                                           danTuoCount:(NSInteger)count
{
    __block NSMutableArray<NSIndexPath *> *indexPaths = [NSMutableArray<NSIndexPath *> array];
    
    if (itemIndexs.count > 1) {
        
        // 全、大、小、单、双、清
        
        // 胆码
        if (self.dataOfSectionModelArray.count > 0) {
            CFCGameBetPlayClassSectionModel *sectionDanMaModel = self.dataOfSectionModelArray[0];
            CFCGameBetPlayClassSectionModel *sectionTuoMaModel = self.dataOfSectionModelArray[1];
            [itemIndexs enumerateObjectsUsingBlock:^(NSNumber * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                NSInteger itemIndex = obj.integerValue;
                if (itemIndex >= 0 && itemIndex < sectionDanMaModel.list.count && itemIndex < sectionTuoMaModel.list.count) {
                    CFCGameBetPlayClassModel *elemDanMa = sectionDanMaModel.list[itemIndex];
                    CFCGameBetPlayClassModel *elemTuoMa = sectionTuoMaModel.list[itemIndex];
                    elemDanMa.isSelected = elemTuoMa.isSelected ? NO : elemDanMa.isSelected;
                    //
                    NSIndexPath *itemIndexPath = [NSIndexPath indexPathForRow:itemIndex inSection:0];
                    [indexPaths addObject:itemIndexPath];
                }
            }];
        }
        
        // 拖码
        if (self.dataOfSectionModelArray.count > 1) {
            CFCGameBetPlayClassSectionModel *sectionTuoMaModel = self.dataOfSectionModelArray[1];
            [itemIndexs enumerateObjectsUsingBlock:^(NSNumber * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                NSInteger itemIndex = obj.integerValue;
                if (itemIndex >= 0 && itemIndex < sectionTuoMaModel.list.count) {
                    CFCGameBetPlayClassModel *elem = sectionTuoMaModel.list[itemIndex];
                    elem.isSelected = elem.isSelected;
                    //
                    NSIndexPath *itemIndexPath = [NSIndexPath indexPathForRow:itemIndex inSection:1];
                    [indexPaths addObject:itemIndexPath];
                }
            }];
        }
        
    } else if (itemIndexs.count > 0) {
        
        // 项目
        
        NSInteger itemIndex = [itemIndexs objectAtIndex:0].integerValue;
        
        if (0 == indexPath.section) {
            
            // 胆码
            if (self.dataOfSectionModelArray.count > 0) {
                // 选中的胆码
                CFCGameBetPlayClassSectionModel *sectionDanMaModel = self.dataOfSectionModelArray[0];
                if (itemIndex >= 0 && itemIndex < sectionDanMaModel.list.count) {
                    CFCGameBetPlayClassModel *elem = sectionDanMaModel.list[itemIndex];
                    elem.isSelected = !elem.isSelected;
                    //
                    NSIndexPath *itemIndexPath = [NSIndexPath indexPathForRow:itemIndex inSection:indexPath.section];
                    [indexPaths addObject:itemIndexPath];
                }
                // 胆码最多[danTuoCount-1]个
                __block NSInteger selectedDanMaCount = 0;
                [sectionDanMaModel.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    if (obj.isSelected) {
                        selectedDanMaCount ++;
                    }
                }];
                NSString *lastSelectedIndexKey = [NSString stringWithFormat:@"[%@-%@]", self.className, self.classCode];
                if (selectedDanMaCount > count-1) {
                    NSInteger lastSelectedIndex = [self.lastSelectedIndexOfDanMaDictionary objectForKey:lastSelectedIndexKey].integerValue;
                    if (lastSelectedIndex >= 0 && lastSelectedIndex < sectionDanMaModel.list.count) {
                        CFCGameBetPlayClassModel *elem = sectionDanMaModel.list[lastSelectedIndex];
                        elem.isSelected = NO;
                        //
                        NSIndexPath *itemIndexPath = [NSIndexPath indexPathForRow:lastSelectedIndex inSection:indexPath.section];
                        [indexPaths addObject:itemIndexPath];
                    }
                }
                // 存储最后个胆码下标
                [self.lastSelectedIndexOfDanMaDictionary setObject:[NSNumber numberWithInteger:itemIndex] forKey:lastSelectedIndexKey];
            }
            
            // 拖码
            if (self.dataOfSectionModelArray.count > 1) {
                CFCGameBetPlayClassSectionModel *sectionTuoMaModel = self.dataOfSectionModelArray[1];
                if (itemIndex >= 0 && itemIndex < sectionTuoMaModel.list.count) {
                    CFCGameBetPlayClassModel *elem = sectionTuoMaModel.list[itemIndex];
                    elem.isSelected = NO;
                    //
                    NSIndexPath *itemIndexPath = [NSIndexPath indexPathForRow:itemIndex inSection:1];
                    [indexPaths addObject:itemIndexPath];
                }
            }
            
        } else {
            
            // 胆码
            if (self.dataOfSectionModelArray.count > 0) {
                CFCGameBetPlayClassSectionModel *sectionDanMaModel = self.dataOfSectionModelArray[0];
                if (itemIndex >= 0 && itemIndex < sectionDanMaModel.list.count) {
                    CFCGameBetPlayClassModel *elem = sectionDanMaModel.list[itemIndex];
                    elem.isSelected = NO;
                    //
                    NSIndexPath *itemIndexPath = [NSIndexPath indexPathForRow:itemIndex inSection:0];
                    [indexPaths addObject:itemIndexPath];
                }
            }
            
            // 拖码
            if (self.dataOfSectionModelArray.count > 1) {
                CFCGameBetPlayClassSectionModel *sectionTuoMaModel = self.dataOfSectionModelArray[1];
                if (itemIndex >= 0 && itemIndex < sectionTuoMaModel.list.count) {
                    CFCGameBetPlayClassModel *elem = sectionTuoMaModel.list[itemIndex];
                    elem.isSelected = !elem.isSelected;
                    //
                    NSIndexPath *itemIndexPath = [NSIndexPath indexPathForRow:itemIndex inSection:indexPath.section];
                    [indexPaths addObject:itemIndexPath];
                }
            }
            
        }  // if (0 == indexPath.section)
        
    } // if (itemIndexs.count > 1)
    
    return indexPaths;
}


- (NSMutableDictionary *)lastSelectedIndexOfDanMaDictionary
{
    if (!_lastSelectedIndexOfDanMaDictionary) {
        _lastSelectedIndexOfDanMaDictionary = [[NSMutableDictionary alloc] init];
    }
    return _lastSelectedIndexOfDanMaDictionary;
}


@end

