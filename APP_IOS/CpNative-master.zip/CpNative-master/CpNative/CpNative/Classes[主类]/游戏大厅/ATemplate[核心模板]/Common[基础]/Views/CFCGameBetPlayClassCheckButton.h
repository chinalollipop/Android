//
//  游戏 - 官方玩法 - 投注设置框（全、大、小、单、双）
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCGameBetPlayClassCheckButton : UIControl

- (void)setChecked:(BOOL)boolValue;
- (void)setDisabled:(BOOL)boolValue;
- (void)setText:(NSString *)stringValue;

@property(nonatomic, copy) NSString *text;
@property(nonatomic, assign) BOOL checked;
@property(nonatomic, assign) BOOL disabled;

@property(nonatomic, strong) UIColor *normalBgColor;
@property(nonatomic, strong) UIColor *selectBgColor;

@property(nonatomic, strong) NSAttributedString *normalAttributedText;
@property(nonatomic, strong) NSAttributedString *selectAttributedText;

@end

NS_ASSUME_NONNULL_END
