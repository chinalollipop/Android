
#import "CFCGameBetPlayClassCollectionSectionHeaderView.h"

// Section Header Identifier
NSString * const CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_COLLECTION_SECTION_HEADER = @"CFCGameBetPlayClassCollectionSectionHeaderIdentifier";

@interface CFCGameBetPlayClassCollectionSectionHeaderView ()

@property (nonatomic, strong) UILabel *contentLabel;

@end

@implementation CFCGameBetPlayClassCollectionSectionHeaderView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        CGFloat magin = CFC_AUTOSIZING_MARGIN(MARGIN);
        self.contentLabel = [[UILabel alloc] init];
        [self addSubview:self.contentLabel];
        [self.contentLabel setNumberOfLines:0];
        [self.contentLabel setTextAlignment:NSTextAlignmentCenter];
        [self.contentLabel setFont:GROUP_CREDIT_FONT_GAME_PLAY_ITEM_TITLE];
        [self.contentLabel setTextColor:GROUP_CREDIT_COLOR_GAME_PLAY_ITEM_TITLE];
        [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self.mas_centerX);
            make.width.equalTo(self.mas_width);
            make.bottom.equalTo(self.mas_bottom).offset(-magin*0.5f);
        }];
    }
    return self;
}

- (void)setModel:(CFCGameBetPlayClassSectionModel *)model
{
    if (_model) {
        [_model removeObserver:self forKeyPath:@"title"];
        _model = nil;
    }
    
    _model = model;

    [_model addObserver:self forKeyPath:@"title" options:NSKeyValueObservingOptionNew | NSKeyValueObservingOptionOld context:NULL];
    
    [_contentLabel setText:model.title];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    if ([keyPath isEqualToString:@"title"]) {
        [self.contentLabel setText:_model.title];
    } else {
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}

- (void)dealloc
{
    [_model removeObserver:self forKeyPath:@"title"];
}


@end



