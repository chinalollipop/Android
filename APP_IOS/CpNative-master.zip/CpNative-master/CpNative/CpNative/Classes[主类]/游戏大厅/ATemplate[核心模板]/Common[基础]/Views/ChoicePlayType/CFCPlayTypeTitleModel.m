//
//  游戏 - 投注页面头部区域 - 玩法选择 - 标题
//

#import "CFCPlayTypeTitleModel.h"

@implementation CFCPlayTypeTitleModel

@end
