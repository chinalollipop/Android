//
// 游戏 - 投注区 - 选注页面（帮助工具）
//


#import "CFCGameBetPlayClassViewController+Helpers.h"

@implementation CFCGameBetPlayClassViewController (Helpers)


#pragma mark -
#pragma mark 帮助工具 - 分组类型 - 分组内容是否是投注号码
- (BOOL)isNormalSectionModel:(CFCGameBetPlayClassSectionModel *)sectionModel
{
    if ([self isCheckboxSectionModel:sectionModel]
        || [self isSingleSectionModel:sectionModel]) {
        return NO;
    }
    return YES;
}

#pragma mark 帮助工具 - 分组类型 - 分组内容是否是复选按钮
- (BOOL)isCheckboxSectionModel:(CFCGameBetPlayClassSectionModel *)sectionModel
{
    // 投注项目，有复选按钮 -> 如：时时彩官方玩法中<任选二、任选三>玩法中的复选按钮
    if (CFCGameBetPlayClassSectionTypeOfficial3 == sectionModel.type) {
        return YES;
    }
    return NO;
}

#pragma mark 帮助工具 - 分组类型 - 分组内容是否是单式号码
- (BOOL)isSingleSectionModel:(CFCGameBetPlayClassSectionModel *)sectionModel
{
    // 投注项目，有操作按钮 -> 如：时时彩、极速3D官方玩法中<单式、混合组选>
    // 投注项目，有操作按钮 -> 如：北京PK拾、11选5官方玩法中<单式、混合组选>
    if (CFCGameBetPlayClassSectionTypeOfficial6 == sectionModel.type
        || CFCGameBetPlayClassSectionTypeOfficial7 == sectionModel.type) {
        return YES;
    }
    return NO;
}


#pragma mark -
#pragma mark 帮助工具 - 投注总数 - 排列注数
- (NSInteger)numberOfBettingRecordsForArrangement:(NSInteger)m
{
    __block NSInteger numberOfBettingRecords = 0;
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull obj0, NSUInteger idx0, BOOL * _Nonnull stop0) {
        if ([self isNormalSectionModel:obj0]) { // 分组内容是否是投注号码
            [obj0.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull obj1, NSUInteger idx1, BOOL * _Nonnull stop1) {
                if (obj1.isSelected) {
                    numberOfBettingRecords ++;
                }
            }];
        }
    }];
    return [CFCPaiLieZuHeMathUtil arrangementWithN:numberOfBettingRecords andM:m];
}


#pragma mark 帮助工具 - 投注总数 - 组合注数
- (NSInteger)numberOfBettingRecordsForCombination:(NSInteger)m
{
    __block NSInteger numberOfBettingRecords = 0;
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull obj0, NSUInteger idx0, BOOL * _Nonnull stop0) {
        if ([self isNormalSectionModel:obj0]) { // 分组内容是否是投注号码
            [obj0.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull obj1, NSUInteger idx1, BOOL * _Nonnull stop1) {
                if (obj1.isSelected) {
                    numberOfBettingRecords ++;
                }
            }];
        }
    }];
    return [CFCPaiLieZuHeMathUtil combinationWithN:numberOfBettingRecords andM:m];
}


#pragma mark -
#pragma mark 帮助工具 - 投注内容 - 排列内容
- (NSArray<NSString *> *)contentOfBettingRecordsForArrangement:(NSInteger)m
{
    __block NSMutableArray<NSString *> *selectedItems = [NSMutableArray arrayWithCapacity:0];
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull obj0, NSUInteger idx0, BOOL * _Nonnull stop0) {
        if ([self isNormalSectionModel:obj0]) { // 分组内容是否是投注号码
            [obj0.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull obj1, NSUInteger idx1, BOOL * _Nonnull stop1) {
                if (obj1.isSelected) {
                    [selectedItems addObject:obj1.name];
                }
            }];
        }
    }];
    
    if (m > selectedItems.count) {
        return [NSArray array];
    }
    
    NSMutableArray<NSString *> *contents = [NSMutableArray arrayWithCapacity:0];
    NSArray *bettingRecords = [CFCPaiLieZuHeMathUtil arrangementSelect:selectedItems andN:m];
    if (!bettingRecords || 0 == bettingRecords.count) {
        return [NSArray array];
    }
    
    WEAKSELF(weakSelf);
    NSString *bettingMoney = @"1";
    
    CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[0];
    CFCGameBetPlayClassModel *playClassModel = sectionModel.list[0];
    [bettingRecords enumerateObjectsUsingBlock:^(NSArray * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSString *money = [CFCSysUtil validateStringEmpty:bettingMoney] ? STR_APP_TEXT_NULL : bettingMoney;
        NSString *betNumbers = [obj componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_COMMA];
        NSString *content = STR_PLAY_CLASS_BETTING_CONTENT(weakSelf.className, betNumbers, playClassModel.odds, money);
        [contents addObject:content];
    }];
    
    return contents;
}


#pragma mark 帮助工具 - 投注内容 - 组合内容
- (NSArray<NSString *> *)contentOfBettingRecordsForCombination:(NSInteger)m
{
    __block NSMutableArray<NSString *> *selectedItems = [NSMutableArray arrayWithCapacity:0];
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull obj0, NSUInteger idx0, BOOL * _Nonnull stop0) {
        if ([self isNormalSectionModel:obj0]) { // 分组内容是否是投注号码
            [obj0.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull obj1, NSUInteger idx1, BOOL * _Nonnull stop1) {
                if (obj1.isSelected) {
                    [selectedItems addObject:obj1.name];
                }
            }];
        }
    }];
    
    if (m > selectedItems.count) {
        return [NSArray array];
    }
    
    NSMutableArray<NSString *> *contents = [NSMutableArray arrayWithCapacity:0];
    NSArray *bettingRecords = [CFCPaiLieZuHeMathUtil combinationSelect:selectedItems andN:m];
    if (!bettingRecords || 0 == bettingRecords.count) {
        return [NSArray array];
    }
    
    WEAKSELF(weakSelf);
    NSString *bettingMoney = @"1";
    
    CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[0];
    CFCGameBetPlayClassModel *playClassModel = sectionModel.list[0];
    [bettingRecords enumerateObjectsUsingBlock:^(NSArray * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSString *money = [CFCSysUtil validateStringEmpty:bettingMoney] ? STR_APP_TEXT_NULL : bettingMoney;
        NSString *betNumbers = [obj componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_COMMA];
        NSString *content = STR_PLAY_CLASS_BETTING_CONTENT(weakSelf.className, betNumbers, playClassModel.odds, money);
        [contents addObject:content];
    }];
    
    return contents;
}


#pragma mark -
#pragma mark 帮助工具 - 投注结果 - 结果模板N01 - 号码格式（01 02 03 04 05 06 07 08 09 10|01 02 03 04 05 06 07 08 09 10）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsTemplateN01:(NSDictionary *)dictOfBetSetting
{
    // 默认投注结果
    CFCGameBetRecordModel *model = [self buildindBettingResultModelForBettingRecordsOfCompose:dictOfBetSetting];
    
    // 投注号码格式（01 02 03 04 05 06 07 08 09 10|01 02 03 04 05 06 07 08 09 10）
    __block NSMutableArray<NSString *> *all_selected_numbers = [NSMutableArray array];
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull obj0, NSUInteger idx0, BOOL * _Nonnull stop0) {
        // 分组内容是否是投注号码
        if ([self isNormalSectionModel:obj0]) {
            // 每一组选中的投注号码的数组
            __block NSMutableArray<NSString *> *section_selected_numbers = [NSMutableArray array];
            [obj0.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull obj1, NSUInteger idx1, BOOL * _Nonnull stop1) {
                if (obj1.isSelected) {
                    [section_selected_numbers addObject:obj1.classNumber];
                }
            }];
            // 每一组选中的投注号码字符串
            NSString *selected_numbers_string = [section_selected_numbers componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_SPACE];
            if (selected_numbers_string.length > 0) {
                [all_selected_numbers addObject:selected_numbers_string];
            } else {
                [all_selected_numbers addObject:@""];
            }
        }
    }];
    NSString *all_selected_numbers_string = [all_selected_numbers componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_VERTICAL];
    [model setBall:all_selected_numbers_string]; // 投注号码格式
    
    // 投注结果列表
    return [NSArray<CFCGameBetRecordModel *> arrayWithObject:model];
}


#pragma mark 帮助工具 - 投注结果 - 结果模板N02 - 号码格式（01|02|03|04|05|06|07|08|09|10*01|02|03|04|05|06|07|08|09|10）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsTemplateN02:(NSDictionary *)dictOfBetSetting
{
    // 默认投注结果
    CFCGameBetRecordModel *model = [self buildindBettingResultModelForBettingRecordsOfCompose:dictOfBetSetting];
    
    // 投注号码格式（01|02|03|04|05|06|07|08|09|10*01|02|03|04|05|06|07|08|09|10）
    __block NSMutableArray<NSString *> *all_selected_numbers = [NSMutableArray array];
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull obj0, NSUInteger idx0, BOOL * _Nonnull stop0) {
        // 分组内容是否是投注号码
        if ([self isNormalSectionModel:obj0]) {
            // 每一组选中的投注号码的数组
            __block NSMutableArray<NSString *> *section_selected_numbers = [NSMutableArray array];
            [obj0.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull obj1, NSUInteger idx1, BOOL * _Nonnull stop1) {
                if (obj1.isSelected) {
                    [section_selected_numbers addObject:obj1.classNumber];
                }
            }];
            // 每一组选中的投注号码字符串
            NSString *selected_numbers_string = [section_selected_numbers componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_VERTICAL];
            if (selected_numbers_string.length > 0) {
                [all_selected_numbers addObject:selected_numbers_string];
            } else {
                [all_selected_numbers addObject:@""];
            }
        }
    }];
    NSString *all_selected_numbers_string = [all_selected_numbers componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_ASTERISK];
    [model setBall:all_selected_numbers_string]; // 投注号码格式
    
    // 投注结果列表
    return [NSArray<CFCGameBetRecordModel *> arrayWithObject:model];
}


#pragma mark 帮助工具 - 投注结果 - 结果模板N03 - 号码格式（012345678910|012345678910|012345678910|012345678910）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsTemplateN03:(NSDictionary *)dictOfBetSetting
{
    // 默认投注结果
    CFCGameBetRecordModel *model = [self buildindBettingResultModelForBettingRecordsOfCompose:dictOfBetSetting];
    
    // 投注号码格式（012345678910|012345678910）
    __block NSMutableArray<NSString *> *all_selected_numbers = [NSMutableArray array];
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull obj0, NSUInteger idx0, BOOL * _Nonnull stop0) {
        // 分组内容是否是投注号码
        if ([self isNormalSectionModel:obj0]) {
            // 每一组选中的投注号码的数组
            __block NSMutableArray<NSString *> *section_selected_numbers = [NSMutableArray array];
            [obj0.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull obj1, NSUInteger idx1, BOOL * _Nonnull stop1) {
                if (obj1.isSelected) {
                    [section_selected_numbers addObject:obj1.classNumber];
                }
            }];
            // 每一组选中的投注号码字符串
            NSString *selected_numbers_string = [section_selected_numbers componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_NONE];
            if (selected_numbers_string.length > 0) {
                [all_selected_numbers addObject:selected_numbers_string];
            } else {
                [all_selected_numbers addObject:@""];
            }
        }
    }];
    NSString *all_selected_numbers_string = [all_selected_numbers componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_VERTICAL];
    [model setBall:all_selected_numbers_string]; // 投注号码格式
    
    // 投注结果列表
    return [NSArray<CFCGameBetRecordModel *> arrayWithObject:model];
}


@end

