//
// 游戏 - 投注区 - 官方模式
//

#import "CFCGameBetOfficialViewController.h"
#import "CFCBettingSuccessPopNoticeView.h"
#import "CFCBettingFailurePopNoticeView.h"
#import "CFCGameBetSliderView.h"
#import "LoginViewController.h"


@interface CFCGameBetOfficialViewController () <CWPopMenuDelegate, CFCGameBetSliderViewDelegate, UITextFieldDelegate> {
    CGFloat _transformY; // 位置偏移量
    CGFloat _currentKeyboardHeight; // 当前键盘高度
    BOOL _keyboardNotificationEnable; // 键盘通知是否可用
}
/**
 * 投注弹框 - 成功提示
 */
@property (nonatomic, strong) CFCBettingSuccessPopNoticeView *popNoticeSuccessView;
/**
 * 投注弹框 - 失败提示
 */
@property (nonatomic, strong) CFCBettingFailurePopNoticeView *popNoticeFailureView;
/**
 * 底部区域 - 容器控件
 */
@property (nonatomic, strong) UIView *bottomAreaContainerView;
/**
 * 底部区域 - 滑条控件
 */
@property (nonatomic, strong) CFCGameBetSliderView *bottomAreaSliderView;
/**
 * 底部区域 - 单位按钮
 */
@property (nonatomic, strong) CWPopMenu *menuOfUnitPopView;
@property (nonatomic, strong) UILabel *buttonUnitModelLabel;
@property (nonatomic, strong) NSMutableArray<CWPopMenuModel *> *arryOfUnitModes;
/**
 * 底部区域 - 倍输入框
 */
@property (nonatomic, strong) UITextField *multipleTextField;
/**
 * 底部区域 - 清空按钮
 */
@property (nonatomic, strong) UILabel *buttonClearLabel;
/**
 * 底部区域 - 投注按钮
 */
@property (nonatomic, strong) UILabel *buttonSubmitLabel;
/**
 * 底部区域 - 确认按钮
 */
@property (nonatomic, strong) UILabel *buttonConfimLabel;
/**
 * 底部区域 - 投注信息
 */
@property (nonatomic, strong) UILabel *bettingInfomationLabel;


@end


@implementation CFCGameBetOfficialViewController


#pragma mark -
#pragma mark 事件处理 - 单位按钮事件
- (void)doBettingButtonUnitModelAction:(UITapGestureRecognizer *)gesture
{
    [self resignFirstResponderOfTextField];
    
    [self.menuOfUnitPopView showMenu:YES];
}

#pragma mark 事件处理 - 清空按钮事件
- (void)doBettingButtonClearAction:(UITapGestureRecognizer *)gesture
{
    [self resignFirstResponderOfTextField];
    
    // 清空投注信息
    [self setBettingNumberValue:@"0"];
    [self setBettingInfomationLabelValue:@"0"];
    
    // 清空子页面数据
    if (self.delegate_betting_playclass && [self.delegate_betting_playclass respondsToSelector:@selector(doClearButtonActionForPlayClassViewController)]) {
        [self.delegate_betting_playclass doClearButtonActionForPlayClassViewController];
    } else {
        NSAssert(NO, @"[CFCGameBetPlayClassViewController]类必须实现代理方法[doClearButtonActionForPlayClassViewController]");
    }
}

#pragma mark 事件处理 - 投注按钮事件
- (void)doBettingButtonSubmitAction:(UITapGestureRecognizer *)gesture
{
    // 注销键盘焦点
    [self resignFirstResponderOfTextField];
    
    // 验证登录状态
    if ([Singleton shared].loginState == LoginStateNone) {
        LoginViewController *login = [[LoginViewController alloc] init];
        [self.navigationController pushViewController:login animated:YES];
        return;
    }
    
    // 投注按钮事件
    if (self.delegate_betting_playclass && [self.delegate_betting_playclass respondsToSelector:@selector(doBettingButtonActionForPlayClassViewController)]) {
        [self.delegate_betting_playclass doBettingButtonActionForPlayClassViewController];
    } else {
        NSAssert(NO, @"[CFCGameBetPlayClassViewController]类必须实现代理方法[doBettingButtonActionForPlayClassViewController]");
    }
    
    // 验证投注注数
    if ([CFCSysUtil validateObjectIsNull:self.bettingNumberValue] || self.bettingNumberValue.integerValue <= 0) {
        [TSMessage showNotificationInViewController:self.parentViewController.parentViewController.parentViewController
                                              title:NSLocalizedString(STR_ALERT_MESSAGE_TITLE_INFO, nil)
                                           subtitle:NSLocalizedString(@"提示：请您正解选择投注号码！", nil)
                                               type:TSMessageNotificationTypeMessage
                                           duration:ALERT_MESSAGE_DURATION];
        return;
    }
    
    // 投注提交数据
    [self doBettingButtonSubmitActionRequestWithDictionaryOfSetting];
}

#pragma mark 事件处理 - 确认按钮事件
- (void)doBettingButtonConfimAction:(UITapGestureRecognizer *)gesture
{
    [self resignFirstResponderOfTextField];
    
    [Tools alertWithTitle:@"此功能正在开发中！" message:nil handle:nil cancel:nil confirm:@"确定"];
}


#pragma mark -
#pragma mark 逻辑处理 - 投注按钮事件 - 提交数据
- (void)doBettingButtonSubmitActionRequestWithDictionaryOfSetting
{
    // 获取投注记录数据模型列表
    NSArray<CFCGameBetRecordModel *> *bettingRecordModels = nil;
    if (!self.delegate_betting_playclass || ![self.delegate_betting_playclass respondsToSelector:@selector(bettingRecordModelsFromPlayClassViewController:)]) {
        NSAssert(NO, @"[CFCGameBetPlayClassViewController]类必须实现代理方法[bettingRecordModelsFromPlayClassViewController:]");
    } else {
        // 获取单位、倍数、类型信息
        NSMutableDictionary *dictOfBetSetting = [NSMutableDictionary dictionary];
        [dictOfBetSetting setValue:[CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.bettingTypeValue]
                            forKey:KEY_BETTING_RESULT_PLAY_TYPE]; // 类型标识
        [dictOfBetSetting setValue:[CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.bettingPSeriesWayIdValue]
                            forKey:KEY_BETTING_RESULT_WAY_UUID]; // 类型主键
        [dictOfBetSetting setValue:[CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.bettingUnitValue]
                            forKey:KEY_BETTING_RESULT_MONEY_UNIT]; // 单位
        [dictOfBetSetting setValue:[CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.bettingMultipleValue]
                            forKey:KEY_BETTING_RESULT_MULTIPLE]; // 倍数
        [dictOfBetSetting setValue:[CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.bettingNumberValue]
                            forKey:KEY_BETTING_RESULT_BET_NUMBER]; // 投注总数
        [dictOfBetSetting setValue:[CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.bettingPriceValue]
                            forKey:KEY_BETTING_RESULT_ONE_PRICE]; // 价格
        [dictOfBetSetting setValue:[CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.bottomAreaSliderView.sliderRateValue]
                            forKey:KEY_BETTING_RESULT_RATE_GROUP]; // 返点
        [dictOfBetSetting setValue:[CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.bottomAreaSliderView.sliderPrizeValue]
                            forKey:KEY_BETTING_RESULT_PRIZE_GROUP]; // 奖金组
        [dictOfBetSetting setValue:@""
                            forKey:KEY_BETTING_RESULT_VIEW_BALLS]; // 未知
        // 获取投注记录数据模型列表
        bettingRecordModels = [self.delegate_betting_playclass bettingRecordModelsFromPlayClassViewController:dictOfBetSetting];
    }
    
    
    // 获取生成追号数据记录列表
    NSMutableDictionary<NSString *, NSString *> *bettingOrderDict = [NSMutableDictionary<NSString *, NSString *> dictionary];
    // 获取当前时间投注盘口期号
    if (self.delegate_betting_header && [self.delegate_betting_header respondsToSelector:@selector(currentBettingIssueNumberFromPlayScrollViewHeader)]) {
        NSString *currentIssueNumber = [self.delegate_betting_header currentBettingIssueNumberFromPlayScrollViewHeader];
        [bettingOrderDict setValue:@"1" forKey:[CFCSysUtil stringByTrimmingWhitespaceAndNewline:currentIssueNumber]];
    } else {
        NSAssert(NO, @"[CFCGameBetPlayScrollViewHeader]类必须实现代理方法[currentBettingIssueNumberFromPlayScrollViewHeader]");
    }
    
    
    // 创建生成投注结果数据模型
    CFCGameBetFormModel *bettingResultModel = [CFCGameBetFormModel buildingDataModleForBettingForms];
    [bettingResultModel setGameId:self.gameId];
    [bettingResultModel setBalls:bettingRecordModels];
    [bettingResultModel setAmount:self.bettingAmountValue];
    [bettingResultModel setOrders:[NSDictionary dictionaryWithDictionary:bettingOrderDict]];
    NSString *dataOfResultJSONString = bettingResultModel.yy_modelToJSONString;
    CFCLog(@"Result JSON String => %@", dataOfResultJSONString);

    
    // 请求地址与参数
    NSString *url = URL_API_GAME_BETTING;
    NSMutableDictionary *params = [CFCNetworkParamsUtil getGameBettingParameters:self.gameId data:dataOfResultJSONString];
    CFCLog(@"\n请求地址：%@ \n请求参数：%@", url, params);
    
    
    // 提交的逻辑处理
    [CFCNetworkHTTPSessionUtil POST:url parameters:params success:^(id responseObject) {
        
        // 请求成功，解析数据
        NSDictionary *data = [responseObject objectForKey:CFC_REQUEST_KEY_DATA];
        NSInteger status = [[responseObject objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
        NSString *message = [responseObject objectForKey:CFC_REQUEST_KEY_MESS];
        if ([CFCSysUtil validateResultCodeIsSuccess:status] && ![CFCSysUtil validateObjectIsNull:data]) {
            
            CFCLog(@"投注请求成功：%@", responseObject);
            
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.popNoticeSuccessView setContent:@"投注成功"];
                [self.popNoticeSuccessView setCount:3L];
                [self.popNoticeSuccessView show];
            });

        } else {
            
            CFCLog(@"投注请求失败：%@", message);
            
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.popNoticeFailureView setContent:message];
                [self.popNoticeFailureView setCount:3L];
                [self.popNoticeFailureView show];
            });
            
        }

    } failure:^(NSError *error) {
        
        CFCLog(@"投注请求异常：%@", error);
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.popNoticeFailureView setContent:@"请求数据异常"];
            [self.popNoticeFailureView setCount:3L];
            [self.popNoticeFailureView show];
        });
        
    } showMessage:@"提交中..." showProgressHUD:YES isHideErrorMessage:YES];
    
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // 创建底部主区域
    [self createBottomAreaMainView];
}

#pragma mark 视图生命周期（将要显示）
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    _keyboardNotificationEnable = NO; // 键盘通知是否可用
    
    [self setKeyboardManagerEnabled:[[IQKeyboardManager sharedManager] isEnabled]];
    
    [[IQKeyboardManager sharedManager] setEnable:NO];
}

#pragma mark 视图生命周期（将要消失）
- (void)viewDidDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    _keyboardNotificationEnable = NO; // 键盘通知是否可用
    
    [[IQKeyboardManager sharedManager] setEnable:self.keyboardManagerEnabled];
}

#pragma mark 创建底部主区域
- (void)createBottomAreaMainView
{
    CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
    CGFloat button_width = CFC_AUTOSIZING_WIDTH(62.0f);
    CGFloat button_height = CFC_GAME_PLAY_SCROLL_BOTTOM_BUTTON_HEIGHT * 0.65f;
    CGFloat button_left_right_margin = margin * 0.5f;
    UIColor *button_title_color = COLOR_HEXSTRING(@"#FFFFFF");
    UIFont *button_title_font = [UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(12.5f)];
    
    // 单位、倍数边框
    UIColor *borderColor = COLOR_HEXSTRING(@"#C6C6C6");
    
    // 单位
    UIFont *unitFont = [UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(14.0f)];
    UIColor *unitColor = COLOR_GAME_DRAW_RESULT_ISSUE_CHINESE;
    
    // 倍数
    UIFont *textFieldFont = [UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)];
    UIColor *textFieldColor = COLOR_GAME_DRAW_RESULT_ISSUE_CHINESE;
    UIColor *textFieldPlaceholderColor = [UIColor colorWithRed:0.68 green:0.68 blue:0.68 alpha:1.00]; // 输入框暂位符颜色
    
    //
    UIColor *container_color = COLOR_HEXSTRING(@"#000000");
    UIColor *container_line_color = COLOR_HEXSTRING(@"#424242");
    UIFont *content_font = [UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(13.0f)];
    
    
    // 底部区域 - 此处必须手动计算尺寸大小，不能使用Masonry
    UIView *bottomAreaContainerView = ({
        CGFloat heightOfBottom = [self heightOfBottomAreaMainView];
        CGRect frame = CGRectMake(0,
                                  self.view.height - heightOfBottom - STATUS_NAVIGATION_BAR_HEIGHT - SCROLL_GAME_SUB_TAB_HEIGHT,
                                  self.view.width,
                                  heightOfBottom);
        UIView *container = [[UIView alloc] initWithFrame:frame];
        [self.view addSubview:container];
        [container setBackgroundColor:container_color];

        container;
    });
    self.bottomAreaContainerView = bottomAreaContainerView;
    self.bottomAreaContainerView.mas_key = @"bottomAreaBettingMoneyView";
    
    
    // 底部区域 - 模式、倍数配置区域高度
    UIView *bottomAreaSettingView = ({
        // 容器
        UIView *container = [[UIView alloc] initWithFrame:CGRectMake(0,
                                                                     0,
                                                                     bottomAreaContainerView.width,
                                                                     CFC_GAME_PLAY_SCROLL_BOTTOM_SETTING_HEIGHT)];
        [bottomAreaContainerView addSubview:container];
        [container setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_FRONT];
        
        // 分割线
        UIView *topLineView = ({
            UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, -SEPARATOR_LINE_HEIGHT, container.width, SEPARATOR_LINE_HEIGHT)];
            [container addSubview:view];
            [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
            
            view;
        });
        topLineView.mas_key = @"topLineView";
        
        // 单位（元、角、分、厘）
        UILabel *buttonUnitModelLabel = ({
            CGFloat width = container.height * 0.85f;
            CGFloat height = container.height * 0.7f;
            CGFloat x = margin*0.5f;
            CGFloat y = (container.height-height)/2.0f;
            UILabel *label = [[UILabel alloc]  initWithFrame:CGRectMake(x, y, width, height)];
            [container addSubview:label];
            [label setFont:unitFont];
            [label setTextColor:unitColor];
            [label setText:STR_BETTING_UNIT_YUAN];
            [label setUserInteractionEnabled:YES];
            [label setTextAlignment:NSTextAlignmentCenter];
            [label addBorderWithColor:borderColor cornerRadius:margin*0.5f andWidth:1.0f];

            label;
        });
        self.buttonUnitModelLabel = buttonUnitModelLabel;
        self.buttonUnitModelLabel.mas_key = @"buttonUnitModelLabel";
        
        // 单位（元、角、分、厘）
        UILabel *unitModelLabel = ({
            CGFloat width = container.height * 0.8f;
            CGFloat height = container.height * 0.7f;
            CGFloat x = CGRectGetMaxX(buttonUnitModelLabel.frame);
            CGFloat y = (container.height-height)/2.0f;
            UILabel *label = [[UILabel alloc]  initWithFrame:CGRectMake(x, y, width, height)];
            [container addSubview:label];
            [label setFont:unitFont];
            [label setTextColor:unitColor];
            [label setText:@"模式"];
            [label setUserInteractionEnabled:YES];
            [label setTextAlignment:NSTextAlignmentLeft];

            label;
        });
        unitModelLabel.mas_key = @"unitModelLabel";
        
        // 单位（元、角、分、厘）
        UILabel *unitModelActionLabel = ({
            UILabel *label = [[UILabel alloc]  initWithFrame:CGRectMake(0, 0, CGRectGetMaxX(unitModelLabel.frame), container.height)];
            [container addSubview:label];
            [label setUserInteractionEnabled:YES];
        
            UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doBettingButtonUnitModelAction:)];
            [label addGestureRecognizer:tapGesture];
            
            label;
        });
        unitModelActionLabel.mas_key = @"unitModelActionLabel";
        
        // 倍输入框
        UITextField *multipleTextField = ({
            CGFloat textFieldWidth = container.height * 0.85f;
            CGFloat textFieldHeight = container.height * 0.70f;
            CGFloat textFieldX = CGRectGetMaxX(unitModelActionLabel.frame);
            CGFloat textFieldY = (container.height-textFieldHeight)/2.0f;
            UITextField *textField = [[UITextField alloc] initWithFrame:CGRectMake(textFieldX, textFieldY, textFieldWidth, textFieldHeight)];
            [container addSubview:textField];
            [textField setDelegate:self];
            [textField setFont:textFieldFont];
            [textField setTextColor:textFieldColor];
            [textField setText:STR_BETTING_MULTIPLE_DEFAULT];
            [textField setTextAlignment:NSTextAlignmentCenter];
            [textField setKeyboardType:UIKeyboardTypeNumberPad];
            [textField setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
            [textField addBorderWithColor:borderColor cornerRadius:margin*0.5f andWidth:1.0f];
            [textField setAttributedPlaceholder:[[NSAttributedString alloc] initWithString:@"倍数" attributes:@{ NSForegroundColorAttributeName : textFieldPlaceholderColor }]];
            
            // 倍
            UILabel *textFieldLabel = ({
                CGFloat x = CGRectGetMaxX(textField.frame) + margin*0.2f;
                UILabel *label = [[UILabel alloc]  initWithFrame:CGRectMake(x, textFieldY, textFieldWidth, textFieldHeight)];
                [container addSubview:label];
                [label setFont:unitFont];
                [label setTextColor:unitColor];
                [label setText:@"倍"];
                [label setTextAlignment:NSTextAlignmentLeft];
                
                label;
            });
            textFieldLabel.mas_key = @"textFieldLabel";
            
            textField;
        });
        self.multipleTextField = multipleTextField;
        self.multipleTextField.mas_key = @"multipleTextField";
        
        // 滑条控件
        CFCGameBetSliderView *bottomAreaSliderView = ({
            CGFloat left_percent = 0.39f;
            CFCGameBetSliderView *sliderView = [[CFCGameBetSliderView alloc] initWithFrame:CGRectMake(container.width*left_percent, 0, container.width*(1-left_percent), container.height)];
            [sliderView setDelegate:self];
            [container addSubview:sliderView];

            sliderView;
        });
        self.bottomAreaSliderView = bottomAreaSliderView;
        self.bottomAreaSliderView.mas_key = @"bottomAreaSliderView";
        
        container;
    });
    bottomAreaSettingView.mas_key = @"bottomAreaSettingView";
    
    
    // 底部区域 - 清空、投注按钮区域高度
    UIView *bottomAreaButtonView = ({
        // 容器
        UIView *container = [[UIView alloc] initWithFrame:CGRectMake(0,
                                                                     CFC_GAME_PLAY_SCROLL_BOTTOM_SETTING_HEIGHT,
                                                                     bottomAreaContainerView.width,
                                                                     CFC_GAME_PLAY_SCROLL_BOTTOM_BUTTON_HEIGHT)];
        [bottomAreaContainerView addSubview:container];
        [container setBackgroundColor:container_color];
        
        // 清空按钮
        UILabel *buttonClearLabel = ({
            CGFloat label_width = container.height *0.75f;
            UILabel *label = [[UILabel alloc]  initWithFrame:CGRectMake(0, 0, label_width, container.height)];
            [container addSubview:label];
            [label setUserInteractionEnabled:YES];
            
            // 事件
            UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doBettingButtonClearAction:)];
            [label addGestureRecognizer:tapGesture];
            
            // 图片
            UIImageView *clearImageView = ({
                CGSize imageSize = CGSizeMake(label_width*0.62f, label_width*0.62f);
                UIImage *image = [[UIImage imageNamed:ICON_GAME_BETTING_CLEAR] imageByScalingProportionallyToSize:imageSize];
                UIImageView *imageView = [UIImageView new];
                [label addSubview:imageView];
                [imageView setImage:image];
                [imageView setUserInteractionEnabled:YES];
                [imageView setContentMode:UIViewContentModeScaleAspectFit];
                
                [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.centerX.equalTo(label.mas_centerX);
                    make.centerY.equalTo(label.mas_centerY).offset(margin*0.1f);
                    make.size.mas_equalTo(imageSize);
                }];
                
                imageView;
            });
            clearImageView.mas_key = @"clearImageView";
            
            // 竖线
            UIView *verticalLineView = ({
                UIView *view = [[UIView alloc] initWithFrame:CGRectMake(label_width, (container.height-button_height)/2.0f, 1.0f, button_height)];
                [label addSubview:view];
                [view setBackgroundColor:container_line_color];
                
                view;
            });
            verticalLineView.mas_key = @"verticalLineView";
            
            label;
        });
        self.buttonClearLabel = buttonClearLabel;
        self.buttonClearLabel.mas_key = @"buttonClearLabel";
        
        // 确认按钮
        UILabel *buttonConfimLabel = ({
            CGFloat btnX = container.width - button_left_right_margin - button_width;
            CGFloat btnY = (container.height-button_height)/2.0f;
            UILabel *label = [[UILabel alloc]  initWithFrame:CGRectMake(btnX, btnY, button_width, button_height)];
            [container addSubview:label];
            [label setText:@"确认选号"];
            [label setFont:button_title_font];
            [label setTextColor:button_title_color];
            [label addCornerRadius:margin*0.5f];
            [label setUserInteractionEnabled:YES];
            [label setTextAlignment:NSTextAlignmentCenter];
            [label setBackgroundColor:COLOR_HEXSTRING(@"#E67B2F")];
            
            UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doBettingButtonConfimAction:)];
            [label addGestureRecognizer:tapGesture];
            
            label;
        });
        self.buttonConfimLabel = buttonConfimLabel;
        self.buttonConfimLabel.mas_key = @"buttonConfimLabel";
        
        // 投注按钮
        UILabel *buttonSubmitLabel = ({
            // CGFloat btnX = container.width - button_left_right_margin - button_width - margin*0.5f - button_width;
            CGFloat btnX = container.width - button_left_right_margin - button_width;
            CGFloat btnY = (container.height-button_height)/2.0f;
            UILabel *label = [[UILabel alloc]  initWithFrame:CGRectMake(btnX, btnY, button_width, button_height)];
            [container addSubview:label];
            [label setText:@"立即下注"];
            [label setFont:button_title_font];
            [label setTextColor:button_title_color];
            [label addCornerRadius:margin*0.5f];
            [label setUserInteractionEnabled:YES];
            [label setTextAlignment:NSTextAlignmentCenter];
            [label setBackgroundColor:COLOR_SYSTEM_MAIN_BUTTON_BACKGROUND_SELECT_DEFAULT];
            
            UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doBettingButtonSubmitAction:)];
            [label addGestureRecognizer:tapGesture];
            
            label;
        });
        self.buttonSubmitLabel = buttonSubmitLabel;
        self.buttonSubmitLabel.mas_key = @"buttonSubmitLabel";
        
        // 投注信息
        UILabel *bettingInfomationLabel = ({
            UILabel *label = [UILabel new];
            [container addSubview:label];
            [label setFont:content_font];
            [label setTextAlignment:NSTextAlignmentLeft];
            
            [label mas_makeConstraints:^(MASConstraintMaker *make) {
                make.centerY.equalTo(container.mas_centerY);
                make.left.equalTo(buttonClearLabel.mas_right).offset(margin*0.50f);
                make.right.equalTo(buttonSubmitLabel.mas_left).offset(-margin*0.25f);
            }];

            label;
        });
        self.bettingInfomationLabel = bettingInfomationLabel;
        self.bettingInfomationLabel.mas_key = @"bettingInfomationLabel";
        
        container;
    });
    bottomAreaButtonView.mas_key = @"bottomAreaButtonView";
    
    // 分割线
    if (IS_IPHONE_X_OR_GREATER) {
        UIView *bootomLineView = ({
            UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0,
                                                                    CFC_GAME_PLAY_SCROLL_BOTTOM_SETTING_HEIGHT + CFC_GAME_PLAY_SCROLL_BOTTOM_BUTTON_HEIGHT,
                                                                    bottomAreaContainerView.width,
                                                                    1.0f)];
            [bottomAreaContainerView addSubview:view];
            [view setBackgroundColor:container_line_color];

            view;
        });
        bootomLineView.mas_key = @"bootomLineView";
    }

    // 设置默认值
    {
        // 投注单位
        [self setBettingUnitValue:STR_BETTING_DATA_YUAN];
        
        // 投注倍数
        [self setBettingMultipleMinValue:STR_BETTING_MULTIPLE_MIN];
        [self setBettingMultipleMaxValue:STR_BETTING_MULTIPLE_MAX];
        [self setBettingMultipleValue:STR_BETTING_MULTIPLE_DEFAULT];
        
        // 投注信息
        [self setBettingInfomationLabelValue:@"0"];
    }
}


#pragma mark -
#pragma mark CFCGameBetPlayScrollViewControllerProtocol
#pragma mark 界面元素 - 滑动菜单栏控件高度
- (CGFloat)heightOfScrollSegmentView
{
    return CFC_GAME_PLAY_OFFICIAL_SCROLL_SEGMENT_HEIGHT;
}

#pragma mark 界面元素 - 底部区域的视图高度
- (CGFloat)heightOfBottomAreaMainView
{
    return CFC_GAME_PLAY_OFFICIAL_SCROLL_BOTTOM_AREA_HEIGHT;
}

#pragma mark 界面元素 - 表格头部的视图高度
- (CGFloat)heightOfTableHeaderView
{
    return CFC_GAME_PLAY_OFFICIAL_SCROLL_TABLEVIEW_HEADER_HEIGHT;
}

#pragma mark 界面元素 - 表格头部信息的视图
- (UIView *)viewOfTableHeaderView
{
    CGFloat heightOfTableHeaderView = [self heightOfTableHeaderView];
    CFCGameBetDrawResultItemType drawResultItemType = [self getDrawResultItemType];
    CFCGameBetPlayScrollViewOfficialHeader *tableHeaderView = [[CFCGameBetPlayScrollViewOfficialHeader alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, heightOfTableHeaderView)
                                                                                                                     gameId:self.gameId
                                                                                                                   gameName:self.gameName
                                                                                                             gameIdentifier:self.gameIdentifier
                                                                                                                   playMode:self.playModeClass
                                                                                                         drawResultItemType:drawResultItemType
                                                                                                       parentViewController:self];
    tableHeaderView.backgroundColor = COLOR_SYSTEM_MAIN_UI_BACKGROUND_WHITE;
    tableHeaderView.heightOfBottomAreaMainView = [self heightOfBottomAreaMainView];
    self.delegate_betting_header = tableHeaderView;
    return tableHeaderView;
}


#pragma mark -
#pragma mark 主页数据 - 加载完数据前操作，每次刷新加载数据前都会执行
- (void)viewDidLoadBeforeLoadPlayClassViewControllerNetworkDataOrCacheData
{
    [super viewDidLoadBeforeLoadPlayClassViewControllerNetworkDataOrCacheData];
    
}

#pragma mark 主页数据 - 加载完数据后操作，每次刷新加载数据后都会执行
- (void)viewDidLoadAfterLoadPlayClassViewControllerNetworkDataOrCacheData
{
    [super viewDidLoadAfterLoadPlayClassViewControllerNetworkDataOrCacheData];
    
    // 请求成功，解析数据
    NSDictionary *data = [self.allResponseDataOrCacheData objectForKey:CFC_REQUEST_KEY_DATA];
    NSInteger status = [[self.allResponseDataOrCacheData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
    if (![CFCSysUtil validateResultCodeIsSuccess:status] || [CFCSysUtil validateObjectIsNull:data]) {
        return;
    }
    
    // 底部滑条赋值
    NSArray<NSDictionary *> *allSliderData = [data objectForKey:@"optionalPrizes"];
    [self.bottomAreaSliderView setAllSliderData:allSliderData];
}

    
#pragma mark -
#pragma mark CFCGameBetPlayClassViewControllerDelegate
#pragma mark 投注总数 - 在主页面更新用户的投注总数
- (BOOL)changeSumNumberOfBettingForMainGameBetViewController:(NSInteger)number
{
    // 更新投注信息
    NSString *bettingNumber = [NSString stringWithFormat:@"%ld", number];
    [self setBettingInfomationLabelValue:bettingNumber];
    
    // 更新投注按钮
    if (bettingNumber.integerValue > 0) {
        [self setButtonSubmitLabelEnable:YES];
    } else {
        [self setButtonSubmitLabelEnable:NO];
    }
    
    // 保存投注注数
    return [super changeSumNumberOfBettingForMainGameBetViewController:number];
}

#pragma mark 倒计时间 - 在倒计时间结束后是否可以弹提示信息框
- (BOOL)canAlertTipInfoDialogAfterCounting
{
    [self.popNoticeSuccessView dismiss];
    [self.popNoticeFailureView dismiss];
    
    return [super canAlertTipInfoDialogAfterCounting];
}


#pragma mark -
#pragma mark CWPopMenuDelegate
#pragma mark 单位模式 - 投注单位模式选择代理
- (void)popMenu:(CWPopMenu *)tableView content:(NSString *)content selectIndex:(NSInteger *)index
{
    // 更新投注单位控件
    [self.buttonUnitModelLabel setText:content];
    
    // 更新投注单位价格（元1.0, 角0.5）
    if ([STR_BETTING_UNIT_YUAN isEqualToString:content]) {
        [self setBettingUnitValue:STR_BETTING_DATA_YUAN];
    } else if ([STR_BETTING_UNIT_JIAO isEqualToString:content]) {
        [self setBettingUnitValue:STR_BETTING_DATA_JIAO];
    }

    // 更新投注信息
    if (self.delegate_betting_playclass && [self.delegate_betting_playclass respondsToSelector:@selector(doBettingButtonActionForPlayClassViewController)]) {
        [self.delegate_betting_playclass doBettingButtonActionForPlayClassViewController];
    } else {
        NSAssert(NO, @"[CFCGameBetPlayClassViewController]类必须实现代理方法[doBettingButtonActionForPlayClassViewController]");
    }
}


#pragma mark -
#pragma mark CFCGameBetSliderViewDelegate
#pragma mark 奖金返点 - 奖金返点滑动代理
- (void)sliderView:(CFCGameBetSliderView *)slider sliderPrizeValue:(NSString *)sliderPrizeValue sliderRateValue:(NSString *)sliderRateValue
{
    // 保存返点赔率、奖金分组
    [self setBettingSliderRateValue:sliderRateValue];
    [self setBettingSliderPrizeValue:sliderPrizeValue];
    
    // 更新提示信息
    [self setBettingInfomationLabelValue:self.bettingNumberValue];
}


#pragma mark - UITextFieldDelegate
#pragma mark  文本输入框 - 文本将要改变
- (BOOL)textField:(UITextField*)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    // 限定内容为数字
    NSCharacterSet *characterSet = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789\n"] invertedSet];
    NSString *filtered = [[string componentsSeparatedByCharactersInSet:characterSet] componentsJoinedByString:@""];
    BOOL basicTest = [string isEqualToString:filtered];
    if (!basicTest) {
        [TSMessage showNotificationInViewController:self.parentViewController.parentViewController.parentViewController
                                              title:NSLocalizedString(STR_ALERT_MESSAGE_TITLE_INFO, nil)
                                           subtitle:NSLocalizedString(@"提示：只能输入数字！", nil)
                                               type:TSMessageNotificationTypeMessage
                                           duration:ALERT_MESSAGE_DURATION];
        return NO;
    }
    
    // 倍数必须大于零
    NSString * textNumValue = [textField.text stringByReplacingCharactersInRange:range withString:string];
    if ((textNumValue.floatValue < self.bettingMultipleMinValue.floatValue || textNumValue.floatValue > self.bettingMultipleMaxValue.floatValue) && ![CFCSysUtil validateStringEmpty:textNumValue]) {
        NSString *message = [NSString stringWithFormat:@"提示：请输入%@~%@之间的数字！", self.bettingMultipleMinValue, self.bettingMultipleMaxValue];
        [TSMessage showNotificationInViewController:self.parentViewController.parentViewController.parentViewController
                                              title:NSLocalizedString(STR_ALERT_MESSAGE_TITLE_INFO, nil)
                                           subtitle:NSLocalizedString(message, nil)
                                               type:TSMessageNotificationTypeMessage
                                           duration:ALERT_MESSAGE_DURATION];
        return NO;
    }
    
    // 保存投注倍数
    if (![CFCSysUtil validateStringEmpty:textNumValue]) {
        [self setBettingMultipleValue:textNumValue];
    } else {
        [self setBettingMultipleValue:STR_BETTING_MULTIPLE_DEFAULT];
    }
    
    // 更新投注信息
    if (self.delegate_betting_playclass && [self.delegate_betting_playclass respondsToSelector:@selector(doBettingButtonActionForPlayClassViewController)]) {
        [self.delegate_betting_playclass doBettingButtonActionForPlayClassViewController];
    } else {
        NSAssert(NO, @"[CFCGameBetPlayClassViewController]类必须实现代理方法[doBettingButtonActionForPlayClassViewController]");
    }
    
    return YES;
}

#pragma mark  文本输入框 - 文本结束编辑
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    // 倍数默认值
    if ([CFCSysUtil validateStringEmpty:textField.text]) {
        
        // 设置控件值
        [textField setText:STR_BETTING_MULTIPLE_DEFAULT];
        
        // 默认投注倍数
        [self setBettingMultipleValue:STR_BETTING_MULTIPLE_DEFAULT];
        
        // 更新投注信息
        if (self.delegate_betting_playclass && [self.delegate_betting_playclass respondsToSelector:@selector(doBettingButtonActionForPlayClassViewController)]) {
            [self.delegate_betting_playclass doBettingButtonActionForPlayClassViewController];
        } else {
            NSAssert(NO, @"[CFCGameBetPlayClassViewController]类必须实现代理方法[doBettingButtonActionForPlayClassViewController]");
        }
    }
}

#pragma mark  文本输入框 - 将要开始编辑
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    _keyboardNotificationEnable = YES; // 键盘通知是否可用
    
    return YES;
}


#pragma mark - Private

#pragma mark 页面点击事件
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self resignFirstResponderOfTextField];
}

#pragma mark 注销页面焦点
- (void)resignFirstResponderOfTextField
{
    [self.view endEditing:YES];
    [self.multipleTextField resignFirstResponder];
}

#pragma mark 键盘事件 - 键盘将要弹出
- (void)keyboardWillShow:(NSNotification *)notification
{
    // 键盘通知是否可用
    if (!_keyboardNotificationEnable) {
        return;
    }
    // 已显示则直接返回
    if (_currentKeyboardHeight > 0) {
        return;
    }
    // 键盘最后的尺寸
    CGRect keyBoardFrame = [[[notification userInfo]objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGFloat keyBoardFrameHeight = keyBoardFrame.size.height;
    // 需要移动的距离
    if (keyBoardFrameHeight > 0) {
        // 偏移计算
        _transformY = keyBoardFrameHeight -_currentKeyboardHeight;
        _currentKeyboardHeight = keyBoardFrameHeight;
        // 移动处理
        WEAKSELF(weakSelf);
        CGFloat duration = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] floatValue];
        [UIView animateWithDuration:duration animations:^{
            CGRect frame = weakSelf.bottomAreaContainerView.frame;
            frame.origin.y -= (IS_IPHONE_X_OR_GREATER ? _transformY - TAB_BAR_DANGER_HEIGHT : _transformY);
            weakSelf.bottomAreaContainerView.frame = frame;
        }];
    }
}

#pragma mark 键盘事件 - 键盘将要隐藏
- (void)keyboardWillHide:(NSNotification *)notification
{
    // 键盘通知是否可用
    if (!_keyboardNotificationEnable) {
        return;
    }
    // 隐藏时只执行1次
    if (_currentKeyboardHeight <= 0) {
        return;
    }
    // 需要移动的距离
    WEAKSELF(weakSelf);
    CGFloat duration = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] floatValue];
    [UIView animateWithDuration:duration animations:^{
        CGRect frame = weakSelf.bottomAreaContainerView.frame;
        frame.origin.y += (IS_IPHONE_X_OR_GREATER ? _currentKeyboardHeight - TAB_BAR_DANGER_HEIGHT : _currentKeyboardHeight);
        weakSelf.bottomAreaContainerView.frame = frame;
        _currentKeyboardHeight = 0;
        _keyboardNotificationEnable = NO; // 键盘通知是否可用
    }];
}


#pragma mark -
#pragma mark 投注成功提示框
- (CFCBettingSuccessPopNoticeView *)popNoticeSuccessView
{
    if (!_popNoticeSuccessView) {
        WEAKSELF(weakSelf);
        _popNoticeSuccessView = [CFCBettingSuccessPopNoticeView sharePopNoticeView];
        [_popNoticeSuccessView setCount:3L];
        [_popNoticeSuccessView setContent:@"投注成功"];
        [_popNoticeSuccessView setAfterDismissBlock:^{
            [weakSelf doBettingButtonClearAction:nil];
        }];
    }
    return _popNoticeSuccessView;
}

#pragma mark 投注失败提示框
- (CFCBettingFailurePopNoticeView *)popNoticeFailureView
{
    if (!_popNoticeFailureView) {
        _popNoticeFailureView = [CFCBettingFailurePopNoticeView sharePopNoticeView];
        [_popNoticeFailureView setCount:3L];
        [_popNoticeFailureView setContent:@"数据异常"];
        [_popNoticeFailureView setAfterDismissBlock:^{
            
        }];
    }
    return _popNoticeFailureView;
}

#pragma mark 模式单位弹出菜单
- (CWPopMenu *)menuOfUnitPopView
{
    if (!_menuOfUnitPopView) {
        CGFloat width = CGRectGetWidth(self.buttonUnitModelLabel.frame);
        CGFloat height = width * 1.20f;
        CGFloat y = SCREEN_HEIGHT + (CFC_GAME_PLAY_SCROLL_BOTTOM_SETTING_HEIGHT-self.buttonUnitModelLabel.height)/3.0f - [self heightOfBottomAreaMainView];
        _menuOfUnitPopView = [[CWPopMenu alloc]initWithArrow:CGPointMake(self.buttonUnitModelLabel.centerX, y)
                                                    menuSize:CGSizeMake(width, height*self.arryOfUnitModes.count)
                                                  arrowStyle:CWPopMenuArrowBottomCenter];
        _menuOfUnitPopView.delegate = self;
        _menuOfUnitPopView.menuModes = self.arryOfUnitModes;
        _menuOfUnitPopView.menuViewBgColor = [UIColor whiteColor];
        _menuOfUnitPopView.arrowHeight = 0.0f;
        _menuOfUnitPopView.bgAlpha = 0.1;
    }
    return _menuOfUnitPopView;
}

#pragma mark 模式单位数据列表
- (NSMutableArray<CWPopMenuModel *> *)arryOfUnitModes
{
    if (!_arryOfUnitModes) {
        _arryOfUnitModes = [NSMutableArray<CWPopMenuModel *> array];
        {
            CWPopMenuModel *model = [[CWPopMenuModel alloc] init];
            [model setContent:STR_BETTING_UNIT_YUAN];
            [model setIsSelected:YES];
            [model setContentNormalColor:COLOR_HEXSTRING(@"#565656")];
            [model setContentSelectColor:COLOR_HEXSTRING(@"#FFFFFF")];
            [model setNormalBackgroundColor:COLOR_HEXSTRING(@"#EEEEEE")];
            [model setSelectBackgroundColor:COLOR_HEXSTRING(@"#C43641")];
            [_arryOfUnitModes addObject:model];
        }
        {
            CWPopMenuModel *model = [[CWPopMenuModel alloc] init];
            [model setContent:STR_BETTING_UNIT_JIAO];
            [model setIsSelected:NO];
            [model setContentNormalColor:COLOR_HEXSTRING(@"#565656")];
            [model setContentSelectColor:COLOR_HEXSTRING(@"#FFFFFF")];
            [model setNormalBackgroundColor:COLOR_HEXSTRING(@"#EEEEEE")];
            [model setSelectBackgroundColor:COLOR_HEXSTRING(@"#C43641")];
            [_arryOfUnitModes addObject:model];
        }
    }
    return _arryOfUnitModes;
}

#pragma mark 设置投注按钮是否可用
- (void)setButtonSubmitLabelEnable:(BOOL)enable
{
    if (enable) {
        // 投注按钮
        [self.buttonSubmitLabel setUserInteractionEnabled:YES];
        [self.buttonSubmitLabel setTextColor:COLOR_HEXSTRING(@"#FFFFFF")];
        [self.buttonSubmitLabel setBackgroundColor:COLOR_SYSTEM_MAIN_BUTTON_BACKGROUND_SELECT_DEFAULT];
        // 确认按钮
        [self.buttonConfimLabel setUserInteractionEnabled:YES];
        [self.buttonConfimLabel setTextColor:COLOR_HEXSTRING(@"#FFFFFF")];
        [self.buttonConfimLabel setBackgroundColor:COLOR_SYSTEM_MAIN_BUTTON_BACKGROUND_SELECT_DEFAULT];
    } else {
        // 投注按钮
        [self.buttonSubmitLabel setUserInteractionEnabled:NO];
        [self.buttonSubmitLabel setTextColor:COLOR_HEXSTRING(@"#656464")];
        [self.buttonSubmitLabel setBackgroundColor:COLOR_HEXSTRING(@"#531715")];
        // 确认按钮
        [self.buttonConfimLabel setUserInteractionEnabled:NO];
        [self.buttonConfimLabel setTextColor:COLOR_HEXSTRING(@"#656464")];
        [self.buttonConfimLabel setBackgroundColor:COLOR_HEXSTRING(@"#531715")];
    }
}

#pragma mark 设置投注提示信息
- (void)setBettingInfomationLabelValue:(NSString *)bettingNumber
{
    // 投注注数
    if ([CFCSysUtil validateStringEmpty:bettingNumber]) {
        bettingNumber = @"0";
    }
    
    // 单注金额
    NSString *bettingPrice = STR_BETTING_PRICE_DEF;
    if ([STR_BETTING_DATA_YUAN isEqualToString:self.bettingUnitValue]) {
        bettingPrice = [CFCStringMathsUtil divNumber1:bettingPrice number2:@"1.0"];
    } else if ([STR_BETTING_DATA_JIAO isEqualToString:self.bettingUnitValue]) {
        bettingPrice = [CFCStringMathsUtil divNumber1:bettingPrice number2:@"10.0"];
    }

    // 下注倍数
    NSString *bettingMultiple = self.bettingMultipleValue;
    if ([CFCSysUtil validateStringEmpty:self.bettingMultipleValue]) {
        bettingMultiple = STR_BETTING_MULTIPLE_DEFAULT;
    }
    
    // 投注总额 = 单注金额 * 下注倍数 * 下注注数
    NSString *amountPriceMultiple = [CFCStringMathsUtil mulNumber1:bettingPrice number2:bettingMultiple];
    NSString *amountMoney = [CFCStringMathsUtil mulNumber1:bettingNumber number2:amountPriceMultiple];
    NSString *amountRound = [NSString stringWithFormat:@"%0.2f", amountMoney.floatValue];

#if 1
    // 投注信息
    NSDictionary *attributesString = @{ NSFontAttributeName:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(14.0f)],
                                        NSForegroundColorAttributeName:COLOR_SYSTEM_MAIN_FONT_DEFAULT };
    NSDictionary *attributesNumber = @{ NSFontAttributeName:[UIFont fontWithName:@"NotoMono" size:CFC_AUTOSIZING_FONT(15)],
                                        NSForegroundColorAttributeName:COLOR_SYSTEM_MAIN_FONT_ASSIST_RED_DEFAULT };
    NSAttributedString *attributedString = [CFCSysUtil attributedString:@[ @"投", bettingNumber, @"注,",
                                                                           bettingMultiple, @"倍,",
                                                                           @"共", amountRound, @"元" ]
                                                         attributeArray:@[ attributesString, attributesNumber, attributesString,
                                                                           attributesNumber, attributesString,
                                                                           attributesString, attributesNumber, attributesString ]];
    [self.bettingInfomationLabel setAttributedText:attributedString];
#elif 1
    // 返点总额
    NSString *amountRateValue = [CFCStringMathsUtil mulNumber1:amountRound number2:self.bettingSliderRateValue];
    NSString *amountRate = [NSString stringWithFormat:@"%0.2f", amountRateValue.floatValue];
    
    // 投注信息
    NSDictionary *attributesString = @{ NSFontAttributeName:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(14.0f)],
                                        NSForegroundColorAttributeName:COLOR_SYSTEM_MAIN_FONT_DEFAULT };
    NSDictionary *attributesNumber = @{ NSFontAttributeName:[UIFont fontWithName:@"NotoMono" size:CFC_AUTOSIZING_FONT(15)],
                                        NSForegroundColorAttributeName:COLOR_SYSTEM_MAIN_FONT_ASSIST_RED_DEFAULT };
    NSAttributedString *attributedString = [CFCSysUtil attributedString:@[ @"投", bettingNumber, @"注,",
                                                                           bettingMultiple, @"倍,返",
                                                                           amountRate,
                                                                           @"元,共", amountRound, @"元" ]
                                                         attributeArray:@[ attributesString, attributesNumber, attributesString,
                                                                           attributesNumber, attributesString,
                                                                           attributesNumber,
                                                                           attributesString, attributesNumber, attributesString ]];
    [self.bettingInfomationLabel setAttributedText:attributedString];
#endif
    
}



@end


