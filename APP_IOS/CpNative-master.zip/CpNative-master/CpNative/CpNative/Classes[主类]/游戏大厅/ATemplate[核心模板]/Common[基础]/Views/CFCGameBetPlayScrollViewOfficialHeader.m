//
//  游戏 - 官方玩法 - 投注页面头部区域
//

#import "CFCGameBetPlayScrollViewOfficialHeader.h"
#import "CFCGameBetPlayTypeButton.h"
#import "YHSDropDownMenuView.h"

@interface CFCGameBetPlayScrollViewOfficialHeader () <CFCGameBetPlayTypePopViewDelegate>
/**
 * 头部区域 - 开奖结果容器 - 玩法按钮 - 弹出选择
 */
@property (nonatomic, strong) CFCGameBetPlayTypeButton *gamePlayTypeButton;
/**
 * 头部区域 - 开奖结果容器 - 开奖结果 - 下拉弹出
 */
@property (nonatomic, strong) YHSDropDownMenuView *dropDownMenuOfDrawResult;
/**
 * 头部区域 - 倒计时区容器 - 盈亏按钮
 */
@property (nonatomic, strong) UILabel *buttonBreakevenLabel;


@end


@implementation CFCGameBetPlayScrollViewOfficialHeader


#pragma mark -
#pragma mark 事件处理 - 盈亏按钮事件
- (void)doBettingButtonEverydayBreakevenAction:(UITapGestureRecognizer *)gesture
{
    // 注销页面焦点
    [self resignFirstResponderOfTextField];
    
    // 跳转至个人报表页面
    PersonalChartViewController *viewController = [[PersonalChartViewController alloc] init];
    [self.parentViewController.navigationController pushViewController:viewController animated:YES];
}

#pragma mark 事件处理 - 开奖按钮事件
- (void)doBettingButtonDrawResultsAction:(UITapGestureRecognizer *)gesture
{
    // 注销页面焦点
    [self resignFirstResponderOfTextField];
    
    // 显示开奖列表
    [self.dropDownMenuOfDrawResult showMenu];
}

#pragma mark 事件处理 - 玩法按钮事件
- (void)doBettingButtonPlayTypeChangeAction
{
    // 注销页面焦点
    [self resignFirstResponderOfTextField];
    
    // 显示玩法选择
    WEAKSELF(weakSelf);
    NSArray<CFCGameBetPlayTypeModel *> *playTypeModels = [NSArray<CFCGameBetPlayTypeModel *> arrayWithArray:self.allGamePlayTypeModels];
    CFCGameBetPlayTypePopView *playTypePopView = [CFCGameBetPlayTypePopView shareGamePlayTypePopView:self.heightOfBottomAreaMainView-CFC_GAME_PLAY_SCROLL_BOTTOM_SETTING_HEIGHT];
    [playTypePopView setDelegate:self];
    [playTypePopView setPlayTypeModels:playTypeModels];
    [playTypePopView setSelectedGameIdentifier:self.selectedGameIdentifier];
    [playTypePopView setSelectedTypeIdentifier:self.selectedTypeIdentifier];
    [playTypePopView setSelectedGroupIdentifier:self.selectedGroupIdentifier];
    [playTypePopView setSelectedClassIdentifier:self.selectedClassIdentifier];
    [playTypePopView setSelectedClassTitleName:self.selectedClassTitleName];
    [playTypePopView setAfterDismissBlock:^{
        [weakSelf.gamePlayTypeButton setPlayTypeButtonIndicator];
    }];
    [playTypePopView show];
}


#pragma mark -
#pragma mark 创建子控件
- (void) createViewAtuoLayout
{
    [super createViewAtuoLayout];
    
    // 创建头玩法选择、开奖结果、倒计时区域
    [self createTopMainContainerAreaView];
    
    // 创建头玩法选择、开奖结果、倒计时区域 - 玩法选择
    [self loadNetworkDataSourceOfPlayTypeSelectThen:^(BOOL success, NSUInteger count) {
        if (success && count > 0) {
            [self createTopAreaGameBetPlayTypeButtonSelect];
        }
    }];
    
    /* 开奖结果数据，修改为从主页面数据中提取 */
    /*
    // 创建头玩法选择、开奖结果、倒计时区域 - 开奖结果
    [self loadNetworkDataSourceOfDrawResultThen:^(BOOL success, NSUInteger count) {
        if (success && count > 0) {
            [self createTopAreaDropDownMenuOfDrawResults];
        }
    }];
    */
}

#pragma mark 创建开奖结果
- (void)createViewOfDrawResultsAtuoLayout:(BOOL)isForce
{
    [super createViewOfDrawResultsAtuoLayout:isForce];
    
    // 创建开奖结果、开奖结果列表
    [self createTopAreaDropDownMenuOfDrawResults:isForce];
}


#pragma mark 创建玩法选择
- (void)createViewOfPlayTypeButtonAtuoLayout:(BOOL)isForce
{
    [super createViewOfPlayTypeButtonAtuoLayout:isForce];
    
    // 创建玩法选择数据模型
    [self createTopAreaGameBetPlayTypeButtonSelect];
}


#pragma mark 创建头玩法选择、开奖结果、倒计时区域
- (void)createTopMainContainerAreaView
{
    WEAKSELF(weakSelf);
    CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
    CGFloat drawResultAreaViewHeight = CFC_GAME_PLAY_OFFICIAL_SCROLL_TABLEVIEW_HEADER_DRAW_RESULTS_HEIGHT;
    CGFloat countDownAreaViewHeight = CFC_GAME_PLAY_OFFICIAL_SCROLL_TABLEVIEW_HEADER_COUNTDOWN_HEIGHT;
    CGFloat separatorLineHeight = CFC_GAME_PLAY_OFFICIAL_SCROLL_TABLEVIEW_HEADER_SEPARATOR_LINE_HEIGHT;
    
    // 开奖结果区域 - 必须手动计算尺寸大小，不能使用Masonry
    UIView *topDrawResultContainerView = ({
        // 容器
        UIView *container = [UIView new];
        [self addSubview:container];
        [container setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_WHITE];
        [container mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.mas_top);
            make.left.equalTo(self.mas_left).offset(0.0);
            make.right.equalTo(self.mas_right).with.offset(0.0);
            make.height.equalTo(@(drawResultAreaViewHeight));
        }];
        
        // 玩法切换
        CFCGameBetPlayTypeButton *gamePlayTypeButton = ({
            CGFloat x = margin*0.3f;
            CGFloat y = margin*0.2f;
            CGFloat width = CFC_GAME_PLAY_OFFICIAL_HEADER_PLAYTYPE_AREA_WIDTH - x;
            CGFloat height = drawResultAreaViewHeight - y - margin*0.4f;
            CGRect frame = CGRectMake(x, y, width, height);
            CFCGameBetPlayTypeButton *view = [[CFCGameBetPlayTypeButton alloc] initWithFrame:frame
                                                                                       title:STR_APP_TEXT_PLACEHOLDER
                                                                                   titleFont:GAME_PLAY_TYPE_BUTTON_TITLE_FONT
                                                                                  titleColor:GAME_PLAY_TYPE_BUTTON_TITLE_COLOR];
            [container addSubview:view];
            
            [view mas_makeConstraints:^(MASConstraintMaker *make) {
                make.width.mas_equalTo(width);
                make.top.equalTo(container.mas_top).offset(y);
                make.left.equalTo(container.mas_left).offset(x);
                make.bottom.equalTo(container.mas_bottom).offset(-margin*0.4f);
            }];
            
            [view setGamePlayTypeChangeBlock:^{
                [weakSelf doBettingButtonPlayTypeChangeAction];
            }];
            
            [view setGamePlayTypeLayoutSubviewsBlock:^{
                [weakSelf setGamePlayTypeButtonTitleValue:weakSelf.selectedClassTitleName];
            }];
            
            view;
        });
        self.gamePlayTypeButton = gamePlayTypeButton;
        self.gamePlayTypeButton.mas_key = @"gamePlayTypeButton";
        
        // 指示箭头
        /*
         UIImageView *indicatorArrowImageView = ({
         CGSize imageSize = CGSizeMake(CFC_AUTOSIZING_WIDTH(8.40f), CFC_AUTOSIZING_WIDTH(14.70f));
         UIImageView *imageView = [UIImageView new];
         [container addSubview:imageView];
         [imageView.layer setMasksToBounds:YES];
         [imageView setUserInteractionEnabled:YES];
         [imageView setContentMode:UIViewContentModeScaleAspectFit];
         [imageView setImage:[[UIImage imageNamed:ICON_GAME_ARROW_LIGHT] imageByScalingProportionallyToSize:imageSize]];
         
         [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
         make.centerY.equalTo(container.mas_centerY).offset(0.0f);
         make.right.equalTo(container.mas_right).offset(-margin*0.5f);
         make.size.mas_equalTo(imageSize);
         }];
         
         imageView;
         });
         indicatorArrowImageView.mas_key = @"indicatorArrowImageView";
         */
        
        // 分割粗线
        UIView *separatorLineView = ({
            UIView *view = [[UIView alloc] init];
            [container addSubview:view];
            [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
            
            [view mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.equalTo(container.mas_left);
                make.right.equalTo(container.mas_right);
                make.bottom.equalTo(container.mas_bottom);
                make.height.equalTo(@(separatorLineHeight));
            }];
            
            view;
        });
        separatorLineView.mas_key = @"separatorLineView";
        
        container;
    });
    self.topDrawResultContainerView = topDrawResultContainerView;
    self.topDrawResultContainerView.mas_key = @"topDrawResultContainerView";
    
    
    // 倒计时区域 - 必须手动计算尺寸大小，不能使用Masonry
    UIView *topCountDownContainerView = ({
        // 容器
        UIView *container = [UIView new];
        [self addSubview:container];
        [container setBackgroundColor:COLOR_GAME_BET_MAINAREA_BACKGROUND_DEFAULT];
        [container mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(topDrawResultContainerView.mas_bottom);
            make.left.equalTo(self.mas_left).offset(0.0);
            make.right.equalTo(self.mas_right).with.offset(0.0);
            make.height.equalTo(@(countDownAreaViewHeight));
        }];
        
        // 闹钟
        UIImageView *alarmClockImageView = ({
            CGSize imageSize = CGSizeMake(countDownAreaViewHeight*0.45f, countDownAreaViewHeight*0.45f);
            UIImage *image = [[UIImage imageNamed:ICON_GAME_STAR_MARK] imageByScalingProportionallyToSize:imageSize];
            UIImageView *imageView = [UIImageView new];
            [container addSubview:imageView];
            [imageView.layer setMasksToBounds:YES];
            [imageView setUserInteractionEnabled:YES];
            [imageView setContentMode:UIViewContentModeScaleAspectFit];
            [imageView setImage:[image imageWithTintColor:COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT]];
            
            [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.centerY.equalTo(container.mas_centerY);
                make.left.equalTo(container.mas_left).offset(margin);
                make.size.mas_equalTo(imageSize);
            }];
            
            imageView;
        });
        alarmClockImageView.mas_key = @"alarmClockImageView";
        
        // 期号
        UILabel *currentIssueNumberLabel = ({
            UILabel *label = [UILabel new];
            [container addSubview:label];
            [label setText:[NSString stringWithFormat:@"第%@期 投注时间", GAME_DRAW_RESULT_ISSUE_NUMBER(self.gameIdentifier)]];
            [label setTextAlignment:NSTextAlignmentLeft];
            
            [label mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.equalTo(alarmClockImageView.mas_right).offset(margin*0.45f);
                make.centerY.equalTo(container.mas_centerY);
            }];
            
            label;
        });
        self.currentIssueNumberLabel = currentIssueNumberLabel;
        self.currentIssueNumberLabel.mas_key = @"currentIssueNumberLabel";
        [self setCurrentIssueNumberLabelValue:GAME_DRAW_RESULT_ISSUE_NUMBER_DEFAULT];
        
        // 倒计时
        CFCCountTimerView *countDownTimeView = ({
            CFCCountTimerView *view = [CFCCountTimerView new];
            [container addSubview:view];
            [view setDelegate:self];
            [view setTextFont:[UIFont fontWithName:@"NotoMono" size:CFC_AUTOSIZING_FONT(16.0f)]];
            [view setTextColor:COLOR_SYSTEM_MAIN_FONT_ASSIST_RED_DEFAULT];
            [view setColonFont:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)]];
            [view setColonColor:COLOR_SYSTEM_MAIN_FONT_ASSIST_RED_DEFAULT];
            [view setTextBackColor:COLOR_GAME_BET_MAINAREA_BACKGROUND_DEFAULT];
            
            [view mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.equalTo(currentIssueNumberLabel.mas_right).offset(margin*0.5f);
                make.centerY.equalTo(container.mas_centerY);
            }];
            
            view;
        });
        self.countDownTimeView = countDownTimeView;
        self.countDownTimeView.mas_key = @"countDownTimeView";
        
        // 盈亏按钮
        UILabel *buttonBreakevenLabel = ({
            CGFloat button_width = CFC_AUTOSIZING_WIDTH(65.0f);
            CGFloat button_height = countDownAreaViewHeight * 0.75f;
            //
            UILabel *label = [[UILabel alloc]  init];
            [container addSubview:label];
            [label setText:@"每日盈亏"];
            [label setFont:[UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(13.0f)]];
            [label setTextColor:COLOR_HEXSTRING(@"#FFFFFF")];
            [label addCornerRadius:margin*0.5f];
            [label setUserInteractionEnabled:YES];
            [label setTextAlignment:NSTextAlignmentCenter];
            [label setBackgroundColor:COLOR_SYSTEM_MAIN_BUTTON_BACKGROUND_SELECT_DEFAULT];
            
            [label mas_makeConstraints:^(MASConstraintMaker *make) {
                make.centerY.equalTo(container.mas_centerY);
                make.right.equalTo(container.mas_right).offset(-margin*0.5f);
                make.size.mas_equalTo(CGSizeMake(button_width, button_height));
            }];
            
            UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doBettingButtonEverydayBreakevenAction:)];
            [label addGestureRecognizer:tapGesture];
            
            label;
        });
        self.buttonBreakevenLabel = buttonBreakevenLabel;
        self.buttonBreakevenLabel.mas_key = @"buttonBreakevenLabel";
        
        // 分割粗线
        UIView *separatorLineView = ({
            UIView *view = [[UIView alloc] init];
            [container addSubview:view];
            [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
            
            [view mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.equalTo(container.mas_left);
                make.right.equalTo(container.mas_right);
                make.bottom.equalTo(container.mas_bottom).offset(separatorLineHeight);
                make.height.equalTo(@(separatorLineHeight));
            }];
            
            view;
        });
        separatorLineView.mas_key = @"separatorLineView";
        
        container;
    });
    self.topCountDownContainerView = topCountDownContainerView;
    self.topCountDownContainerView.mas_key = @"topCountDownContainerView";
}

#pragma mark 创建头玩法选择、开奖结果、倒计时区域 - 玩法选择
- (void)createTopAreaGameBetPlayTypeButtonSelect
{
    WEAKSELF(weakSelf);
    
    // 复原玩法标识的操作选中项
    {
        // 获取保存的所有玩法组选中标识
        NSMutableDictionary<NSString *, NSString *> *selectedPlayTypeDictionary = nil;
        if (self.delegate && [self.delegate respondsToSelector:@selector(selectedPlayTypeDictionaryFromMainGameCoreViewController)]) {
            selectedPlayTypeDictionary = [self.delegate selectedPlayTypeDictionaryFromMainGameCoreViewController];
        } else {
            NSAssert(NO, @"[CFCGameBetPlayScrollViewController]类必须实现代理方法[selectedPlayTypeDictionaryFromMainGameCoreViewController]");
        }
        
        if (selectedPlayTypeDictionary && selectedPlayTypeDictionary.count > 0) {
            // 一级分类（五星、四星）
            [self.allGamePlayTypeModels enumerateObjectsUsingBlock:^(CFCGameBetPlayTypeModel * _Nonnull playTypeModel, NSUInteger playTypeIdx, BOOL * _Nonnull playTypeStop) {
                NSString *playTypeKey = STR_PLAY_TYPE_KEY(self.gameIdentifier,playTypeModel.code);
                NSString *select_group_type = [selectedPlayTypeDictionary stringForKey:playTypeKey];
                if (![CFCSysUtil validateStringEmpty:select_group_type]) {
                    playTypeModel.isSelected = YES;
                    // 二级分类（直选、组选）
                    NSArray<NSString *> *split = [select_group_type split:STR_SPLIT];
                    NSString *selectedGroupIdentifier = (split.count > 0 ? split[0] : @"");
                    NSString *selectedClassIdentifier = (split.count > 1 ? split[1] : @"");
                    [playTypeModel.childrenGroup enumerateObjectsUsingBlock:^(CFCGameBetPlayTypeGroupModel * _Nonnull playTypeGroupModel, NSUInteger playTypeGroupIdx, BOOL * _Nonnull playTypeGroupStop) {
                        if ([selectedGroupIdentifier isEqualToString:playTypeGroupModel.code.uppercaseString]) {
                            playTypeGroupModel.isSelected = YES;
                            // 三级分类（直选复式、组选120）
                            [playTypeGroupModel.childrenClass enumerateObjectsUsingBlock:^(CFCGameBetPlayTypeClassModel * _Nonnull playTypeClassModel, NSUInteger playTypeClassIdx, BOOL * _Nonnull playTypeClassStop) {
                                if ([selectedClassIdentifier isEqualToString:playTypeClassModel.code.uppercaseString]) {
                                    playTypeClassModel.isSelected = YES;
                                } else {
                                    playTypeClassModel.isSelected = NO;
                                }
                            }];
                        } else {
                            playTypeGroupModel.isSelected = NO;
                            // 三级分类（直选复式、组选120）
                            [playTypeGroupModel.childrenClass enumerateObjectsUsingBlock:^(CFCGameBetPlayTypeClassModel * _Nonnull playTypeClassModel, NSUInteger playTypeClassIdx, BOOL * _Nonnull playTypeClassStop) {
                                playTypeClassModel.isSelected = NO;
                            }];
                        }
                    }];
                } else {
                    playTypeModel.isSelected = NO;
                }
            }];
        }
    }
    
    // 复原最后一次选中玩法页面
    {
        // 当前选中的页面标识
        NSString *currentSelectedPlayCodeOfPlayClass = @"";
        if (self.delegate && [self.delegate respondsToSelector:@selector(selectedPlayCodeOfPlayClassFromMainGameCoreViewController:)]) {
            NSString *tabMarkCode = STR_SELECT_PLAY_CLASS_MARK_CODE(self.gameId, self.gameName, self.gameIdentifier);
            currentSelectedPlayCodeOfPlayClass = [self.delegate selectedPlayCodeOfPlayClassFromMainGameCoreViewController:tabMarkCode];
        } else {
            NSAssert(NO, @"[CFCGameBetPlayScrollViewController]类必须实现代理方法[selectedPlayCodeOfPlayClassFromMainGameCoreViewController]");
        }
        
        // 设置初始化默认选项
        if (![CFCSysUtil validateStringEmpty:currentSelectedPlayCodeOfPlayClass]) {
            // 分割当前选中的页面标识
            NSArray<NSString *> *split = [currentSelectedPlayCodeOfPlayClass split:STR_SPLIT];
            NSString *selectedGameIdentifier = ([CFCSysUtil validateStringEmpty:self.gameIdentifier] ? @"" : self.gameIdentifier.uppercaseString);
            NSString *selectedTypeIdentifier = (split.count > 0 ? split[0] : @"");
            NSString *selectedGroupIdentifier = (split.count > 1 ? split[1] : @"");
            NSString *selectedClassIdentifier = (split.count > 2 ? split[2] : @"");
            // 当前游戏的标识
            self.selectedGameIdentifier = selectedGameIdentifier;
            // 一级分类（五星、四星）
            [self.allGamePlayTypeModels enumerateObjectsUsingBlock:^(CFCGameBetPlayTypeModel * _Nonnull playTypeModel, NSUInteger playTypeIdx, BOOL * _Nonnull playTypeStop) {
                if ([selectedTypeIdentifier.uppercaseString isEqualToString:playTypeModel.code.uppercaseString]) {
                    playTypeModel.isSelected = YES;
                    weakSelf.selectedTypeIdentifier = playTypeModel.code;
                    // 二级分类（直选、组选）
                    [playTypeModel.childrenGroup enumerateObjectsUsingBlock:^(CFCGameBetPlayTypeGroupModel * _Nonnull playTypeGroupModel, NSUInteger playTypeGroupIdx, BOOL * _Nonnull playTypeGroupStop) {
                        if ([selectedGroupIdentifier.uppercaseString isEqualToString:playTypeGroupModel.code.uppercaseString]) {
                            playTypeGroupModel.isSelected = YES;
                            weakSelf.selectedGroupIdentifier = playTypeGroupModel.code;
                            // 三级分类（直选复式、组选120）
                            [playTypeGroupModel.childrenClass enumerateObjectsUsingBlock:^(CFCGameBetPlayTypeClassModel * _Nonnull playTypeClassModel, NSUInteger playTypeClassIdx, BOOL * _Nonnull playTypeClassStop) {
                                if ([selectedClassIdentifier.uppercaseString isEqualToString:playTypeClassModel.code.uppercaseString]) {
                                    playTypeClassModel.isSelected = YES;
                                    weakSelf.selectedClassTitleName = playTypeClassModel.name;
                                    weakSelf.selectedClassIdentifier = playTypeClassModel.code;
                                    weakSelf.gamePlayTypeButton.titleString = playTypeClassModel.name;
                                    // 设置默认玩法
                                    NSString *tabClassCode = STR_PLAY_CLASS_CODE(weakSelf.selectedGameIdentifier,
                                                                                 weakSelf.selectedTypeIdentifier,
                                                                                 weakSelf.selectedGroupIdentifier,
                                                                                 weakSelf.selectedClassIdentifier);
                                    CFCLog(@"设置默认玩法[静态]=>[%@-%@][%@]", weakSelf.selectedClassTitleName, weakSelf.selectedGameIdentifier, tabClassCode);
                                    if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(didSelectedPlayClassViewController:
                                                                                                             selectedGameIdentifier:
                                                                                                             selectedTypeIdentifier:
                                                                                                             selectedGroupIdentifier:
                                                                                                             selectedClassIdentifier:
                                                                                                             selectedClassTitleName:
                                                                                                             selectedPlayTypeModel:
                                                                                                             selectedPlayTypeGroupModel:
                                                                                                             selectedPlayTypeClassModel:)]) {
                                        [weakSelf.delegate didSelectedPlayClassViewController:tabClassCode
                                                                       selectedGameIdentifier:weakSelf.selectedGameIdentifier
                                                                       selectedTypeIdentifier:weakSelf.selectedTypeIdentifier
                                                                      selectedGroupIdentifier:weakSelf.selectedGroupIdentifier
                                                                      selectedClassIdentifier:weakSelf.selectedClassIdentifier
                                                                       selectedClassTitleName:weakSelf.selectedClassTitleName
                                                                        selectedPlayTypeModel:playTypeModel
                                                                   selectedPlayTypeGroupModel:playTypeGroupModel
                                                                   selectedPlayTypeClassModel:playTypeClassModel];
                                    }
                                } else {
                                    playTypeClassModel.isSelected = NO;
                                }
                            }];
                        } else {
                            playTypeGroupModel.isSelected = NO;
                        }
                    }];
                } else {
                    playTypeModel.isSelected = NO;
                }
            }];
        } else {
            // 如果没有设置默认选中玩法，则设置网络数据的第一个玩法为选中
            self.selectedGameIdentifier = self.gameIdentifier;
            if (self.allGamePlayTypeModels.count > 0) {
                CFCGameBetPlayTypeModel *firstPlayTypeModel = [self.allGamePlayTypeModels objectAtIndex:0];
                firstPlayTypeModel.isSelected = YES;
                self.selectedTypeIdentifier = firstPlayTypeModel.code;
                if (firstPlayTypeModel.childrenGroup.count > 0) {
                    CFCGameBetPlayTypeGroupModel *firstPlayTypeGroup = [firstPlayTypeModel.childrenGroup objectAtIndex:0];
                    firstPlayTypeGroup.isSelected = YES;
                    self.selectedGroupIdentifier = firstPlayTypeGroup.code;
                    if (firstPlayTypeGroup.childrenClass.count > 0) {
                        CFCGameBetPlayTypeClassModel *firstPlayTypeClass = [firstPlayTypeGroup.childrenClass objectAtIndex:0];
                        firstPlayTypeClass.isSelected = YES;
                        self.selectedClassTitleName = firstPlayTypeClass.name;
                        self.selectedClassIdentifier = firstPlayTypeClass.code;
                        self.gamePlayTypeButton.titleString = firstPlayTypeClass.name;
                        // 设置默认玩法
                        NSString *tabClassCode = STR_PLAY_CLASS_CODE(self.selectedGameIdentifier,
                                                                     self.selectedTypeIdentifier,
                                                                     self.selectedGroupIdentifier,
                                                                     self.selectedClassIdentifier);
                        CFCLog(@"设置默认玩法[网络]=>[%@-%@][%@]", self.selectedClassTitleName, self.selectedGameIdentifier, tabClassCode);
                        if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectedPlayClassViewController:
                                                                                         selectedGameIdentifier:
                                                                                         selectedTypeIdentifier:
                                                                                         selectedGroupIdentifier:
                                                                                         selectedClassIdentifier:
                                                                                         selectedClassTitleName:
                                                                                         selectedPlayTypeModel:
                                                                                         selectedPlayTypeGroupModel:
                                                                                         selectedPlayTypeClassModel:)]) {
                            [self.delegate didSelectedPlayClassViewController:tabClassCode
                                                       selectedGameIdentifier:self.selectedGameIdentifier
                                                       selectedTypeIdentifier:self.selectedTypeIdentifier
                                                      selectedGroupIdentifier:self.selectedGroupIdentifier
                                                      selectedClassIdentifier:self.selectedClassIdentifier
                                                       selectedClassTitleName:self.selectedClassTitleName
                                                        selectedPlayTypeModel:firstPlayTypeModel
                                                   selectedPlayTypeGroupModel:firstPlayTypeGroup
                                                   selectedPlayTypeClassModel:firstPlayTypeClass];
                        }
                    }
                }
            }
        }
    }
    
}

#pragma mark 创建头玩法选择、开奖结果、倒计时区域 - 开奖结果
- (void)createTopAreaDropDownMenuOfDrawResults:(BOOL)isForce
{
    // 开奖结果 - 下拉详情
    {
        // 下拉菜单 - 数据模型
        NSString *cellHaderName = @"CFCGameBetDrawResultHeaderTableViewCell";
        NSString *cellClassName = [self buildingDrawResultTableViewCellClassNameForDropDownMenuItemType:self.drawResultItemType
                                                                                                 itemId:self.gameIdentifier];
        NSArray<NSString *> *cellClassNames = @[ cellHaderName, cellClassName ];
        NSMutableArray<CFCGameBetDrawResultModel *> *menuModelsArray = [NSMutableArray<CFCGameBetDrawResultModel *> arrayWithArray:self.drawResultDetailModels];
        // 下拉菜单 - 表格标题
        {
            CFCGameBetDrawResultModel *firstModel = menuModelsArray.firstObject;
            CFCGameBetDrawResultModel *headerModel = [CFCGameBetDrawResultModel new];
            headerModel.issueNumber = firstModel.issueNumber;
            //
            [menuModelsArray insertObject:headerModel atIndex:0];
            [menuModelsArray enumerateObjectsUsingBlock:^(CFCGameBetDrawResultModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                if (0 == idx) {
                    obj.cellClassName = cellHaderName;
                } else {
                    obj.cellClassName = cellClassName;
                }
            }];
        }
        
        // 下拉菜单 - 如果存在则先删除
        if (self.dropDownMenuOfDrawResult && isForce) {
            [self.dropDownMenuOfDrawResult.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
            [self.dropDownMenuOfDrawResult removeFromSuperview];
            [self setDropDownMenuOfDrawResult:nil];
        } else if (self.dropDownMenuOfDrawResult) {
            self.dropDownMenuOfDrawResult.menuModelsArray = [NSArray<CFCGameBetDrawResultModel *> arrayWithArray:menuModelsArray];
            [self.dropDownMenuOfDrawResult reloadMenu];
        }
        
        // 下拉菜单 - 如果不存在则创建
        if (!self.dropDownMenuOfDrawResult) {
            self.dropDownMenuOfDrawResult = [YHSDropDownMenuView new];
            // 设置动画效果,可以根据项目需求设置自己所需要的动画效果
            self.dropDownMenuOfDrawResult.menuAnimateType = YHSDropDownMenuViewAnimateType_FallFromTop;
            // 若不需要灰色透明蒙板，下面的两个透明度可以设置为0
            self.dropDownMenuOfDrawResult.bgColorbeginAlpha = 0;
            self.dropDownMenuOfDrawResult.bgColorEndAlpha = 0;
            // 设置下拉菜单的宽度为整个屏幕的宽度
            self.dropDownMenuOfDrawResult.menuWidth = [UIScreen mainScreen].bounds.size.width;
            // 设置菜单距离屏幕右边的边距为0
            self.dropDownMenuOfDrawResult.menuRightMargin = 0;
            // 取消菜单圆角效果
            self.dropDownMenuOfDrawResult.menuCornerRadius = 0;
            // 隐藏三角形
            self.dropDownMenuOfDrawResult.triangleSize = CGSizeZero;
            self.dropDownMenuOfDrawResult.eachMenuItemHeight = 80;
            self.dropDownMenuOfDrawResult.menuItemBackgroundColor = COLOR_RGBA(255, 255, 255, 0.7);
            self.dropDownMenuOfDrawResult.cellClassName = cellClassName;
            self.dropDownMenuOfDrawResult.cellClassNames = cellClassNames;
            self.dropDownMenuOfDrawResult.menuModelsArray = [NSArray<CFCGameBetDrawResultModel *> arrayWithArray:menuModelsArray];
            self.dropDownMenuOfDrawResult.triangleY = STATUS_NAVIGATION_BAR_HEIGHT + SCROLL_GAME_SUB_TAB_HEIGHT + CFC_GAME_PLAY_OFFICIAL_SCROLL_TABLEVIEW_HEADER_DRAW_RESULTS_HEIGHT;
            [self.dropDownMenuOfDrawResult addShadowWithOffset:CGSizeMake(0, 5) opacity:1.0f andRadius:5.0];
            [self.dropDownMenuOfDrawResult setup];
        }
    }
    
    // 开奖结果 - 头部显示
    {
        // 如果存在则先删除
        if (self.drawResultTopAreaView && isForce) {
            [self.drawResultTopAreaView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
            [self.drawResultTopAreaView removeFromSuperview];
            [self setDrawResultTopAreaView:nil];
        } else if (self.drawResultTopAreaView) {
            CFCGameBetDrawResultModel *drawResultsModel = [self buildingDataModleForHeaderArea:self.drawResultDetailModels.firstObject
                                                                                      itemType:self.drawResultItemType
                                                                                        itemId:self.gameIdentifier];
            [self.drawResultTopAreaView reloadDrawResult:drawResultsModel];
        }
        
        // 重新创建开奖详情
        if (!self.drawResultTopAreaView) {
            CFCGameBetDrawResultDefaultTopAreaView *drawResultTopAreaView = ({
                CGFloat width = SCREEN_WIDTH - CFC_GAME_PLAY_OFFICIAL_HEADER_PLAYTYPE_AREA_WIDTH;
                CGFloat height = CFC_GAME_PLAY_SCROLL_TABLEVIEW_HEADER_DRAW_RESULTS_HEIGHT;
                CGRect frame = CGRectMake(CFC_GAME_PLAY_OFFICIAL_HEADER_PLAYTYPE_AREA_WIDTH, 0, width, height);
                CFCGameBetDrawResultDefaultTopAreaView *view = [self viewForHeaderDrawResultsAreaFrame:frame];
                [self.topDrawResultContainerView addSubview:view];
                
                UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doBettingButtonDrawResultsAction:)];
                [view addGestureRecognizer:tapGesture];
                
                view;
            });
            self.drawResultTopAreaView = drawResultTopAreaView;
            self.drawResultTopAreaView.mas_key = @"drawResultTopAreaView";
        }
    }
    
}


#pragma mark - CFCGameBetPlayTypePopViewDelegate
#pragma mark 验证玩法的页面是否存在
- (BOOL)canSelectedGameIdentifier:(NSString *)selectedGameIdentifier
           selectedTypeIdentifier:(NSString *)selectedTypeIdentifier
          selectedGroupIdentifier:(NSString *)selectedGroupIdentifier
          selectedClassIdentifier:(NSString *)selectedClassIdentifier
           selectedClassTitleName:(NSString *)selectedClassTitleName
{
    NSString *tabClassCode = STR_PLAY_CLASS_CODE(selectedGameIdentifier,
                                                 selectedTypeIdentifier,
                                                 selectedGroupIdentifier,
                                                 selectedClassIdentifier);
    if (self.delegate && [self.delegate respondsToSelector:@selector(canSelectedPlayClassViewController:
                                                                     selectedGameIdentifier:
                                                                     selectedTypeIdentifier:
                                                                     selectedGroupIdentifier:
                                                                     selectedClassIdentifier:
                                                                     selectedClassTitleName:)]) {
        return [self.delegate canSelectedPlayClassViewController:tabClassCode
                                          selectedGameIdentifier:selectedGameIdentifier
                                          selectedTypeIdentifier:selectedTypeIdentifier
                                         selectedGroupIdentifier:selectedGroupIdentifier
                                         selectedClassIdentifier:selectedClassIdentifier
                                          selectedClassTitleName:selectedClassTitleName];
    }
    return NO;
}

#pragma mark 玩法页面存在则切换
- (void)didSelectedGameIdentifier:(NSString *)selectedGameIdentifier
           selectedTypeIdentifier:(NSString *)selectedTypeIdentifier
          selectedGroupIdentifier:(NSString *)selectedGroupIdentifier
          selectedClassIdentifier:(NSString *)selectedClassIdentifier
           selectedClassTitleName:(NSString *)selectedClassTitleName
            selectedPlayTypeModel:(CFCGameBetPlayTypeModel *)selectedGameBetPlayTypeModel
       selectedPlayTypeGroupModel:(CFCGameBetPlayTypeGroupModel *)selectedGameBetPlayTypeGroupModel
       selectedPlayTypeClassModel:(CFCGameBetPlayTypeClassModel *)selectedGameBetPlayTypeClassModel
{
    self.selectedClassTitleName = selectedClassTitleName;
    self.selectedGameIdentifier = selectedGameIdentifier;
    self.selectedTypeIdentifier = selectedTypeIdentifier;
    self.selectedGroupIdentifier = selectedGroupIdentifier;
    self.selectedClassIdentifier = selectedClassIdentifier;
    //
    [self setGamePlayTypeButtonTitleValue:selectedClassTitleName];
    //
    NSString *tabClassCode = STR_PLAY_CLASS_CODE(selectedGameIdentifier,
                                                 selectedTypeIdentifier,
                                                 selectedGroupIdentifier,
                                                 selectedClassIdentifier);
    CFCLog(@"选择玩法=>DELEGATE=>[%@-%@][%@]", selectedClassTitleName, selectedGameIdentifier, tabClassCode);
    if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectedPlayClassViewController:
                                                                     selectedGameIdentifier:
                                                                     selectedTypeIdentifier:
                                                                     selectedGroupIdentifier:
                                                                     selectedClassIdentifier:
                                                                     selectedClassTitleName:
                                                                     selectedPlayTypeModel:
                                                                     selectedPlayTypeGroupModel:
                                                                     selectedPlayTypeClassModel:)]) {
        [self.delegate didSelectedPlayClassViewController:tabClassCode
                                   selectedGameIdentifier:selectedGameIdentifier
                                   selectedTypeIdentifier:selectedTypeIdentifier
                                  selectedGroupIdentifier:selectedGroupIdentifier
                                  selectedClassIdentifier:selectedClassIdentifier
                                   selectedClassTitleName:selectedClassTitleName
                                    selectedPlayTypeModel:selectedGameBetPlayTypeModel
                               selectedPlayTypeGroupModel:selectedGameBetPlayTypeGroupModel
                               selectedPlayTypeClassModel:selectedGameBetPlayTypeClassModel];
    }
}


#pragma mark -
#pragma mark Private
#pragma mark 设置调整玩法选择按钮大小宽度
- (void)setGamePlayTypeButtonTitleValue:(NSString *)titleString
{
    // 控件宽度
    NSInteger titleMaxNum = 8;
    NSInteger titleLength = titleString.length > titleMaxNum ? titleMaxNum :titleString.length;
    NSString *titleStr = [titleString substringToIndex:titleLength];
    // 计算模式与标题按钮宽度
    CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
    CGFloat indicatorSize = CFC_AUTOSIZING_WIDTH(15.0f);
    CGFloat titleWidth = [titleString widthWithFont:self.gamePlayTypeButton.titleFont constrainedToHeight:MAXFLOAT] + margin*0.5f;
    CGFloat title_indicator_gap = margin * 0.20f;
    CGFloat button_width = indicatorSize + titleWidth + title_indicator_gap + margin*1.5f;
    // 玩法位置
    CGRect frame_button = self.gamePlayTypeButton.frame;
    CGFloat width = CFC_GAME_PLAY_OFFICIAL_HEADER_PLAYTYPE_AREA_WIDTH - frame_button.origin.x;
    if (button_width < width) {
        button_width = width;
    }
    frame_button = CGRectMake(frame_button.origin.x, frame_button.origin.y, button_width, frame_button.size.height);
    [self.gamePlayTypeButton setFrame:frame_button];
    // 玩法名称
    [self.gamePlayTypeButton setTitleString:titleStr];
    
    // 开奖结果
    CGRect frame_drawresult = self.drawResultTopAreaView.frame;
    [self.drawResultTopAreaView setFrame:CGRectMake(CGRectGetMaxX(frame_button),
                                                    frame_drawresult.origin.y,
                                                    SCREEN_WIDTH - CGRectGetMaxX(frame_button),
                                                    frame_drawresult.size.height)];
    [self.drawResultTopAreaView reloadDrawResult];
}

#pragma mark 注销页面焦点
- (void)resignFirstResponderOfTextField
{
    [self.parentViewController.view endEditing:YES];
}


@end



