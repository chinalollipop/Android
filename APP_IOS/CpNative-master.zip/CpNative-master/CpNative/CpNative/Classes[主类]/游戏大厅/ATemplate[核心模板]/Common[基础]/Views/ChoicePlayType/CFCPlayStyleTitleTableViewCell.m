//
//  游戏 - 投注页面头部区域 - 玩法选择 - 标题
//

#import "CFCPlayStyleTitleTableViewCell.h"
#import "CFCPlayTypeTitleModel.h"


// Cell Identifier
NSString * const CELL_IDENTIFIER_GAME_PLAY_TYPE_TITLE_TABLE_VIEW_CELL = @"CFCPlayStyleTitleTableViewCellIdentifier";


@interface CFCPlayStyleTitleTableViewCell ()
/**
 * 根容器组件
 */
@property (nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonatomic, strong) UIView *publicContainerView;
/**
 * 标题控件
 */
@property (nonatomic, strong) UILabel *titleLabel;

@end


@implementation CFCPlayStyleTitleTableViewCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createViewAtuoLayout];
    }
    return self;
}


#pragma mark 创建子控件
- (void) createViewAtuoLayout
{
    CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
    
    // 根容器
    UIView *rootContainerView = ({
        UIView *view = [[UIView alloc] init];
        [self.contentView insertSubview:view atIndex:0];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@0.0f);
            make.top.equalTo(@0.0f);
            make.right.equalTo(@0.0f);
            make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
        }];
        
        view;
    });
    self.rootContainerView = rootContainerView;
    self.rootContainerView.mas_key = @"rootContainerView";
    
    // 公共容器
    UIView *publicContainerView = ({
        UIView *view = [[UIView alloc] init];
        [view setBackgroundColor:COLOR_SYSTEM_MAIN_BUTTON_BACKGROUND_SELECT_DEFAULT];
        [rootContainerView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(rootContainerView.mas_left).offset(0.0f);
            make.top.equalTo(rootContainerView.mas_top).offset(0.0f);
            make.right.equalTo(rootContainerView.mas_right).offset(0.0f);
            make.bottom.equalTo(rootContainerView.mas_bottom).offset(0.0f);
        }];
        
        view;
    });
    self.publicContainerView = publicContainerView;
    self.publicContainerView.mas_key = @"publicContainerView";
    
    // 标题控件
    UILabel *titleLabel = ({
        UILabel *label = [UILabel new];
        [label setUserInteractionEnabled:YES];
        [label setText:STR_APP_TEXT_PLACEHOLDER];
        [label setTextAlignment:NSTextAlignmentCenter];
        [label setLineBreakMode:NSLineBreakByClipping];
        [publicContainerView addSubview:label];
        
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(publicContainerView.mas_centerX);
            make.centerY.equalTo(publicContainerView.mas_centerY);
        }];
        
        label;
    });
    self.titleLabel = titleLabel;
    self.titleLabel.mas_key = @"titleLabel";
    
    // 分割线
    UIView *separatorLineView = ({
        UIView *view = [[UIView alloc] init];
        [publicContainerView addSubview:view];
        [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_LIGHTGRAY];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(publicContainerView.mas_left).offset(0.0f);
            make.top.equalTo(titleLabel.mas_bottom).offset(margin*1.25);
            make.right.equalTo(publicContainerView.mas_right).offset(0.0f);
            make.height.equalTo(@(0.0f));
        }];
        
        view;
    });
    separatorLineView.mas_key = @"separatorLineView";
    
    // 约束的完整性
    [self.publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(separatorLineView.mas_bottom).offset(0.0f).priority(749);
    }];
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCPlayTypeTitleModel *)model
{
    // 类型安全检查
    if (![model isKindOfClass:[CFCPlayTypeTitleModel class]]) {
        return;
    }
    
    // 数据赋值
    _model = model;

    // 设置标题
    [self.titleLabel setText:model.title];
    [self.titleLabel setFont:model.titleFont];
    [self.titleLabel setTextColor:model.titleColor];
}


@end

