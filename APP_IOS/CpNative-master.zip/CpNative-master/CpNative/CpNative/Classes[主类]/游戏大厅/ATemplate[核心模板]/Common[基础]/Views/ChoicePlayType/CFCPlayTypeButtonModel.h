//
//  游戏 - 投注页面头部区域 - 玩法选择 - 确定按钮
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCPlayTypeButtonModel : NSObject
@property (nonatomic, copy) NSString *title;  // 标题
@property (nonatomic, strong) UIFont *titleFont; // 标题字体
@property (nonatomic, strong) UIColor *titleColor; // 标题颜色
@end

NS_ASSUME_NONNULL_END
