//
// 游戏 - 投注区 - 官方模式 - 11选5 - 任选复式 - 任选复式 - 任选五中五复式
//

#import "CFCGameBetPlayClassModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFC11X5PlayClassRXFSRenXuan05Model : CFCGameBetPlayClassModel

+ (NSMutableArray *) buildingDataModlesForSection1;

@end


@interface CFC11X5PlayClassRXFSRenXuan05SectionModel : CFCGameBetPlayClassSectionModel

+ (NSMutableArray *) buildingDataModles;

@end

NS_ASSUME_NONNULL_END
