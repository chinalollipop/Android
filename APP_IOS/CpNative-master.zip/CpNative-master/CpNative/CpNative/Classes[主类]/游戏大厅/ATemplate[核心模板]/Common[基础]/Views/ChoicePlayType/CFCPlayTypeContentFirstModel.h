//
//  游戏 - 投注页面头部区域 - 玩法选择 - 一级分类
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCPlayTypeContentFirstModel : NSObject

@property (nonatomic, strong) NSArray<CFCGameBetPlayTypeModel *> *menuChildren;

@end

NS_ASSUME_NONNULL_END
