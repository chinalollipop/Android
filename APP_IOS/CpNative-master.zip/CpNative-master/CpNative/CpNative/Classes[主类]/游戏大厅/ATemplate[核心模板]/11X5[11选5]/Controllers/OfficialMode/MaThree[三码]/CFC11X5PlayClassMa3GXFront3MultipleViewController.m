//
// 游戏 - 投注区 - 官方模式 - 11选5 - 三码 - 组选 - 前三组选复式
//

#import "CFC11X5PlayClassMa3GXFront3MultipleViewController.h"
#import "CFC11X5PlayClassMa3GXFront3MultipleModel.h"


@interface CFC11X5PlayClassMa3GXFront3MultipleViewController ()

@end


@implementation CFC11X5PlayClassMa3GXFront3MultipleViewController


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.className = GAME_PLAY_CLASS_NAME_11X5_MA3_GX_FRONT_3_MULTIPLE;
        self.classCode = GAME_PLAY_CLASS_CODE_11X5_MA3_GX_FRONT_3_MULTIPLE;
    }
    return self;
}


#pragma mark -
#pragma mark 数据模型 - 静态数据模型
- (NSArray<CFCGameBetPlayClassSectionModel *> *)dataOfPlayClassModelsForBettingRecords
{
    return [CFC11X5PlayClassMa3GXFront3MultipleSectionModel buildingDataModles];
}


#pragma mark 投注总数 - 计算投注总数
- (NSInteger)numberOfBettingRecords
{
    return [self numberOfBettingRecordsForCombination:3];
}


#pragma mark 投注结果 - 官方模式
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsOfficial:(NSDictionary *)dictOfBetSetting
{
    return [self bettingResultModelsForBettingRecordsTemplateN01:dictOfBetSetting];
}


@end

