//
// 游戏 - 投注区 - 官方模式 - 北京快乐8 - 任选一 - 任选一 - 复式
//

#import "CFCBJKL8PlayClassRenXuan01ViewController.h"
#import "CFCBJKL8PlayClassRenXuan01Model.h"


@interface CFCBJKL8PlayClassRenXuan01ViewController ()

@end


@implementation CFCBJKL8PlayClassRenXuan01ViewController


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.className = GAME_PLAY_CLASS_NAME_BJKL8_RENXUAN1_RENXUAN1_MULTIPLE;
        self.classCode = GAME_PLAY_CLASS_CODE_BJKL8_RENXUAN1_RENXUAN1_MULTIPLE;
    }
    return self;
}


#pragma mark -
#pragma mark 数据模型 - 静态数据模型
- (NSArray<CFCGameBetPlayClassSectionModel *> *)dataOfPlayClassModelsForBettingRecords
{
    return [CFCBJKL8PlayClassRenXuan01SectionModel buildingDataModles];
}


#pragma mark 投注总数 - 计算投注总数
- (NSInteger)numberOfBettingRecords
{
    return [self numberOfBettingRecordsForCombination:1];
}


#pragma mark 投注结果 - 官方模式
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsOfficial:(NSDictionary *)dictOfBetSetting
{
    return [self bettingResultModelsForBettingRecordsTemplateN01:dictOfBetSetting];
}


@end

