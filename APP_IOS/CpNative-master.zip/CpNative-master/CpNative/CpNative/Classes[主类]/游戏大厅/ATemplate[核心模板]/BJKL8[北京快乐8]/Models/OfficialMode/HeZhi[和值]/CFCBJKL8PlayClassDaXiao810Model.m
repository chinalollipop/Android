//
// 游戏 - 投注区 - 官方模式 - 北京快乐8 - 和值 - 和值 - 大小810
//

#import "CFCBJKL8PlayClassDaXiao810Model.h"

@implementation CFCBJKL8PlayClassDaXiao810Model

+ (NSMutableArray *) buildingDataModlesForSection1
{
    NSMutableArray<CFCBJKL8PlayClassDaXiao810Model *> *models = [NSMutableArray array];
    {
        NSArray<NSString *> *names = @[ @"大", @"810", @"小" ];
        NSArray<NSString *> *classNumbers = @[ @"2", @"1", @"0" ];
        for (int index = 0; index < names.count; index ++) {
            CFCBJKL8PlayClassDaXiao810Model *model = [[CFCBJKL8PlayClassDaXiao810Model alloc] init];
            // 名称
            [model setName:names[index]];
            [model setNameNormalFont:NAME_FONT_GAME_PLAY_MODEL_NUMBER_NORMAL];
            [model setNameSelectFont:NAME_FONT_GAME_PLAY_MODEL_NUMBER_SELECT];
            [model setNameNormalColor:NAME_COLOR_GAME_PLAY_MODEL_NORMAL];
            [model setNameSelectColor:NAME_COLOR_GAME_PLAY_MODEL_SELECT];
            [model setNameBackgroundColor:NAME_COLOR_GAME_PLAY_BACKGROUND_DEFAULT];
            // 赔率
            [model setOdds:ODDS_STRI_GAME_PLAY_MODEL_DEFAULT];
            [model setOddsNormalFont:ODDS_FONT_GAME_PLAY_MODEL_NORMAL];
            [model setOddsSelectFont:ODDS_FONT_GAME_PLAY_MODEL_SELECT];
            [model setOddsNormalColor:ODDS_COLOR_GAME_PLAY_MODEL_NORMAL];
            [model setOddsSelectColor:ODDS_COLOR_GAME_PLAY_MODEL_SELECT];
            [model setOddsBackgroundColor:ODDS_COLOR_GAME_PLAY_BACKGROUND_DEFAULT];
            // 号码
            [model setClassNumber:classNumbers[index]];
            [model setClassRemark:REMARK_STRI_GAME_PLAY_MODEL_DEFAULT];
            // 其它
            [model setType:CFCGameBetPlayClassItemType01];
            [model setIsSelected:GAME_PLAY_MODEL_SELECTED_DEFAULT];
            //
            [models addObject:model];
        }
    }
    return models;
}

@end


@implementation CFCBJKL8PlayClassDaXiao810SectionModel

+ (NSMutableArray *) buildingDataModles
{
    NSMutableArray<CFCBJKL8PlayClassDaXiao810SectionModel *> *models = [NSMutableArray array];
    {
        // 第一个分组
        CFCBJKL8PlayClassDaXiao810SectionModel *model1 = [[CFCBJKL8PlayClassDaXiao810SectionModel alloc] init];
        [model1 setTitle:@"大小810"];
        [model1 setType:CFCGameBetPlayClassSectionTypeOfficial2];
        [model1 setColumnsCount:GAME_PLAY_MODEL_SECTION_COLUMN_N003];
        [model1 setIsShowHeader:GAME_PLAY_MODEL_SECTION_HEADER_SHOW_NO];
        [model1 setIsShowFooter:GAME_PLAY_MODEL_SECTION_FOOTER_SHOW_NO];
        [model1 setList:[CFCBJKL8PlayClassDaXiao810Model buildingDataModlesForSection1]];
        [models addObject:model1];
    }
    return models;
}

@end

