//
// 游戏 - 投注区 - 官方模式 - 北京快乐8 - 上中下 - 上中下 - 上中下
//

#import "CFCGameBetPlayClassModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCBJKL8PlayClassShangZhongXiaModel : CFCGameBetPlayClassModel

+ (NSMutableArray *) buildingDataModlesForSection1;

@end


@interface CFCBJKL8PlayClassShangZhongXiaSectionModel : CFCGameBetPlayClassSectionModel

+ (NSMutableArray *) buildingDataModles;

@end

NS_ASSUME_NONNULL_END
