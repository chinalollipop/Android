//
// 游戏 - 投注区 - 信用模式
//

#import "CFCGameBetViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCGameBetCreditViewController : CFCGameBetViewController

@end

NS_ASSUME_NONNULL_END
