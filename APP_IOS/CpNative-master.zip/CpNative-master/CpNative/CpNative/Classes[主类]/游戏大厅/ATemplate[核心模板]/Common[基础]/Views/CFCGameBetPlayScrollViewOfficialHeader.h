//
//  游戏 - 官方玩法 - 投注页面头部区域
//

#import "CFCGameBetPlayScrollViewHeader.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCGameBetPlayScrollViewOfficialHeader : CFCGameBetPlayScrollViewHeader

@end

NS_ASSUME_NONNULL_END
