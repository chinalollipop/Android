//
//  游戏 - 投注页面头部区域 - 玩法选择 - 一级分类
//

#import <UIKit/UIKit.h>
@class CFCPlayTypeContentFirstModel;


NS_ASSUME_NONNULL_BEGIN


UIKIT_EXTERN NSString * const CELL_IDENTIFIER_GAME_PLAY_TYPE_CONTENT_FRIST_TABLE_VIEW_CELL;

@protocol CFCPlayTypeContentFirstTableViewCellDelegate <NSObject>
@required
- (void)didSelectPlayTypeContentFirstModelAtIndexPath:(NSIndexPath *)indexPath
                                     playTypeTagIndex:(NSInteger)playTypeTagIndex
                                        playTypeModel:(CFCGameBetPlayTypeModel *)playTypeModel;
@end

@interface CFCPlayTypeContentFirstTableViewCell : UITableViewCell

@property (nonatomic, strong) NSIndexPath *indexPath;

@property (nonatomic, strong) CFCPlayTypeContentFirstModel *model;

@property (nonatomic, weak) id<CFCPlayTypeContentFirstTableViewCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
