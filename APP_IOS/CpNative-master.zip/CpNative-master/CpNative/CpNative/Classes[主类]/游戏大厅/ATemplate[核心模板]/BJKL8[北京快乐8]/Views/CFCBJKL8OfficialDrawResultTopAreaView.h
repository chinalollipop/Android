//
// 游戏 - 开奖结果 - 北京快乐8
//

#import "CFCGameBetDrawResultDefaultTopAreaView.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCBJKL8OfficialDrawResultTopAreaView : CFCGameBetDrawResultDefaultTopAreaView

@end

NS_ASSUME_NONNULL_END
