//
// 游戏 - 投注区 - 官方模式 - 11选5 - 二码 - 组选 - 前二组选单式
//

#import "CFC11X5PlayClassMa2GXFront2SingleViewController.h"
#import "CFC11X5PlayClassMa2GXFront2SingleModel.h"


@interface CFC11X5PlayClassMa2GXFront2SingleViewController ()

@end


@implementation CFC11X5PlayClassMa2GXFront2SingleViewController


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.className = GAME_PLAY_CLASS_NAME_11X5_MA2_GX_FRONT_2_SINGLE;
        self.classCode = GAME_PLAY_CLASS_CODE_11X5_MA2_GX_FRONT_2_SINGLE;
    }
    return self;
}


#pragma mark -
#pragma mark 数据模型 - 静态数据模型
- (NSArray<CFCGameBetPlayClassSectionModel *> *)dataOfPlayClassModelsForBettingRecords
{
    return [CFC11X5PlayClassMa2GXFront2SingleSectionModel buildingDataModles];
}


#pragma mark 投注总数 - 计算投注总数
- (NSInteger)numberOfBettingRecords
{
    return [self numberOfBettingRecordsForSingleN07:2];
}


#pragma mark 投注内容 - 组装单式内容
- (NSArray<NSString *> *)contentOfBettingRecords
{
    return [self contentOfBettingRecordsForSingleN07:2];
}


#pragma mark 投注结果 - 官方模式
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsOfficial:(NSDictionary *)dictOfBetSetting
{
    return [self bettingResultModelsForBettingRecordsSingleTemplateN07:dictOfBetSetting count:2];
}


@end

