//
// 游戏 - 投注区 - 官方模式 - 11选5 - 三码 - 直选 - 前三直选复式
//


#import "CFC11X5PlayClassMa3ZXFront3MultipleViewController.h"
#import "CFC11X5PlayClassMa3ZXFront3MultipleModel.h"


@interface CFC11X5PlayClassMa3ZXFront3MultipleViewController ()

@end


@implementation CFC11X5PlayClassMa3ZXFront3MultipleViewController


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.className = GAME_PLAY_CLASS_NAME_11X5_MA3_ZX_FRONT_3_MULTIPLE;
        self.classCode = GAME_PLAY_CLASS_CODE_11X5_MA3_ZX_FRONT_3_MULTIPLE;
    }
    return self;
}


#pragma mark -
#pragma mark 数据模型 - 静态数据模型
- (NSArray<CFCGameBetPlayClassSectionModel *> *)dataOfPlayClassModelsForBettingRecords
{
    return [CFC11X5PlayClassMa3ZXFront3MultipleSectionModel buildingDataModles];
}


#pragma mark 投注总数 - 计算投注总数
- (NSInteger)numberOfBettingRecords
{
    __block NSInteger numberOfBettingRecords = 0;
    if (self.dataOfSectionModelArray.count > 2) {
        CFCGameBetPlayClassSectionModel *sectionTuoMaModel0 = self.dataOfSectionModelArray[0];
        CFCGameBetPlayClassSectionModel *sectionTuoMaModel1 = self.dataOfSectionModelArray[1];
        CFCGameBetPlayClassSectionModel *sectionTuoMaModel2 = self.dataOfSectionModelArray[2];
        [sectionTuoMaModel0.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull obj0, NSUInteger idx0, BOOL * _Nonnull stop0) {
            if (obj0.isSelected) {
                [sectionTuoMaModel1.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull obj1, NSUInteger idx1, BOOL * _Nonnull stop1) {
                    if (obj1.isSelected) {
                        [sectionTuoMaModel2.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull obj2, NSUInteger idx2, BOOL * _Nonnull stop2) {
                            if (obj2.isSelected && idx0 != idx1 && idx0 != idx2 && idx1 != idx2) {
                                numberOfBettingRecords ++;
                            }
                        }];
                    }
                }];
            }
        }];
    }
    return numberOfBettingRecords;
}


#pragma mark 投注结果 - 官方模式
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsOfficial:(NSDictionary *)dictOfBetSetting
{
    return [self bettingResultModelsForBettingRecordsTemplateN01:dictOfBetSetting];
}


@end

