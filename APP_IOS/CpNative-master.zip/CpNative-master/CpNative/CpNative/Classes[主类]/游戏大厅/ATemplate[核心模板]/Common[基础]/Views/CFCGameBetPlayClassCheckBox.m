//
//  游戏 - 官方玩法 - 投注复选框
//

#import "CFCGameBetPlayClassCheckBox.h"

@interface CFCGameBetPlayClassCheckBox () {
    BOOL loaded;
}
@property(nonatomic, strong) UIView *backView;
@property(nonatomic, strong) UILabel *textLabel;
@property(nonatomic, strong) UIImageView *imageView;
@end


@implementation CFCGameBetPlayClassCheckBox

@synthesize checked = _checked;
@synthesize disabled = _disabled;
@synthesize text = _text;
@synthesize textLabel = _textLabel;

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wobjc-missing-super-calls"
- (void)awakeFromNib
{
    self.backgroundColor = [UIColor clearColor];
}
#pragma clang diagnostic pop


-(void)drawRect:(CGRect)rect
{
    if(!loaded) {
        // 背景
        _backView = [[UIView alloc] initWithFrame:self.bounds];
        [_backView setUserInteractionEnabled:NO];
        [self addSubview:_backView];
        
        // 图标
        UIImage *image = [UIImage imageNamed:self.checked ? _selectBgImage : _normalBgImage];
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(self.frame.size.height*0.40f,
                                                                               self.frame.size.height*0.25f,
                                                                               self.frame.size.height*0.50f,
                                                                               self.frame.size.height*0.50f)];
        [imageView setImage:image];
        [self addSubview:imageView];
        
        // 标题
        _textLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.frame.size.height*0.9f + 5,
                                                               0,
                                                               self.frame.size.width-self.frame.size.height*0.9f-5,
                                                               self.frame.size.height)];
        _textLabel.font = _textFont;
        _textLabel.textColor = _textColor;
        _textLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:_textLabel];
        
        loaded = TRUE;
    }
    
    if(self.disabled) {
        self.userInteractionEnabled = FALSE;
        self.alpha = 0.7f;
    } else {
        self.userInteractionEnabled = TRUE;
        self.alpha = 1.0f;
    }
    
    if(self.text) {
        _textLabel.text = self.text;
    }
    
    if (self.checked) {
        UIImage *image = [UIImage imageNamed:self.checked ? _selectBgImage : _normalBgImage];
        [self.imageView setImage:image];
    } else {
        UIImage *image = [UIImage imageNamed:self.checked ? _selectBgImage : _normalBgImage];
        [self.imageView setImage:image];
    }

    if (self.checked) {
        [self.textLabel setTextColor:COLOR_HEXSTRING(@"#FFFFFF")];
        [self.textLabel setBackgroundColor:COLOR_SYSTEM_MAIN_BUTTON_BACKGROUND_SELECT_DEFAULT];
        [self addBorderWithColor:COLOR_HEXSTRING(@"#E5827F") cornerRadius:self.frame.size.height/2.0f andWidth:2.0];
        [self.backView setBackgroundColor:COLOR_SYSTEM_MAIN_BUTTON_BACKGROUND_SELECT_DEFAULT];
        [self.layer setMasksToBounds:YES];
    } else {
        
        [self.textLabel setTextColor:_textColor];
        [self.textLabel setBackgroundColor:COLOR_HEXSTRING(@"#FCF4F3")];
        [self addBorderWithColor:COLOR_HEXSTRING(@"#E4E4E4") cornerRadius:self.frame.size.height/2.0f andWidth:2.0];
        [self.backView setBackgroundColor:COLOR_HEXSTRING(@"#FCF4F3")];
        [self.layer setMasksToBounds:YES];
    }
}

- (BOOL)beginTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event
{
    [self setChecked:!self.checked];
    return TRUE;
}

- (void)setChecked:(BOOL)boolValue
{
    _checked = boolValue;
    [self setNeedsDisplay];
}

- (void)setDisabled:(BOOL)boolValue
{
    _disabled = boolValue;
    [self setNeedsDisplay];
}

- (void)setText:(NSString *)stringValue
{
    _text = stringValue;
    [self setNeedsDisplay];
}

@end

