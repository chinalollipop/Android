//
// 游戏 - 投注区 - 官方模式 - 11选5 - 任选胆拖 - 任选胆拖 - 任选七中五胆拖
//

#import "CFC11X5PlayClassRXDTRenXuan07ViewController.h"
#import "CFC11X5PlayClassRXDTRenXuan07Model.h"


@interface CFC11X5PlayClassRXDTRenXuan07ViewController ()

@end


@implementation CFC11X5PlayClassRXDTRenXuan07ViewController


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.className = GAME_PLAY_CLASS_NAME_11X5_RENXUANDANTUO_RXDT_RENXUAN07;
        self.classCode = GAME_PLAY_CLASS_CODE_11X5_RENXUANDANTUO_RXDT_RENXUAN07;
    }
    return self;
}


#pragma mark -
#pragma mark 数据模型 - 静态数据模型
- (NSArray<CFCGameBetPlayClassSectionModel *> *)dataOfPlayClassModelsForBettingRecords
{
    return [CFC11X5PlayClassRXDTRenXuan07SectionModel buildingDataModles];
}


#pragma mark 投注总数 - 计算投注总数
- (NSInteger)numberOfBettingRecords
{
    // 胆码
    __block NSInteger numberOfBettingRecordsFirst = 0;
    if (self.dataOfSectionModelArray.count > 0) {
        CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[0];
        [sectionModel.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if (obj.isSelected) {
                numberOfBettingRecordsFirst ++;
            }
        }];
    }
    if (0 == numberOfBettingRecordsFirst || 7 <= numberOfBettingRecordsFirst) {
        return 0;
    }
    
    // 拖码
    __block NSInteger numberOfBettingRecordsSecond = 0;
    if (self.dataOfSectionModelArray.count > 1) {
        CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[1];
        [sectionModel.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if (obj.isSelected) {
                numberOfBettingRecordsSecond ++;
            }
        }];
    }
    if (0 == numberOfBettingRecordsSecond) {
        return 0;
    }
    
    // 投注总数
    NSInteger count = 7 - numberOfBettingRecordsFirst;
    return [CFCPaiLieZuHeMathUtil combinationWithN:numberOfBettingRecordsSecond andM:count];
}


#pragma mark 投注结果 - 官方模式
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsOfficial:(NSDictionary *)dictOfBetSetting
{
    return [self bettingResultModelsForBettingRecordsTemplateN01:dictOfBetSetting];
}


#pragma mark -
#pragma mark 事件处理 - 点击投注表格后处理数据
- (NSArray<NSIndexPath *> *)doUpdatePlayClassCellModelsAtIndexPath:(NSIndexPath *)indexPath itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels itemIndexs:(NSArray<NSNumber *> *)itemIndexs
{
    return [self doRefreshDanTuoPlayClassCellRowAtIndexPath:indexPath itemModels:itemModels itemIndexs:itemIndexs danTuoCount:7];
}




@end
