//
// 游戏 - 投注区 - 信用模式 - 北京快乐8
//

#import "CFCBJKL8CreditViewController.h"

@interface CFCBJKL8CreditViewController ()

@end

@implementation CFCBJKL8CreditViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
