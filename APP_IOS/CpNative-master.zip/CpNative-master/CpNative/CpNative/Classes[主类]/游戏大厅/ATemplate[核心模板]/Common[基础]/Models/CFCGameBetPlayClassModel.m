//
// 游戏 - 投注区 - 选注页面每一个具体选项的数据模型的基类 -> 游戏中所有具体选项的数据模型必须以此类为基类。
//

#import "CFCGameBetPlayClassModel.h"

@implementation CFCGameBetPlayClassModel

- (instancetype)init
{
    self = [super init];
    if (self) {
        _name = NAME_STRI_GAME_PLAY_MODEL_DEFAULT; // 名称
        _nameNormalFont = NAME_FONT_GAME_PLAY_MODEL_NUMBER_NORMAL; // 名称字体 - 正常
        _nameSelectFont = NAME_FONT_GAME_PLAY_MODEL_NUMBER_SELECT; // 名称字体 - 选中
        _nameNormalColor = NAME_COLOR_GAME_PLAY_MODEL_NORMAL;  // 名称颜色 - 正常
        _nameSelectColor = NAME_COLOR_GAME_PLAY_MODEL_SELECT;  // 名称颜色 - 正常
        _nameBackgroundColor = NAME_COLOR_GAME_PLAY_BACKGROUND_DEFAULT;  // 名称背景色
        
        _odds = ODDS_STRI_GAME_PLAY_MODEL_DEFAULT; // 赔率
        _oddsNormalFont = ODDS_FONT_GAME_PLAY_MODEL_NORMAL; // 赔率字体 - 正常
        _oddsSelectFont = ODDS_FONT_GAME_PLAY_MODEL_SELECT; // 赔率字体 - 选中
        _oddsNormalColor = ODDS_COLOR_GAME_PLAY_MODEL_NORMAL;  // 赔率颜色 - 正常
        _oddsSelectColor = ODDS_COLOR_GAME_PLAY_MODEL_SELECT;  // 赔率颜色 - 正常
        _oddsBackgroundColor = ODDS_COLOR_GAME_PLAY_BACKGROUND_DEFAULT;  // 赔率背景色
        
        _isShowName = NAME_SHOW_GAME_PLAY_MODEL_YES; // 默认显示名称
        _isShowOdds = ODDS_SHOW_GAME_PLAY_MODEL_YES; // 默认显示赔率
        _isShowDesc = DESC_SHOW_GAME_PLAY_MODEL_YES; // 默认显示描述
        _isCornerRadius = CORNER_RADIUS_GAME_PLAY_MODEL_YES; // 默认切圆角
        
        _type = CFCGameBetPlayClassItemType01; // 项目类型
        _isSelected = GAME_PLAY_MODEL_SELECTED_DEFAULT; // 是否已选中
    }
    return self;
}

// 根据赔率排序
- (NSComparisonResult)compareOddsValue:(CFCGameBetPlayClassModel *)model
{
    if (self.odds.doubleValue > model.odds.doubleValue) {
        return NSOrderedDescending;
    } else if (self.odds.doubleValue < model.odds.doubleValue) {
        return NSOrderedAscending;
    } else {
        return NSOrderedSame;
    }
}

// 根据数字排序
- (NSComparisonResult)compareNumberValue:(CFCGameBetPlayClassModel *)model
{
    return NSOrderedSame;
}

+ (NSMutableArray *) buildingDataModlesForSection1
{
    NSMutableArray<CFCGameBetPlayClassModel *> *models = [NSMutableArray array];
    {
        NSArray<NSString *> *names = @[ STR_NUMBER_00, STR_NUMBER_01, STR_NUMBER_02, STR_NUMBER_03, STR_NUMBER_04,
                                        STR_NUMBER_05, STR_NUMBER_06, STR_NUMBER_07, STR_NUMBER_08, STR_NUMBER_09 ];
        NSArray<NSString *> *classNumbers = @[ STR_NUMDATA_00, STR_NUMDATA_01, STR_NUMDATA_02, STR_NUMDATA_03, STR_NUMDATA_04,
                                               STR_NUMDATA_05, STR_NUMDATA_06, STR_NUMDATA_07, STR_NUMDATA_08, STR_NUMDATA_09 ];
        for (int index = 0; index < names.count; index ++) {
            CFCGameBetPlayClassModel *model = [[CFCGameBetPlayClassModel alloc] init];
            // 名称
            [model setName:names[index]];
            [model setNameNormalFont:NAME_FONT_GAME_PLAY_MODEL_NUMBER_NORMAL];
            [model setNameSelectFont:NAME_FONT_GAME_PLAY_MODEL_NUMBER_SELECT];
            [model setNameNormalColor:NAME_COLOR_GAME_PLAY_MODEL_NORMAL];
            [model setNameSelectColor:NAME_COLOR_GAME_PLAY_MODEL_SELECT];
            [model setNameBackgroundColor:NAME_COLOR_GAME_PLAY_BACKGROUND_DEFAULT];
            // 赔率
            [model setOdds:ODDS_STRI_GAME_PLAY_MODEL_DEFAULT];
            [model setOddsNormalFont:ODDS_FONT_GAME_PLAY_MODEL_NORMAL];
            [model setOddsSelectFont:ODDS_FONT_GAME_PLAY_MODEL_SELECT];
            [model setOddsNormalColor:ODDS_COLOR_GAME_PLAY_MODEL_NORMAL];
            [model setOddsSelectColor:ODDS_COLOR_GAME_PLAY_MODEL_SELECT];
            [model setOddsBackgroundColor:ODDS_COLOR_GAME_PLAY_BACKGROUND_DEFAULT];
            // 号码
            [model setClassNumber:classNumbers[index]];
            [model setClassRemark:REMARK_STRI_GAME_PLAY_MODEL_DEFAULT];
            // 其它
            [model setOddskey:ODDS_KEY_GAME_PLAY_MODEL_DEFAULT];
            [model setType:CFCGameBetPlayClassItemType01];
            [model setIsSelected:GAME_PLAY_MODEL_SELECTED_DEFAULT];
            //
            [models addObject:model];
        }
    }
    
    return models;
}

+ (NSMutableArray *) buildingDataModlesForSection2
{
    NSMutableArray<CFCGameBetPlayClassModel *> *models = [NSMutableArray array];
    {
        NSArray<NSString *> *names = @[ STR_CHINESE_DA, STR_CHINESE_XIAO, STR_CHINESE_DAN, STR_CHINESE_SHUANG, STR_CHINESE_ZHI, STR_CHINESE_HE ];
        NSArray<NSString *> *classNumbers = @[ STR_CHINDATA_DA, STR_CHINDATA_XIAO, STR_CHINDATA_DAN, STR_CHINDATA_SHUANG, STR_CHINDATA_ZHI, STR_CHINDATA_HE ];
        for (int index = 0; index < names.count; index ++) {
            CFCGameBetPlayClassModel *model = [[CFCGameBetPlayClassModel alloc] init];
            // 名称
            [model setName:names[index]];
            [model setNameNormalFont:NAME_FONT_GAME_PLAY_MODEL_CHINESE_NORMAL];
            [model setNameSelectFont:NAME_FONT_GAME_PLAY_MODEL_CHINESE_SELECT];
            [model setNameNormalColor:NAME_COLOR_GAME_PLAY_MODEL_NORMAL];
            [model setNameSelectColor:NAME_COLOR_GAME_PLAY_MODEL_SELECT];
            [model setNameBackgroundColor:NAME_COLOR_GAME_PLAY_BACKGROUND_DEFAULT];
            // 赔率
            [model setOdds:ODDS_STRI_GAME_PLAY_MODEL_DEFAULT];
            [model setOddsNormalFont:ODDS_FONT_GAME_PLAY_MODEL_NORMAL];
            [model setOddsSelectFont:ODDS_FONT_GAME_PLAY_MODEL_SELECT];
            [model setOddsNormalColor:ODDS_COLOR_GAME_PLAY_MODEL_NORMAL];
            [model setOddsSelectColor:ODDS_COLOR_GAME_PLAY_MODEL_SELECT];
            [model setOddsBackgroundColor:ODDS_COLOR_GAME_PLAY_BACKGROUND_DEFAULT];
            // 号码
            [model setClassNumber:classNumbers[index]];
            [model setClassRemark:REMARK_STRI_GAME_PLAY_MODEL_DEFAULT];
            // 其它
            [model setOddskey:ODDS_KEY_GAME_PLAY_MODEL_DEFAULT];
            [model setType:CFCGameBetPlayClassItemType01];
            [model setIsSelected:GAME_PLAY_MODEL_SELECTED_DEFAULT];
            //
            [models addObject:model];
        }
    }
    
    return models;
}

@end


@implementation CFCGameBetPlayClassSectionModel

- (instancetype)init
{
    self = [super init];
    if (self) {
        _type = CFCGameBetPlayClassSectionTypeDefault; // 分组类型
        _columnsCount = GAME_PLAY_MODEL_SECTION_COLUMN_DEFAULT; // 默认列数
        _selectedOptBtnTitle = GAME_PLAY_MODEL_BUTTON_TITLE_NULL; // 默认按钮标题
        
        _isShowSectionContent = GAME_PLAY_MODEL_SECTION_SHOW_YES; // 默认显示分组视图
        
        _isShowHeader = GAME_PLAY_MODEL_SECTION_HEADER_SHOW_YES; // 是否显示分组头部视图
        _isShowFooter = GAME_PLAY_MODEL_SECTION_FOOTER_SHOW_YES; // 是否显示分组底部视图
        _heightOfHeader = GAME_PLAY_MODEL_SECTION_HEADER_HEIGHT_DEFAULT; // 分组头部视图高度
        _heightOfFooter = GAME_PLAY_MODEL_SECTION_FOOTER_HEIGHT_DEFAULT; // 分组底部视图高度
    }
    return self;
}

+ (NSMutableArray *) buildingDataModles
{
    NSMutableArray<CFCGameBetPlayClassSectionModel *> *models = [NSMutableArray array];
    {
        // 第一个分组
        CFCGameBetPlayClassSectionModel *model1 = [[CFCGameBetPlayClassSectionModel alloc] init];
        [model1 setTitle:@"第一个分组"];
        [model1 setList:[CFCGameBetPlayClassModel buildingDataModlesForSection1]];
        [models addObject:model1];
        
        // 第二个分组
        CFCGameBetPlayClassSectionModel *model2 = [[CFCGameBetPlayClassSectionModel alloc] init];
        [model2 setTitle:@"第二个分组"];
        [model2 setList:[CFCGameBetPlayClassModel buildingDataModlesForSection2]];
        [models addObject:model2];
    }
    return models;
}

@end

