//
// 游戏 - 投注区 - 官方模式 - 11选5 - 任选单式 - 任选单式 - 任选三中三单式
//

#import "CFC11X5PlayClassRXDSRenXuan03ViewController.h"
#import "CFC11X5PlayClassRXDSRenXuan03Model.h"


@interface CFC11X5PlayClassRXDSRenXuan03ViewController ()

@end


@implementation CFC11X5PlayClassRXDSRenXuan03ViewController


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.className = GAME_PLAY_CLASS_NAME_11X5_RENXUANDANSHI_RXDS_RENXUAN03;
        self.classCode = GAME_PLAY_CLASS_CODE_11X5_RENXUANDANSHI_RXDS_RENXUAN03;
    }
    return self;
}


#pragma mark -
#pragma mark 数据模型 - 静态数据模型
- (NSArray<CFCGameBetPlayClassSectionModel *> *)dataOfPlayClassModelsForBettingRecords
{
    return [CFC11X5PlayClassRXDSRenXuan03SectionModel buildingDataModles];
}


#pragma mark 投注总数 - 计算投注总数
- (NSInteger)numberOfBettingRecords
{
    return [self numberOfBettingRecordsForSingleN08:3];
}


#pragma mark 投注内容 - 组装单式内容
- (NSArray<NSString *> *)contentOfBettingRecords
{
    return [self contentOfBettingRecordsForSingleN08:3];
}


#pragma mark 投注结果 - 官方模式
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsOfficial:(NSDictionary *)dictOfBetSetting
{
    return [self bettingResultModelsForBettingRecordsSingleTemplateN08:dictOfBetSetting count:3];
}


@end

