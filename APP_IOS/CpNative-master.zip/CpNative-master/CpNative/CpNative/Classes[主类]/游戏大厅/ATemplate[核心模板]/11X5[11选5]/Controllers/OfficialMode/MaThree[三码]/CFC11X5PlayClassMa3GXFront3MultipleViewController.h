//
// 游戏 - 投注区 - 官方模式 - 11选5 - 三码 - 组选 - 前三组选复式
//

#import "CFC11X5PlayClassBaseOfficialViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFC11X5PlayClassMa3GXFront3MultipleViewController : CFC11X5PlayClassBaseOfficialViewController

@end

NS_ASSUME_NONNULL_END
