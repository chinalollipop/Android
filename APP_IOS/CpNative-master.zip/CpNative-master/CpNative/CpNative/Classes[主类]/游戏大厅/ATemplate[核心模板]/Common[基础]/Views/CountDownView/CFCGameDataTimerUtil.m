

#import "CFCGameDataTimerUtil.h"


@interface CFCGameDataTimerUtil ()

@property (nonatomic, copy) NSString *gameId; // 游戏主键
@property (nonatomic, copy) NSString *gameName; // 游戏名称
@property (nonatomic, copy) NSString *gameIdentifier; // 游戏标识

@property(nonatomic, retain) dispatch_source_t timer; // 定时器
@property (nonatomic, assign) NSInteger timer_timeout; // 倒计时长

@end


@implementation CFCGameDataTimerUtil


#pragma mark -
#pragma mark 定时器单例
+ (instancetype)sharedGameDataTimerUtil
{
    static CFCGameDataTimerUtil *_singetonInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken,^{
        if (nil == _singetonInstance) {
            _singetonInstance = [[super allocWithZone:NULL] init];
        }
    });
    return _singetonInstance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone
{
    return [[self class] sharedGameDataTimerUtil];
}

- (id)copyWithZone:(struct _NSZone *)zone
{
    return [[self class] sharedGameDataTimerUtil];
}


#pragma mark -
#pragma mark 每秒走一次，回调block
- (void)countDownWithBlock:(void (^)(void))block
                    gameId:(NSString *)gameId
                  gameName:(NSString *)gameName
            gameIdentifier:(NSString *)gameIdentifier
{
    // 如果切换了，则释放旧定时器
    if (![gameId isEqualToString:[CFCGameDataTimerUtil sharedGameDataTimerUtil].gameId]
        || ![gameIdentifier isEqualToString:[CFCGameDataTimerUtil sharedGameDataTimerUtil].gameIdentifier]) {
        [[CFCGameDataTimerUtil sharedGameDataTimerUtil] destoryTimer];
        //
        [CFCGameDataTimerUtil sharedGameDataTimerUtil].gameId = gameId;
        [CFCGameDataTimerUtil sharedGameDataTimerUtil].gameName = gameName;
        [CFCGameDataTimerUtil sharedGameDataTimerUtil].gameIdentifier = gameIdentifier;
    }
    
    // 定时器为空，则创建新定时器
    if (APPINFORMATION.isGameDataTimerEnable) {
        if ([CFCGameDataTimerUtil sharedGameDataTimerUtil].timer == nil) {
            [CFCGameDataTimerUtil sharedGameDataTimerUtil].timer_timeout = 0L; // 倒计时间秒数变量
            //
            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
            [CFCGameDataTimerUtil sharedGameDataTimerUtil].timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
            dispatch_source_set_timer([CFCGameDataTimerUtil sharedGameDataTimerUtil].timer, dispatch_walltime(NULL, 0), 1.0*NSEC_PER_SEC, 0); // 每秒执行
            dispatch_source_set_event_handler([CFCGameDataTimerUtil sharedGameDataTimerUtil].timer, ^{
                if ([CFCGameDataTimerUtil sharedGameDataTimerUtil].timer_timeout > 0) {
                    CFCLog(@"主页数据 => [%@-%@-%@] => 加载已用时[%ld]秒",
                           [CFCGameDataTimerUtil sharedGameDataTimerUtil].gameId,
                           [CFCGameDataTimerUtil sharedGameDataTimerUtil].gameIdentifier,
                           [CFCGameDataTimerUtil sharedGameDataTimerUtil].gameName,
                           [CFCGameDataTimerUtil sharedGameDataTimerUtil].timer_timeout);
                    dispatch_async(dispatch_get_main_queue(), ^{
                        block();
                    });
                }
                [CFCGameDataTimerUtil sharedGameDataTimerUtil].timer_timeout ++;
            });
            dispatch_resume([CFCGameDataTimerUtil sharedGameDataTimerUtil].timer);
        }
    } else {
        [[CFCGameDataTimerUtil sharedGameDataTimerUtil] destoryTimer];
    }
}


#pragma mark 销毁定时器
- (void)destoryTimer
{
    if ([CFCGameDataTimerUtil sharedGameDataTimerUtil].timer) {
        CFCLog(@"释放定时器[主页数据][%@-%@-%@]",
               [CFCGameDataTimerUtil sharedGameDataTimerUtil].gameId,
               [CFCGameDataTimerUtil sharedGameDataTimerUtil].gameIdentifier,
               [CFCGameDataTimerUtil sharedGameDataTimerUtil].gameName);
        dispatch_source_cancel([CFCGameDataTimerUtil sharedGameDataTimerUtil].timer);
        [CFCGameDataTimerUtil sharedGameDataTimerUtil].timer = nil;
    }
}


@end


