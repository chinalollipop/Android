//
// 游戏 - 投注区 - 选注页面
//

#import "CFCGameBetPlayClassViewController.h"

NSString *const CFCGameBetPlayClassParentTableViewDidLeaveFromTopNotification = @"CFCGameBetPlayClassParentTableViewDidLeaveFromTopNotification";


@interface CFCGameBetPlayClassViewController () <UIScrollViewDelegate>

@end

@implementation CFCGameBetPlayClassViewController


#pragma mark -
#pragma mark 事件处理 - 点击投注表格操作事件
- (void)didSelectPlayClassCellRowAtIndexPath:(NSIndexPath *)indexPath itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels itemIndexs:(NSArray<NSNumber *> *)itemIndexs itemReload:(BOOL)itemReload;
{
    // TODO: 请在子类中重载该方法，并处理表格点击事件
    
    // 安全检查
    if (!self.dataOfSectionModelArray
        || self.dataOfSectionModelArray.count <= 0
        || self.dataOfSectionModelArray.count <= indexPath.section
        || ![self.dataOfSectionModelArray[indexPath.section] isKindOfClass:[CFCGameBetPlayClassSectionModel class]]) {
        return ;
    }
    
    // 更新数据
    NSArray<NSIndexPath *> *indexPaths = [self doUpdatePlayClassCellModelsAtIndexPath:indexPath itemModels:itemModels itemIndexs:itemIndexs];
    
    // 更新界面
    [self doRefreshMainUIOfGameBetViewControllerWithChangeBetNumber:YES changeContents:YES changeSelectedDataMarks:YES changeSelectedDataRemarks:YES];
    
    // 刷新界面
    if (itemReload) {
        [self doReloadPlayClassSectionModelRowsAtIndexPaths:indexPaths];
    }
}

#pragma mark 事件处理 - 点击投注表格后更新数据
- (NSArray<NSIndexPath *> *)doUpdatePlayClassCellModelsAtIndexPath:(NSIndexPath *)indexPath itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels itemIndexs:(NSArray<NSNumber *> *)itemIndexs
{
    // TODO: 请在子类中重载该方法，并根据相应要求进行自定义处理
    
    CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[indexPath.section];
    if (itemIndexs.count > 1) {
        // 项目 - 多个
        [itemIndexs enumerateObjectsUsingBlock:^(NSNumber * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSInteger itemIndex = obj.integerValue;
            if (itemIndex >= 0 && itemIndex < sectionModel.list.count) {
                CFCGameBetPlayClassModel *elem = sectionModel.list[itemIndex];
                elem.isSelected = !elem.isSelected;
            }
        }];
    } else if (itemIndexs.count > 0) {
        // 项目 - 单个
        NSInteger itemIndex = [itemIndexs objectAtIndex:0].integerValue;
        if (itemIndex >= 0 && itemIndex < sectionModel.list.count) {
            CFCGameBetPlayClassModel *elem = sectionModel.list[itemIndex];
            elem.isSelected = !elem.isSelected;
        }
    }
    
    __block NSMutableArray<NSIndexPath *> *indexPaths = [NSMutableArray<NSIndexPath *> arrayWithCapacity:itemIndexs.count];
    [itemIndexs enumerateObjectsUsingBlock:^(NSNumber * _Nonnull row, NSUInteger idx, BOOL * _Nonnull stop) {
        NSIndexPath *itemIndexPath = [NSIndexPath indexPathForRow:row.integerValue inSection:indexPath.section];
        [indexPaths addObject:itemIndexPath];
    }];
    
    return [NSArray<NSIndexPath *> arrayWithArray:indexPaths];
}

#pragma mark 事件处理 - 点击投注表格后刷新表格
- (void)doReloadPlayClassSectionModelRowsAtIndexPaths:(NSArray<NSIndexPath *> *)indexPaths
{
    // TODO: 请在子类中重载该方法，并刷新相关控件
    
}

#pragma mark 事件处理 - 点击投注表格后刷新表格 - 刷新类型模式
- (CFCPlayClassAfterSelectedItemOfRefreshMode)doReloadPlayClassAfterSelectedItemOfRefreshMode
{
    // TODO: 请在子类中重载该方法，并刷设置刷新模式
    
    return CFCPlayClassAfterSelectedItemOfRefreshModeRows;
}

#pragma mark 事件处理 - 点击投注表格后刷新主页
- (void)doRefreshMainUIOfGameBetViewControllerWithChangeBetNumber:(BOOL)changeBetNumber
                                                   changeContents:(BOOL)changeContents
                                          changeSelectedDataMarks:(BOOL)changeSelectedDataMarks
                                        changeSelectedDataRemarks:(BOOL)changeSelectedDataRemarks
{
    // TODO: 请在子类中重载该方法，并刷新主页数据
    
    // ① 投注总数
    if (changeBetNumber) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(changeSumNumberOfBettingForMainGameBetViewController:)]) {
            NSInteger numberOfBettingRecords = [self numberOfBettingRecords]; // 每一个子类必须实现此方法，投注总数计算
            if (![self.delegate changeSumNumberOfBettingForMainGameBetViewController:numberOfBettingRecords]) {
                CFCLog(@"[changeSumNumberOfBettingForMainGameBetViewController:]更新投注总数失败");
            }
        } else {
            NSAssert(NO, @"[CFCGameBetBaseViewController]类必须实现代理方法[changeSumNumberOfBettingForMainGameBetViewController:]");
        }
    }
    
    // ② 投注内容
    if (changeContents) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(changeContentsOfBettingForMainGameCoreViewController:)]) {
            NSArray<NSString *> *contents = [self contentOfBettingRecords]; // 每一个子类必须实现此方法，投注内容组装
            if (![self.delegate changeContentsOfBettingForMainGameCoreViewController:contents]) {
                CFCLog(@"[changeContentsOfBettingForMainGameCoreViewController:]更新投注内容失败");
            }
        } else {
            NSAssert(NO, @"[CFCGameBetPlayScrollViewController]类必须实现代理方法[changeContentsOfBettingForMainGameCoreViewController:]");
        }
    }
    
    // ③ 投注标识
    if (changeSelectedDataMarks) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(changeSelectedDataMarkOfBettingForMainGameCoreViewController:tabClassCode:)]) {
            NSArray *selectedDataMarkOfBettingRecords = [self selectedDataMarkOfBettingRecords]; // 每一个子类必须实现此方法，投注标识组装
            if (![self.delegate changeSelectedDataMarkOfBettingForMainGameCoreViewController:selectedDataMarkOfBettingRecords tabClassCode:self.tabClassCode]) {
                CFCLog(@"[changeSelectedDataMarkOfBettingForPlayTabPagerViewController:tabClassCode:]更新投注标识失败");
            }
        } else {
            NSAssert(NO, @"[CFCGameBetPlayScrollViewController]类必须实现代理方法[changeSelectedDataMarkOfBettingForPlayTabPagerViewController:tabClassCode:]");
        }
    }
    
    // ④ 投注备注
    if (changeSelectedDataRemarks) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(changeSelectedDataRemarkOfBettingForMainGameCoreViewController:tabClassCode:)]) {
            NSArray *selectedDataRemarkOfBettingRecords = [self selectedDataRemarkOfBettingRecords]; // 每一个子类必须实现此方法，投注备注组装
            if (![self.delegate changeSelectedDataRemarkOfBettingForMainGameCoreViewController:selectedDataRemarkOfBettingRecords tabClassCode:self.tabClassCode]) {
                CFCLog(@"[changeSelectedDataRemarkOfBettingForMainGameCoreViewController:tabClassCode:]更新投注标识失败");
            }
        } else {
            NSAssert(NO, @"[CFCGameBetPlayScrollViewController]类必须实现代理方法[changeSelectedDataRemarkOfBettingForMainGameCoreViewController:tabClassCode:]");
        }
    }
}


#pragma mark -
#pragma mark 数据处理 - 返回当前长度最大的名称
- (NSString *)itemNameOfMaxLengthInDataOfSectionModelArray:(CFCGameBetPlayClassModel *)model
{
    __block NSString *maxItemNameString = @"";
    __block CGFloat maxItemNameWidth = [maxItemNameString widthWithFont:model.nameSelectFont constrainedToHeight:MAXFLOAT] + GAME_PLAY_MODEL_NAME_NUMBE_WIDTH_GAP;
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull obj0, NSUInteger idx0, BOOL * _Nonnull stop0) {
        if (obj0.isShowSectionContent) {
            [obj0.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull obj1, NSUInteger idx1, BOOL * _Nonnull stop1) {
                CGFloat itemNameWidth = [obj1.name widthWithFont:model.nameSelectFont constrainedToHeight:MAXFLOAT] + GAME_PLAY_MODEL_NAME_NUMBE_WIDTH_GAP;
                if (itemNameWidth > maxItemNameWidth) {
                    maxItemNameString = obj1.name;
                    maxItemNameWidth = [maxItemNameString widthWithFont:model.nameSelectFont constrainedToHeight:MAXFLOAT] + GAME_PLAY_MODEL_NAME_NUMBE_WIDTH_GAP;
                }
            }];
        }
    }];
    return maxItemNameString;
}

#pragma mark 数据处理 - 返回当前长度最大的赔率
- (NSString *)itemOddsOfMaxLengthInDataOfSectionModelArray:(CFCGameBetPlayClassModel *)model
{
    __block NSString *maxItemOddsString = @"";
    __block CGFloat maxItemOddsWidth = [maxItemOddsString widthWithFont:model.oddsSelectFont constrainedToHeight:MAXFLOAT];
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull obj0, NSUInteger idx0, BOOL * _Nonnull stop0) {
        if (obj0.isShowSectionContent) {
            [obj0.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull obj1, NSUInteger idx1, BOOL * _Nonnull stop1) {
                CGFloat itemOddsWidth = [obj1.odds widthWithFont:model.oddsSelectFont constrainedToHeight:MAXFLOAT];
                if (itemOddsWidth > maxItemOddsWidth) {
                    maxItemOddsString = [CFCGameUtil getOddsValue:obj1.odds radixPoint:GAME_PLAY_MODEL_ODDS_NUMBE_POINT_LEN];
                    maxItemOddsWidth = [maxItemOddsString widthWithFont:model.oddsSelectFont constrainedToHeight:MAXFLOAT];
                }
            }];
        }
    }];
    return maxItemOddsString;
}


#pragma mark -
#pragma mark CFCGameBetPlayClassDataComputeProtocol
#pragma mark 必须实现 - 投注总数（在具体的子控制器中必须实现）
- (NSInteger)numberOfBettingRecords
{
    // TODO: 子类必须继承此方法，并根据用户操作计算投注总数
    
    __block NSInteger numberOfBettingRecords = 0;
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
            if (classObj.isSelected) {
                numberOfBettingRecords ++;
            }
        }];
    }];
    return numberOfBettingRecords;
}

#pragma mark 必须实现 - 投注内容（在具体的子控制器中必须实现）
- (NSArray<NSString *> *)contentOfBettingRecords
{
    // TODO: 子类必须继承此方法，并根据用户操作组装投注内容
    
    NSString *bettingMoney = @"1";
    
    __block NSMutableArray<NSString *> *contents = [NSMutableArray arrayWithCapacity:0];
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionModel, NSUInteger idx1, BOOL * _Nonnull stop1) {
        [sectionModel.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull playClassModel, NSUInteger idx2, BOOL * _Nonnull stop2) {
            if (playClassModel.isSelected) {
                NSString *money = [CFCSysUtil validateStringEmpty:bettingMoney] ? STR_APP_TEXT_NULL : bettingMoney;
                NSString *title = [[sectionModel.title stringByReplacingOccurrencesOfString:@" " withString:@""]
                                   stringByReplacingOccurrencesOfString:@"\r\n" withString:@""];
                NSString *content = [NSString stringWithFormat:@"[%@-%@]@%@×%@", title, playClassModel.name, playClassModel.odds, money];
                [contents addObject:content];
            }
        }];
    }];
    return contents;
}

#pragma mark 必须实现 - 投注标识（在具体的子控制器中必须实现）
- (NSArray *)selectedDataMarkOfBettingRecords
{
    // TODO: 子类必须继承此方法，并根据用户操作组装投注标识
    
    NSMutableArray *selectedDataMarkOfBettingRecords = [NSMutableArray arrayWithCapacity:0];
    for (CFCGameBetPlayClassSectionModel *obj in self.dataOfSectionModelArray) {
        NSMutableArray<NSNumber *> *selectedDataMarkSection = [NSMutableArray arrayWithCapacity:obj.list.count];
        for (CFCGameBetPlayClassModel *model in obj.list) {
            [selectedDataMarkSection addObject:[NSNumber numberWithBool:model.isSelected]];
        }
        [selectedDataMarkOfBettingRecords addObject:selectedDataMarkSection];
    }
    return [NSArray arrayWithArray:selectedDataMarkOfBettingRecords];
}

#pragma mark 必须实现 - 投注备注（在具体的子控制器中必须实现）
- (NSArray *)selectedDataRemarkOfBettingRecords
{
    // TODO: 子类必须继承此方法，并根据用户操作组装投注备注
    
    NSMutableArray *selectedDataRemarkOfBettingRecords = [NSMutableArray arrayWithCapacity:0];
    for (CFCGameBetPlayClassSectionModel *obj in self.dataOfSectionModelArray) {
        NSMutableArray<NSString *> *selectedDataRemarkSection = [NSMutableArray arrayWithCapacity:obj.list.count];
        for (CFCGameBetPlayClassModel *model in obj.list) {
            [selectedDataRemarkSection addObject:model.classRemark];
        }
        [selectedDataRemarkOfBettingRecords addObject:selectedDataRemarkSection];
    }
    return [NSArray arrayWithArray:selectedDataRemarkOfBettingRecords];
}

#pragma mark 必须实现 - 赔率键值 - 在具体的子控制器中必须实现
- (NSArray<NSString *> *)keyOfOddsForBettingRecords
{
    __block NSMutableArray<NSString *> *keyOfOddsArray = [NSMutableArray<NSString *> array];
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionModel, NSUInteger idx1, BOOL * _Nonnull stop1) {
        [sectionModel.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull playClassModel, NSUInteger idx2, BOOL * _Nonnull stop2) {
            if (![CFCSysUtil validateStringEmpty:playClassModel.oddskey]
                && (NSNotFound == [keyOfOddsArray indexOfObject:playClassModel.oddskey])) {
                [keyOfOddsArray addObject:playClassModel.oddskey];
            }
        }];
    }];
    return [NSArray<NSString *> arrayWithArray:keyOfOddsArray];
}

#pragma mark 必须实现 - 数据模型（在具体的子控制器中必须实现）
- (NSArray<CFCGameBetPlayClassSectionModel *> *)dataOfPlayClassModelsForBettingRecords
{
    // TODO: 子类必须继承此方法，创建并返回静态数据模型列表
    
    return [NSArray array];
}

#pragma mark 必须实现 - 投注结果（在具体的子控制器中必须实现）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecords:(NSDictionary *)dictOfBetSetting
{
    // TODO: 子类必须继承此方法，并根据用户操作组装投注结果
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(currentPlayModeClassForMainGameCoreViewController)]) {
        CFCGameCorePlayModeClass currentPlayModeClass = [self.delegate currentPlayModeClassForMainGameCoreViewController];
        if (CFCGameCorePlayModeClassOfficial == currentPlayModeClass) {
            // 官方模式
            return [self bettingResultModelsForBettingRecordsOfficial:dictOfBetSetting];
        } else if (CFCGameCorePlayModeClassCredit == currentPlayModeClass) {
            // 信用模式
            return [self bettingResultModelsForBettingRecordsCredit:dictOfBetSetting];
        }
    } else {
        NSAssert(NO, @"[CFCGameBetPlayScrollViewController]类必须实现代理方法[currentPlayModeClassForMainGameCoreViewController]");
    }
    return nil;
}

#pragma mark 必须实现 - 投注结果 - 官方模式
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsOfficial:(NSDictionary *)dictOfBetSetting
{
    CFCGameBetRecordModel *model = [self buildindBettingResultModelForBettingRecordsOfCompose:dictOfBetSetting];
    
    return [NSArray<CFCGameBetRecordModel *> arrayWithObject:model];
}

#pragma mark 必须实现 - 投注结果 - 信用模式
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsCredit:(NSDictionary *)dictOfBetSetting
{
    return [NSArray<CFCGameBetRecordModel *> array];
}

#pragma mark 必须实现 - 投注结果 - 组合结果
- (CFCGameBetRecordModel *)buildindBettingResultModelForBettingRecordsOfCompose:(NSDictionary *)dictOfBetSetting
{
    // 获取设置信息
    NSString *type = [dictOfBetSetting stringForKey:KEY_BETTING_RESULT_PLAY_TYPE]; // 类型标识
    NSString *wayId = [dictOfBetSetting stringForKey:KEY_BETTING_RESULT_WAY_UUID]; // 类型主键
    NSString *money_unit = [dictOfBetSetting stringForKey:KEY_BETTING_RESULT_MONEY_UNIT];  // 单位
    NSString *multiple = [dictOfBetSetting stringForKey:KEY_BETTING_RESULT_MULTIPLE]; // 倍数
    NSString *number = [dictOfBetSetting stringForKey:KEY_BETTING_RESULT_BET_NUMBER]; // 投注总数
    NSString *one_price = [dictOfBetSetting stringForKey:KEY_BETTING_RESULT_ONE_PRICE]; // 价格
    NSString *prize_group = [dictOfBetSetting stringForKey:KEY_BETTING_RESULT_PRIZE_GROUP]; // 奖金组
    NSString *viewBalls = [dictOfBetSetting stringForKey:KEY_BETTING_RESULT_VIEW_BALLS]; // 未知
    
    // 创建投注模型
    CFCGameBetRecordModel *model = [CFCGameBetRecordModel buildingDataModleForBettingRecords];
    [model setType:type];
    [model setWayId:wayId];
    [model setMoneyunit:money_unit];
    [model setMultiple:multiple];
    [model setNum:number];
    [model setOnePrice:one_price];
    [model setPrizeGroup:prize_group];
    [model setViewBalls:viewBalls];
    
    return model;
}


#pragma mark -
#pragma mark CFCGameBetPlayScrollToPlayClassViewControllerProtocol

#pragma mark 清空操作 - 清空按钮事件传递至叶子结点页面
- (void)doClearButtonActionForPlayClassViewController
{
    // TODO: 清空按钮事件，进行相关处理
    
    // 清空数据选中标识
    __block BOOL isNormalSectionModel = YES; // 是否为正常的分组数据模型
    __block NSIndexPath *indexPath = [NSIndexPath indexPathWithIndex:0];
    __block NSMutableArray<NSNumber *> *selectedIndexs = [NSMutableArray array];
    __block NSMutableArray<CFCGameBetPlayClassModel *> *selectedModels = [NSMutableArray array];
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
       if ([self isNormalSectionModel:sectionObj]) {
           // 分组内容是否是投注号码
           [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
               classObj.isSelected = NO;
           }];
       } else if ([self isSingleSectionModel:sectionObj]) {
           // 非正常的分组数据模型
           isNormalSectionModel = NO;
           indexPath = [NSIndexPath indexPathWithIndex:sectionIdx];
           // 分组内容是否是单式号码
           [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
               classObj.isSelected = YES;  // 代表清空文本
               classObj.classNumber = STR_APP_TEXT_EMPTY;
               classObj.classRemark = REMARK_STRI_GAME_PLAY_MODEL_EMPTY;
               classObj.name = GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_CLEAR;
               [selectedModels addObject:classObj];
               [selectedIndexs addObject:[NSNumber numberWithInteger:classIdx]];
           }];
       }
    }];
    [self reloadRefreshViewData];
    
    // 刷新主页界面信息
    if (!isNormalSectionModel) {
        [self didSelectPlayClassCellRowAtIndexPath:indexPath itemModels:selectedModels itemIndexs:selectedIndexs itemReload:YES];
    } else {
        [self doRefreshMainUIOfGameBetViewControllerWithChangeBetNumber:YES changeContents:YES changeSelectedDataMarks:YES changeSelectedDataRemarks:YES];
    }
}

#pragma mark 投注操作 - 投注按钮事件传递至叶子结点页面
- (void)doBettingButtonActionForPlayClassViewController
{
    // TODO: 投注按钮事件，进行相关处理
    
    // 判断是否为单式分组数据模型
    __block BOOL isSingleSectionModel = NO; // 是否为单式分组数据模型
    __block NSIndexPath *indexPath = [NSIndexPath indexPathWithIndex:0];
    __block NSMutableArray<NSNumber *> *selectedIndexs = [NSMutableArray array];
    __block NSMutableArray<CFCGameBetPlayClassModel *> *selectedModels = [NSMutableArray array];
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        if ([self isSingleSectionModel:sectionObj]) {
            // 是否为单式分组数据模型
            isSingleSectionModel = YES;
            indexPath = [NSIndexPath indexPathWithIndex:sectionIdx];
            // 分组内容是否是单式号码
            [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
                [classObj setIsSelected:NO];  // 代表筛选号码
                [classObj setName:GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_FILTER];
                [selectedModels addObject:classObj];
                [selectedIndexs addObject:[NSNumber numberWithInteger:classIdx]];
            }];
        }
    }];
    
    // 刷新主界面信息
    if (isSingleSectionModel) {
        [self didSelectPlayClassCellRowAtIndexPath:indexPath itemModels:selectedModels itemIndexs:selectedIndexs itemReload:YES];
    } else {
        [self doRefreshMainUIOfGameBetViewControllerWithChangeBetNumber:YES changeContents:YES changeSelectedDataMarks:YES changeSelectedDataRemarks:YES];
    }
}

#pragma mark 投注结果 - 从叶子结点页面获取投注结果数据
- (NSArray<CFCGameBetRecordModel *> *)bettingRecordModelsFromPlayClassViewController:(NSDictionary *)dictOfBetSetting
{
    // TODO: 投注操作事件，组装并返回投注结果列表
    
    return [self bettingResultModelsForBettingRecords:dictOfBetSetting];
}

#pragma mark 投注赔率 - 加载刷新赔率数据至叶子结点页面
- (void)doRefreshRequestOddsDataForPlayClassViewController:(NSDictionary *)responseData
{
    // TODO: 加载投注赔率，根据模型刷新子结点页面
    
    // 保存主页面接口的所有数据
    self.allResponseDataOrCacheData = responseData;
    
    // 加载数据
    WEAKSELF(weakSelf);
    [self buildingStaticDataModles:responseData then:^(NSArray *dataModles) {
        // 创建表格
        [weakSelf createUIRefreshView:NO];
        // 刷新数据
        [weakSelf reloadRefreshViewData];
    }];
}


#pragma mark -
#pragma mark 加载数据
- (void)buildingStaticDataModles:(NSDictionary<NSString *, NSObject *> *)responseData then:(void (^)(NSArray *dataModles))then
{
    // 数据源处理
    self.dataOfSectionModelArray = [NSMutableArray array];
    
    // 获取静态数据模型
    NSArray<CFCGameBetPlayClassSectionModel *> *models = [self dataOfPlayClassModelsForBettingRecords];
    if (models && 0 < models.count) {
        [self.dataOfSectionModelArray addObjectsFromArray:models];
    }
    
    // 加载数据前操作
    [self doBeforeBuildingStaticDataModlesOrNetworkData];
    
    // TODO: 加载请求赔率数据
    
    // 重新加载页面时，对已经选中的数据处理
    NSArray *selectedDataMark = nil;
    if (self.delegate && [self.delegate respondsToSelector:@selector(selectedDataMarkOfBettingFromMainGameCoreViewController:)]) {
        selectedDataMark = [self.delegate selectedDataMarkOfBettingFromMainGameCoreViewController:self.tabClassCode];
    } else {
        NSAssert(NO, @"[CFCGameBetPlayScrollViewController]类必须实现代理方法[selectedDataMarkOfBettingFromMainGameCoreViewController:]");
    }
    if (selectedDataMark && selectedDataMark.count == self.dataOfSectionModelArray.count) {
        for (int i  = 0; i < selectedDataMark.count && i < self.dataOfSectionModelArray.count; i ++) {
            NSArray<NSNumber *> *sectionMarkSection = selectedDataMark[i];
            CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[i];
            for (int j  = 0; j < sectionMarkSection.count && j < sectionModel.list.count; j ++) {
                NSNumber *boolNumber = sectionMarkSection[j];
                CFCGameBetPlayClassModel *playClassModel = sectionModel.list[j];
                [playClassModel setIsSelected:boolNumber.boolValue];
            }
        }
    }
    
    // 重新加载页面时，对重新赋值投注备注
    NSArray *selectedDataRemark = nil;
    if (self.delegate && [self.delegate respondsToSelector:@selector(selectedDataRemarkOfBettingFromMainGameCoreViewController:)]) {
        selectedDataRemark = [self.delegate selectedDataRemarkOfBettingFromMainGameCoreViewController:self.tabClassCode];
    } else {
        NSAssert(NO, @"[CFCGameBetPlayScrollViewController]类必须实现代理方法[selectedDataRemarkOfBettingFromMainGameCoreViewController:]");
    }
    if (selectedDataRemark && selectedDataRemark.count == self.dataOfSectionModelArray.count) {
        for (int i  = 0; i < selectedDataRemark.count && i < self.dataOfSectionModelArray.count; i ++) {
            NSArray<NSString *> *sectionRemarkSection = selectedDataRemark[i];
            CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[i];
            for (int j  = 0; j < sectionRemarkSection.count && j < sectionModel.list.count; j ++) {
                NSString *classRemark = sectionRemarkSection[j];
                CFCGameBetPlayClassModel *playClassModel = sectionModel.list[j];
                [playClassModel setClassRemark:classRemark];
            }
        }
    }
    
    // 加载数据后操作
    [self doAfterBuildingStaticDataModlesOrNetworkData];
    
    // 刷新主界面信息
    [self doRefreshMainUIOfGameBetViewControllerWithChangeBetNumber:YES changeContents:YES changeSelectedDataMarks:YES changeSelectedDataRemarks:YES];
    
    // 执行块操作 -> 刷新界面
    then ? then(self.dataOfSectionModelArray) : nil;
}

#pragma mark 加载数据 - 加载完数据后操作
- (void)doBeforeBuildingStaticDataModlesOrNetworkData
{
    // TODO: 子类必须继承此方法，加载数据前进行相关操作
    
}

#pragma mark 加载数据 - 加载完数据后操作
- (void)doAfterBuildingStaticDataModlesOrNetworkData
{
    // TODO: 子类必须继承此方法，加载数据后进行相关操作
    
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // 禁止自动适配
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    // 利用通知可以同时修改所有的子控制器的 scrollView 的 contentOffset 为 CGPointZero
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(leaveFromTop)
                                                 name:CFCGameBetPlayClassParentTableViewDidLeaveFromTopNotification
                                               object:nil];
    
    // 加载数据
    WEAKSELF(weakSelf);
    [self buildingStaticDataModles:[NSDictionary dictionary] then:^(NSArray *dataModles) {
        // 创建表格
        [weakSelf createUIRefreshView:NO];
        // 刷新数据
        [weakSelf reloadRefreshViewData];
        // 加载数据
        if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(doLoadRefreshOddsDataFromPlayScrollViewController)]) {
            [weakSelf.delegate doLoadRefreshOddsDataFromPlayScrollViewController];
        } else {
            NSAssert(NO, @"[CFCGameBetPlayScrollViewController]类必须实现代理方法[doLoadRefreshOddsDataFromPlayScrollViewController]");
        }
    }];
}

#pragma mark 视图生命周期（将要显示）
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    // 刷新主界面信息
    if (self.delegate && [self.delegate respondsToSelector:@selector(currentSelectedPlayCodeOfPlayClassFromMainGameCoreViewController)]) {
        NSString *currentSelectedPlayCodeOfPlayClass = [self.delegate currentSelectedPlayCodeOfPlayClassFromMainGameCoreViewController];
        if ([self.classCode isEqualToString:currentSelectedPlayCodeOfPlayClass]
            || [self.tabClassCode isEqualToString:currentSelectedPlayCodeOfPlayClass]) {
            [self doRefreshMainUIOfGameBetViewControllerWithChangeBetNumber:YES changeContents:YES changeSelectedDataMarks:YES changeSelectedDataRemarks:YES];
        }
    } else {
        NSAssert(NO, @"[CFCGameBetPlayScrollViewController]类必须实现代理方法[currentSelectedPlayCodeOfPlayClassFromMainGameCoreViewController]");
    }
}

#pragma mark 视图生命周期（将要消失）
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];

}


#pragma mark -
#pragma mark 刷新界面表格
- (void)reloadRefreshViewData
{
    // TODO: 请在子类中重载该方法，并重新加载数据
    
}

#pragma mark 创建界面表格
- (void)createUIRefreshView:(BOOL)force
{
    // TODO: 请在子类中重载该方法，并创建相应控件
    
}


#pragma mark -
#pragma mark 私有方法
- (void)leaveFromTop
{
    _scrollView.contentOffset = CGPointZero;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (!_scrollView) {
        // 子控制器的 ScrollView、TableView、CollectionView
        _scrollView = scrollView;
    }
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(scrollViewIsScrolling:)]) {
        [self.delegate scrollViewIsScrolling:scrollView];
    }
}

@end

