//
// 游戏 - 投注区 - 选注页面每一个具体选项的数据模型的基类 -> 游戏中所有具体选项的数据模型必须以此类为基类。
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


typedef NS_ENUM(NSInteger, CFCGameBetPlayClassItemType) {
    CFCGameBetPlayClassItemType01 = 201, // 类型01 -> 投注项目类型 -> 投注项目 -> 如：时时彩玩法中<五星、两面>的投注按钮
    CFCGameBetPlayClassItemType02 = 202, // 类型02 -> 投注项目类型 -> 投注项目 -> 如：六合彩玩法中<特码、正码>的投注按钮，标题背景圆角
    CFCGameBetPlayClassItemType03 = 203, // 类型03 -> 预留字段，暂时未用
    CFCGameBetPlayClassItemType04 = 204, // 类型04 -> 预留字段，暂时未用
};


typedef NS_ENUM(NSInteger, CFCGameBetPlayClassSectionType) {
    // 默认为空
    CFCGameBetPlayClassSectionTypeDefault = 300,   // 类型00 -> 分组内容为 -> 默认为空
    // 官方玩法
    CFCGameBetPlayClassSectionTypeOfficial1 = 311, // 类型11 -> 分组内容为 -> 官方玩法 -> 投注项目，有操作按钮 -> 如：时时彩官方玩法中<五星、四星>
    CFCGameBetPlayClassSectionTypeOfficial2 = 312, // 类型13 -> 分组内容为 -> 官方玩法 -> 投注项目，无操作按钮 -> 如：时时彩官方玩法中<大小单双>
    CFCGameBetPlayClassSectionTypeOfficial3 = 313, // 类型12 -> 分组内容为 -> 官方玩法 -> 投注项目，有复选按钮 -> 如：时时彩官方玩法中<任选二、任选三>玩法中的复选按钮
    CFCGameBetPlayClassSectionTypeOfficial4 = 314, // 类型14 -> 分组内容为 -> 官方玩法 -> 投注项目，无操作按钮 -> 如：江苏快三官方玩法中<快三和值>
    CFCGameBetPlayClassSectionTypeOfficial5 = 315, // 类型15 -> 分组内容为 -> 官方玩法 -> 投注项目，有操作按钮 -> 如：北京快乐八官方玩法中<任选一、任选二>
    CFCGameBetPlayClassSectionTypeOfficial6 = 316, // 类型16 -> 分组内容为 -> 官方玩法 -> 投注项目，无操作按钮 -> 如：时时彩、极速3D官方玩法中<单式、混合组选>
    CFCGameBetPlayClassSectionTypeOfficial7 = 317, // 类型17 -> 分组内容为 -> 官方玩法 -> 投注项目，无操作按钮 -> 如：北京PK拾、11选5官方玩法中<单式、混合组选>
    CFCGameBetPlayClassSectionTypeOfficial8 = 318, // 类型18 -> 分组内容为 -> 官方玩法 -> 预留字段，暂时未用
    CFCGameBetPlayClassSectionTypeOfficial9 = 319, // 类型19 -> 分组内容为 -> 官方玩法 -> 预留字段，暂时未用
    // 信用玩法
    CFCGameBetPlayClassSectionTypeCredit1 = 321, // 类型21 -> 分组内容为 -> 信用玩法 -> 投注项目，常规 -> 如：时时彩信用玩法中<双面、跨度>
    CFCGameBetPlayClassSectionTypeCredit2 = 322, // 类型22 -> 分组内容为 -> 信用玩法 -> 投注项目，生肖 -> 如：六合彩信用玩法中<半波、特肖>
    CFCGameBetPlayClassSectionTypeCredit3 = 323, // 类型23 -> 分组内容为 -> 信用玩法 -> 预留字段，暂时未用
    CFCGameBetPlayClassSectionTypeCredit4 = 324, // 类型24 -> 分组内容为 -> 信用玩法 -> 预留字段，暂时未用
    CFCGameBetPlayClassSectionTypeCredit5 = 325, // 类型25 -> 分组内容为 -> 信用玩法 -> 预留字段，暂时未用
    CFCGameBetPlayClassSectionTypeCredit6 = 326, // 类型26 -> 分组内容为 -> 信用玩法 -> 预留字段，暂时未用
    CFCGameBetPlayClassSectionTypeCredit7 = 327, // 类型27 -> 分组内容为 -> 信用玩法 -> 预留字段，暂时未用
    CFCGameBetPlayClassSectionTypeCredit8 = 328, // 类型28 -> 分组内容为 -> 信用玩法 -> 预留字段，暂时未用
    CFCGameBetPlayClassSectionTypeCredit9 = 329, // 类型29 -> 分组内容为 -> 信用玩法 -> 预留字段，暂时未用
};


@interface CFCGameBetPlayClassModel : NSObject

@property (nonatomic, copy) NSString *name;  // 名称
@property (nonatomic, strong) UIFont *nameNormalFont; // 名称字体 - 正常
@property (nonatomic, strong) UIFont *nameSelectFont; // 名称字体 - 选中
@property (nonatomic, strong) UIColor *nameNormalColor; // 名称颜色 - 正常
@property (nonatomic, strong) UIColor *nameSelectColor; // 名称颜色 - 选中
@property (nonatomic, strong) UIColor *nameBackgroundColor; // 名称背景颜色

@property (nonatomic, copy) NSString *odds;  // 赔率
@property (nonatomic, strong) UIFont *oddsNormalFont; // 赔率字体 - 正常
@property (nonatomic, strong) UIFont *oddsSelectFont; // 赔率字体 - 选中
@property (nonatomic, strong) UIColor *oddsNormalColor; // 赔率颜色 - 正常
@property (nonatomic, strong) UIColor *oddsSelectColor; // 赔率颜色 - 选中
@property (nonatomic, strong) UIColor *oddsBackgroundColor; // 赔率背景颜色

@property (nonatomic, strong) NSArray<NSString *> *descArray; // 描述信息，如：六合彩中特肖、半波中详情
@property (nonatomic, strong) NSArray<UIFont *> *descNormalFontArray; // 描述信息字体 - 正常
@property (nonatomic, strong) NSArray<UIFont *> *descSelectFontArray; // 描述信息字体 - 选中
@property (nonatomic, strong) NSArray<UIColor *> *descNormalColorArray; // 描述信息颜色 - 正常
@property (nonatomic, strong) NSArray<UIColor *> *descSelectColorArray; // 描述信息颜色 - 选中
@property (nonatomic, strong) NSArray<UIColor *> *descBackgroundColorArray; // 描述信息背景颜色

@property (nonatomic, copy) NSString *classNumber; // 号码（后台专用）
@property (nonatomic, copy) NSString *classRemark; // 备注（后台专用）

@property (nonatomic, copy) NSString *oddskey; // 赔率键值
@property (nonatomic, assign) BOOL isSelected; // 是否已选中
@property (nonatomic, assign) BOOL isShowName; // 是否显示名称
@property (nonatomic, assign) BOOL isShowOdds; // 是否显示赔率
@property (nonatomic, assign) BOOL isShowDesc; // 是否显示描述
@property (nonatomic, assign) BOOL isCornerRadius; // 是否切圆角
@property (nonatomic, assign) CFCGameBetPlayClassItemType type; // 项目类型

- (NSComparisonResult)compareOddsValue:(CFCGameBetPlayClassModel *)model;
- (NSComparisonResult)compareNumberValue:(CFCGameBetPlayClassModel *)model;

+ (NSMutableArray *) buildingDataModlesForSection1;
+ (NSMutableArray *) buildingDataModlesForSection2;

@end


@interface CFCGameBetPlayClassSectionModel : NSObject

@property (nonatomic, copy) NSString *title; // 分组标题
@property (nonatomic, copy) NSString *selectedOptBtnTitle; // 当前选中操作按钮的名称，大小单双全清

@property (nonatomic, assign) BOOL isShowHeader; // 是否显示分组头部视图
@property (nonatomic, assign) BOOL isShowFooter; // 是否显示分组底部视图
@property (nonatomic, assign) CGFloat heightOfHeader; // 分组头部视图高度
@property (nonatomic, assign) CGFloat heightOfFooter; // 分组底部视图高度

@property (nonatomic, assign) NSInteger columnsCount; // 分组列数
@property (nonatomic, assign) BOOL isShowSectionContent; // 是否显示分组视图
@property (nonatomic, assign) CFCGameBetPlayClassSectionType type; // 分组类型
@property (nonatomic, strong) NSArray<CFCGameBetPlayClassModel *> *list; // 分组列表

+ (NSMutableArray *) buildingDataModles;

@end


NS_ASSUME_NONNULL_END
