//
// 游戏 - 开奖结果 - 11X5
//

#import "CFC11X5OfficialDrawResultTopAreaView.h"
#import "CFC11X5DrawResultModel.h"


@implementation CFC11X5OfficialDrawResultTopAreaView


#pragma mark 开奖结果动画效果 - 动画过程
- (void)animationWithDrawResultWinnerNumber:(CFCGameBetDrawResultModel *)drawResultModel
{
    // 开奖动画的开启状态值
    if(!self.isStartWinnerAnimation) {
        return;
    }
    
    // 随机排序数组
    NSArray<NSString *> *winnerNumbers = @[ STR_NUMBER_01, STR_NUMBER_02, STR_NUMBER_03, STR_NUMBER_04, STR_NUMBER_05,
                                            STR_NUMBER_06, STR_NUMBER_07, STR_NUMBER_08, STR_NUMBER_09, STR_NUMBER_10,
                                            STR_NUMBER_11 ];
    NSMutableArray *randomMutableArray = [NSMutableArray arrayWithArray:winnerNumbers];
    if ([randomMutableArray count] > 1) {
        for (NSUInteger i = [randomMutableArray count] - 1; i > 0; --i) {
            [randomMutableArray exchangeObjectAtIndex:i withObjectAtIndex:arc4random_uniform((int32_t)(i + 1))];
        }
    }
    // 随机获取号码
    NSMutableArray *numbers = [NSMutableArray arrayWithCapacity:3];
    for (NSInteger idx = 0; idx < 5; idx ++) {
        NSString *number = [randomMutableArray objectAtIndex:arc4random_uniform((int32_t)(numbers.count))];
        [numbers addObject:number];
    }
    NSArray *randomWinnerNumbers = [NSArray arrayWithArray:numbers];
    // 创建数据模型
    NSArray<NSString *> *winnerNumberArray = [CFC11X5DrawResultModel building11X5WinnerResultNumbers:randomWinnerNumbers];
    [self.leftWinnerLabelArray enumerateObjectsUsingBlock:^(CFCScrollStringLabel * _Nonnull itemLabel, NSUInteger idx, BOOL * _Nonnull stop) {
        [itemLabel setText:winnerNumberArray[idx]];
    }];
}


@end

