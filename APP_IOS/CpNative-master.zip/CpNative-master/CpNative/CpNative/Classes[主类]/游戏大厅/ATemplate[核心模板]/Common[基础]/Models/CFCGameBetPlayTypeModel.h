//
// 游戏 - 投注区 - 玩法数据模型的基类
//

#import <Foundation/Foundation.h>
@class CFCGameBetPlayTypeGroupModel, CFCGameBetPlayTypeClassModel;

NS_ASSUME_NONNULL_BEGIN

@interface CFCGameBetPlayTypeModel : NSObject

@property (nonatomic, strong) NSNumber *uuid;
@property (nonatomic, strong) NSNumber *pid;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *code;
@property (nonatomic, strong) NSArray<CFCGameBetPlayTypeGroupModel *> *childrenGroup;

@property (nonatomic, assign) BOOL isSelected; // 是否已选中

@end

@interface CFCGameBetPlayTypeGroupModel : NSObject

@property (nonatomic, strong) NSNumber *uuid;
@property (nonatomic, strong) NSNumber *pid;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *code;
@property (nonatomic, strong) NSArray<CFCGameBetPlayTypeClassModel *> *childrenClass;

@property (nonatomic, assign) BOOL isSelected; // 是否已选中

@end

@interface CFCGameBetPlayTypeClassModel : NSObject

@property (nonatomic, strong) NSNumber *uuid;
@property (nonatomic, strong) NSNumber *pid;
@property (nonatomic, strong) NSNumber *series_way_id;
@property (nonatomic, strong) NSNumber *price;
@property (nonatomic, strong) NSNumber *max_multiple;
@property (nonatomic, copy) NSString *prize;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *code;
@property (nonatomic, copy) NSString *bet_note;
@property (nonatomic, copy) NSString *bonus_note;
@property (nonatomic, copy) NSString *basic_methods;

@property (nonatomic, assign) BOOL isSelected; // 是否已选中

@end

NS_ASSUME_NONNULL_END
