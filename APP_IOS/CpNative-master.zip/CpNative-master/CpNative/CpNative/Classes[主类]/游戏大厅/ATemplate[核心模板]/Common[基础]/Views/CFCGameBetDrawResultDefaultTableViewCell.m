//
// 游戏 - 投注区 - 开奖结果
//


#import "CFCGameBetDrawResultDefaultTableViewCell.h"
#import "CFCGameBetDrawResultModel.h"

@implementation CFCGameBetDrawResultDefaultTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createViewAtuoLayout];
    }
    return self;
}

#pragma mark 创建子控件
- (void)createViewAtuoLayout
{
    // 根容器
    UIView *rootContainerView = ({
        UIView *view = [[UIView alloc] init];
        [self.contentView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@0.0f);
            make.top.equalTo(@0.0f);
            make.right.equalTo(@0.0f);
            make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
        }];
        
        view;
    });
    self.rootContainerView = rootContainerView;
    self.rootContainerView.mas_key = @"rootContainerView";
    
    // 公共容器
    UIView *publicContainerView = ({
        UIView *view = [[UIView alloc] init];
        [view.layer setMasksToBounds:YES];
        [view setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_WHITE];
        [rootContainerView addSubview:view];
        
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressPublicItemView:)];
        [view addGestureRecognizer:tapGesture];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@0.0f);
            make.top.equalTo(@0.0f);
            make.right.equalTo(@0.0f);
            make.bottom.equalTo(rootContainerView.mas_bottom).offset(0.0f);
        }];
        
        view;
    });
    self.publicContainerView = publicContainerView;
    self.publicContainerView.mas_key = @"publicContainerView";
    
    // 开奖期号
    UILabel *leftIssueNumberLabel = ({
        UILabel *label = [UILabel new];
        [publicContainerView addSubview:label];
        [label setUserInteractionEnabled:YES];
        [label setTextAlignment:NSTextAlignmentCenter];
        
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(publicContainerView.mas_centerY).offset(0.0f);
            make.left.equalTo(publicContainerView.mas_left).offset(0.0f);
        }];
        
        label;
    });
    self.leftIssueNumberLabel = leftIssueNumberLabel;
    self.leftIssueNumberLabel.mas_key = @"leftIssueNumberLabel";
    
    // 右边容器
    UIView *rightWinnerContainerView = ({
        UIView *view = [[UIView alloc] init];
        [publicContainerView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(leftIssueNumberLabel.mas_right).offset(0.0f);
            make.top.equalTo(publicContainerView.mas_top).offset(0.0f);
            make.right.equalTo(publicContainerView.mas_right).offset(0.0f);
            make.bottom.equalTo(publicContainerView.mas_bottom).offset(0.0f);
        }];
        
        view;
    });
    self.rightWinnerContainerView = rightWinnerContainerView;
    self.rightWinnerContainerView.mas_key = @"rightWinnerContainerView";
    
    // 分割线
    UIView *separatorLineView = ({
        UIView *view = [[UIView alloc] init];
        [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_LIGHTGRAY];
        [publicContainerView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(leftIssueNumberLabel.mas_bottom).offset(0.0f);
            make.left.equalTo(publicContainerView.mas_left).offset(0.0f);
            make.right.equalTo(publicContainerView.mas_right).offset(0.0f);
            make.height.equalTo(@(1.0f));
        }];
        
        view;
    });
    self.separatorLineView = separatorLineView;
    self.separatorLineView.mas_key = @"separatorLineView";
    
    // 约束完整性
    [self.publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(separatorLineView.mas_bottom).offset(0.0).priority(749);
    }];
    
}


#pragma mark - 设置数据模型
- (void)setMenuModel:(CFCGameBetDrawResultModel *)menuModel
{
    // 类型安全检查
    if (![menuModel isKindOfClass:[CFCGameBetDrawResultModel class]]) {
        return;
    }
    
    // 数据赋值
    _menuModel = menuModel;
    CFCGameBetDrawResultModel *model_original = (CFCGameBetDrawResultModel *)menuModel;
    
    // 开奖期号 - 左边大小
    CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
    CGFloat leftChinaWidth = [GAME_DRAW_RESULT_ISSUE_CHINA_WIDTH_STR widthWithFont:FONT_GAME_DRAW_RESULT_ISSUE_CHINESE
                                                               constrainedToHeight:MAXFLOAT] + margin*0.5f;
    CGFloat leftNumberWidth = [model_original.issueNumber widthWithFont:FONT_GAME_DRAW_RESULT_ISSUE_NUMBER
                                                    constrainedToHeight:MAXFLOAT] + margin*0.5f;
    CGFloat leftIssueWidth = leftChinaWidth + leftNumberWidth;
    [self.leftIssueNumberLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@(leftIssueWidth));
    }];
    
    // 开奖期号 - 数据赋值
    NSDictionary *attributesText = @{ NSFontAttributeName:FONT_GAME_DRAW_RESULT_ISSUE_CHINESE,
                                      NSForegroundColorAttributeName:COLOR_GAME_DRAW_RESULT_ISSUE_CHINESE };
    NSDictionary *attributesNumber = @{ NSFontAttributeName:FONT_GAME_DRAW_RESULT_ISSUE_NUMBER,
                                        NSForegroundColorAttributeName:COLOR_GAME_DRAW_RESULT_ISSUE_NUMBER };
    NSAttributedString *attributedString = [CFCSysUtil attributedString:@[ @"第", model_original.issueNumber, @"期:" ]
                                                         attributeArray:@[ attributesText, attributesNumber, attributesText ]];
    [self.leftIssueNumberLabel setAttributedText:attributedString];
    
    // 开奖号码
    {
        // 删除控件
        [self.rightWinnerContainerView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
        
        // 大小间距
        CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
        NSInteger column = GAME_DRAW_RESULT_WINNER_NUMBER_COLUMN;
        CGFloat top_margin = GAME_DRAW_RESULT_WINNER_NUMBER_TOP_MARGIN;
        CGFloat bottom_margin = GAME_DRAW_RESULT_WINNER_NUMBER_BOTTOM_MARGIN;
        CGFloat left_margin = GAME_DRAW_RESULT_WINNER_NUMBER_LEFT_MARGIN;
        CGFloat item_margin = GAME_DRAW_RESULT_WINNER_NUMBER_ITEM_MARGIN;
        CGSize itemSize = [self itemSizeOfWinnerNumber];
        CGFloat itemSizeWidth = itemSize.width;
        CGFloat itemSizeHeight = itemSize.height;
        
        // 调整左右间距
        CGFloat left_margin_column = model_original.winnerNumberArray.count > column ? column : model_original.winnerNumberArray.count;
        CGFloat left_margin_adjust = (SCREEN_WIDTH - leftIssueWidth - item_margin *(left_margin_column-1) - itemSizeWidth * left_margin_column - margin*0.5f) / 2.0f;
        if (left_margin < left_margin_adjust) {
            left_margin = left_margin_adjust;
        } else if (left_margin > left_margin_adjust) {
            left_margin = left_margin_adjust;
        }
        
        // 开奖状态
        if (model_original.isDrawed) {
            
            // 开奖号码
            UILabel *lastItemLabel = nil;
            for (int i = 0; i < model_original.winnerNumberArray.count; i ++) {
                
                // 字体设置
                UIFont *itemNameFont = model_original.winnerNumberFontArray[i];
                UIColor *itemNameColor = model_original.winnerNumberColorArray[i];
                UIColor *itemBackgroundColor = model_original.winnerNumberBackgroundColorArray[i];
                CFCGameBetDrawResultWinNumberType winNumberType = model_original.winnerNumberTypeArray[i].integerValue;
                
                // 描述信息
                NSString *itemName = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:model_original.winnerNumberArray[i]];
                NSDictionary *attributesName = @{ NSFontAttributeName:itemNameFont, NSForegroundColorAttributeName:itemNameColor};
                NSAttributedString *attributedNameString = [CFCSysUtil attributedString:@[ [NSString stringWithFormat:@"%@", itemName] ]
                                                                         attributeArray:@[ attributesName ] ];
                
                // 描述控件
                UILabel *itemLabel = ({
                    UILabel *itemLabel = [[UILabel alloc] init];
                    [itemLabel.layer setMasksToBounds:YES];
                    [itemLabel setTextAlignment:NSTextAlignmentCenter];
                    [itemLabel setAttributedText:attributedNameString];
                    [itemLabel setBackgroundColor:itemBackgroundColor];
                    [self.rightWinnerContainerView addSubview:itemLabel];
                    
                    // 类型1 -> 开奖号码类型 -> 如：开奖号码背景圆形边框
                    if (CFCGameBetDrawResultWinNumberType1 == winNumberType) {
                        [itemLabel addBorderWithColor:COLOR_GAME_DRAW_RESULT_ITEM_BORDER_COLOR_LIGHT cornerRadius:itemSizeWidth/2.0f andWidth:0.0f];
                    }
                    // 类型2 -> 开奖号码类型 -> 如：开奖号码背景方形边框
                    else if (CFCGameBetDrawResultWinNumberType2 == winNumberType) {
                        [itemLabel addBorderWithColor:COLOR_GAME_DRAW_RESULT_ITEM_BORDER_COLOR_BLACK cornerRadius:margin*0.50f andWidth:1.0f];
                    }
                    
                    [itemLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
                        make.width.equalTo(@(itemSizeWidth));
                        make.height.equalTo(@(itemSizeHeight));
                        
                        if (!lastItemLabel) {
                            make.left.equalTo(self.rightWinnerContainerView.mas_left).offset(left_margin);
                            if (model_original.winnerNumberArray.count > column) {
                                make.top.equalTo(self.rightWinnerContainerView.mas_top).offset(top_margin);
                            } else {
                                make.centerY.equalTo(self.rightWinnerContainerView.mas_centerY);
                            }
                        } else {
                            if (0 == i % column) {
                                make.top.equalTo(lastItemLabel.mas_bottom).offset(item_margin);
                                make.left.equalTo(self.rightWinnerContainerView.mas_left).offset(left_margin);
                            } else {
                                make.top.equalTo(lastItemLabel.mas_top).offset(0);
                                make.left.equalTo(lastItemLabel.mas_right).offset(item_margin);
                            }
                        }
                    }];
                    itemLabel.mas_key = [NSString stringWithFormat:@"itemLabel%d",i];
                    
                    itemLabel;
                });
                
                lastItemLabel = itemLabel;
                
            } // 开奖号码
            
            // 约束的完整性
            [self.separatorLineView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(lastItemLabel.mas_bottom).offset(bottom_margin).priority(749);
            }];
            
        } else {
            
            // 正在开奖
            UILabel *statusLabel = ({
                
                NSDictionary *attributesText = @{ NSFontAttributeName:FONT_GAME_DRAW_RESULT_ISSUE_CHINESE,
                                                  NSForegroundColorAttributeName:COLOR_GAME_DRAW_RESULT_ISSUE_CHINESE };
                NSAttributedString *attributedString = [CFCSysUtil attributedString:@[ @"开奖中" ] attributeArray:@[ attributesText ]];
                
                UILabel *itemLabel = [[UILabel alloc] init];
                [itemLabel.layer setMasksToBounds:YES];
                [itemLabel setTextAlignment:NSTextAlignmentCenter];
                [itemLabel setAttributedText:attributedString];
                [self.rightWinnerContainerView addSubview:itemLabel];
                
                [itemLabel mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.left.equalTo(self.rightWinnerContainerView.mas_left);
                    make.right.equalTo(self.rightWinnerContainerView.mas_right);
                    make.centerY.equalTo(self.rightWinnerContainerView.mas_centerY);
                }];
                
                itemLabel;
            });
            statusLabel.mas_key = [NSString stringWithFormat:@"statusLabel"];
            
            // 约束的完整性
            [self.separatorLineView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(statusLabel.mas_bottom).offset(bottom_margin).priority(749);
            }];
            
        } // 开奖状态
        
    }
    
}


#pragma mark - 开奖号码大小
- (CGSize)itemSizeOfWinnerNumber
{
    return [CFCGameUtil getDrawResultsItemSizeOfWinnerNumber];
}


#pragma mark - 开奖结果列表高度 - 未开奖
+ (CGFloat)heightForDrawResultTableViewCellWithModel:(CFCGameBetDrawResultModel *)model
{
    if (model.winnerNumberArray && model.winnerNumberArray.count > 0) {
        NSInteger column = GAME_DRAW_RESULT_WINNER_NUMBER_COLUMN;
        CGFloat top_margin = GAME_DRAW_RESULT_WINNER_NUMBER_TOP_MARGIN;
        CGFloat bottom_margin = GAME_DRAW_RESULT_WINNER_NUMBER_BOTTOM_MARGIN;
        CGFloat item_margin = GAME_DRAW_RESULT_WINNER_NUMBER_ITEM_MARGIN;
        CGSize itemSize = [CFCGameUtil getDrawResultsItemSizeOfWinnerNumber];
        CGFloat itemSizeHeight = itemSize.height;
        NSInteger rows = (0 == model.winnerNumberArray.count % column) ? (model.winnerNumberArray.count / column) : (model.winnerNumberArray.count / column + 1);
        //
        return top_margin + itemSizeHeight * rows + item_margin * (rows - 1) + bottom_margin;
    }
    
    return CFC_GAME_PLAY_SCROLL_TABLEVIEW_HEADER_DRAW_RESULTS_HEIGHT;
}


#pragma mark - 触发操作事件
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture
{
    // 强击类型转换
    CFCGameBetDrawResultModel *model_original = (CFCGameBetDrawResultModel *)self.menuModel;
    id<CFCGameBetDrawResultDefaultTableViewCellDelegate> delegate_original = (id<CFCGameBetDrawResultDefaultTableViewCellDelegate>)self.delegate;
    
    if (delegate_original && [delegate_original respondsToSelector:@selector(didSelectRowAtGameBetDrawResultModel:)]) {
        [delegate_original didSelectRowAtGameBetDrawResultModel:model_original];
    }
}


@end








