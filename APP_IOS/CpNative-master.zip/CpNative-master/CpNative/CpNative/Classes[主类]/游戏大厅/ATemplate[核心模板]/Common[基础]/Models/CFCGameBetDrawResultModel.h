//
// 游戏 - 投注区 - 开奖结果
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, CFCGameBetDrawResultItemType) {
    // 默认为空
    CFCGameBetDrawResultItemTypeDefault = 100,    // 类型00 -> 开奖结果类型 -> 默认
    // 官方玩法
    CFCGameBetDrawResultItemTypeOfficial01 = 211,  // 类型01 -> 开奖结果类型 -> 官方玩法 -> 时时彩（重庆时时彩、官网分分彩、官网三分彩、官网五分彩）
    CFCGameBetDrawResultItemTypeOfficial02 = 212,  // 类型02 -> 开奖结果类型 -> 官方玩法 -> 11选5（广东11选5、官网11选、11选5三分彩）
    CFCGameBetDrawResultItemTypeOfficial03 = 213,  // 类型03 -> 开奖结果类型 -> 官方玩法 -> PK10（幸运飞艇、北京PK10、极速PK10）
    CFCGameBetDrawResultItemTypeOfficial04 = 214,  // 类型04 -> 开奖结果类型 -> 官方玩法 -> 快三（江苏快三、官网快三分分彩）
    CFCGameBetDrawResultItemTypeOfficial05 = 215,  // 类型04 -> 开奖结果类型 -> 官方玩法 -> 极速3D（官网极速3D）
    CFCGameBetDrawResultItemTypeOfficial06 = 216,  // 类型04 -> 开奖结果类型 -> 官方玩法 -> 北京快乐8（北京快乐8）
    // 信用玩法
    CFCGameBetDrawResultItemTypeCredit01 = 311,   // 类型05 -> 开奖结果类型 -> 信用玩法 ->
};

typedef NS_ENUM(NSInteger, CFCGameBetDrawResultWinNumberType) {
    CFCGameBetDrawResultWinNumberType1 = 101, // 类型1 -> 开奖号码类型 -> 如：开奖号码背景圆形边框
    CFCGameBetDrawResultWinNumberType2 = 102, // 类型2 -> 开奖号码类型 -> 如：开奖号码背景方形边框
};

@interface CFCGameBetDrawResultModel : YHSDropDownMenuBasedModel

@property (nonatomic, copy) NSString *issue;  // 开奖期号 - 后台完整
@property (nonatomic, copy) NSString *winnum;  // 开奖号码 - 后台完整
@property (nonatomic, copy) NSString *issueNumber;  // 开奖期号 - 界面显示
@property (nonatomic, copy) NSString *winnerNumber;  // 开奖号码 - 界面显示
@property (nonatomic, assign) CFCGameBetDrawResultItemType type; // 开奖结果类型
@property (nonatomic, assign) BOOL isDrawed; // 开奖结果状态（YES已开奖, NO未开奖）

@property (nonatomic, strong) NSArray<NSString *> *winnerNumberArray; // 开奖号码列表
@property (nonatomic, strong) NSArray<UIFont *> *winnerNumberFontArray; // 开奖号码字体 - 正常
@property (nonatomic, strong) NSArray<UIColor *> *winnerNumberColorArray; // 开奖号码颜色 - 正常
@property (nonatomic, strong) NSArray<UIColor *> *winnerNumberBackgroundColorArray; // 开奖号码背景颜色
@property (nonatomic, strong) NSArray<NSNumber *> *winnerNumberTypeArray; // 开奖号码类型列表

/**
 * 开奖结果 - 动态数据 - 头部区域
 */
+ (CFCGameBetDrawResultModel *) buildingDataModleForHeaderArea:(CFCGameBetDrawResultModel *)dataModel
                                                      itemType:(CFCGameBetDrawResultItemType)itemType
                                                        itemId:(NSString *)itemId;
/**
 * 开奖结果 - 动态数据 - 动态表格
 */
+ (NSMutableArray<CFCGameBetDrawResultModel *> *) buildingDataModles:(NSMutableArray<CFCGameBetDrawResultModel *> *)dataModels
                                                            itemType:(CFCGameBetDrawResultItemType)itemType
                                                              itemId:(NSString *)itemId;

@end

NS_ASSUME_NONNULL_END
