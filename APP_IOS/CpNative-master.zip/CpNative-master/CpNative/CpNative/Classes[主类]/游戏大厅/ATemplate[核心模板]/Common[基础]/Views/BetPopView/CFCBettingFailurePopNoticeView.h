//
//  游戏 - 提示信息框 - 投注失败
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^CFCBettingFailurePopNoticeViewDismissBlock)(void);

@interface CFCBettingFailurePopNoticeView : UIView

@property (nonatomic, assign) BOOL isShow;

@property (nonatomic, copy) NSString *content;

@property (nonatomic, assign) NSInteger count;

@property (nonatomic, copy) CFCBettingFailurePopNoticeViewDismissBlock afterDismissBlock;

+ (instancetype)sharePopNoticeView;

- (void)show;

- (void)dismiss;

@end

NS_ASSUME_NONNULL_END
