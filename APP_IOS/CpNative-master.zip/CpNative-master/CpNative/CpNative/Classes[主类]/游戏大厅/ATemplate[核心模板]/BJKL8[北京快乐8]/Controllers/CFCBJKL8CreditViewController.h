//
// 游戏 - 投注区 - 信用模式 - 北京快乐8
//

#import "CFCGameBetCreditViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCBJKL8CreditViewController : CFCGameBetCreditViewController

@end

NS_ASSUME_NONNULL_END
