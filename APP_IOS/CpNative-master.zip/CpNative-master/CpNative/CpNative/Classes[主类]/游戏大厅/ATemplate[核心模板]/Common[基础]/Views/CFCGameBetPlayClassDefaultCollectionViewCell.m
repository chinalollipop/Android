//
//  游戏 - 每一个具体玩法的基类 - 默认为空
//
//  说明：此类以 UICollectionView 实现。如果不能满足你的要求，请另外实现。
//

#import "CFCGameBetPlayClassDefaultCollectionViewCell.h"
#import "CFCGameBetPlayClassModel.h"


// Cell Identifier
NSString * const CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_DEFAULT_COLLECTION_VIEW_CELL = @"CFCGameBetPlayClassDefaultCollectionViewCellIdentifier";


@interface CFCGameBetPlayClassDefaultCollectionViewCell ()

@end


@implementation CFCGameBetPlayClassDefaultCollectionViewCell


-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self) {
        [self createViewAtuoLayout];
    }
    return self;
}

#pragma mark 创建子控件
- (void) createViewAtuoLayout
{
    
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCGameBetPlayClassModel *)model
{
    // 类型安全检查
    if (![model isKindOfClass:[CFCGameBetPlayClassModel class]]) {
        return;
    }
    
    // 数据赋值
    _model = (CFCGameBetPlayClassModel *)model;
    
}

#pragma mark - 表格行高
+ (CGFloat)heightForCellAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model
{
    return GAME_PLAY_COLLECTION_ITEM_HEIGHT_ZERO;
}


@end




