//
//  游戏 - 投注页面头部区域 - 基类
//

#import <UIKit/UIKit.h>
@class CFCGameBetPlayTypeModel, CFCGameBetPlayTypeGroupModel, CFCGameBetPlayTypeClassModel;


NS_ASSUME_NONNULL_BEGIN


@protocol CFCGameBetPlayScrollViewHeaderProtocol <NSObject>
@required
- (void)createViewAtuoLayout;
- (void)createViewOfDrawResultsAtuoLayout:(BOOL)isForce;
- (void)createViewOfPlayTypeButtonAtuoLayout:(BOOL)isForce;
- (void)setCountDownTimeMinuteValue:(CGFloat)minute;
- (void)setCountDownTimeFinishDate:(NSDate *)finishDate andBeginDate:(NSDate *)beginDate;
- (void)setCurrentIssueNumberLabelValue:(NSString *)issueNumber;
@end


@protocol CFCGameBetPlayScrollViewHeaderDelegate <NSObject>
@required
// 切换玩法 - 验证玩法标识对应的页面是否存在
- (BOOL)canSelectedPlayClassViewController:(NSString *)classCode
                    selectedGameIdentifier:(NSString *)selectedGameIdentifier
                    selectedTypeIdentifier:(NSString *)selectedTypeIdentifier
                   selectedGroupIdentifier:(NSString *)selectedGroupIdentifier
                   selectedClassIdentifier:(NSString *)selectedClassIdentifier
                    selectedClassTitleName:(NSString *)selectedClassTitleName;
// 玩法标识 - 玩法标识对应的页面存在则就切换
- (void)didSelectedPlayClassViewController:(NSString *)classCode
                    selectedGameIdentifier:(NSString *)selectedGameIdentifier
                    selectedTypeIdentifier:(NSString *)selectedTypeIdentifier
                   selectedGroupIdentifier:(NSString *)selectedGroupIdentifier
                   selectedClassIdentifier:(NSString *)selectedClassIdentifier
                    selectedClassTitleName:(NSString *)selectedClassTitleName
                     selectedPlayTypeModel:(CFCGameBetPlayTypeModel *)selectedGameBetPlayTypeModel
                selectedPlayTypeGroupModel:(CFCGameBetPlayTypeGroupModel *)selectedGameBetPlayTypeGroupModel
                selectedPlayTypeClassModel:(CFCGameBetPlayTypeClassModel *)selectedGameBetPlayTypeClassModel;

// 玩法标识 - 获取已保存的具体玩法标识 selectedPlayCodeOfPlayClass
- (NSString *)selectedPlayCodeOfPlayClassFromMainGameCoreViewController:(NSString *)tabMarkCode;
// 玩法标识 - 获取已保存的玩法弹出框标识 selectedPlayTypeDictionary
- (NSMutableDictionary<NSString *, NSString *> *)selectedPlayTypeDictionaryFromMainGameCoreViewController;
// 倒计时间 - 在倒计时间结束后是否可以弹提示信息框
- (BOOL)canAlertTipInfoDialogAfterCounting;

@end


@interface CFCGameBetPlayScrollViewHeader : UIView <CFCGameBetPlayScrollViewHeaderProtocol, CFCGameBetPlayScrollToPlayScrollViewHeaderProtocol, CFCCountTimerViewDelegate>

@property (nonatomic, copy) NSString *gameId; // 游戏主键
@property (nonatomic, copy) NSString *gameName; // 游戏名称
@property (nonatomic, copy) NSString *gameIdentifier; // 游戏标识
@property (nonatomic, assign) CFCGameCorePlayModeClass playModeClass; // 玩法模式
@property (nonatomic, assign) CFCGameBetDrawResultItemType drawResultItemType; // 开奖类型（CFCGameBetDrawResultItemType）
@property (nonatomic, strong) CFCGameBetBaseViewController<CFCGameBetPlayScrollViewHeaderDelegate> *parentViewController; // 父控制器

@property (nonatomic, assign) CGFloat heightOfBottomAreaMainView; // 底部工具条区域高度
@property (nonatomic, weak) id<CFCGameBetPlayScrollViewHeaderDelegate> delegate; // 投注页面代理（CFCGameBetPlayScrollViewController）

@property (nonatomic, strong) NSDictionary *allResponseDataOrCacheData; // 主页面接口的所有数据
@property (nonatomic, strong) NSMutableArray<CFCGameBetPlayTypeModel *> *allGamePlayTypeModels; // 游戏玩法 - 游戏玩法数据
@property (nonatomic, strong) NSMutableArray<CFCGameBetDrawResultModel *> *drawResultDetailModels; // 开奖结果 - 下拉详情列表
@property (nonatomic, strong, nullable) CFCGameBetDrawResultDefaultTopAreaView *drawResultTopAreaView; // 开奖结果 - 头部动画视图

/**
 * 游戏标题、游戏玩法、游戏分组、玩法标识、玩法名称
 */
@property (nonatomic, copy) NSString *selectedGameIdentifier; // 游戏标题
@property (nonatomic, copy) NSString *selectedTypeIdentifier; // 五星、四星
@property (nonatomic, copy) NSString *selectedGroupIdentifier; // 直选、组选
@property (nonatomic, copy) NSString *selectedClassIdentifier; // 直选复式、组选120
@property (nonatomic, copy) NSString *selectedClassTitleName; // 直选复式、组选120

/**
 * 头部区域 - 公共控件
 */
@property (nonatomic, strong) UIView *topDrawResultContainerView; // 头部区域 - 开奖结果容器
@property (nonatomic, strong) UIView *topCountDownContainerView; // 头部区域 - 倒计时区容器
@property (nonatomic, strong) UILabel *currentIssueNumberLabel; // 头部区域 - 期号控件
@property (nonatomic, strong, nullable) CFCCountTimerView *countDownTimeView; // 头部区域 - 倒计时控件


#pragma mark -
#pragma mark 构造函数
- (instancetype)initWithFrame:(CGRect)frame
                       gameId:(NSString *)gameId
                     gameName:(NSString *)gameName
               gameIdentifier:(NSString *)gameIdentifier
                     playMode:(CFCGameCorePlayModeClass)playModeClass
           drawResultItemType:(CFCGameBetDrawResultItemType)drawResultItemType
         parentViewController:(CFCGameBetBaseViewController *)parentViewController;
#pragma make 创建子类控件
- (void) createViewAtuoLayout;
#pragma mark 创建开奖结果
- (void)createViewOfDrawResultsAtuoLayout:(BOOL)isForce;
#pragma mark 创建玩法选择
- (void)createViewOfPlayTypeButtonAtuoLayout:(BOOL)isForce;


#pragma mark -
#pragma mark 设置倒计时控件值（分钟）
- (void)setCountDownTimeMinuteValue:(CGFloat)minute;
#pragma mark 设置倒计时控件值（结束日期-开始日期）
- (void)setCountDownTimeFinishDate:(NSDate *)finishDate andBeginDate:(NSDate *)beginDate;
#pragma mark 设置当前期号的值
- (void)setCurrentIssueNumberLabelValue:(NSString *)issueNumber;


#pragma mark -
#pragma mark 刷新数据 - 请求数据
- (void)loadNetworkDataOfRefresh;
#pragma mark 刷新数据 - 请求数据 - 加载请求网络数据
- (void)loadNetworkDataSourceOfRefreshThen:(void (^)(BOOL success, NSUInteger count))then;
#pragma mark 刷新数据 - 请求数据 - 加载请求玩法标签网络或缓存数据
- (NSMutableArray *)loadNetworkDataOrCacheDataOfRefresh:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData;
#pragma mark 刷新数据 - 请求数据 - 加载完数据前操作，每次刷新加载数据前都会执行
- (void)viewDidLoadBeforeRequestRefreshNetworkDataOrCacheData;
#pragma mark 刷新数据 - 请求数据 - 加载完数据后操作，每次刷新加载数据后都会执行
- (void)viewDidLoadAfterRequestRefreshNetworkDataOrCacheData;


#pragma mark -
#pragma mark 玩法选择 - 加载请求网络数据
- (void)loadNetworkDataSourceOfPlayTypeSelectThen:(void (^)(BOOL success, NSUInteger count))then;
#pragma mark 玩法选择 - 加载请求玩法标签网络或缓存数据
- (NSMutableArray<CFCGameBetPlayTypeModel *> *)loadNetworkDataOrCacheDataOfPlayTypeSelect:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData;


#pragma mark -
#pragma mark 开奖结果 - 请求数据 - 加载请求网络数据
- (void)loadNetworkDataSourceOfDrawResultThen:(void (^)(BOOL success, NSUInteger count))then;
#pragma mark 开奖结果 - 请求数据 - 加载请求玩法标签网络或缓存数据
- (NSMutableArray<CFCGameBetDrawResultModel *> *)loadNetworkDataOrCacheDataOfDrawResult:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData;
#pragma mark 开奖结果 - 处理数据 - 组装开奖结果详情列表数据模型
- (NSMutableArray<CFCGameBetDrawResultModel *> *)doWithNetworkDataOrCacheDataOfDrawResult:(NSArray<NSDictionary *> *)dataOfDrawResult;


#pragma mark -
#pragma mark 开奖结果 - 头部区域 - 头部开奖详情视图
- (CFCGameBetDrawResultDefaultTopAreaView *)viewForHeaderDrawResultsAreaFrame:(CGRect)frame;
#pragma mark 开奖结果 - 头部区域 - 头部开奖详情数据
- (CFCGameBetDrawResultModel *) buildingDataModleForHeaderArea:(CFCGameBetDrawResultModel *)dataModel
                                                      itemType:(CFCGameBetDrawResultItemType)drawResultItemType
                                                        itemId:(NSString *)itemId;


#pragma mark -
#pragma mark 开奖结果 - 详情列表 - 根据开奖类型标识处理网络或缓存数据
- (NSArray<CFCGameBetDrawResultModel *> *)buildingDrawResultModelsForDropDownMenu:(NSMutableArray<CFCGameBetDrawResultModel *> *)dataModels
                                                                         itemType:(CFCGameBetDrawResultItemType)drawResultItemType
                                                                           itemId:(NSString *)itemId;
#pragma mark 开奖结果 - 详情列表 - 根据开奖类型标识获取对应的表格名称
- (NSString *)buildingDrawResultTableViewCellClassNameForDropDownMenuItemType:(CFCGameBetDrawResultItemType)drawResultItemType
                                                                       itemId:(NSString *)itemId;


@end

NS_ASSUME_NONNULL_END

