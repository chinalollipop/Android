//
// 游戏 - 投注区 - 官方模式 - 11选5 - 二码 - 直选 - 前二直选单式
//

#import "CFC11X5PlayClassMa2ZXFront2SingleModel.h"

@implementation CFC11X5PlayClassMa2ZXFront2SingleModel

+ (NSMutableArray *) buildingDataModlesForSection1
{
    NSMutableArray<CFC11X5PlayClassMa2ZXFront2SingleModel *> *models = [NSMutableArray array];
    {
        NSArray<NSString *> *names = @[ STR_APP_TEXT_EMPTY ];
        NSArray<NSString *> *classNumbers = @[ STR_APP_TEXT_EMPTY ];
        for (int index = 0; index < names.count; index ++) {
            CFC11X5PlayClassMa2ZXFront2SingleModel *model = [[CFC11X5PlayClassMa2ZXFront2SingleModel alloc] init];
            // 名称
            [model setName:names[index]];
            [model setNameNormalFont:NAME_FONT_GAME_PLAY_MODEL_NUMBER_NORMAL];
            [model setNameSelectFont:NAME_FONT_GAME_PLAY_MODEL_NUMBER_SELECT];
            [model setNameNormalColor:NAME_COLOR_GAME_PLAY_MODEL_NORMAL];
            [model setNameSelectColor:NAME_COLOR_GAME_PLAY_MODEL_SELECT];
            [model setNameBackgroundColor:NAME_COLOR_GAME_PLAY_BACKGROUND_DEFAULT];
            // 赔率
            [model setOdds:ODDS_STRI_GAME_PLAY_MODEL_DEFAULT];
            [model setOddsNormalFont:ODDS_FONT_GAME_PLAY_MODEL_NORMAL];
            [model setOddsSelectFont:ODDS_FONT_GAME_PLAY_MODEL_SELECT];
            [model setOddsNormalColor:ODDS_COLOR_GAME_PLAY_MODEL_NORMAL];
            [model setOddsSelectColor:ODDS_COLOR_GAME_PLAY_MODEL_SELECT];
            [model setOddsBackgroundColor:ODDS_COLOR_GAME_PLAY_BACKGROUND_DEFAULT];
            // 号码
            [model setClassNumber:classNumbers[index]];
            [model setClassRemark:REMARK_STRI_GAME_PLAY_MODEL_EMPTY];
            // 其它
            [model setType:CFCGameBetPlayClassItemType01];
            [model setIsSelected:GAME_PLAY_MODEL_SELECTED_DEFAULT];
            //
            [models addObject:model];
        }
    }
    return models;
}

@end


@implementation CFC11X5PlayClassMa2ZXFront2SingleSectionModel

+ (NSMutableArray *) buildingDataModles
{
    NSMutableArray<CFC11X5PlayClassMa2ZXFront2SingleSectionModel *> *models = [NSMutableArray array];
    {
        // 第一个分组
        CFC11X5PlayClassMa2ZXFront2SingleSectionModel *model1 = [[CFC11X5PlayClassMa2ZXFront2SingleSectionModel alloc] init];
        [model1 setTitle:@"单式"];
        [model1 setType:CFCGameBetPlayClassSectionTypeOfficial7];
        [model1 setColumnsCount:GAME_PLAY_MODEL_SECTION_COLUMN_N005];
        [model1 setIsShowHeader:GAME_PLAY_MODEL_SECTION_HEADER_SHOW_NO];
        [model1 setIsShowFooter:GAME_PLAY_MODEL_SECTION_FOOTER_SHOW_NO];
        [model1 setList:[CFC11X5PlayClassMa2ZXFront2SingleModel buildingDataModlesForSection1]];
        [models addObject:model1];
    }
    return models;
}

@end

