//
// 游戏 - 投注区 - 官方模式 - 11选5 - 任选单式 - 任选单式 - 任选一中一单式
//

#import "CFC11X5PlayClassBaseOfficialViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFC11X5PlayClassRXDSRenXuan01ViewController : CFC11X5PlayClassBaseOfficialViewController

@end

NS_ASSUME_NONNULL_END
