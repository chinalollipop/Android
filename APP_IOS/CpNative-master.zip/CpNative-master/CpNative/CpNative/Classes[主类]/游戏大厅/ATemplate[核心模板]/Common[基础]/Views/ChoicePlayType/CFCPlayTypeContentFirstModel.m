//
//  游戏 - 投注页面头部区域 - 玩法选择 - 一级分类
//

#import "CFCPlayTypeContentFirstModel.h"

@implementation CFCPlayTypeContentFirstModel

@end
