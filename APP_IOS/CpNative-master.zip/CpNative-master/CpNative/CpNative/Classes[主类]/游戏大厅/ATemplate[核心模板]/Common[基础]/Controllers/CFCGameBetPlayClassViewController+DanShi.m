
#import "CFCGameBetPlayClassViewController+DanShi.h"

@implementation CFCGameBetPlayClassViewController (DanShi)


#pragma mark -
#pragma mark 投注总数 - 计算投注总数 - 直选单式
- (NSInteger)numberOfBettingRecordsForSingleN01:(NSInteger)count
{
    // 是否需要过滤
    __block BOOL isFliter = NO;
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        if ([self isSingleSectionModel:sectionObj]) {
            [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
                if ([GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_FILTER isEqualToString:classObj.name]) {
                    isFliter = YES;
                }
            }];
        }
    }];
    
    // 返回投注内容
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN01:count filter:isFliter];
    
    // 返回投注注数
    return contentOfBettingRecords.count;
}


#pragma mark 投注总数 - 计算投注总数 - 组选单式 - 组三单式
- (NSInteger)numberOfBettingRecordsForSingleN02:(NSInteger)count
{
    // 是否需要过滤
    __block BOOL isFliter = NO;
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        if ([self isSingleSectionModel:sectionObj]) {
            [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
                if ([GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_FILTER isEqualToString:classObj.name]) {
                    isFliter = YES;
                }
            }];
        }
    }];
    
    // 返回投注内容
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN02:count filter:isFliter];
    
    // 返回投注注数
    return contentOfBettingRecords.count;
}


#pragma mark 投注总数 - 计算投注总数 - 组选单式 - 组六单式
- (NSInteger)numberOfBettingRecordsForSingleN03:(NSInteger)count
{
    // 是否需要过滤
    __block BOOL isFliter = NO;
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        if ([self isSingleSectionModel:sectionObj]) {
            [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
                if ([GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_FILTER isEqualToString:classObj.name]) {
                    isFliter = YES;
                }
            }];
        }
    }];
    
    // 返回投注内容
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN03:count filter:isFliter];
    
    // 返回投注注数
    return contentOfBettingRecords.count;
}


#pragma mark 投注总数 - 计算投注总数 - 组选单式 - 混合单式
- (NSInteger)numberOfBettingRecordsForSingleN04:(NSInteger)count
{
    // 是否需要过滤
    __block BOOL isFliter = NO;
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        if ([self isSingleSectionModel:sectionObj]) {
            [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
                if ([GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_FILTER isEqualToString:classObj.name]) {
                    isFliter = YES;
                }
            }];
        }
    }];
    
    // 返回投注内容
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN04:count filter:isFliter];
    
    // 返回投注注数
    return contentOfBettingRecords.count;
}


#pragma mark 投注总数 - 计算投注总数 - 组选单式 - 二星单式
- (NSInteger)numberOfBettingRecordsForSingleN05:(NSInteger)count
{
    // 是否需要过滤
    __block BOOL isFliter = NO;
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        if ([self isSingleSectionModel:sectionObj]) {
            [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
                if ([GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_FILTER isEqualToString:classObj.name]) {
                    isFliter = YES;
                }
            }];
        }
    }];
    
    // 返回投注内容
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN05:count filter:isFliter];
    
    // 返回投注注数
    return contentOfBettingRecords.count;
}


#pragma mark 投注总数 - 计算投注总数 - 直选单式 - PK拾单式
- (NSInteger)numberOfBettingRecordsForSingleN06:(NSInteger)count
{
    // 是否需要过滤
    __block BOOL isFliter = NO;
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        if ([self isSingleSectionModel:sectionObj]) {
            [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
                if ([GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_FILTER isEqualToString:classObj.name]) {
                    isFliter = YES;
                }
            }];
        }
    }];
    
    // 返回投注内容
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN06:count filter:isFliter];
    
    // 返回投注注数
    return contentOfBettingRecords.count;
}


#pragma mark 投注总数 - 计算投注总数 - 直选单式 - 11选5单式
- (NSInteger)numberOfBettingRecordsForSingleN07:(NSInteger)count
{
    // 是否需要过滤
    __block BOOL isFliter = NO;
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        if ([self isSingleSectionModel:sectionObj]) {
            [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
                if ([GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_FILTER isEqualToString:classObj.name]) {
                    isFliter = YES;
                }
            }];
        }
    }];
    
    // 返回投注内容
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN07:count filter:isFliter];
    
    // 返回投注注数
    return contentOfBettingRecords.count;
}


#pragma mark 投注总数 - 计算投注总数 - 组选单式 - 11选5单式
- (NSInteger)numberOfBettingRecordsForSingleN08:(NSInteger)count
{
    // 是否需要过滤
    __block BOOL isFliter = NO;
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        if ([self isSingleSectionModel:sectionObj]) {
            [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
                if ([GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_FILTER isEqualToString:classObj.name]) {
                    isFliter = YES;
                }
            }];
        }
    }];
    
    // 返回投注内容
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN08:count filter:isFliter];
    
    // 返回投注注数
    return contentOfBettingRecords.count;
}


#pragma mark -
#pragma mark 投注内容 - 组装单式内容 - 直选单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN01:(NSInteger)count
{
    // 是否更新输入
    __block BOOL isFliter = NO;
    __block BOOL isSelected = NO;
    __block CFCGameBetPlayClassModel *playClassModel = nil;
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        if ([self isSingleSectionModel:sectionObj]) {
            [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
                if ([GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_FILTER isEqualToString:classObj.name]) {
                    isFliter = YES;
                }
                if (classObj.isSelected) {
                    isSelected = YES;
                    playClassModel = classObj;
                    *classStop = YES;
                    *sectionStop = YES;
                }
            }];
        }
    }];
    
    // 返回投注内容
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN01:count filter:isFliter];
    
    // 更新输入文本
    if (isSelected) {
        NSString *classRemark = [contentOfBettingRecords componentsJoinedByString:STR_BETTING_DANSHI_COMPONENTS_JOINED];
        [playClassModel setClassRemark:classRemark];
    }
    
    // 返回投注内容
    return contentOfBettingRecords;
}

#pragma mark 投注内容 - 组装单式内容 - 组选单式 - 组三单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN02:(NSInteger)count
{
    // 是否更新输入
    __block BOOL isFliter = NO;
    __block BOOL isSelected = NO;
    __block CFCGameBetPlayClassModel *playClassModel = nil;
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        if ([self isSingleSectionModel:sectionObj]) {
            [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
                if ([GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_FILTER isEqualToString:classObj.name]) {
                    isFliter = YES;
                }
                if (classObj.isSelected) {
                    isSelected = YES;
                    playClassModel = classObj;
                    *classStop = YES;
                    *sectionStop = YES;
                }
            }];
        }
    }];
    
    // 返回投注内容
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN02:count filter:isFliter];
    
    // 更新输入文本
    if (isSelected) {
        NSString *classRemark = [contentOfBettingRecords componentsJoinedByString:STR_BETTING_DANSHI_COMPONENTS_JOINED];
        [playClassModel setClassRemark:classRemark];
    }
    
    // 返回投注内容
    return contentOfBettingRecords;
}


#pragma mark 投注内容 - 组装单式内容 - 组选单式 - 组六单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN03:(NSInteger)count
{
    // 是否更新输入
    __block BOOL isFliter = NO;
    __block BOOL isSelected = NO;
    __block CFCGameBetPlayClassModel *playClassModel = nil;
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        if ([self isSingleSectionModel:sectionObj]) {
            [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
                if ([GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_FILTER isEqualToString:classObj.name]) {
                    isFliter = YES;
                }
                if (classObj.isSelected) {
                    isSelected = YES;
                    playClassModel = classObj;
                    *classStop = YES;
                    *sectionStop = YES;
                }
            }];
        }
    }];
    
    // 返回投注内容
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN03:count filter:isFliter];
    
    // 更新输入文本
    if (isSelected) {
        NSString *classRemark = [contentOfBettingRecords componentsJoinedByString:STR_BETTING_DANSHI_COMPONENTS_JOINED];
        [playClassModel setClassRemark:classRemark];
    }
    
    // 返回投注内容
    return contentOfBettingRecords;
}


#pragma mark 投注内容 - 组装单式内容 - 组选单式 - 混合单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN04:(NSInteger)count
{
    // 是否更新输入
    __block BOOL isFliter = NO;
    __block BOOL isSelected = NO;
    __block CFCGameBetPlayClassModel *playClassModel = nil;
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        if ([self isSingleSectionModel:sectionObj]) {
            [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
                if ([GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_FILTER isEqualToString:classObj.name]) {
                    isFliter = YES;
                }
                if (classObj.isSelected) {
                    isSelected = YES;
                    playClassModel = classObj;
                    *classStop = YES;
                    *sectionStop = YES;
                }
            }];
        }
    }];
    
    // 返回投注内容
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN04:count filter:isFliter];
    
    // 更新输入文本
    if (isSelected) {
        NSString *classRemark = [contentOfBettingRecords componentsJoinedByString:STR_BETTING_DANSHI_COMPONENTS_JOINED];
        [playClassModel setClassRemark:classRemark];
    }
    
    // 返回投注内容
    return contentOfBettingRecords;
}


#pragma mark 投注内容 - 组装单式内容 - 组选单式 - 二星单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN05:(NSInteger)count
{
    // 是否更新输入
    __block BOOL isFliter = NO;
    __block BOOL isSelected = NO;
    __block CFCGameBetPlayClassModel *playClassModel = nil;
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        if ([self isSingleSectionModel:sectionObj]) {
            [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
                if ([GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_FILTER isEqualToString:classObj.name]) {
                    isFliter = YES;
                }
                if (classObj.isSelected) {
                    isSelected = YES;
                    playClassModel = classObj;
                    *classStop = YES;
                    *sectionStop = YES;
                }
            }];
        }
    }];
    
    // 返回投注内容
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN05:count filter:isFliter];
    
    // 更新输入文本
    if (isSelected) {
        NSString *classRemark = [contentOfBettingRecords componentsJoinedByString:STR_BETTING_DANSHI_COMPONENTS_JOINED];
        [playClassModel setClassRemark:classRemark];
    }
    
    // 返回投注内容
    return contentOfBettingRecords;
}


#pragma mark 投注内容 - 组装单式内容 - 直选单式 - PK拾单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN06:(NSInteger)count
{
    // 是否更新输入
    __block BOOL isFliter = NO;
    __block BOOL isSelected = NO;
    __block CFCGameBetPlayClassModel *playClassModel = nil;
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        if ([self isSingleSectionModel:sectionObj]) {
            [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
                if ([GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_FILTER isEqualToString:classObj.name]) {
                    isFliter = YES;
                }
                if (classObj.isSelected) {
                    isSelected = YES;
                    playClassModel = classObj;
                    *classStop = YES;
                    *sectionStop = YES;
                }
            }];
        }
    }];
    
    // 返回投注内容
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN06:count filter:isFliter];
    
    // 更新输入文本
    if (isSelected) {
        NSString *classRemark = [contentOfBettingRecords componentsJoinedByString:STR_BETTING_DANSHI_COMPONENTS_JOINED];
        [playClassModel setClassRemark:classRemark];
    }
    
    // 返回投注内容
    return contentOfBettingRecords;
}


#pragma mark 投注内容 - 组装单式内容 - 直选单式 - 11选5单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN07:(NSInteger)count
{
    // 是否更新输入
    __block BOOL isFliter = NO;
    __block BOOL isSelected = NO;
    __block CFCGameBetPlayClassModel *playClassModel = nil;
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        if ([self isSingleSectionModel:sectionObj]) {
            [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
                if ([GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_FILTER isEqualToString:classObj.name]) {
                    isFliter = YES;
                }
                if (classObj.isSelected) {
                    isSelected = YES;
                    playClassModel = classObj;
                    *classStop = YES;
                    *sectionStop = YES;
                }
            }];
        }
    }];
    
    // 返回投注内容
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN07:count filter:isFliter];
    
    // 更新输入文本
    if (isSelected) {
        NSString *classRemark = [contentOfBettingRecords componentsJoinedByString:STR_BETTING_DANSHI_COMPONENTS_JOINED];
        [playClassModel setClassRemark:classRemark];
    }
    
    // 返回投注内容
    return contentOfBettingRecords;
}


#pragma mark 投注内容 - 组装单式内容 - 组选单式 - 11选5单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN08:(NSInteger)count
{
    // 是否更新输入
    __block BOOL isFliter = NO;
    __block BOOL isSelected = NO;
    __block CFCGameBetPlayClassModel *playClassModel = nil;
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        if ([self isSingleSectionModel:sectionObj]) {
            [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
                if ([GAME_PLAY_MODEL_BUTTON_TITLE_SINGLE_FILTER isEqualToString:classObj.name]) {
                    isFliter = YES;
                }
                if (classObj.isSelected) {
                    isSelected = YES;
                    playClassModel = classObj;
                    *classStop = YES;
                    *sectionStop = YES;
                }
            }];
        }
    }];
    
    // 返回投注内容
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN08:count filter:isFliter];
    
    // 更新输入文本
    if (isSelected) {
        NSString *classRemark = [contentOfBettingRecords componentsJoinedByString:STR_BETTING_DANSHI_COMPONENTS_JOINED];
        [playClassModel setClassRemark:classRemark];
    }
    
    // 返回投注内容
    return contentOfBettingRecords;
}


#pragma mark -
#pragma mark 帮助工具 - 投注内容 - 单式内容 - 直选单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN01:(NSInteger)count filter:(BOOL)isFilter
{
    // 分割字符长度
    if (count <= 0) {
        return [NSArray<NSString *> array];
    }
    
    // 获取投注内容
    __block NSMutableArray<NSString *> *bettingContents = [NSMutableArray<NSString *> array];
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        if ([self isSingleSectionModel:sectionObj]) {
            [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
                [bettingContents addObject:classObj.classRemark];
            }];
        }
    }];
    
    // 用户输入内容（删除特殊符号）
    NSString *bettingContentString = [bettingContents componentsJoinedByString:@""];
    NSCharacterSet *characterSet = [NSCharacterSet characterSetWithCharactersInString:STR_BETTING_DANSHI_SPLIT_CHARACHTERSET];
    NSArray<NSString *> *bettingContentSplit = [bettingContentString componentsSeparatedByCharactersInSet:characterSet];
    NSString *bettingContentWithNoCharachterString = [bettingContentSplit componentsJoinedByString:@""];
    
    // 投注号码列表
    NSMutableArray<NSString *> *contentOfBettingRecords = [NSMutableArray<NSString *> array];
    if (isFilter) {
        // 过滤重复号码
        if (count <= bettingContentWithNoCharachterString.length) {
            NSString *bettingContentSubString = bettingContentWithNoCharachterString;
            while (count <= bettingContentSubString.length) {
                NSString *substring = [bettingContentSubString substringToIndex:count];
                bettingContentSubString = [bettingContentSubString substringFromIndex:count];
                if (![contentOfBettingRecords containsObject:substring]) {
                    [contentOfBettingRecords addObject:substring];
                }
            }
        }
    } else {
        // 包含重复号码
        if (count <= bettingContentWithNoCharachterString.length) {
            NSString *bettingContentSubString = bettingContentWithNoCharachterString;
            while (count <= bettingContentSubString.length) {
                NSString *substring = [bettingContentSubString substringToIndex:count];
                bettingContentSubString = [bettingContentSubString substringFromIndex:count];
                [contentOfBettingRecords addObject:substring];
            }
        }
    }
    
    // 单式投注列表
    return [NSArray<NSString *> arrayWithArray:contentOfBettingRecords];
}


#pragma mark 帮助工具 - 投注内容 - 单式内容 - 组选单式 - 组三单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN02:(NSInteger)count filter:(BOOL)isFilter
{
    // 投注号码列表
    NSMutableArray<NSString *> *contentOfBettingRecords = [NSMutableArray<NSString *> array];
    
    // 用户输入内容
    NSArray<NSString *> *contents = [self contentOfBettingRecordsForSingleN01:count filter:isFilter];
    
    // 过滤不合法号（组三形态为任一个数加一个对子）
    NSMutableArray<NSString *> *contentOfSortedFliter = [NSMutableArray<NSString *> array];
    for (NSString *content in contents) {
        // 拆为单个字符
        NSRange range = NSMakeRange(0, 0);
        NSMutableArray<NSString *> *characters = [NSMutableArray<NSString *> array];
        for (NSInteger idx = 0; idx < content.length; idx += range.length) {
            range = [content rangeOfComposedCharacterSequenceAtIndex:idx];
            NSString *character = [content substringWithRange:range];
            [characters addObject:character];
        }
        // 过滤不合法号
        if (characters.count < 3) {
            continue;
        }
        NSString *num1 = [characters stringAtIndex:0];
        NSString *num2 = [characters stringAtIndex:1];
        NSString *num3 = [characters stringAtIndex:2];
        // 过滤掉豹子号
        if ([num1 isEqualToString:num2] && [num1 isEqualToString:num3] && [num2 isEqualToString:num3]) {
            continue;
        }
        // 任意两个相等
        if (([num1 isEqualToString:num2] || [num1 isEqualToString:num3] || [num2 isEqualToString:num3])) {
            // 过滤重复号码
            if (isFilter) {
                NSArray<NSString *> *sortedCharacters = [CFCStringMathsUtil sortedArray:characters];
                NSString *sortedContent = [sortedCharacters componentsJoinedByString:@""];
                if (![contentOfSortedFliter containsObject:sortedContent]) {
                    [contentOfBettingRecords addObject:content];
                    [contentOfSortedFliter addObject:sortedContent];
                }
            } else {
                [contentOfBettingRecords addObject:content];
            }
        }
    }
    
    // 单式投注列表
    return [NSArray<NSString *> arrayWithArray:contentOfBettingRecords];
}


#pragma mark 帮助工具 - 投注内容 - 单式内容 - 组选单式 - 组六单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN03:(NSInteger)count filter:(BOOL)isFilter
{
    // 投注号码列表
    NSMutableArray<NSString *> *contentOfBettingRecords = [NSMutableArray<NSString *> array];
    
    // 用户输入内容
    NSArray<NSString *> *contents = [self contentOfBettingRecordsForSingleN01:count filter:isFilter];
    
    // 过滤不合法号（组六形态为任意三个不相同数字）
    NSMutableArray<NSString *> *contentOfSortedFliter = [NSMutableArray<NSString *> array];
    for (NSString *content in contents) {
        // 拆为单个字符
        NSRange range = NSMakeRange(0, 0);
        NSMutableArray<NSString *> *characters = [NSMutableArray<NSString *> array];
        for (NSInteger idx = 0; idx < content.length; idx += range.length) {
            range = [content rangeOfComposedCharacterSequenceAtIndex:idx];
            NSString *character = [content substringWithRange:range];
            [characters addObject:character];
        }
        // 过滤不合法号
        if (characters.count < 3) {
            continue;
        }
        NSString *num1 = [characters stringAtIndex:0];
        NSString *num2 = [characters stringAtIndex:1];
        NSString *num3 = [characters stringAtIndex:2];
        // 过滤掉豹子号
        if ([num1 isEqualToString:num2] && [num1 isEqualToString:num3] && [num2 isEqualToString:num3]) {
            continue;
        }
        // 任意两个相等
        if (([num1 isEqualToString:num2] || [num1 isEqualToString:num3] || [num2 isEqualToString:num3])) {
            continue;
        }
        // 过滤重复号码
        if (isFilter) {
            NSArray<NSString *> *sortedCharacters = [CFCStringMathsUtil sortedArray:characters];
            NSString *sortedContent = [sortedCharacters componentsJoinedByString:@""];
            if (![contentOfSortedFliter containsObject:sortedContent]) {
                [contentOfBettingRecords addObject:content];
                [contentOfSortedFliter addObject:sortedContent];
            }
        } else {
            [contentOfBettingRecords addObject:content];
        }
    }
    
    // 单式投注列表
    return [NSArray<NSString *> arrayWithArray:contentOfBettingRecords];
}


#pragma mark 帮助工具 - 投注内容 - 单式内容 - 组选单式 - 混合单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN04:(NSInteger)count filter:(BOOL)isFilter
{
    // 投注号码列表
    NSMutableArray<NSString *> *contentOfBettingRecords = [NSMutableArray<NSString *> array];
    
    // 用户输入内容
    NSArray<NSString *> *contents = [self contentOfBettingRecordsForSingleN01:count filter:isFilter];
    
    // 过滤不合法号（组六形态为任意三个不相同数字）
    NSMutableArray<NSString *> *contentOfSortedFliter = [NSMutableArray<NSString *> array];
    for (NSString *content in contents) {
        // 拆为单个字符
        NSRange range = NSMakeRange(0, 0);
        NSMutableArray<NSString *> *characters = [NSMutableArray<NSString *> array];
        for (NSInteger idx = 0; idx < content.length; idx += range.length) {
            range = [content rangeOfComposedCharacterSequenceAtIndex:idx];
            NSString *character = [content substringWithRange:range];
            [characters addObject:character];
        }
        // 过滤不合法号
        if (characters.count < 3) {
            continue;
        }
        NSString *num1 = [characters stringAtIndex:0];
        NSString *num2 = [characters stringAtIndex:1];
        NSString *num3 = [characters stringAtIndex:2];
        // 过滤掉豹子号
        if ([num1 isEqualToString:num2] && [num1 isEqualToString:num3] && [num2 isEqualToString:num3]) {
            continue;
        }
        // 过滤重复号码
        if (isFilter) {
            NSArray<NSString *> *sortedCharacters = [CFCStringMathsUtil sortedArray:characters];
            NSString *sortedContent = [sortedCharacters componentsJoinedByString:@""];
            if (![contentOfSortedFliter containsObject:sortedContent]) {
                [contentOfBettingRecords addObject:content];
                [contentOfSortedFliter addObject:sortedContent];
            }
        } else {
            [contentOfBettingRecords addObject:content];
        }
    }
    
    // 单式投注列表
    return [NSArray<NSString *> arrayWithArray:contentOfBettingRecords];
}


#pragma mark 帮助工具 - 投注内容 - 单式内容 - 组选单式 - 二星单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN05:(NSInteger)count filter:(BOOL)isFilter
{
    // 投注号码列表
    NSMutableArray<NSString *> *contentOfBettingRecords = [NSMutableArray<NSString *> array];
    
    // 用户输入内容
    NSArray<NSString *> *contents = [self contentOfBettingRecordsForSingleN01:count filter:isFilter];
    
    // 过滤不合法号
    NSMutableArray<NSString *> *contentOfSortedFliter = [NSMutableArray<NSString *> array];
    for (NSString *content in contents) {
        // 拆为单个字符
        NSRange range = NSMakeRange(0, 0);
        NSMutableArray<NSString *> *characters = [NSMutableArray<NSString *> array];
        for (NSInteger idx = 0; idx < content.length; idx += range.length) {
            range = [content rangeOfComposedCharacterSequenceAtIndex:idx];
            NSString *character = [content substringWithRange:range];
            [characters addObject:character];
        }
        // 过滤不合法号
        if (characters.count < 2) {
            continue;
        }
        NSString *num1 = [characters stringAtIndex:0];
        NSString *num2 = [characters stringAtIndex:1];
        // 过滤掉豹子号
        if ([num1 isEqualToString:num2] && [num1 isEqualToString:num2]) {
            continue;
        }
        // 过滤重复号码
        if (isFilter) {
            NSArray<NSString *> *sortedCharacters = [CFCStringMathsUtil sortedArray:characters];
            NSString *sortedContent = [sortedCharacters componentsJoinedByString:@""];
            if (![contentOfSortedFliter containsObject:sortedContent]) {
                [contentOfBettingRecords addObject:content];
                [contentOfSortedFliter addObject:sortedContent];
            }
        } else {
            [contentOfBettingRecords addObject:content];
        }
    }
    
    // 单式投注列表
    return [NSArray<NSString *> arrayWithArray:contentOfBettingRecords];
}


#pragma mark 帮助工具 - 投注内容 - 单式内容 - 直选单式 - PK拾单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN06:(NSInteger)count filter:(BOOL)isFilter
{
    // 分割字符长度
    if (count <= 0) {
        return [NSArray<NSString *> array];
    }
    
    // 获取投注内容
    __block NSMutableArray<NSString *> *bettingContents = [NSMutableArray<NSString *> array];
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        if ([self isSingleSectionModel:sectionObj]) {
            [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
                [bettingContents addObject:classObj.classRemark];
            }];
        }
    }];
    
    // 用户输入内容（删除特殊符号）
    NSString *bettingContentString = [bettingContents componentsJoinedByString:@""];
    NSCharacterSet *characterSet = [NSCharacterSet characterSetWithCharactersInString:STR_BETTING_DANSHI_SPLIT_CHARACHTERSET];
    NSArray<NSString *> *bettingContentSplit = [bettingContentString componentsSeparatedByCharactersInSet:characterSet];
    
    // 过滤错误数字（01~10）
    __block NSString *number_min = @"1";
    __block NSString *number_max = @"10";
    __block NSMutableArray<NSString *> *numbers = [NSMutableArray<NSString *> array];
    [bettingContentSplit enumerateObjectsUsingBlock:^(NSString * _Nonnull number, NSUInteger idx, BOOL * _Nonnull stop) {
        if (number_min.integerValue <= number.integerValue  && number.integerValue <= number_max.integerValue) {
            [numbers addObject:number];
        }
    }];
    
    // 投注号码列表
    __block NSMutableArray<NSString *> *contentOfBettingRecords = [NSMutableArray<NSString *> array];
    if (isFilter) {
        // 过滤重复号码
        for (NSInteger idx = 0; (idx + count - 1)  < numbers.count; idx += count) {
            // 每一注的元素
            NSMutableArray<NSString *> *nums = [NSMutableArray<NSString *> array];
            for (NSInteger n = 0; (n<count)&&(idx+n<numbers.count); n ++) {
                NSString *num = [numbers stringAtIndex:idx+n];
                [nums addObject:num];
            }
            // 过滤相等号码
            if ([CFCStringMathsUtil hasEqualValueArray:nums]) {
                continue;
            }
            // 过滤重复号码
            NSString *content = [nums componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_COMMA];
            if (![contentOfBettingRecords containsObject:content]) {
                [contentOfBettingRecords addObject:content];
            }
        }
    } else {
        // 包含重复号码
        for (NSInteger idx = 0; (idx + count - 1) < numbers.count; idx += count) {
            // 每一注的元素
            NSMutableArray<NSString *> *nums = [NSMutableArray<NSString *> array];
            for (NSInteger n = 0; (n<count)&&(idx+n<numbers.count); n ++) {
                NSString *num = [numbers stringAtIndex:idx+n];
                [nums addObject:num];
            }
            // 过滤相等号码
            if ([CFCStringMathsUtil hasEqualValueArray:nums]) {
                continue;
            }
            NSString *content = [nums componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_COMMA];
            [contentOfBettingRecords addObject:content];
        }
    }
    
    // 单式投注列表
    return [NSArray<NSString *> arrayWithArray:contentOfBettingRecords];
}


#pragma mark 帮助工具 - 投注内容 - 单式内容 - 直选单式 - 11选5单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN07:(NSInteger)count filter:(BOOL)isFilter
{
    // 分割字符长度
    if (count <= 0) {
        return [NSArray<NSString *> array];
    }
    
    // 获取投注内容
    __block NSMutableArray<NSString *> *bettingContents = [NSMutableArray<NSString *> array];
    [self.dataOfSectionModelArray enumerateObjectsUsingBlock:^(CFCGameBetPlayClassSectionModel * _Nonnull sectionObj, NSUInteger sectionIdx, BOOL * _Nonnull sectionStop) {
        if ([self isSingleSectionModel:sectionObj]) {
            [sectionObj.list enumerateObjectsUsingBlock:^(CFCGameBetPlayClassModel * _Nonnull classObj, NSUInteger classIdx, BOOL * _Nonnull classStop) {
                [bettingContents addObject:classObj.classRemark];
            }];
        }
    }];
    
    // 用户输入内容（删除特殊符号）
    NSString *bettingContentString = [bettingContents componentsJoinedByString:@""];
    NSCharacterSet *characterSet = [NSCharacterSet characterSetWithCharactersInString:STR_BETTING_DANSHI_SPLIT_CHARACHTERSET];
    NSArray<NSString *> *bettingContentSplit = [bettingContentString componentsSeparatedByCharactersInSet:characterSet];
    
    // 过滤错误数字（01~10）
    __block NSString *number_min = @"1";
    __block NSString *number_max = @"11";
    __block NSMutableArray<NSString *> *numbers = [NSMutableArray<NSString *> array];
    [bettingContentSplit enumerateObjectsUsingBlock:^(NSString * _Nonnull number, NSUInteger idx, BOOL * _Nonnull stop) {
        if (number_min.integerValue <= number.integerValue  && number.integerValue <= number_max.integerValue) {
            [numbers addObject:[NSString stringWithFormat:@"%02ld", number.integerValue]];
        }
    }];
    
    // 投注号码列表
    __block NSMutableArray<NSString *> *contentOfBettingRecords = [NSMutableArray<NSString *> array];
    if (isFilter) {
        // 过滤重复号码
        for (NSInteger idx = 0; (idx + count - 1)  < numbers.count; idx += count) {
            // 每一注的元素
            NSMutableArray<NSString *> *nums = [NSMutableArray<NSString *> array];
            for (NSInteger n = 0; (n<count)&&(idx+n<numbers.count); n ++) {
                NSString *num = [numbers stringAtIndex:idx+n];
                [nums addObject:num];
            }
            // 过滤相等号码
            if ([CFCStringMathsUtil hasEqualValueArray:nums]) {
                continue;
            }
            // 过滤重复号码
            NSString *content = [nums componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_COMMA];
            if (![contentOfBettingRecords containsObject:content]) {
                [contentOfBettingRecords addObject:content];
            }
        }
    } else {
        // 包含重复号码
        for (NSInteger idx = 0; (idx + count - 1) < numbers.count; idx += count) {
            // 每一注的元素
            NSMutableArray<NSString *> *nums = [NSMutableArray<NSString *> array];
            for (NSInteger n = 0; (n<count)&&(idx+n<numbers.count); n ++) {
                NSString *num = [numbers stringAtIndex:idx+n];
                [nums addObject:num];
            }
            // 过滤相等号码
            if ([CFCStringMathsUtil hasEqualValueArray:nums]) {
                continue;
            }
            NSString *content = [nums componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_COMMA];
            [contentOfBettingRecords addObject:content];
        }
    }
    
    // 单式投注列表
    return [NSArray<NSString *> arrayWithArray:contentOfBettingRecords];
}


#pragma mark 帮助工具 - 投注内容 - 单式内容 - 组选单式 - 11选5单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN08:(NSInteger)count filter:(BOOL)isFilter
{
    // 投注号码列表
    NSMutableArray<NSString *> *contentOfBettingRecords = [NSMutableArray<NSString *> array];
    
    // 用户输入内容
    NSArray<NSString *> *contents = [self contentOfBettingRecordsForSingleN07:count filter:isFilter];
    
    // 过滤重复号码
    NSMutableArray<NSString *> *contentOfSortedFliter = [NSMutableArray<NSString *> array];
    for (NSString *content in contents) {
        // 过滤重复号码
        if (isFilter) {
            NSCharacterSet *characterSet = [NSCharacterSet characterSetWithCharactersInString:STR_BETTING_DANSHI_SPLIT_CHARACHTERSET];
            NSArray<NSString *> *split = [content componentsSeparatedByCharactersInSet:characterSet];
            NSArray<NSString *> *sorted = [CFCStringMathsUtil sortedArray:split];
            NSString *sortedContent = [sorted componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_COMMA];
            if (![contentOfSortedFliter containsObject:sortedContent]) {
                [contentOfBettingRecords addObject:content];
                [contentOfSortedFliter addObject:sortedContent];
            }
        } else {
            [contentOfBettingRecords addObject:content];
        }
    }
    
    // 单式投注列表
    return [NSArray<NSString *> arrayWithArray:contentOfBettingRecords];
}


#pragma mark -
#pragma mark 帮助工具 - 投注结果 - 结果模板N01 - 号码格式 - 直选单式（012345|012345|012345|012345|012345|012345|012345）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsSingleTemplateN01:(NSDictionary *)dictOfBetSetting count:(NSInteger)count
{
    // 默认投注结果
    CFCGameBetRecordModel *model = [self buildindBettingResultModelForBettingRecordsOfCompose:dictOfBetSetting];
    
    // 投注号码格式（012345|012345|012345|012345|012345）
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN01:count filter:YES];
    NSString *all_selected_numbers_string = [contentOfBettingRecords componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_VERTICAL];
    [model setBall:all_selected_numbers_string];
    
    // 投注结果列表
    return [NSArray<CFCGameBetRecordModel *> arrayWithObject:model];
}


#pragma mark 帮助工具 - 投注结果 - 结果模板N02 - 号码格式 - 组选单式 - 组三单式（012345|012345|012345|012345|012345|012345|012345）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsSingleTemplateN02:(NSDictionary *)dictOfBetSetting count:(NSInteger)count
{
    // 默认投注结果
    CFCGameBetRecordModel *model = [self buildindBettingResultModelForBettingRecordsOfCompose:dictOfBetSetting];
    
    // 投注号码格式（012345|012345|012345|012345|012345）
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN02:count filter:YES];
    NSString *all_selected_numbers_string = [contentOfBettingRecords componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_VERTICAL];
    [model setBall:all_selected_numbers_string];
    
    // 投注结果列表
    return [NSArray<CFCGameBetRecordModel *> arrayWithObject:model];
}


#pragma mark 帮助工具 - 投注结果 - 结果模板N03 - 号码格式 - 组选单式 - 组六单式（012345|012345|012345|012345|012345|012345|012345）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsSingleTemplateN03:(NSDictionary *)dictOfBetSetting count:(NSInteger)count
{
    // 默认投注结果
    CFCGameBetRecordModel *model = [self buildindBettingResultModelForBettingRecordsOfCompose:dictOfBetSetting];
    
    // 投注号码格式（012345|012345|012345|012345|012345）
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN03:count filter:YES];
    NSString *all_selected_numbers_string = [contentOfBettingRecords componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_VERTICAL];
    [model setBall:all_selected_numbers_string];
    
    // 投注结果列表
    return [NSArray<CFCGameBetRecordModel *> arrayWithObject:model];
}


#pragma mark 帮助工具 - 投注结果 - 结果模板N04 - 号码格式 - 组选单式 - 混合单式（012345|012345|012345|012345|012345|012345|012345）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsSingleTemplateN04:(NSDictionary *)dictOfBetSetting count:(NSInteger)count
{
    // 默认投注结果
    CFCGameBetRecordModel *model = [self buildindBettingResultModelForBettingRecordsOfCompose:dictOfBetSetting];
    
    // 投注号码格式（012345|012345|012345|012345|012345）
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN04:count filter:YES];
    NSString *all_selected_numbers_string = [contentOfBettingRecords componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_VERTICAL];
    [model setBall:all_selected_numbers_string];
    
    // 投注结果列表
    return [NSArray<CFCGameBetRecordModel *> arrayWithObject:model];
}


#pragma mark 帮助工具 - 投注结果 - 结果模板N05 - 号码格式 - 组选单式 - 二星单式（012345|012345|012345|012345|012345|012345|012345）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsSingleTemplateN05:(NSDictionary *)dictOfBetSetting count:(NSInteger)count
{
    // 默认投注结果
    CFCGameBetRecordModel *model = [self buildindBettingResultModelForBettingRecordsOfCompose:dictOfBetSetting];
    
    // 投注号码格式（012345|012345|012345|012345|012345）
    NSArray<NSString *> *contentOfBettingRecords = [self contentOfBettingRecordsForSingleN05:count filter:YES];
    NSString *all_selected_numbers_string = [contentOfBettingRecords componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_VERTICAL];
    [model setBall:all_selected_numbers_string];
    
    // 投注结果列表
    return [NSArray<CFCGameBetRecordModel *> arrayWithObject:model];
}


#pragma mark 帮助工具 - 投注结果 - 结果模板N06 - 号码格式 - 直选单式 - PK拾单式（1 2 3 4 5|1 2 3 4 5|1 2 3 4 5|1 2 3 4 5|1 2 3 4 5）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsSingleTemplateN06:(NSDictionary *)dictOfBetSetting count:(NSInteger)count
{
    // 默认投注结果
    CFCGameBetRecordModel *model = [self buildindBettingResultModelForBettingRecordsOfCompose:dictOfBetSetting];
    
    // 获取投注内容
    NSArray<NSString *> *contentOfRecords = [self contentOfBettingRecordsForSingleN06:count filter:YES];
    
    // 投注号码格式（1 2 3 4 5|1 2 3 4 5|1 2 3 4 5|1 2 3 4 5|1 2 3 4 5）
    __block NSMutableArray<NSString *> *contentOfBettingRecords = [NSMutableArray<NSString *> array];
    [contentOfRecords enumerateObjectsUsingBlock:^(NSString * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSCharacterSet *characterSet = [NSCharacterSet characterSetWithCharactersInString:STR_BETTING_DANSHI_SPLIT_CHARACHTERSET];
        NSArray<NSString *> *split = [obj componentsSeparatedByCharactersInSet:characterSet];
        NSString *content = [split componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_SPACE];
        [contentOfBettingRecords addObject:content];
    }];
    NSString *all_selected_numbers_string = [contentOfBettingRecords componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_VERTICAL];
    [model setBall:all_selected_numbers_string];
    
    // 投注结果列表
    return [NSArray<CFCGameBetRecordModel *> arrayWithObject:model];
}


#pragma mark 帮助工具 - 投注结果 - 结果模板N07 - 号码格式 - 直选单式 - 11选5单式（01 02 03 04 05|01 02 03 04 05|01 02 03 04 05|01 02 03 04 05）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsSingleTemplateN07:(NSDictionary *)dictOfBetSetting count:(NSInteger)count
{
    // 默认投注结果
    CFCGameBetRecordModel *model = [self buildindBettingResultModelForBettingRecordsOfCompose:dictOfBetSetting];
    
    // 获取投注内容
    NSArray<NSString *> *contentOfRecords = [self contentOfBettingRecordsForSingleN07:count filter:YES];
    
    // 投注号码格式（1 2 3 4 5|1 2 3 4 5|1 2 3 4 5|1 2 3 4 5|1 2 3 4 5）
    __block NSMutableArray<NSString *> *contentOfBettingRecords = [NSMutableArray<NSString *> array];
    [contentOfRecords enumerateObjectsUsingBlock:^(NSString * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSCharacterSet *characterSet = [NSCharacterSet characterSetWithCharactersInString:STR_BETTING_DANSHI_SPLIT_CHARACHTERSET];
        NSArray<NSString *> *split = [obj componentsSeparatedByCharactersInSet:characterSet];
        NSString *content = [split componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_SPACE];
        [contentOfBettingRecords addObject:content];
    }];
    NSString *all_selected_numbers_string = [contentOfBettingRecords componentsJoinedByString:STR_BETTING_RESULT_SPLIT_SYMBOL_VERTICAL];
    [model setBall:all_selected_numbers_string];
    
    // 投注结果列表
    return [NSArray<CFCGameBetRecordModel *> arrayWithObject:model];
}


#pragma mark 帮助工具 - 投注结果 - 结果模板N08 - 号码格式 - 组选单式 - 11选5单式（01 02 03 04 05|01 02 03 04 05|01 02 03 04 05|01 02 03 04 05）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsSingleTemplateN08:(NSDictionary *)dictOfBetSetting count:(NSInteger)count
{
    // 投注结果列表
    return [self bettingResultModelsForBettingRecordsSingleTemplateN07:dictOfBetSetting count:count];
}





@end

