

#import "CFCGameTimerUtil.h"


@interface CFCGameTimerUtil ()

@property (nonatomic, copy) NSString *gameId; // 游戏主键
@property (nonatomic, copy) NSString *gameName; // 游戏名称
@property (nonatomic, copy) NSString *gameIdentifier; // 游戏标识

@property(nonatomic, retain) dispatch_source_t timer; // 定时器
@property (nonatomic, assign) NSInteger timer_timeout; // 倒计时长
@property (nonatomic, assign) NSInteger timer_timeout_per_sec; // 定时器间隔

@end


@implementation CFCGameTimerUtil


#pragma mark -
#pragma mark 定时器单例
+ (instancetype)sharedGameTimerUtil
{
    static CFCGameTimerUtil *_singetonInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken,^{
        if (nil == _singetonInstance) {
            _singetonInstance = [[super allocWithZone:NULL] init];
        }
    });
    return _singetonInstance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone
{
    return [[self class] sharedGameTimerUtil];
}

- (id)copyWithZone:(struct _NSZone *)zone
{
    return [[self class] sharedGameTimerUtil];
}


#pragma mark -
#pragma mark 每秒走一次，回调block
- (void)countDownWithBlock:(void (^)(void))block
                    gameId:(NSString *)gameId
                  gameName:(NSString *)gameName
            gameIdentifier:(NSString *)gameIdentifier
{
    // 如果切换了，则释放旧定时器
    if (![gameId isEqualToString:[CFCGameTimerUtil sharedGameTimerUtil].gameId]
        || ![gameIdentifier isEqualToString:[CFCGameTimerUtil sharedGameTimerUtil].gameIdentifier]) {
        [[CFCGameTimerUtil sharedGameTimerUtil] destoryTimer];
        //
        [CFCGameTimerUtil sharedGameTimerUtil].gameId = gameId;
        [CFCGameTimerUtil sharedGameTimerUtil].gameName = gameName;
        [CFCGameTimerUtil sharedGameTimerUtil].gameIdentifier = gameIdentifier;
    }
    
    // 定时器为空，则创建新定时器
    if (APPINFORMATION.isGameTimerEnable) {
        if ([CFCGameTimerUtil sharedGameTimerUtil].timer == nil) {
            [CFCGameTimerUtil sharedGameTimerUtil].timer_timeout = 0L; // 倒计时间秒数变量
            [CFCGameTimerUtil sharedGameTimerUtil].timer_timeout_per_sec = [CFCGameUtil getDrawResultTimerIntervalByGameId:[CFCGameTimerUtil sharedGameTimerUtil].gameId
                                                                                                                  gameName:[CFCGameTimerUtil sharedGameTimerUtil].gameName
                                                                                                            gameIdentifier:[CFCGameTimerUtil sharedGameTimerUtil].gameIdentifier]; // 倒计时间设置间隔N秒
            //
            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
            [CFCGameTimerUtil sharedGameTimerUtil].timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
            dispatch_source_set_timer([CFCGameTimerUtil sharedGameTimerUtil].timer, dispatch_walltime(NULL, 0), 1.0*NSEC_PER_SEC, 0); // 每秒执行
            dispatch_source_set_event_handler([CFCGameTimerUtil sharedGameTimerUtil].timer, ^{
                if (APPINFORMATION.isGameTimerEnable) {
                    if ([CFCGameTimerUtil sharedGameTimerUtil].timer_timeout > 0) {
                        CFCLog(@"开奖结果 => [%@-%@-%@] => 开奖已用时[%ld]秒",
                               [CFCGameTimerUtil sharedGameTimerUtil].gameId,
                               [CFCGameTimerUtil sharedGameTimerUtil].gameIdentifier,
                               [CFCGameTimerUtil sharedGameTimerUtil].gameName,
                               [CFCGameTimerUtil sharedGameTimerUtil].timer_timeout);
                        if (0 == [CFCGameTimerUtil sharedGameTimerUtil].timer_timeout % [CFCGameTimerUtil sharedGameTimerUtil].timer_timeout_per_sec) {
                            dispatch_async(dispatch_get_main_queue(), ^{
                                block();
                            });
                        }
                    }
                    [CFCGameTimerUtil sharedGameTimerUtil].timer_timeout ++;
                } else {
                    [[CFCGameTimerUtil sharedGameTimerUtil] destoryTimer];
                }
            });
            dispatch_resume([CFCGameTimerUtil sharedGameTimerUtil].timer);
        }
    } else {
        [[CFCGameTimerUtil sharedGameTimerUtil] destoryTimer];
    }
}


#pragma mark 销毁定时器
- (void)destoryTimer
{
    if ([CFCGameTimerUtil sharedGameTimerUtil].timer) {
        CFCLog(@"释放定时器[开奖结果][%@-%@-%@]",
               [CFCGameTimerUtil sharedGameTimerUtil].gameId,
               [CFCGameTimerUtil sharedGameTimerUtil].gameIdentifier,
               [CFCGameTimerUtil sharedGameTimerUtil].gameName);
        dispatch_source_cancel([CFCGameTimerUtil sharedGameTimerUtil].timer);
        [CFCGameTimerUtil sharedGameTimerUtil].timer = nil;
    }
}


@end

