//
//  游戏 - 官方玩法 - 投注设置框（全、大、小、单、双）
//

#import "CFCGameBetPlayClassCheckButton.h"

@interface CFCGameBetPlayClassCheckButton () {
    BOOL loaded;
}
@property(nonatomic, strong) UILabel *textLabel;

@end

@implementation CFCGameBetPlayClassCheckButton

@synthesize checked = _checked;
@synthesize disabled = _disabled;
@synthesize text = _text;
@synthesize textLabel = _textLabel;

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wobjc-missing-super-calls"
- (void)awakeFromNib
{
    self.backgroundColor = [UIColor clearColor];
}
#pragma clang diagnostic pop

- (void)drawRect:(CGRect)rect
{
    
    UIImage *image = [self buttonImageFromColor:self.checked ? _selectBgColor : _normalBgColor rect:self.frame];
    [image drawInRect:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
    
    if(self.disabled) {
        self.userInteractionEnabled = FALSE;
        self.alpha = 1.0f;
    } else {
        self.userInteractionEnabled = TRUE;
        self.alpha = 1.0f;
    }
    
    if(self.text) {
        if(!loaded) {
            _textLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
            _textLabel.backgroundColor = [UIColor clearColor];
            _textLabel.textAlignment = NSTextAlignmentCenter;
            [self addSubview:_textLabel];
            
            loaded = TRUE;
        }
        if (self.checked) {
            // 按钮选中状态
            [_textLabel setAttributedText:self.selectAttributedText];
        } else {
            // 按钮正常状态
            [_textLabel setAttributedText:self.normalAttributedText];
        }
    }
}

-(BOOL)beginTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event {
    [self setChecked:!self.checked];
    return TRUE;
}

-(void)setChecked:(BOOL)boolValue {
    _checked = boolValue;
    [self setNeedsDisplay];
}

-(void)setDisabled:(BOOL)boolValue {
    _disabled = boolValue;
    [self setNeedsDisplay];
}

-(void)setText:(NSString *)stringValue {
    _text = stringValue;
    [self setNeedsDisplay];
}

- (UIImage *) buttonImageFromColor:(UIColor *)color rect:(CGRect)frame
{
    CGRect rect = CGRectMake(0, 0, frame.size.width, frame.size.height);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return img;
}

@end
