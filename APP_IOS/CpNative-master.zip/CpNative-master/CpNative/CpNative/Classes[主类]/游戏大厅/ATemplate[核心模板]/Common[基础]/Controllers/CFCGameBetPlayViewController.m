//
// 游戏 - 投注区 - 抽象基类
//

#import "CFCGameBetPlayViewController.h"
#import "CFCGameBetPlayClassViewController.h"

@interface CFCGameBetPlayViewController ()  <CFCGameBetPlayScrollClassDelegate, CFCGameBetPlayScrollClassDataSource>

@end

@implementation CFCGameBetPlayViewController

#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.tabClassCodes = @[].mutableCopy;
        self.tabClassTitles = @[].mutableCopy;
        self.tabClassViewControllers = @[].mutableCopy;
    }
    return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // 设置代理
    [self setDataSource:self];
    [self setDelegate:self];
    
    // 初始化数据，成功则刷新页面
    if ([self viewDidLoadWithDataSource]) {
        [self reloadData];
    }
}

#pragma mark 加载并初始化数据
- (BOOL)viewDidLoadWithDataSource
{
    // TODO: 子类必须继承，并加载数据，成功返回则返回YES，默认返回NO
    
    return NO;
}

#pragma mark -
#pragma mark Calss Data Source
- (NSInteger)numberOfViewControllers
{
    return self.tabClassTitles.count;
}

- (NSString *)titleForTabAtIndex:(NSInteger)index
{
    return self.tabClassTitles[index];
}

- (NSString *)titleCodeForTabAtIndex:(NSInteger)index
{
    return self.tabClassCodes[index];
}

- (UIViewController *)viewControllerForIndex:(NSInteger)index
{
    Class myClass = NSClassFromString(self.tabClassViewControllers[index]);
    CFCGameBetPlayClassViewController *viewController = [[myClass alloc] init];
    // 具体玩法分类页面的控制器必须以类为[CFCGameBetPlayClassViewController]为基类。
    // 例如：福彩3D -> 定位 -> 1.百定位/2.十定位/3.个定位/4.百十定位/5.十个定位/6.百十个定位 -> 共六种玩法
    //      在这 (百定位...百十个定位) 六种玩法中，每一个玩法页面都必须以类[CFCGameBetPlayClassViewController]基类。
    if (![viewController isKindOfClass:[CFCGameBetPlayClassViewController class]]) {
        NSAssert(NO, @"具体玩法分类页面的基类必须是[CFCGameBetPlayClassViewController]类，进行修改。");
    }
    if (index < self.tabClassCodes.count) {
        viewController.tabClassCode = self.tabClassCodes[index];
    } else {
        NSAssert(NO, @"具体玩法分类页面未设置玩法标识[tabClassCode]，请进行修改。");
    }
    if (index < self.tabClassTitles.count) {
        viewController.tabClassTitle = self.tabClassTitles[index];
    } else {
        NSAssert(NO, @"具体玩法分类页面未设置玩法标签[tabClassTitle]，请进行修改。");
    }
    return viewController;
}

@end
