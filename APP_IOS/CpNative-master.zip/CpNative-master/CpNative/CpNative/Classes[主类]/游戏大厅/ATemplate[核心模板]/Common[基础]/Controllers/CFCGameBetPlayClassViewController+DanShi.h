
#import "CFCGameBetPlayClassViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCGameBetPlayClassViewController (DanShi)


#pragma mark -
#pragma mark 投注总数 - 计算投注总数 - 直选单式
- (NSInteger)numberOfBettingRecordsForSingleN01:(NSInteger)count;
#pragma mark 投注总数 - 计算投注总数 - 组选单式 - 组三单式
- (NSInteger)numberOfBettingRecordsForSingleN02:(NSInteger)count;
#pragma mark 投注总数 - 计算投注总数 - 组选单式 - 组六单式
- (NSInteger)numberOfBettingRecordsForSingleN03:(NSInteger)count;
#pragma mark 投注总数 - 计算投注总数 - 组选单式 - 混合单式
- (NSInteger)numberOfBettingRecordsForSingleN04:(NSInteger)count;
#pragma mark 投注总数 - 计算投注总数 - 组选单式 - 二星单式
- (NSInteger)numberOfBettingRecordsForSingleN05:(NSInteger)count;
#pragma mark 投注总数 - 计算投注总数 - 直选单式 - PK拾单式
- (NSInteger)numberOfBettingRecordsForSingleN06:(NSInteger)count;
#pragma mark 投注总数 - 计算投注总数 - 直选单式 - 11选5单式
- (NSInteger)numberOfBettingRecordsForSingleN07:(NSInteger)count;
#pragma mark 投注总数 - 计算投注总数 - 组选单式 - 11选5单式
- (NSInteger)numberOfBettingRecordsForSingleN08:(NSInteger)count;


#pragma mark -
#pragma mark 投注内容 - 组装单式内容 - 直选单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN01:(NSInteger)count;
#pragma mark 投注内容 - 组装单式内容 - 组选单式 - 组三单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN02:(NSInteger)count;
#pragma mark 投注内容 - 组装单式内容 - 组选单式 - 组六单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN03:(NSInteger)count;
#pragma mark 投注内容 - 组装单式内容 - 组选单式 - 混合单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN04:(NSInteger)count;
#pragma mark 投注内容 - 组装单式内容 - 组选单式 - 二星单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN05:(NSInteger)count;
#pragma mark 投注内容 - 组装单式内容 - 直选单式 - PK拾单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN06:(NSInteger)count;
#pragma mark 投注内容 - 组装单式内容 - 直选单式 - 11选5单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN07:(NSInteger)count;
#pragma mark 投注内容 - 组装单式内容 - 组选单式 - 11选5单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN08:(NSInteger)count;


#pragma mark -
#pragma mark 帮助工具 - 投注内容 - 单式内容 - 直选单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN01:(NSInteger)count filter:(BOOL)isFilter;
#pragma mark 帮助工具 - 投注内容 - 单式内容 - 组选单式 - 组三单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN02:(NSInteger)count filter:(BOOL)isFilter;
#pragma mark 帮助工具 - 投注内容 - 单式内容 - 组选单式 - 组六单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN03:(NSInteger)count filter:(BOOL)isFilter;
#pragma mark 帮助工具 - 投注内容 - 单式内容 - 组选单式 - 混合单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN04:(NSInteger)count filter:(BOOL)isFilter;
#pragma mark 帮助工具 - 投注内容 - 单式内容 - 组选单式 - 二星单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN05:(NSInteger)count filter:(BOOL)isFilter;
#pragma mark 帮助工具 - 投注内容 - 单式内容 - 直选单式 - PK拾单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN06:(NSInteger)count filter:(BOOL)isFilter;
#pragma mark 帮助工具 - 投注内容 - 单式内容 - 直选单式 - 11选5单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN07:(NSInteger)count filter:(BOOL)isFilter;
#pragma mark 帮助工具 - 投注内容 - 单式内容 - 组选单式 - 11选5单式
- (NSArray<NSString *> *)contentOfBettingRecordsForSingleN08:(NSInteger)count filter:(BOOL)isFilter;


#pragma mark -
#pragma mark 帮助工具 - 投注结果 - 结果模板N01 - 号码格式 - 直选单式（012345|012345|012345|012345|012345|012345|012345）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsSingleTemplateN01:(NSDictionary *)dictOfBetSetting count:(NSInteger)count;
#pragma mark 帮助工具 - 投注结果 - 结果模板N02 - 号码格式 - 组选单式 - 组三单式（012345|012345|012345|012345|012345|012345|012345）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsSingleTemplateN02:(NSDictionary *)dictOfBetSetting count:(NSInteger)count;
#pragma mark 帮助工具 - 投注结果 - 结果模板N03 - 号码格式 - 组选单式 - 组六单式（012345|012345|012345|012345|012345|012345|012345）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsSingleTemplateN03:(NSDictionary *)dictOfBetSetting count:(NSInteger)count;
#pragma mark 帮助工具 - 投注结果 - 结果模板N04 - 号码格式 - 组选单式 - 混合单式（012345|012345|012345|012345|012345|012345|012345）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsSingleTemplateN04:(NSDictionary *)dictOfBetSetting count:(NSInteger)count;
#pragma mark 帮助工具 - 投注结果 - 结果模板N05 - 号码格式 - 组选单式 - 二星单式（012345|012345|012345|012345|012345|012345|012345）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsSingleTemplateN05:(NSDictionary *)dictOfBetSetting count:(NSInteger)count;
#pragma mark 帮助工具 - 投注结果 - 结果模板N06 - 号码格式 - 直选单式 - PK拾单式（1 2 3 4 5|1 2 3 4 5|1 2 3 4 5|1 2 3 4 5|1 2 3 4 5）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsSingleTemplateN06:(NSDictionary *)dictOfBetSetting count:(NSInteger)count;
#pragma mark 帮助工具 - 投注结果 - 结果模板N07 - 号码格式 - 直选单式 - 11选5单式（01 02 03 04 05|01 02 03 04 05|01 02 03 04 05|01 02 03 04 05）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsSingleTemplateN07:(NSDictionary *)dictOfBetSetting count:(NSInteger)count;
#pragma mark 帮助工具 - 投注结果 - 结果模板N08 - 号码格式 - 组选单式 - 11选5单式（01 02 03 04 05|01 02 03 04 05|01 02 03 04 05|01 02 03 04 05）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsSingleTemplateN08:(NSDictionary *)dictOfBetSetting count:(NSInteger)count;


@end

NS_ASSUME_NONNULL_END
