//
// 游戏 - 投注区 - 投注数据模型
//


#import <Foundation/Foundation.h>


NS_ASSUME_NONNULL_BEGIN


@interface CFCGameBetRecordModel : NSObject

@property (nonatomic, copy) NSString *jsId;
@property (nonatomic, copy) NSString *type;
@property (nonatomic, copy) NSString *wayId;
@property (nonatomic, copy) NSString *multiple;
@property (nonatomic, copy) NSString *moneyunit;
@property (nonatomic, copy) NSString *num;
@property (nonatomic, copy) NSString *onePrice;
@property (nonatomic, copy) NSString *prizeGroup;
@property (nonatomic, copy) NSString *ball;
@property (nonatomic, copy) NSString *viewBalls;
@property (nonatomic, strong) NSDictionary<NSString *, NSString *> *extra;

+ (CFCGameBetRecordModel *) buildingDataModleForBettingRecords;

@end


@interface CFCGameBetFormModel : NSObject

@property (nonatomic, copy) NSString *gameId;
@property (nonatomic, copy) NSString *amount;
@property (nonatomic, copy) NSString *isTrace;
@property (nonatomic, copy) NSString *traceWinStop;
@property (nonatomic, copy) NSString *traceStopValue;
@property (nonatomic, strong) NSArray<CFCGameBetRecordModel *> *balls;
@property (nonatomic, strong) NSDictionary<NSString *, NSString *> *orders;

+ (CFCGameBetFormModel *) buildingDataModleForBettingForms;

@end


NS_ASSUME_NONNULL_END

