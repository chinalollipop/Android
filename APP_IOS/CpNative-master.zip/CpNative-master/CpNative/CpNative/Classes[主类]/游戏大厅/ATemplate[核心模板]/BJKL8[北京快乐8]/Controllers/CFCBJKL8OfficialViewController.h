//
// 游戏 - 投注区 - 官网模式 - 北京快乐8
//

#import "CFCGameBetOfficialViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCBJKL8OfficialViewController : CFCGameBetOfficialViewController

@end

NS_ASSUME_NONNULL_END
