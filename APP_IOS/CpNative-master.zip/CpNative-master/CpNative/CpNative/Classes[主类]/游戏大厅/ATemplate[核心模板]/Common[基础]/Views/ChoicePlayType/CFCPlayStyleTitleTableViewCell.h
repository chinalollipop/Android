//
//  游戏 - 投注页面头部区域 - 玩法选择 - 标题
//

#import <UIKit/UIKit.h>
@class CFCPlayTypeTitleModel;


NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString * const CELL_IDENTIFIER_GAME_PLAY_TYPE_TITLE_TABLE_VIEW_CELL;

@interface CFCPlayStyleTitleTableViewCell : UITableViewCell

@property (nonatomic, strong) CFCPlayTypeTitleModel *model;

@end

NS_ASSUME_NONNULL_END
