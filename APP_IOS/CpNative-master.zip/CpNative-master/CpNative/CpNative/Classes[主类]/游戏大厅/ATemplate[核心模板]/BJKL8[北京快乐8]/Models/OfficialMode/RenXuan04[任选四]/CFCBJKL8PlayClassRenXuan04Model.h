//
// 游戏 - 投注区 - 官方模式 - 北京快乐8 - 任选四 - 任选四 - 复式
//

#import "CFCGameBetPlayClassModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCBJKL8PlayClassRenXuan04Model : CFCGameBetPlayClassModel

+ (NSMutableArray *) buildingDataModlesForSection1;

+ (NSMutableArray *) buildingDataModlesForSection2;

@end


@interface CFCBJKL8PlayClassRenXuan04SectionModel : CFCGameBetPlayClassSectionModel

+ (NSMutableArray *) buildingDataModles;

@end

NS_ASSUME_NONNULL_END
