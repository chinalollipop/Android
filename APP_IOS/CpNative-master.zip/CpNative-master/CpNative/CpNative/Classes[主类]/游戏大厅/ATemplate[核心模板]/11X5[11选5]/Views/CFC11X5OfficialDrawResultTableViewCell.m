//
// 游戏 - 开奖结果 - 11X5
//

#import "CFC11X5OfficialDrawResultTableViewCell.h"
#import "CFC11X5DrawResultModel.h"

@implementation CFC11X5OfficialDrawResultTableViewCell

#pragma mark - 触发操作事件
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture
{
    [super pressPublicItemView:gesture];
    
    // 强击类型转换
    CFC11X5DrawResultModel *model_original = (CFC11X5DrawResultModel *)self.menuModel;
    id<CFC11X5OfficialDrawResultTableViewCellDelegate> delegate_original = (id<CFC11X5OfficialDrawResultTableViewCellDelegate>)self.delegate;
    
    if (delegate_original && [delegate_original respondsToSelector:@selector(didSelectRowAt11X5DrawResultModel:)]) {
        [delegate_original didSelectRowAt11X5DrawResultModel:model_original];
    }
}

@end
