//
// 游戏 - 开奖结果 - 北京快乐8
//

#import "CFCBJKL8OfficialDrawResultTopAreaView.h"

@implementation CFCBJKL8OfficialDrawResultTopAreaView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
