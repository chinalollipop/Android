//
// 游戏 - 投注区 - 官方模式 - 北京快乐8 - 奇偶和 - 奇偶和 - 奇偶和
//

#import "CFCGameBetPlayClassModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCBJKL8PlayClassJiOuHeModel : CFCGameBetPlayClassModel

+ (NSMutableArray *) buildingDataModlesForSection1;

@end


@interface CFCBJKL8PlayClassJiOuHeSectionModel : CFCGameBetPlayClassSectionModel

+ (NSMutableArray *) buildingDataModles;

@end

NS_ASSUME_NONNULL_END
