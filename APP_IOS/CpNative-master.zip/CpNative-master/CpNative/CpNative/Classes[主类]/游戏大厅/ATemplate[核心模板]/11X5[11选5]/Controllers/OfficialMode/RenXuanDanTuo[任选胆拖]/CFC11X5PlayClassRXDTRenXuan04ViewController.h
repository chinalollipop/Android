//
// 游戏 - 投注区 - 官方模式 - 11选5 - 任选胆拖 - 任选胆拖 - 任选四中四胆拖
//

#import "CFC11X5PlayClassBaseOfficialViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFC11X5PlayClassRXDTRenXuan04ViewController : CFC11X5PlayClassBaseOfficialViewController

@end

NS_ASSUME_NONNULL_END
