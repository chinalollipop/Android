//
//  游戏 - 官方玩法 -> 投注项目，无操作按钮 -> 如：时时彩官方玩法中<大小单双>
//
//  说明：此类以 UITableViewCell 实现。如果不能满足你的要求，请另外实现。
//

#import "CFCGameBetPlayClassOfficial2TableViewCell.h"
#import "CFCGameBetPlayClassModel.h"


// Cell Identifier
NSString * const CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_2_TABLE_VIEW_CELL = @"CFCGameBetPlayClassOfficial2TableViewCellIdentifier";


@interface CFCGameBetPlayClassOfficial2TableViewCell ()

@end


@implementation CFCGameBetPlayClassOfficial2TableViewCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createViewAtuoLayout];
    }
    return self;
}


#pragma mark 创建子控件
- (void) createViewAtuoLayout
{
    // 根容器
    UIView *rootContainerView = ({
        UIView *view = [[UIView alloc] init];
        [self.contentView insertSubview:view atIndex:0];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@0.0f);
            make.top.equalTo(@0.0f);
            make.right.equalTo(@0.0f);
            make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
        }];
        
        view;
    });
    self.rootContainerView = rootContainerView;
    self.rootContainerView.mas_key = @"rootContainerView";
    
    // 公共容器
    UIView *publicContainerView = ({
        UIView *view = [[UIView alloc] init];
        [view setBackgroundColor:COLOR_GAME_BET_MAINAREA_BACKGROUND_DEFAULT];
        [rootContainerView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(rootContainerView.mas_left).offset(0.0f);
            make.top.equalTo(rootContainerView.mas_top).offset(0.0f);
            make.right.equalTo(rootContainerView.mas_right).offset(0.0f);
            make.bottom.equalTo(rootContainerView.mas_bottom).offset(0.0f);
        }];
        
        view;
    });
    self.publicContainerView = publicContainerView;
    self.publicContainerView.mas_key = @"publicContainerView";
    
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCGameBetPlayClassSectionModel *)model
{
    // 类型安全检查
    if (![model isKindOfClass:[CFCGameBetPlayClassSectionModel class]]) {
        return;
    }
    
    // 数据赋值
    _model = (CFCGameBetPlayClassSectionModel *)model;
    
    // 删除控件
    [self.publicContainerView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    // 创建控件
    {
        // 大小间距
        NSInteger column = self.model.columnsCount;
        CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
        CGFloat margin_top = margin * 2.25f;
        CGFloat margin_left = margin * 1.50f;
        CGFloat margin_right = margin * 1.50f;
        CGFloat margin_bottom = margin * 2.00f;
        // 操作按钮
        CGFloat operationButtonCount = 6.0f; // 操作按钮（全、大、小、单、双、清）
        CGFloat btn_count_all = operationButtonCount + 1.85f; // 操作宽度 + 分组标签宽度
        CGFloat btn_margin_left = margin * 1.0f;
        CGFloat btn_margin_horizontal = margin * 0.10f;
        CGFloat btn_size_width = (SCREEN_WIDTH - margin_left - margin_right - btn_margin_left - btn_margin_horizontal*(operationButtonCount-1)) / btn_count_all;
        CGFloat btn_size_height = btn_size_width * 0.80f;
        // 分组标签
        CGFloat section_title_width = btn_size_width * (btn_count_all - operationButtonCount);
        CGFloat section_title_height = btn_size_height * 0.90f;
        // 投注按钮
        CGFloat item_margin_horizontal = margin * 0.8f + margin_right / (column-1);
        CGFloat item_margin_vertical = item_margin_horizontal * 0.80f;
        CGFloat item_margin_top = margin_top; // margin_top + btn_size_height + margin * 0.25f;
        CGFloat item_margin_left = margin_left + section_title_width + btn_margin_left;
        CGFloat item_size_width = (SCREEN_WIDTH - item_margin_left - margin_right - item_margin_horizontal*(column-1)) / column;
        CGFloat item_size_height = (SCREEN_WIDTH - item_margin_left - margin_right - item_margin_horizontal*4) / 5;
        // 投注高度
        if (item_size_height > item_size_width) {
            item_size_height = item_size_width;
        }
        // 一行数据
        if (self.model.list.count / column <= 1.0) {
            if (btn_size_height > item_size_height) {
                item_margin_top = margin_top + (btn_size_height - item_size_height) / 2.0f;
            } else {
                item_margin_top = margin_top - (item_size_height - btn_size_height) / 2.0f;
            }
        }
        
        // 投注按钮
        UILabel *lastItemButton = nil;
        self.bettingButtonArray = @[].mutableCopy;
        for (int i = 0; i < self.model.list.count; i ++) {
            
            CFCGameBetPlayClassModel *classModel = self.model.list[i];
            CGFloat radius = classModel.isCornerRadius ? item_size_height*0.50f : item_size_height*0.20f;
            
            UILabel *itemButton = ({
                UILabel *itemLabel = [[UILabel alloc] init];
                [itemLabel setTag:8000+i];
                [itemLabel setUserInteractionEnabled:YES];
                [itemLabel.layer setMasksToBounds:YES];
                [itemLabel.layer setCornerRadius:radius];
                [itemLabel.layer setBorderWidth:GAME_PLAY_ITEM_BORDER_WIDTH_DEFAULT];
                [itemLabel.layer setBorderColor:GAME_PLAY_ITEM_BORDER_COLOR_DEFAULT.CGColor];
                [itemLabel setTextAlignment:NSTextAlignmentCenter];
                [self.publicContainerView addSubview:itemLabel];
                
                UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressItemButtonViewAction:)];
                [itemLabel addGestureRecognizer:tapGesture];
                
                [itemLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
                    make.width.equalTo(@(item_size_width));
                    make.height.equalTo(@(item_size_height));
                    
                    if (!lastItemButton) {
                        make.top.equalTo(self.publicContainerView.mas_top).offset(item_margin_top);
                        make.left.equalTo(self.publicContainerView.mas_left).offset(item_margin_left);
                    } else {
                        if (i % column == 0) {
                            make.top.equalTo(lastItemButton.mas_bottom).offset(item_margin_vertical);
                            make.left.equalTo(self.publicContainerView.mas_left).offset(item_margin_left);
                        } else {
                            make.top.equalTo(lastItemButton.mas_top);
                            make.left.equalTo(lastItemButton.mas_right).offset(item_margin_horizontal);
                        }
                    }
                }];
                itemLabel.mas_key = [NSString stringWithFormat:@"itemContainerView%d",i];
                
                itemLabel;
            });
            [self.bettingButtonArray addObject:itemButton];
            
            lastItemButton = itemButton;
        }
        
        // 分组标题 - 背景
        CFCGameBetPlayClassSectionNameView *sectionTitleView = ({
            CGRect frame = CGRectMake(0, 0, section_title_width, section_title_height);
            CFCGameBetPlayClassSectionNameView *sectionView = [[CFCGameBetPlayClassSectionNameView alloc]
                                                               initWithFrame:frame
                                                               backgroundColor:GAME_PLAY_OFFICI_BUTTON_BACKGROUND_COLOR_SELECT];
            [self.publicContainerView addSubview:sectionView];
            [sectionView.layer setMasksToBounds:YES];
            [sectionView mas_makeConstraints:^(MASConstraintMaker *make) {
                CGFloat offset_top = margin_top + (btn_size_height - section_title_height) / 2.0f;
                make.top.equalTo(self.publicContainerView.mas_top).offset(offset_top);
                make.left.equalTo(self.publicContainerView.mas_left).offset(margin_left);
                make.size.mas_equalTo(frame.size);
            }];
            
            sectionView;
        });
        sectionTitleView.mas_key = @"sectionTitleView";
        
        // 分组标题 - 标题
        UILabel *sectionTitleLabel = ({
            UILabel *label = [UILabel new];
            [sectionTitleView addSubview:label];
            [label mas_makeConstraints:^(MASConstraintMaker *make) {
                make.centerX.equalTo(sectionTitleView.mas_centerX).offset(-margin*0.50f);
                make.centerY.equalTo(sectionTitleView.mas_centerY);
            }];
            
            label;
        });
        self.sectionTitleLabel = sectionTitleLabel;
        self.sectionTitleLabel.mas_key = @"sectionTitleLabel";
        
        // 分割线
        UIView *separatorLineView = ({
            UIView *view = [[UIView alloc] init];
            [self.publicContainerView addSubview:view];
            [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
            
            [view mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.equalTo(self.publicContainerView.mas_left).offset(0.0f);
                make.right.equalTo(self.publicContainerView.mas_right).offset(0.0f);
                make.height.equalTo(@(SEPARATOR_LINE_HEIGHT));
                make.top.equalTo(lastItemButton.mas_bottom).offset(margin_bottom);
            }];
            
            view;
        });
        separatorLineView.mas_key = @"separatorLineView";
        
        // 约束的完整性
        [self.publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(separatorLineView.mas_bottom).offset(0.0f).priority(749);
        }];
        
    }
    
    // 投注按钮
    for (int idx = 0; idx < self.bettingButtonArray.count; idx ++) {
        
        UILabel *bettingLable = self.bettingButtonArray[idx];
        
        if (idx < self.model.list.count) {
            [bettingLable setHidden:NO];
            
            CFCGameBetPlayClassModel *classModel = self.model.list[idx];
            [bettingLable setText:[CFCSysUtil stringByTrimmingWhitespaceAndNewline:classModel.name]];
            
            // 字体颜色
            UIColor *backgroundColor = classModel.isSelected ? GAME_PLAY_ITEM_COLOR_BACKGROUND_SELECT : GAME_PLAY_ITEM_COLOR_BACKGROUND_NORMAL;
            UIColor *nameColor = classModel.isSelected ? classModel.nameSelectColor : classModel.nameNormalColor;
            UIFont *nameFont = classModel.isSelected ? classModel.nameSelectFont : classModel.nameNormalFont;
            
            // 设置内容
            NSString *name = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:classModel.name];
            NSDictionary *attributesName = @{ NSFontAttributeName:nameFont, NSForegroundColorAttributeName:nameColor};
            NSAttributedString *attributedString = [CFCSysUtil attributedString:@[[NSString stringWithFormat:@"%@",name]] attributeArray:@[attributesName]];
            [bettingLable setAttributedText:attributedString];
            [bettingLable setBackgroundColor:backgroundColor];
            
        } else {
            
            [bettingLable setHidden:YES];
            
        }
    }
    
    // 分组标题
    {
        UIFont *fontName = GROUP_OFFICI_FONT_GAME_PLAY_ITEM_TITLE;
        NSString *name = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:self.model.title];
        NSDictionary *attributesName = @{ NSFontAttributeName:fontName,
                                          NSForegroundColorAttributeName:GROUP_OFFICI_COLOR_GAME_PLAY_ITEM_TITLE};
        NSAttributedString *attributedString = [CFCSysUtil attributedString:@[[NSString stringWithFormat:@"%@", name]]
                                                             attributeArray:@[attributesName]];
        [self.sectionTitleLabel setAttributedText:attributedString];
    }
    
}


#pragma mark - 操作事件 - 投注按钮
- (void)pressItemButtonViewAction:(UITapGestureRecognizer *)gesture
{
    UILabel *itemView = (UILabel*)gesture.view;
    
    NSUInteger index = itemView.tag - 8000;
    
    if (index >= self.model.list.count) {
        CFCLog(@"数组越界，请检测代码。");
        return;
    }
    
    // 更新数据
    CFCGameBetPlayClassModel *itemModel = self.model.list[index];
    
    // 执行代理
    if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectPlayClassOfficial2TableViewCellRowAtIndexPath:itemModels:itemIndexs:)]) {
        [self.delegate didSelectPlayClassOfficial2TableViewCellRowAtIndexPath:self.indexPath
                                                                   itemModels:@[itemModel]
                                                                   itemIndexs:@[[NSNumber numberWithInteger:index]] ];
    }
    
}


@end




