//
//  游戏 - 投注页面头部区域 - 玩法选择 - 一级分类
//

#import "CFCPlayTypeContentFirstTableViewCell.h"
#import "CFCPlayTypeContentFirstModel.h"


// Cell Identifier
NSString * const CELL_IDENTIFIER_GAME_PLAY_TYPE_CONTENT_FRIST_TABLE_VIEW_CELL = @"CFCPlayTypeContentFirstTableViewCellIdentifier";


@interface CFCPlayTypeContentFirstTableViewCell ()
/**
 * 根容器组件
 */
@property (nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonatomic, strong) UIView *publicContainerView;
/**
 * 标签按钮
 */
@property (nonatomic, strong) NSMutableArray<UILabel *> *itemButtonArray;

@end


@implementation CFCPlayTypeContentFirstTableViewCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createViewAtuoLayout];
    }
    return self;
}


#pragma mark 创建子控件
- (void) createViewAtuoLayout
{
    // 根容器
    UIView *rootContainerView = ({
        UIView *view = [[UIView alloc] init];
        [self.contentView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@0.0f);
            make.top.equalTo(@0.0f);
            make.right.equalTo(@0.0f);
            make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
        }];
        
        view;
    });
    self.rootContainerView = rootContainerView;
    self.rootContainerView.mas_key = @"rootContainerView";
    
    // 公共容器
    UIView *publicContainerView = ({
        UIView *view = [[UIView alloc] init];
        [view.layer setMasksToBounds:YES];
        [view setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_WHITE];
        [rootContainerView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@0.0f);
            make.top.equalTo(@0.0f);
            make.right.equalTo(@0.0f);
            make.bottom.equalTo(rootContainerView.mas_bottom).offset(0.0f);
        }];
        
        view;
    });
    self.publicContainerView = publicContainerView;
    self.publicContainerView.mas_key = @"publicContainerView";
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCPlayTypeContentFirstModel *)model
{
    // 类型安全检查
    if (![model isKindOfClass:[CFCPlayTypeContentFirstModel class]]) {
        return;
    }
    
    // 数据赋值
    _model = model;

    // 删除控件
    [self.publicContainerView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    // 创建控件
    {
        // 字体颜色
        UIColor *nameColor = COLOR_GAME_PLAY_TYPE_TAG_TITLE_NORMAL;
        UIColor *borderColor = COLOR_GAME_PLAY_TYPE_BORDER_NORMAL;
        UIColor *backgroundColor = COLOR_GAME_PLAY_TYPE_BACKGROUND_NORMAL;
        UIFont *nameFont = FONT_GAME_PLAY_TYPE_TAG_TITLE_NORMAL;
        
        // 大小间距
        CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
        CGFloat item_gap_top = margin * 1.0f;
        CGFloat item_gap_bottom = margin * 1.0f;
        CGFloat item_gap_left_right = margin * 0.5f;
        CGFloat item_gap_vertical = margin * 0.6f;
        CGFloat item_gap_horizontal = margin * 0.6f;
        CGFloat itemRadius = margin*0.5f;
        CGFloat itemBorderWidth = 1.0f;
        CGFloat itemSizeWidth = 0.0f;
        CGFloat itemSizeHeight = [@"占位符" heightWithFont:nameFont constrainedToWidth:MAXFLOAT] + margin*1.2f;
        __block CGFloat itemLineWidth = item_gap_left_right;
        
        UILabel *lastItemButton = nil;
        self.itemButtonArray = @[].mutableCopy;
        for (int i = 0; i < model.menuChildren.count; i ++) {
            
            CFCGameBetPlayTypeModel *itemModel = model.menuChildren[i];
            
            nameColor = itemModel.isSelected ? COLOR_GAME_PLAY_TYPE_TAG_TITLE_SELECT : COLOR_GAME_PLAY_TYPE_TAG_TITLE_NORMAL;
            borderColor = itemModel.isSelected ? COLOR_GAME_PLAY_TYPE_BORDER_SELECT : COLOR_GAME_PLAY_TYPE_BORDER_NORMAL;
            backgroundColor = itemModel.isSelected ? COLOR_GAME_PLAY_TYPE_BACKGROUND_SELECT : COLOR_GAME_PLAY_TYPE_BACKGROUND_NORMAL;
            nameFont = itemModel.isSelected ? FONT_GAME_PLAY_TYPE_TAG_TITLE_SELECT : FONT_GAME_PLAY_TYPE_TAG_TITLE_NORMAL;
            
            UILabel *itemButton = ({
                UILabel *itemLabel = [[UILabel alloc] init];
                [itemLabel setTag:8000+i];
                [itemLabel.layer setMasksToBounds:YES];
                [itemLabel.layer setCornerRadius:itemRadius];
                [itemLabel.layer setBorderWidth:itemBorderWidth];
                [itemLabel.layer setBorderColor:borderColor.CGColor];
                [itemLabel setTextAlignment:NSTextAlignmentCenter];
                [itemLabel setUserInteractionEnabled:YES];
                [self.publicContainerView addSubview:itemLabel];
                
                NSString *name = [CFCSysUtil stringByTrimmingWhitespaceAndNewline:itemModel.name];
                NSDictionary *attributesName = @{ NSFontAttributeName:nameFont, NSForegroundColorAttributeName:nameColor};
                NSAttributedString *attributedString = [CFCSysUtil attributedString:@[[NSString stringWithFormat:@"%@",name]]
                                                                     attributeArray:@[attributesName]];
                [itemLabel setAttributedText:attributedString];
                [itemLabel setBackgroundColor:backgroundColor];
                
                UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pressItemButtonViewAction:)];
                [itemLabel addGestureRecognizer:tapGesture];
                
                itemSizeWidth = [itemModel.name widthWithFont:nameFont constrainedToHeight:MAXFLOAT] + margin*1.7f;
                itemLineWidth = itemLineWidth + itemSizeWidth + item_gap_horizontal;
                
                [itemLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
                    make.width.equalTo(@(itemSizeWidth));
                    make.height.equalTo(@(itemSizeHeight));
                    
                    if (!lastItemButton) {
                        make.top.equalTo(self.publicContainerView.mas_top).offset(item_gap_top);
                        make.left.equalTo(self.publicContainerView.mas_left).offset(item_gap_left_right);
                    } else {
                        if (itemLineWidth > SCREEN_WIDTH) {
                            itemLineWidth = item_gap_left_right + itemSizeWidth + item_gap_horizontal;
                            make.top.equalTo(lastItemButton.mas_bottom).offset(item_gap_vertical);
                            make.left.equalTo(self.publicContainerView.mas_left).offset(item_gap_left_right);
                        } else {
                            make.top.equalTo(lastItemButton.mas_top).offset(0);
                            make.left.equalTo(lastItemButton.mas_right).offset(item_gap_horizontal);
                        }
                    }
                }];
                itemLabel.mas_key = [NSString stringWithFormat:@"itemContainerView%d",i];
                
                itemLabel;
            });
            [self.itemButtonArray addObject:itemButton];
            
            lastItemButton = itemButton;
        }
        
        // 分割线
        UIView *separatorLineView = ({
            UIView *view = [[UIView alloc] init];
            [self.publicContainerView addSubview:view];
            [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_LIGHTGRAY];
            
            [view mas_makeConstraints:^(MASConstraintMaker *make) {
                if (!lastItemButton) {
                    make.top.equalTo(self.publicContainerView.mas_top).offset(0.0f);
                } else {
                    make.top.equalTo(lastItemButton.mas_bottom).offset(item_gap_bottom);
                }
                make.left.equalTo(self.publicContainerView.mas_left).offset(0.0f);
                make.right.equalTo(self.publicContainerView.mas_right).offset(0.0f);
                make.height.equalTo(@(1.0f));
            }];
            
            view;
        });
        separatorLineView.mas_key = @"separatorLineView";
        
        // 约束的完整性
        [self.publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(separatorLineView.mas_bottom).offset(0.0f).priority(749);
        }];
    }
}


#pragma mark - 触发操作事件 - 投注按钮
- (void)pressItemButtonViewAction:(UITapGestureRecognizer *)gesture
{
    UILabel *itemView = (UILabel*)gesture.view;
    
    NSUInteger index = itemView.tag - 8000;
    
    if (index >= self.model.menuChildren.count) {
        CFCLog(@"数组越界，请检测代码。");
        return;
    }
    
    // 更新数据
    CFCGameBetPlayTypeModel *itemModel = self.model.menuChildren[index];
    [self.model.menuChildren enumerateObjectsUsingBlock:^(CFCGameBetPlayTypeModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        obj.isSelected = NO;
    }];
    itemModel.isSelected = YES;
    
    // 执行代理
    if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectPlayTypeContentFirstModelAtIndexPath:playTypeTagIndex:playTypeModel:)]) {
        [self.delegate didSelectPlayTypeContentFirstModelAtIndexPath:self.indexPath playTypeTagIndex:index playTypeModel:itemModel];
    }
}

@end
