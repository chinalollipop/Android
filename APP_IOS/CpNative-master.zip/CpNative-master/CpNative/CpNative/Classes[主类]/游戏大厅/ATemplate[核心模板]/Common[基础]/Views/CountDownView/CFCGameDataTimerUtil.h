

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CFCGameDataTimerUtil : NSObject

/**
 *  定时器单例
 */
+ (instancetype)sharedGameDataTimerUtil;

/**
 *  每秒走一次，回调block
 */
- (void)countDownWithBlock:(void (^)(void))block
                    gameId:(NSString *)gameId
                  gameName:(NSString *)gameName
            gameIdentifier:(NSString *)gameIdentifier;

/**
 *  销毁定时器
 */
- (void)destoryTimer;

@end

NS_ASSUME_NONNULL_END
