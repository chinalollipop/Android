//
// 游戏 - 开奖结果 - 北京快乐8
//

#import "CFCBJKL8OfficialDrawResultTableViewCell.h"
#import "CFCBJKL8DrawResultModel.h"

@implementation CFCBJKL8OfficialDrawResultTableViewCell

#pragma mark - 触发操作事件
- (void)pressPublicItemView:(UITapGestureRecognizer *)gesture
{
    [super pressPublicItemView:gesture];
    
    // 强击类型转换
    CFCBJKL8DrawResultModel *model_original = (CFCBJKL8DrawResultModel *)self.menuModel;
    id<CFCBJKL8OfficialDrawResultTableViewCellDelegate> delegate_original = (id<CFCBJKL8OfficialDrawResultTableViewCellDelegate>)self.delegate;
    
    if (delegate_original && [delegate_original respondsToSelector:@selector(didSelectRowAtBJKL8DrawResultModel:)]) {
        [delegate_original didSelectRowAtBJKL8DrawResultModel:model_original];
    }
}

@end
