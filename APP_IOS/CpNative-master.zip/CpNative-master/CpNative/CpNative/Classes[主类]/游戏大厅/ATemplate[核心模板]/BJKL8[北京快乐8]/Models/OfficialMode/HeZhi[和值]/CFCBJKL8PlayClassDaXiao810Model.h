//
// 游戏 - 投注区 - 官方模式 - 北京快乐8 - 和值 - 和值 - 大小810
//

#import "CFCGameBetPlayClassModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCBJKL8PlayClassDaXiao810Model : CFCGameBetPlayClassModel

+ (NSMutableArray *) buildingDataModlesForSection1;

@end


@interface CFCBJKL8PlayClassDaXiao810SectionModel : CFCGameBetPlayClassSectionModel

+ (NSMutableArray *) buildingDataModles;

@end

NS_ASSUME_NONNULL_END
