//
// 游戏 - 投注区 - 官方模式 - 北京快乐8 - 上中下 - 上中下 - 上中下
//

#import "CFCBJKL8PlayClassShangZhongXiaViewController.h"
#import "CFCBJKL8PlayClassShangZhongXiaModel.h"


@interface CFCBJKL8PlayClassShangZhongXiaViewController ()

@end


@implementation CFCBJKL8PlayClassShangZhongXiaViewController


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.className = GAME_PLAY_CLASS_NAME_BJKL8_SHANGZHONGXIA_SZX_MULTIPLE;
        self.classCode = GAME_PLAY_CLASS_CODE_BJKL8_SHANGZHONGXIA_SZX_MULTIPLE;
    }
    return self;
}


#pragma mark -
#pragma mark 数据模型 - 静态数据模型
- (NSArray<CFCGameBetPlayClassSectionModel *> *)dataOfPlayClassModelsForBettingRecords
{
    return [CFCBJKL8PlayClassShangZhongXiaSectionModel buildingDataModles];
}


#pragma mark 投注结果 - 官方模式
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsOfficial:(NSDictionary *)dictOfBetSetting
{
    return [self bettingResultModelsForBettingRecordsTemplateN03:dictOfBetSetting];
}



@end
