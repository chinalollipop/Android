
#import <UIKit/UIKit.h>
@class CFCSliderView;


@protocol CFCSliderViewDelegate <NSObject>
@optional
- (void)slider:(CFCSliderView *)slider changeValue:(NSString *)value;
@end


@interface CFCSliderView : UIControl

/*
 *** 代理
 */
@property (nonatomic, weak) id<CFCSliderViewDelegate> delegate;

/*
 *** 最小值
 */
@property (nonatomic, assign) CGFloat minValue;

/*
 *** 最大值
 */
@property (nonatomic, assign) CGFloat maxValue;

/*
 *** 默认值
 */
@property (nonatomic, assign) CGFloat value;

/*
 *** 轨道colors
 */
@property (nonatomic, retain) NSArray *trackColors;

/*
 *** 轨道默认color
 */
@property (nonatomic, strong) UIColor *normalColor;

/*
 *** 轨道size
 */
@property (nonatomic, assign) CGSize trackSize;

/*
 *** 滑块size
 */
@property (nonatomic, assign) CGSize thumbSize;

/*
 *** 滑块背景图片
 */
@property (nonatomic, strong) UIImage *thumbImage;

// 刷新视图
- (void)reloadData:(CGFloat)value;


@end

