//
// 游戏 - 投注区 - 选注页面（Table）
//


#import "CFCGameBetPlayClassViewController.h"
#import "CFCGameBetPlayClassModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCGameBetPlayClassTableViewController : CFCGameBetPlayClassViewController

@property (nonatomic, strong) UITableView *tableView; // 表格

#pragma mark 投注表格 - 对投注表格进行配置（子类继承实现）
- (void)tableViewSettingRegisterInitialize:(UITableView *)tableView;
#pragma mark 投注表格 - 自定义投注表格的 UITableViewCell 的控件
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model;
#pragma mark 投注表格 - 自定义投注表格的 UITableViewCell 的高度
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model;
#pragma mark 投注表格 - 自定义投注表格的 SectionHeader 的视图
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section cellModel:(CFCGameBetPlayClassSectionModel *)model;
#pragma mark 投注表格 - 自定义投注表格的 SectionFooter 的视图
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section cellModel:(CFCGameBetPlayClassSectionModel *)model;
#pragma mark 投注表格 - 自定义投注表格的 SectionHeader 的高度
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section cellModel:(CFCGameBetPlayClassSectionModel *)model;
#pragma mark 投注表格 - 自定义投注表格的 SectionFooter 的高度
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section cellModel:(CFCGameBetPlayClassSectionModel *)model;

@end

NS_ASSUME_NONNULL_END
