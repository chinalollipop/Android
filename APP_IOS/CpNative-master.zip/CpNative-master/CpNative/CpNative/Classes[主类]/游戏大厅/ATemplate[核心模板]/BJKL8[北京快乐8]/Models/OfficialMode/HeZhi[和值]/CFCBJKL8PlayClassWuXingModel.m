//
// 游戏 - 投注区 - 官方模式 - 北京快乐8 - 和值 - 和值 - 五行
//

#import "CFCBJKL8PlayClassWuXingModel.h"

@implementation CFCBJKL8PlayClassWuXingModel

+ (NSMutableArray *) buildingDataModlesForSection1
{
    NSMutableArray<CFCBJKL8PlayClassWuXingModel *> *models = [NSMutableArray array];
    {
        NSArray<NSString *> *names = @[ @"金", @"木", @"水", @"火", @"土" ];
        NSArray<NSString *> *classNumbers = @[ @"0", @"1", @"2", @"3", @"4" ];
        for (int index = 0; index < names.count; index ++) {
            CFCBJKL8PlayClassWuXingModel *model = [[CFCBJKL8PlayClassWuXingModel alloc] init];
            // 名称
            [model setName:names[index]];
            [model setNameNormalFont:NAME_FONT_GAME_PLAY_MODEL_NUMBER_NORMAL];
            [model setNameSelectFont:NAME_FONT_GAME_PLAY_MODEL_NUMBER_SELECT];
            [model setNameNormalColor:NAME_COLOR_GAME_PLAY_MODEL_NORMAL];
            [model setNameSelectColor:NAME_COLOR_GAME_PLAY_MODEL_SELECT];
            [model setNameBackgroundColor:NAME_COLOR_GAME_PLAY_BACKGROUND_DEFAULT];
            // 赔率
            [model setOdds:ODDS_STRI_GAME_PLAY_MODEL_DEFAULT];
            [model setOddsNormalFont:ODDS_FONT_GAME_PLAY_MODEL_NORMAL];
            [model setOddsSelectFont:ODDS_FONT_GAME_PLAY_MODEL_SELECT];
            [model setOddsNormalColor:ODDS_COLOR_GAME_PLAY_MODEL_NORMAL];
            [model setOddsSelectColor:ODDS_COLOR_GAME_PLAY_MODEL_SELECT];
            [model setOddsBackgroundColor:ODDS_COLOR_GAME_PLAY_BACKGROUND_DEFAULT];
            // 号码
            [model setClassNumber:classNumbers[index]];
            [model setClassRemark:REMARK_STRI_GAME_PLAY_MODEL_DEFAULT];
            // 其它
            [model setType:CFCGameBetPlayClassItemType01];
            [model setIsSelected:GAME_PLAY_MODEL_SELECTED_DEFAULT];
            //
            [models addObject:model];
        }
    }
    return models;
}

@end


@implementation CFCBJKL8PlayClassWuXingSectionModel

+ (NSMutableArray *) buildingDataModles
{
    NSMutableArray<CFCBJKL8PlayClassWuXingSectionModel *> *models = [NSMutableArray array];
    {
        // 第一个分组
        CFCBJKL8PlayClassWuXingSectionModel *model1 = [[CFCBJKL8PlayClassWuXingSectionModel alloc] init];
        [model1 setTitle:@"五行"];
        [model1 setType:CFCGameBetPlayClassSectionTypeOfficial2];
        [model1 setColumnsCount:GAME_PLAY_MODEL_SECTION_COLUMN_N005];
        [model1 setIsShowHeader:GAME_PLAY_MODEL_SECTION_HEADER_SHOW_NO];
        [model1 setIsShowFooter:GAME_PLAY_MODEL_SECTION_FOOTER_SHOW_NO];
        [model1 setList:[CFCBJKL8PlayClassWuXingModel buildingDataModlesForSection1]];
        [models addObject:model1];
    }
    return models;
}

@end

