

#import "CFCGameBetPlayClassTableSectionFooterView.h"


@interface CFCGameBetPlayClassTableSectionFooterView ()

// 根容器组件
@property (nonnull, nonatomic, strong) UIView *rootContainerView;

// 第N个Section
@property (nonatomic, assign) NSInteger tableSection;

@end


@implementation CFCGameBetPlayClassTableSectionFooterView

- (instancetype)initWithFrame:(CGRect)frame tableSecion:(NSInteger)tableSection
{
    self = [super initWithFrame:frame];
    if (self) {
        _tableSection = tableSection;
        [self createView];
        [self setViewAtuoLayout];
    }
    return self;
}

- (void)createView
{
    // 根容器
    self.rootContainerView = [[UIView alloc] init];
    [self addSubview:self.rootContainerView];

}

- (void)setViewAtuoLayout
{
    // 根容器组件
    [self.rootContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(@0);
    }];
}


@end



