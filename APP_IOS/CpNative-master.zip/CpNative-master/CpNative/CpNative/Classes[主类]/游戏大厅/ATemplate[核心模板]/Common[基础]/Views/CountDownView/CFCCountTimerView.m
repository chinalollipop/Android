
#import "CFCCountTimerView.h"
#import "CFCCountTimerUtil.h"

@implementation CFCCountTimerVerticallyAlignedLabel

- (instancetype)init
{
    if (self = [super init]) {
        self.verticalAlignment = CFCCountTimerVerticalAlignmentCenter;
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        self.verticalAlignment = CFCCountTimerVerticalAlignmentCenter;
    }
    return self;
}

- (void)setVerticalAlignment:(CFCCountTimerVerticalAlignment)verticalAlignment
{
    _verticalAlignment = verticalAlignment;
    
    [self setNeedsDisplay];
}

- (CGRect)textRectForBounds:(CGRect)bounds limitedToNumberOfLines:(NSInteger)numberOfLines
{
    CGRect textRect = [super textRectForBounds:bounds limitedToNumberOfLines:numberOfLines];
    // 通过设定字体区域的Y值来调整垂直位置
    switch (self.verticalAlignment) {
        case CFCCountTimerVerticalAlignmentTop:
            textRect.origin.y = bounds.origin.y;
            break;
        case CFCCountTimerVerticalAlignmentCenter:
            textRect.origin.y = bounds.origin.y + (bounds.size.height - textRect.size.height) / 2.0 - bounds.size.height*0.05f;
            break;
        case CFCCountTimerVerticalAlignmentBottom:
            textRect.origin.y = bounds.origin.y + bounds.size.height - textRect.size.height;
            break;
    }
    return textRect;
}

- (void)drawTextInRect:(CGRect)rect
{
    CGRect actualRect = [self textRectForBounds:rect limitedToNumberOfLines:self.numberOfLines];
    [super drawTextInRect:actualRect];
}

@end


@interface CFCCountTimerView ()
@property (nonatomic, strong) UILabel *hourLabel;
@property (nonatomic, strong) UILabel *minuteLabel;
@property (nonatomic, strong) UILabel *secondLabel;
@property (nonatomic, strong) CFCCountTimerVerticallyAlignedLabel *colonHMLabel;
@property (nonatomic, strong) CFCCountTimerVerticallyAlignedLabel *colonMSLabel;
@end


@implementation CFCCountTimerView

- (instancetype)init
{
    if (self = [super init]) {
        // 圆角
        CGFloat cornerRadius = 3.0f;
        // 设置
        self.textColor = COLOR_SYSTEM_MAIN_FONT_ASSIST_DEFAULT;
        self.textFont = [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(13.0f)];
        self.colonColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;
        self.colonFont = [UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(13.0f)];
        self.textBackColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;
        // 小时
        self.hourLabel = [[UILabel alloc] init];
        self.hourLabel.text = @"00";
        self.hourLabel.font = self.textFont;
        self.hourLabel.textColor = self.textColor;
        self.hourLabel.backgroundColor = self.textBackColor;
        self.hourLabel.layer.masksToBounds = YES;
        self.hourLabel.layer.cornerRadius = cornerRadius;
        self.hourLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.hourLabel];
        // 冒号
        self.colonHMLabel = [[CFCCountTimerVerticallyAlignedLabel alloc] init];
        self.colonHMLabel.text = @":";
        self.colonHMLabel.font = self.colonFont;
        self.colonHMLabel.textColor = self.colonColor;
        self.colonHMLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.colonHMLabel];
        // 分钟
        self.minuteLabel = [[UILabel alloc] init];
        self.minuteLabel.text = @"00";
        self.minuteLabel.font = self.textFont;
        self.minuteLabel.textColor = self.textColor;
        self.minuteLabel.backgroundColor = self.textBackColor;
        self.minuteLabel.layer.masksToBounds = YES;
        self.minuteLabel.layer.cornerRadius = cornerRadius;
        self.minuteLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.minuteLabel];
        // 冒号
        self.colonMSLabel = [[CFCCountTimerVerticallyAlignedLabel alloc] init];
        self.colonMSLabel.text = @":";
        self.colonMSLabel.font = self.colonFont;
        self.colonMSLabel.textColor = self.colonColor;
        self.colonMSLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.colonMSLabel];
        // 秒数
        self.secondLabel = [[UILabel alloc] init];
        self.secondLabel.text = @"00";
        self.secondLabel.font = self.textFont;
        self.secondLabel.textColor = self.textColor;
        self.secondLabel.backgroundColor = self.textBackColor;
        self.secondLabel.layer.masksToBounds = YES;
        self.secondLabel.layer.cornerRadius = cornerRadius;
        self.secondLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.secondLabel];
        // 冒号
        [self.colonHMLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.height.equalTo(self.mas_height);
        }];
        // 水平
        [self.hourLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self);
            make.centerY.equalTo(@[self.colonHMLabel, self.minuteLabel, self.colonMSLabel, self.secondLabel]);
            make.size.equalTo(@[self.minuteLabel, self.secondLabel]);
            make.height.equalTo(self.mas_height);
            make.width.equalTo(self.mas_height);
        }];
        [self distributeSpacingHorizontallyWith:@[self.hourLabel, self.colonHMLabel, self.minuteLabel, self.colonMSLabel, self.secondLabel]];
    }
    
    return self;
}

- (void)setTextFont:(UIFont *)textFont
{
    _textFont = textFont;
    self.hourLabel.font = self.textFont;
    self.minuteLabel.font = self.textFont;
    self.secondLabel.font = self.textFont;
}

- (void)setTextColor:(UIColor *)textColor
{
    _textColor = textColor;
    self.hourLabel.textColor = self.textColor;
    self.minuteLabel.textColor = self.textColor;
    self.secondLabel.textColor = self.textColor;
}

- (void)setColonFont:(UIFont *)colonFont
{
    _colonFont = colonFont;
    self.colonHMLabel.font = self.colonFont;
    self.colonMSLabel.font = self.colonFont;
}

- (void)setColonColor:(UIColor *)colonColor
{
    _colonColor = colonColor;
    self.colonHMLabel.textColor = self.colonColor;
    self.colonMSLabel.textColor = self.colonColor;
}

- (void)setTextBackColor:(UIColor *)textBackColor
{
    _textBackColor = textBackColor;
    self.hourLabel.backgroundColor = self.textBackColor;
    self.minuteLabel.backgroundColor = self.textBackColor;
    self.secondLabel.backgroundColor = self.textBackColor;
}

- (void)setFinishDate:(NSDate *)finishDate
         andBeginDate:(NSDate *)beginDate
               gameId:(NSString *)gameId
             gameName:(NSString *)gameName
       gameIdentifier:(NSString *)gameIdentifier
{
    WEAKSELF(weakSelf);
    [[CFCCountTimerUtil sharedCountTimerUtil] countDownWithBeginDate:beginDate finishDate:finishDate gameId:gameId gameName:gameName gameIdentifier:gameIdentifier hourLabel:self.hourLabel minuteLabel:self.minuteLabel secondLabel:self.secondLabel block:^(NSInteger timeInterval, NSInteger day, NSInteger hour, NSInteger minute, NSInteger second) {
        
        if(timeInterval <= 0) {
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if (weakSelf.countDownTimerCompleteBlock) {
                    weakSelf.countDownTimerCompleteBlock();
                }
                
                if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(doAfterCountDownTimerComplete)]) {
                    [weakSelf.delegate doAfterCountDownTimerComplete];
                }
                
            });
        }
        
    }];
}

- (void)dealloc
{
    [self timer_cancel];
}

- (void)timer_cancel
{
    [[CFCCountTimerUtil sharedCountTimerUtil] destoryTimer];
}

@end






