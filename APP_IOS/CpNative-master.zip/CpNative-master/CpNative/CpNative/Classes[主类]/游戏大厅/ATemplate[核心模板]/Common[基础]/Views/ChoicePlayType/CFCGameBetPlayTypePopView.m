//
//  游戏 - 投注页面头部区域 - 玩法选择
//

#import "CFCGameBetPlayTypePopView.h"
//
#import "CFCPlayStyleTitleTableViewCell.h"
#import "CFCPlayTypeTitleModel.h"
//
#import "CFCPlayStyleButtonTableViewCell.h"
#import "CFCPlayTypeButtonModel.h"
//
#import "CFCPlayTypeContentFirstTableViewCell.h"
#import "CFCPlayTypeContentFirstModel.h"
//
#import "CFCPlayTypeContentSecondTableViewCell.h"
#import "CFCPlayTypeContentSecondModel.h"


@interface CFCGameBetPlayTypePopView () <UITableViewDelegate, UITableViewDataSource, CFCPlayStyleButtonTableViewCellDelegate, CFCPlayTypeContentFirstTableViewCellDelegate, CFCPlayTypeContentSecondTableViewCellDelegate>
@property (nonatomic, strong) UIButton *backCoverAlphaButton;
@property (nonatomic, strong) UIView *container;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *tableData;
@property (nonatomic, assign) CGFloat animateDuration;
@end

@implementation CFCGameBetPlayTypePopView

+ (instancetype)shareGamePlayTypePopView:(CGFloat)heightOfBottomAreaMainView
{
    static CFCGameBetPlayTypePopView *_singetonInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _singetonInstance = [[super allocWithZone:NULL] initWithFrame:[UIScreen mainScreen].bounds heightOfBottomAreaMainView:heightOfBottomAreaMainView];
    });
    return _singetonInstance;
}

- (instancetype)initWithFrame:(CGRect)frame heightOfBottomAreaMainView:(CGFloat)heightOfBottomAreaMainView
{
    if (self = [super initWithFrame:frame]) {
        _heightOfBottomAreaMainView = heightOfBottomAreaMainView;
        [self createViewAtuoLayout];
    }
    return self;
}

#pragma mark 添加控件
- (void)createViewAtuoLayout
{
    // 动画时间
    _animateDuration = 0.2f;
    
    // 背景按钮
    [self addSubview:self.backCoverAlphaButton];
    [self.backCoverAlphaButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    // 表格容器
    CGFloat y = STATUS_NAVIGATION_BAR_HEIGHT + SCROLL_GAME_SUB_TAB_HEIGHT + CFC_GAME_PLAY_OFFICIAL_SCROLL_TABLEVIEW_HEADER_DRAW_RESULTS_HEIGHT;
    CGRect frame_container = CGRectMake(0, y, self.width, self.height-y-self.heightOfBottomAreaMainView);
    [self addSubview:self.container];
    [self.container setFrame:frame_container];
    
    // 表格控件
    CGRect frame_table = CGRectMake(0, 0, self.width, self.height-y-self.heightOfBottomAreaMainView);
    [self.container addSubview:self.tableView];
    [self.tableView setFrame:frame_table];
}

- (void)show
{
    // 处理数据
    {
        _tableData = [NSMutableArray array];
        
        // 初始选中
        __block NSArray<CFCGameBetPlayTypeGroupModel *> *secondMenuChildren = nil;
        NSArray<CFCGameBetPlayTypeModel *> *firstMenuChildren = [NSArray<CFCGameBetPlayTypeModel *> arrayWithArray:self.playTypeModels];
        [firstMenuChildren enumerateObjectsUsingBlock:^(CFCGameBetPlayTypeModel * _Nonnull obj1, NSUInteger idx1, BOOL * _Nonnull stop1) {
            if ([self.selectedTypeIdentifier isEqualToString:obj1.code]) {
                obj1.isSelected = YES;
                secondMenuChildren = [NSArray<CFCGameBetPlayTypeGroupModel *> arrayWithArray:obj1.childrenGroup];
                [secondMenuChildren enumerateObjectsUsingBlock:^(CFCGameBetPlayTypeGroupModel * _Nonnull obj2, NSUInteger idx2, BOOL * _Nonnull stop2) {
                    if ([self.selectedGroupIdentifier isEqualToString:obj2.code]) {
                        obj2.isSelected = YES;
                        [obj2.childrenClass enumerateObjectsUsingBlock:^(CFCGameBetPlayTypeClassModel * _Nonnull obj3, NSUInteger idx3, BOOL * _Nonnull stop3) {
                            if ([self.selectedClassIdentifier isEqualToString:obj3.code]) {
                                obj3.isSelected = YES;
                            } else {
                                obj3.isSelected = NO;
                            }
                        }];
                    } else {
                        obj2.isSelected = NO;
                        [obj2.childrenClass enumerateObjectsUsingBlock:^(CFCGameBetPlayTypeClassModel * _Nonnull obj3, NSUInteger idx3, BOOL * _Nonnull stop3) {
                            obj3.isSelected = NO;
                        }];
                    }
                }];
            } else {
                obj1.isSelected = NO;
            }
        }];
        
        // 玩法数据
        {
            // 样式变更
            UIColor *titleColor = COLOR_HEXSTRING(@"#FFFFFF");
            
            // 游戏玩法 - 玩法标题
            CFCPlayTypeTitleModel *modle_title = [CFCPlayTypeTitleModel new];
            modle_title.title = @"玩法选择";
            modle_title.titleColor = titleColor;
            modle_title.titleFont = [UIFont boldItalicSystemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)];
            [_tableData addObject:@[modle_title]];
            
            // 游戏玩法 - 玩法分类 - 五星、一星
            CFCPlayTypeContentFirstModel *model_first = [CFCPlayTypeContentFirstModel new];
            model_first.menuChildren = firstMenuChildren;
            [_tableData addObject:@[model_first]];
            
            // 游戏玩法 - 具体分类 - 直选、组选
            NSMutableArray<CFCPlayTypeContentSecondModel *> *model_second = [NSMutableArray<CFCPlayTypeContentSecondModel *> array];
            NSString *maxLengthNameString = [self itemNameOfMaxLengthInGameBetPlayTypeGroupModelArray:secondMenuChildren];
            for (CFCGameBetPlayTypeGroupModel *groupModel in secondMenuChildren) {
                CFCPlayTypeContentSecondModel *secondModel = [CFCPlayTypeContentSecondModel new];
                secondModel.menuGroupModel = groupModel;
                secondModel.maxLengthNameString = maxLengthNameString;
                [model_second addObject:secondModel];
            }
            [_tableData addObject:[NSArray<CFCPlayTypeContentSecondModel *> arrayWithArray:model_second]];
            
            // 游戏玩法 - 确定按钮
            CFCPlayTypeButtonModel *modle_button = [CFCPlayTypeButtonModel new];
            modle_button.title = @"确  定";
            modle_button.titleColor = titleColor;
            modle_button.titleFont = [UIFont boldItalicSystemFontOfSize:CFC_AUTOSIZING_FONT(15.0f)];
            [_tableData addObject:@[modle_button]];
        }

        // 重新刷新加载
        [self.tableView reloadData];
    }
    
    // 上往下落下
    {
        WEAKSELF(weakSelf);
        CGRect tableViewLayerFrame = self.container.bounds;
        tableViewLayerFrame.origin.y = -tableViewLayerFrame.size.height;
        self.tableView.layer.frame = tableViewLayerFrame;
        [UIView animateWithDuration:self.animateDuration animations:^{
            weakSelf.tableView.layer.frame = weakSelf.container.bounds;
        }];
    }
    
    // 显示内容
    {
        UIWindow *window = [UIApplication sharedApplication].keyWindow;
        [window addSubview:self];
    }
}

- (void)dismiss
{
    WEAKSELF(weakSelf);
    [UIView animateWithDuration:self.animateDuration animations:^{
        CGRect tableViewLayerFrame = self.container.bounds;
        tableViewLayerFrame.origin.y = -tableViewLayerFrame.size.height;
        weakSelf.tableView.layer.frame = tableViewLayerFrame;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
    
    if (self.afterDismissBlock) {
        self.afterDismissBlock();
    }
}


#pragma mark -
#pragma mark 事件处理

- (void)doBackCoverAlphaButtonClickAction
{
    [self dismiss];
}

- (void)doTableViewBackgroundViewAction
{
    [self dismiss];
}


#pragma mark - Getter/Setter


- (UIButton *)backCoverAlphaButton
{
    if(!_backCoverAlphaButton) {
        _backCoverAlphaButton = [[UIButton alloc] init];
        [_backCoverAlphaButton setAlpha:0.02f];
        [_backCoverAlphaButton setEnabled:YES];
        [_backCoverAlphaButton setBackgroundColor:[UIColor whiteColor]];
        [_backCoverAlphaButton addTarget:self action:@selector(doBackCoverAlphaButtonClickAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _backCoverAlphaButton;
}

- (UIView *)container
{
    if(!_container) {
        _container = [[UIView alloc] init];
        [_container.layer setMasksToBounds:YES];
        [_container setBackgroundColor:[UIColor clearColor]];
    }
    return _container;
}

- (UITableView *)tableView
{
    if(!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero
                                                  style:UITableViewStyleGrouped];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.fd_debugLogEnabled = YES;
        _tableView.sectionHeaderHeight = FLOAT_MIN;
        _tableView.sectionFooterHeight = FLOAT_MIN;
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, FLOAT_MIN)];
        _tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, FLOAT_MIN)];
        
        // 设置背景
        UIView *backgroundView = [[UIView alloc] init];
        [backgroundView setAlpha:0.02f];
        [backgroundView setBackgroundColor:[UIColor whiteColor]];
        UITapGestureRecognizer *tapGestureBackgroundView = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doTableViewBackgroundViewAction)];
        [backgroundView addGestureRecognizer:tapGestureBackgroundView];
        [_tableView setBackgroundView:backgroundView];
        
        // 表格设置
        [self tableViewSetting];
    }
    return _tableView;
}

- (void)tableViewSetting
{
    [self.tableView registerClass:[CFCPlayStyleTitleTableViewCell class]
           forCellReuseIdentifier:CELL_IDENTIFIER_GAME_PLAY_TYPE_TITLE_TABLE_VIEW_CELL];

    [self.tableView registerClass:[CFCPlayStyleButtonTableViewCell class]
           forCellReuseIdentifier:CELL_IDENTIFIER_GAME_PLAY_TYPE_BUTTON_TABLE_VIEW_CELL];

    [self.tableView registerClass:[CFCPlayTypeContentFirstTableViewCell class]
           forCellReuseIdentifier:CELL_IDENTIFIER_GAME_PLAY_TYPE_CONTENT_FRIST_TABLE_VIEW_CELL];
    
    [self.tableView registerClass:[CFCPlayTypeContentSecondTableViewCell class]
           forCellReuseIdentifier:CELL_IDENTIFIER_GAME_PLAY_TYPE_CONTENT_SECOND_TABLE_VIEW_CELL];
}

#pragma mark - TableView Data Source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (self.tableData && self.tableData.count > 0) {
        return self.tableData.count;
    }
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.tableData && self.tableData.count > 0 && self.tableData.count > section) {
        if ([self.tableData[section] isKindOfClass:[NSArray class]]) {
            NSArray *group = self.tableData[section];
            return group.count;
        }
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (!self.tableData
        || self.tableData.count <= 0
        || self.tableData.count <= indexPath.section
        || ![self.tableData[indexPath.section] isKindOfClass:[NSArray class]]) {
        return nil;
    }
    
    if (0 == indexPath.section) {
        CFCPlayStyleTitleTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_GAME_PLAY_TYPE_TITLE_TABLE_VIEW_CELL];
        if (!cell) {
            cell = [[CFCPlayStyleTitleTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_GAME_PLAY_TYPE_TITLE_TABLE_VIEW_CELL];
        }
        cell.model = self.tableData[indexPath.section][indexPath.row];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    } else if (1 == indexPath.section) {
        CFCPlayTypeContentFirstTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_GAME_PLAY_TYPE_CONTENT_FRIST_TABLE_VIEW_CELL];
        if (!cell) {
            cell = [[CFCPlayTypeContentFirstTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_GAME_PLAY_TYPE_CONTENT_FRIST_TABLE_VIEW_CELL];
        }
        cell.delegate = self;
        cell.indexPath = indexPath;
        cell.model = self.tableData[indexPath.section][indexPath.row];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    } else if (2 == indexPath.section) {
        CFCPlayTypeContentSecondTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_GAME_PLAY_TYPE_CONTENT_SECOND_TABLE_VIEW_CELL];
        if (!cell) {
            cell = [[CFCPlayTypeContentSecondTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_GAME_PLAY_TYPE_CONTENT_SECOND_TABLE_VIEW_CELL];
        }
        cell.delegate = self;
        cell.indexPath = indexPath;
        cell.model = self.tableData[indexPath.section][indexPath.row];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    } else if (3 == indexPath.section) {
        CFCPlayStyleButtonTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_GAME_PLAY_TYPE_BUTTON_TABLE_VIEW_CELL];
        if (!cell) {
            cell = [[CFCPlayStyleButtonTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_GAME_PLAY_TYPE_BUTTON_TABLE_VIEW_CELL];
        }
        cell.delegate = self;
        cell.model = self.tableData[indexPath.section][indexPath.row];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (!self.tableData
        || self.tableData.count <= 0
        || self.tableData.count <= indexPath.section
        || ![self.tableData[indexPath.section] isKindOfClass:[NSArray class]]) {
        return FLOAT_MIN;
    }
    
    if (0 == indexPath.section) {
        return [self.tableView fd_heightForCellWithIdentifier:CELL_IDENTIFIER_GAME_PLAY_TYPE_TITLE_TABLE_VIEW_CELL cacheByIndexPath:indexPath configuration:^(CFCPlayStyleTitleTableViewCell *cell) {
            cell.model = self.tableData[indexPath.section][indexPath.row];
        }];
    } else if (1 == indexPath.section) {
        return [self.tableView fd_heightForCellWithIdentifier:CELL_IDENTIFIER_GAME_PLAY_TYPE_CONTENT_FRIST_TABLE_VIEW_CELL cacheByIndexPath:indexPath configuration:^(CFCPlayTypeContentFirstTableViewCell *cell) {
            cell.model = self.tableData[indexPath.section][indexPath.row];
        }];
    } else if (2 == indexPath.section) {
        return [self.tableView fd_heightForCellWithIdentifier:CELL_IDENTIFIER_GAME_PLAY_TYPE_CONTENT_SECOND_TABLE_VIEW_CELL cacheByIndexPath:indexPath configuration:^(CFCPlayTypeContentSecondTableViewCell *cell) {
            cell.model = self.tableData[indexPath.section][indexPath.row];
        }];
    } else if (3 == indexPath.section) {
        return [self.tableView fd_heightForCellWithIdentifier:CELL_IDENTIFIER_GAME_PLAY_TYPE_BUTTON_TABLE_VIEW_CELL cacheByIndexPath:indexPath configuration:^(CFCPlayStyleButtonTableViewCell *cell) {
            cell.model = self.tableData[indexPath.section][indexPath.row];
        }];
    }
    
    return FLOAT_MIN;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    CGFloat height = 0.01f;
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableView.frame.size.width, height)];
    [headerView setBackgroundColor:COLOR_TABLEVIEW_HEADER_VIEW_BACKGROUND_DEFAULT];
    
    return headerView;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    CGFloat height = 0.01f;
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableView.frame.size.width, height)];
    [footerView setBackgroundColor:COLOR_TABLEVIEW_FOOTER_VIEW_BACKGROUND_DEFAULT];
    
    return footerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return FLOAT_MIN;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return FLOAT_MIN;
}

#pragma mark -
#pragma mark 数据处理 - 返回当前长度最大的名称
- (NSString *)itemNameOfMaxLengthInGameBetPlayTypeGroupModelArray:(NSArray<CFCGameBetPlayTypeGroupModel *> *)childrenGroup
{
    __block NSString *maxItemNameString = @"";
    __block NSInteger maxItemNameCount = 0;
    [childrenGroup enumerateObjectsUsingBlock:^(CFCGameBetPlayTypeGroupModel * _Nonnull model, NSUInteger idx, BOOL * _Nonnull stop) {
        if (model.name.length > maxItemNameCount) {
            maxItemNameString = model.name;
        }
    }];
    return maxItemNameString;
}


#pragma mark -
#pragma mark 事件处理 - 确定按钮 - CFCPlayStyleButtonTableViewCellDelegate
- (void)didSelectPlayTypeButtonAction
{
    WEAKSELF(weakSelf);
    __block CFCGameBetPlayTypeModel *selectedPlayTypeModel = nil;
    __block CFCGameBetPlayTypeGroupModel *selectedPlayTypeGroupModel = nil;
    __block CFCGameBetPlayTypeClassModel *selectedPlayTypeClassModel = nil;
    NSArray<CFCGameBetPlayTypeModel *> *firstMenuChildren = [NSArray<CFCGameBetPlayTypeModel *> arrayWithArray:self.playTypeModels];
    [firstMenuChildren enumerateObjectsUsingBlock:^(CFCGameBetPlayTypeModel * _Nonnull obj1, NSUInteger idx1, BOOL * _Nonnull stop1) {
        if (obj1.isSelected) {
            selectedPlayTypeModel = obj1;
            weakSelf.selectedTypeIdentifier = obj1.code;
            [obj1.childrenGroup enumerateObjectsUsingBlock:^(CFCGameBetPlayTypeGroupModel * _Nonnull obj2, NSUInteger idx2, BOOL * _Nonnull stop2) {
                if (obj2.isSelected) {
                    selectedPlayTypeGroupModel = obj2;
                    weakSelf.selectedGroupIdentifier = obj2.code;
                    [obj2.childrenClass enumerateObjectsUsingBlock:^(CFCGameBetPlayTypeClassModel * _Nonnull obj3, NSUInteger idx3, BOOL * _Nonnull stop3) {
                        if (obj3.isSelected) {
                            selectedPlayTypeClassModel = obj3;
                            weakSelf.selectedClassTitleName = obj3.name;
                            weakSelf.selectedClassIdentifier = obj3.code;
                            *stop3 = YES;
                        }
                    }];
                    *stop2 = YES;
                }
            }];
            *stop1 = YES;
        }
    }];
    
    // 验证玩法的页面是否存在
    if (self.delegate && [self.delegate respondsToSelector:@selector(canSelectedGameIdentifier:
                                                                     selectedTypeIdentifier:
                                                                     selectedGroupIdentifier:
                                                                     selectedClassIdentifier:
                                                                     selectedClassTitleName:)]) {
        if ([self.delegate canSelectedGameIdentifier:self.selectedGameIdentifier
                              selectedTypeIdentifier:self.selectedTypeIdentifier
                             selectedGroupIdentifier:self.selectedGroupIdentifier
                             selectedClassIdentifier:self.selectedClassIdentifier
                              selectedClassTitleName:self.selectedClassTitleName]) {
            [self dismiss];
        } else {
            [CFCProgressAlertUtil showMessage:@"玩法页面不存在，请选择其它玩法！" toView:self];
            return;
        }
    }
    
    // 玩法页面存在则切换切换
    if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectedGameIdentifier:
                                                                     selectedTypeIdentifier:
                                                                     selectedGroupIdentifier:
                                                                     selectedClassIdentifier:
                                                                     selectedClassTitleName:
                                                                     selectedPlayTypeModel:
                                                                     selectedPlayTypeGroupModel:
                                                                     selectedPlayTypeClassModel:)]) {
        [self.delegate didSelectedGameIdentifier:self.selectedGameIdentifier
                          selectedTypeIdentifier:self.selectedTypeIdentifier
                         selectedGroupIdentifier:self.selectedGroupIdentifier
                         selectedClassIdentifier:self.selectedClassIdentifier
                          selectedClassTitleName:self.selectedClassTitleName
                           selectedPlayTypeModel:selectedPlayTypeModel
                      selectedPlayTypeGroupModel:selectedPlayTypeGroupModel
                      selectedPlayTypeClassModel:selectedPlayTypeClassModel];
    }
}

#pragma mark 事件处理 - 一级分类 - CFCPlayTypeContentFirstTableViewCellDelegate
- (void)didSelectPlayTypeContentFirstModelAtIndexPath:(NSIndexPath *)indexPath
                                     playTypeTagIndex:(NSInteger)playTypeTagIndex
                                        playTypeModel:(CFCGameBetPlayTypeModel *)playTypeModel
{
    // 游戏玩法 - 具体分类 - 直选、组选
    NSMutableArray<CFCPlayTypeContentSecondModel *> *model_second = [NSMutableArray<CFCPlayTypeContentSecondModel *> array];
    NSString *maxLengthNameString = [self itemNameOfMaxLengthInGameBetPlayTypeGroupModelArray:playTypeModel.childrenGroup];
    for (CFCGameBetPlayTypeGroupModel *groupModel in playTypeModel.childrenGroup) {
        CFCPlayTypeContentSecondModel *secondModel = [CFCPlayTypeContentSecondModel new];
        secondModel.menuGroupModel = groupModel;
        secondModel.maxLengthNameString = maxLengthNameString;
        [model_second addObject:secondModel];
    }
    [_tableData replaceObjectAtIndex:2 withObject:[NSArray<CFCPlayTypeContentSecondModel *> arrayWithArray:model_second]];
    
    // 刷新表格数据
    [self.tableView reloadData];
}

#pragma mark 事件处理 - 二级分类 - CFCPlayTypeContentSecondTableViewCellDelegate
- (void)didSelectPlayTypeContentSecondModelAtIndexPath:(NSIndexPath *)indexPath
                                    playTypeClassIndex:(NSInteger)playTypeClassIndex
                                    playTypeClassModel:(CFCGameBetPlayTypeClassModel *)playTypeClassModel
{
    // 游戏玩法 - 具体分类 - 直选、组选
    NSMutableArray<CFCPlayTypeContentSecondModel *> *secondModels = [self.tableData objectAtIndex:indexPath.section];
    [secondModels enumerateObjectsUsingBlock:^(CFCPlayTypeContentSecondModel * _Nonnull obj1, NSUInteger idx1, BOOL * _Nonnull stop1) {
        if (indexPath.row == idx1) {
            obj1.menuGroupModel.isSelected = YES;
            [obj1.menuGroupModel.childrenClass enumerateObjectsUsingBlock:^(CFCGameBetPlayTypeClassModel * _Nonnull obj2, NSUInteger idx2, BOOL * _Nonnull stop2) {
                if (playTypeClassIndex == idx2) {
                    obj2.isSelected = YES;
                } else {
                    obj2.isSelected = NO;
                }
            }];
        } else {
            obj1.menuGroupModel.isSelected = NO;
            [obj1.menuGroupModel.childrenClass enumerateObjectsUsingBlock:^(CFCGameBetPlayTypeClassModel * _Nonnull obj2, NSUInteger idx2, BOOL * _Nonnull stop2) {
                obj2.isSelected = NO;
            }];
        }
    }];
    
    // 刷新表格数据
    [self.tableView reloadData];
}


@end

