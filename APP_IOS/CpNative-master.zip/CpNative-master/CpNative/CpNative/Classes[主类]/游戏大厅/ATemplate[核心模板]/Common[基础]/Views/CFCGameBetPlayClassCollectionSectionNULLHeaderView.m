

#import "CFCGameBetPlayClassCollectionSectionNULLHeaderView.h"

// Section Header Identifier
NSString * const CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_COLLECTION_SECTION_NULL_HEADER = @"CFCGameBetPlayClassCollectionSectionNULLHeaderIdentifier";

@implementation CFCGameBetPlayClassCollectionSectionNULLHeaderView

@end
