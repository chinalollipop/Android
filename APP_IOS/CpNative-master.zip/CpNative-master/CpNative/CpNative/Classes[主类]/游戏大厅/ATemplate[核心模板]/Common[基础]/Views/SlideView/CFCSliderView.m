
#define kSCREEN_WIDTH    [[UIScreen mainScreen] bounds].size.width
#define kSCREEN_HEIGHT   [[UIScreen mainScreen] bounds].size.height


#import "CFCSliderView.h"
#import "CFCTrackView.h"


@interface CFCSliderView ()

@property (nonatomic, strong) UIView *normalTrack;
@property (nonatomic, strong) CFCTrackView *highLightTrack;
@property (nonatomic, strong) UIView *slider;

@end


@implementation CFCSliderView

- (void)layoutSubviews {
    [super layoutSubviews];
    [self setupViewUI];
}

- (void)setupViewUI {

    [self addSubview:self.highLightTrack];
    [self addSubview:self.normalTrack];
    
    [self addSubview:self.slider];
    
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(sliderChangeValue:)];
    [self.slider addGestureRecognizer:panGesture];
}


- (void)sliderChangeValue:(UIPanGestureRecognizer *)panChange
{
    CGPoint point = [panChange translationInView:self]; // slider相对位移
    static CGPoint center; // slider中心坐标
    
    if (panChange.state == UIGestureRecognizerStateBegan) {
        center = panChange.view.center;
        // 放大
        panChange.view.transform = CGAffineTransformIdentity;
        [UIView animateKeyframesWithDuration:0.1 delay:0 options:0 animations: ^{
            panChange.view.transform = CGAffineTransformMakeScale(2.5, 2.5);
        } completion:nil];
    } else if (panChange.state == UIGestureRecognizerStateEnded) {
        // 缩小
        panChange.view.transform = CGAffineTransformIdentity;
        [UIView animateKeyframesWithDuration:0.1 delay:0 options:0 animations: ^{
            panChange.view.transform = CGAffineTransformMakeScale(1.0, 1.0);
        } completion:nil];
    }
    
    CGFloat slider_x = center.x + point.x;
    
    if (slider_x <= (self.width-self.trackSize.width)*0.5) {
        slider_x = (self.width-self.trackSize.width)*0.5;
    } else if (slider_x >= (self.width-self.trackSize.width)*0.5+self.trackSize.width){
        slider_x = (self.width-self.trackSize.width)*0.5+self.trackSize.width;
    }
    
    CGFloat x = slider_x;
    if (slider_x <= ((self.width-self.trackSize.width)*0.5+panChange.view.width*0.5f)) {
        x = (self.width-self.trackSize.width)*0.5+panChange.view.width*0.5f;
    } else if (slider_x >= (self.width-self.trackSize.width)*0.5+self.trackSize.width-panChange.view.width*0.5f){
        x = (self.width-self.trackSize.width)*0.5+self.trackSize.width-panChange.view.width*0.5f;
    }
    panChange.view.center = CGPointMake(x, center.y);

    self.normalTrack.frame = CGRectMake(slider_x, (self.height-self.trackSize.height)/2.0f, self.trackSize.width-slider_x+(self.width-self.trackSize.width)*0.5, self.trackSize.height);
    
    [self valueChangeWithFloat:slider_x];
}

// 通过滑块移动获取当前选择Value
- (void)valueChangeWithFloat:(CGFloat)num
{
    CGFloat value = (num - (self.width-self.trackSize.width)*0.5)/self.trackSize.width*(self.maxValue-self.minValue);
    
    self.value = value;
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(slider:changeValue:)]) {
        NSString *str_value = [NSString stringWithFormat:@"%.f",value];
        [self.delegate slider:self changeValue:str_value];
    }
}

- (void)reloadData:(CGFloat)value
{
    self.value = value;
    
    self.normalTrack.frame = CGRectMake((self.width-self.trackSize.width)*0.5+self.trackSize.width*(value/(self.maxValue-self.minValue)), (self.height-self.trackSize.height)/2.0f, self.trackSize.width*(1- value/(self.maxValue-self.minValue)), self.trackSize.height);
    
    CGFloat x = CGRectGetMinX(self.normalTrack.frame);
    if (x <= self.slider.width*0.5f) {
        x = (self.width-self.trackSize.width)*0.5+self.slider.width*0.5f;
    } else if (x >= (self.width-self.trackSize.width)*0.5+self.trackSize.width-self.slider.width*0.5f){
        x = (self.width-self.trackSize.width)*0.5+self.trackSize.width-self.slider.width*0.5f;
    }
    self.slider.center = CGPointMake(x, self.highLightTrack.center.y);
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(slider:changeValue:)]) {
        NSString *str_value = [NSString stringWithFormat:@"%.f",value];
        [self.delegate slider:self changeValue:str_value];
    }
}

#pragma mark -- lazy 懒加载所有的视图
- (UIView *)slider {
    if (!_slider) {
        _slider = [[UIView alloc] init];
        CGRect frame = _slider.frame;
        frame.size = self.thumbSize;
        _slider.frame = frame;
        
        CGFloat x = CGRectGetMinX(self.normalTrack.frame);
        if (x <= 0) {
            x = (self.width-self.trackSize.width)*0.5+self.slider.width*0.5f;
        } else if (x >= (self.width-self.trackSize.width)*0.5+self.trackSize.width-self.slider.width*0.5f){
            x = (self.width-self.trackSize.width)*0.5+self.trackSize.width-self.slider.width*0.5f;
        }
        _slider.center = CGPointMake(x, self.highLightTrack.center.y);
        
        _slider.layer.cornerRadius = self.thumbSize.height/2;
        _slider.userInteractionEnabled = YES;
        
        if (self.thumbImage) {
            UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(_slider.frame), CGRectGetHeight(_slider.frame))];
            imageView.image = self.thumbImage;
            [_slider addSubview:imageView];
        } else {
            _slider.backgroundColor = [UIColor blueColor];
        }
    }
    return _slider;
}

- (UIView *)normalTrack{
    if (!_normalTrack) {
        _normalTrack = [[UIView alloc] initWithFrame:CGRectMake((self.width-self.trackSize.width)*0.5+self.trackSize.width*(self.value/(self.maxValue-self.minValue)), (self.height-self.trackSize.height)/2.0f, self.trackSize.width*(1- self.value/(self.maxValue-self.minValue)), self.trackSize.height)];
        _normalTrack.backgroundColor = self.normalColor;
        _normalTrack.layer.cornerRadius = self.trackSize.height/2;
    }
    return _normalTrack;
}

- (CFCTrackView *)highLightTrack {
    if (!_highLightTrack) {
        _highLightTrack = [[CFCTrackView alloc] initWithFrame:CGRectMake((self.width-self.trackSize.width)*0.5, (self.height-self.trackSize.height)/2.0f, self.trackSize.width, self.trackSize.height)];
        _highLightTrack.startPoint = CGPointMake(0, 0);
        _highLightTrack.endPoint = CGPointMake(1, 0);
        _highLightTrack.colors = self.trackColors;
    }
    return _highLightTrack;
}

- (CGFloat)minValue {
    if (_minValue == 0) {
        _minValue = 0;
    }
    return _minValue;
}

- (CGFloat)maxValue {
    if (_maxValue == 0) {
        _maxValue = 1000;
    }
    return _maxValue;
}

- (CGFloat)value {
    if (_value == 0) {
        _value = 0;
    } else if (_value > _maxValue){
        return _maxValue;
    } else if (_value < _minValue){
        return _minValue;
    }
    return _value;
}

- (NSArray *)trackColors {
    if (!_trackColors || _trackColors.count < 2) {
        _trackColors = @[(__bridge id)[UIColor colorWithRed:255/255.f green:140/255.f blue:45/255.f alpha:1.0].CGColor, (__bridge id)[UIColor colorWithRed:255/255.f green:90/255.f blue:70/255.f alpha:1.0].CGColor];
    }
    return _trackColors;
}

- (UIColor *)normalColor {
    if (_normalColor == nil) {
        _normalColor = [UIColor colorWithRed:153/255.f green:153/255.f blue:153/255.f alpha:1.0];
    }
    return _normalColor;
}

- (CGSize)trackSize {
    if (![NSValue valueWithCGSize:_trackSize]) {
        _trackSize = CGSizeMake(self.width-40, 10);
    }
    return _trackSize;
}

- (CGSize)thumbSize {
    if (![NSValue valueWithCGSize:_thumbSize]) {
        _thumbSize = CGSizeMake(25, 25);
    }
    return _thumbSize;
}

@end
