//
// 游戏 - 投注区 - 抽象基类（公共逻辑）
//

#import "CFCGameBetViewController.h"


NSInteger const INIT_SETTING_SELECTED_INDEX_OF_PLAY_CLASS = 0;
NSString * const INIT_SETTING_SELECTED_PLAY_CODE_OF_PLAY_CLASS = @"INIT_SETTING_SELECTED_PLAY_CODE_OF_PLAY_CLASS";


@interface CFCGameBetViewController ()

@end


@implementation CFCGameBetViewController


#pragma mark -
#pragma mark 开奖结果 - 开奖类型
- (CFCGameBetDrawResultItemType)getDrawResultItemType
{
    return CFCGameBetDrawResultItemTypeDefault;
}


#pragma mark -
#pragma mark 玩法下标 - 返回默认选中的玩法标识
- (NSString *)getSelectedPlayCodeOfPlayClass
{
    // TODO: 子类继承实现，初始化设置首次加载页面选中玩法项目的标识 selectedPlayCodeOfPlayClass
    
    return nil;
}

#pragma mark 玩法下标 - 设置默认选中的玩法下标
- (NSDictionary<NSString *, NSNumber *> *)settingSelectedIndexOfPlayClassDictionary
{
    // TODO: 子类继承实现，初始化设置首次加载页面选中玩法项目的下标 selectedIndexOfPlayClass

    // 获取默认玩法标识下标
    NSInteger selectedIndex = INIT_SETTING_SELECTED_INDEX_OF_PLAY_CLASS;
    NSString *selectedPlayClassCode = [self getSelectedPlayCodeOfPlayClass];
    if (![CFCSysUtil validateStringEmpty:selectedPlayClassCode]) {
        NSUInteger index = [self.tabClassCodes indexOfObject:selectedPlayClassCode];
        if (index >=0 && index < self.tabClassCodes.count) {
            selectedIndex = index;
        }
    }
    
    // 返回默认玩法标识字典
    NSMutableDictionary<NSString *, NSNumber *> *selectedIndexOfPlayClassDictionary = [NSMutableDictionary dictionary];
    NSString *tabMarkCode = STR_SELECT_PLAY_CLASS_MARK_CODE(self.gameId, self.gameName, self.gameIdentifier);
    [selectedIndexOfPlayClassDictionary setObject:[NSNumber numberWithInteger:selectedIndex] forKey:tabMarkCode];
    return selectedIndexOfPlayClassDictionary;
}

#pragma mark 玩法下标 - 设置默认选中的玩法标识
- (NSDictionary<NSString *, NSString *> *)settingSelectedPlayCodeOfPlayClassDictionary
{
    // TODO: 子类继承实现，初始化设置首次加载页面选中玩法项目的标识 selectedPlayCodeOfPlayClass
    
    NSMutableDictionary<NSString *, NSString *> *selectedPlayCodeOfPlayClassDictionary = [NSMutableDictionary dictionary];
    NSString *tabMarkCode = STR_SELECT_PLAY_CLASS_MARK_CODE(self.gameId, self.gameName, self.gameIdentifier);
    NSDictionary<NSString *, NSNumber *> *selectedIndexOfPlayClassDictionary = [self settingSelectedIndexOfPlayClassDictionary];
    NSInteger currentIndex = [selectedIndexOfPlayClassDictionary objectForKey:tabMarkCode].integerValue;
    NSString *selectedPlayClassCode = (currentIndex >=0 && currentIndex < self.tabClassCodes.count) ?
                                        self.tabClassCodes[currentIndex] : INIT_SETTING_SELECTED_PLAY_CODE_OF_PLAY_CLASS;
    [selectedPlayCodeOfPlayClassDictionary setObject:selectedPlayClassCode forKey:tabMarkCode];
    return selectedPlayCodeOfPlayClassDictionary;
}


#pragma mark -
#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
    [super viewDidLoad];
 
    // 验证当前页面是否已经加载过
    NSInteger countOfLoad = 0;
    if (self.delegate_betting_core && [self.delegate_betting_core respondsToSelector:@selector(numberHasLoadOfGameBetPlayScrollFromMainGameCoreViewController)]) {
        countOfLoad = [self.delegate_betting_core numberHasLoadOfGameBetPlayScrollFromMainGameCoreViewController];
    } else {
        NSAssert(NO, @"[CFCGameCoreViewController]类必须实现代理方法[numberHasLoadOfGameBetPlayScrollFromMainGameCoreViewController]");
    }
    
    // 如果当前页面没有加载过，则初始化设置
    if (countOfLoad <= 1) {
        // 初始化默认选中的玩法下标 - 在主页面保存玩法下标
        NSDictionary<NSString *, NSNumber *> *selectedIndexOfPlayClassDictionary = [self settingSelectedIndexOfPlayClassDictionary];
        if (self.delegate_betting_core && [self.delegate_betting_core respondsToSelector:@selector(changeSelectedIndexOfPlayClassForMainGameCoreViewController:tabMarkCode:)]) {
            NSString *tabMarkCode = STR_SELECT_PLAY_CLASS_MARK_CODE(self.gameId, self.gameName, self.gameIdentifier);
            NSInteger selectedIndex = [selectedIndexOfPlayClassDictionary numberForKey:tabMarkCode].integerValue;
            if (![self.delegate_betting_core changeSelectedIndexOfPlayClassForMainGameCoreViewController:selectedIndex tabMarkCode:tabMarkCode]) {
                CFCLog(@"[changeSelectedIndexOfPlayClassForMainGameCoreViewController:tabMarkCode:]更玩法下标失败");
            }
        } else {
            NSAssert(NO, @"[CFCGameCoreViewController]类必须实现代理方法[changeSelectedIndexOfPlayClassForMainGameCoreViewController:tabMarkCode:]");
        }
        
        // 初始化默认选中的玩法标识 - 在主页面保存玩法标识
        NSDictionary<NSString *, NSString *> *selectedPlayCodeDictionary = [self settingSelectedPlayCodeOfPlayClassDictionary];
        if (self.delegate_betting_core && [self.delegate_betting_core respondsToSelector:@selector(changeSelectedPlayCodeOfPlayClassForMainGameCoreViewController:tabMarkCode:)]) {
            NSString *tabMarkCode = STR_SELECT_PLAY_CLASS_MARK_CODE(self.gameId, self.gameName, self.gameIdentifier);
            NSString *selectedPlayClassCode = [selectedPlayCodeDictionary stringForKey:tabMarkCode];
            if (![self.delegate_betting_core changeSelectedPlayCodeOfPlayClassForMainGameCoreViewController:selectedPlayClassCode tabMarkCode:tabMarkCode]) {
                CFCLog(@"[changeSelectedPlayCodeOfPlayClassForMainGameCoreViewController:tabMarkCode:]更玩法标识失败");
            }
        } else {
            NSAssert(NO, @"[CFCGameCoreViewController]类必须实现代理方法[changeSelectedPlayCodeOfPlayClassForMainGameCoreViewController:tabMarkCode:]");
        }
    }
    
}


#pragma mark -
#pragma mark CFCGameBetPlayClassViewControllerDelegate
#pragma mark 投注总数 - 在主页面更新用户的投注总数
- (BOOL)changeSumNumberOfBettingForMainGameBetViewController:(NSInteger)number
{
    // 投注总数
    NSString *bettingNumber = [NSString stringWithFormat:@"%ld", number];
    [self setBettingNumberValue:bettingNumber];
    
    // 单注金额
    NSString *bettingPrice = STR_BETTING_PRICE_DEF;
    if ([STR_BETTING_DATA_YUAN isEqualToString:self.bettingUnitValue]) {
        bettingPrice = [CFCStringMathsUtil divNumber1:bettingPrice number2:@"1.0"];
    } else if ([STR_BETTING_DATA_JIAO isEqualToString:self.bettingUnitValue]) {
        bettingPrice = [CFCStringMathsUtil divNumber1:bettingPrice number2:@"10.0"];
    }
    
    // 投注总额 = 价格*倍数*注数
    NSString *amountPriceMultiple = [CFCStringMathsUtil mulNumber1:bettingPrice number2:self.bettingMultipleValue];
    NSString *amountMoney = [CFCStringMathsUtil mulNumber1:bettingNumber number2:amountPriceMultiple];
    NSString *amountRound = [NSString stringWithFormat:@"%0.2f", amountMoney.floatValue];
    [self setBettingAmountValue:amountRound];
    
    return YES;
}


#pragma mark -
#pragma mark CFCGameBetPlayScrollViewHeaderDelegate
#pragma mark 事件处理 - 切换玩法 - 玩法页面存在则切换
- (void)didSelectedPlayClassViewController:(NSString *)classCode
                    selectedGameIdentifier:(NSString *)selectedGameIdentifier
                    selectedTypeIdentifier:(NSString *)selectedTypeIdentifier
                   selectedGroupIdentifier:(NSString *)selectedGroupIdentifier
                   selectedClassIdentifier:(NSString *)selectedClassIdentifier
                    selectedClassTitleName:(NSString *)selectedClassTitleName
                     selectedPlayTypeModel:(CFCGameBetPlayTypeModel *)selectedGameBetPlayTypeModel
                selectedPlayTypeGroupModel:(CFCGameBetPlayTypeGroupModel *)selectedGameBetPlayTypeGroupModel
                selectedPlayTypeClassModel:(CFCGameBetPlayTypeClassModel *)selectedGameBetPlayTypeClassModel
{
    [super didSelectedPlayClassViewController:classCode
                       selectedGameIdentifier:selectedGameIdentifier
                       selectedTypeIdentifier:selectedTypeIdentifier
                      selectedGroupIdentifier:selectedGroupIdentifier
                      selectedClassIdentifier:selectedClassIdentifier
                       selectedClassTitleName:selectedClassTitleName
                        selectedPlayTypeModel:selectedGameBetPlayTypeModel
                   selectedPlayTypeGroupModel:selectedGameBetPlayTypeGroupModel
                   selectedPlayTypeClassModel:selectedGameBetPlayTypeClassModel];
    
    [self setBettingTypeValue:STR_PLAY_CLASS_BETTING_TYPE(selectedTypeIdentifier,selectedGroupIdentifier,selectedClassIdentifier)]; // 投注类型
    [self setBettingPidValue:selectedGameBetPlayTypeClassModel.pid.stringValue]; // 投注外键
    [self setBettingPSeriesWayIdValue:selectedGameBetPlayTypeClassModel.series_way_id.stringValue]; // 服务主键
    [self setBettingPriceValue:selectedGameBetPlayTypeClassModel.price.stringValue]; // 单价金额
    [self setBettingPrizeValue:selectedGameBetPlayTypeClassModel.prize]; // 奖金分组
    [self setBettingBasicMethodsValue:selectedGameBetPlayTypeClassModel.basic_methods]; // 投注方式
    [self setBettingMultipleMinValue:STR_BETTING_MULTIPLE_MIN]; // 投注倍数（最小值）
    if (selectedGameBetPlayTypeClassModel.max_multiple.floatValue > STR_BETTING_MULTIPLE_MAX.floatValue) {
        [self setBettingMultipleMaxValue:STR_BETTING_MULTIPLE_MAX]; // 投注倍数（最大值）
    } else {
        [self setBettingMultipleMaxValue:selectedGameBetPlayTypeClassModel.max_multiple.stringValue]; // 投注倍数（最大值）
    }
}


@end

