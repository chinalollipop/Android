
#import <UIKit/UIKit.h>

@interface CFCGameBetPlayClassTableSectionHeaderView : UIView

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title tableSecion:(NSInteger)tableSection;

@end
