//
// 游戏 - 投注区 - 官方模式 - 北京快乐8 - 和值 - 和值 - 单双
//

#import "CFCBJKL8PlayClassBaseOfficialViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCBJKL8PlayClassDanShuangViewController : CFCBJKL8PlayClassBaseOfficialViewController

@end

NS_ASSUME_NONNULL_END
