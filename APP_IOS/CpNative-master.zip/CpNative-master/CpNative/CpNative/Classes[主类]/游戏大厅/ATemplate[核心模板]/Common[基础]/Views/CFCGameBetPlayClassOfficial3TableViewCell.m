//
//  游戏 - 官方玩法 -> 投注项目，有复选按钮 -> 如：时时彩官方玩法中<任选二、任选三>玩法中的复选按钮
//
//  说明：此类以 UITableViewCell 实现。如果不能满足你的要求，请另外实现。
//

#import "CFCGameBetPlayClassOfficial3TableViewCell.h"
#import "CFCGameBetPlayClassModel.h"


// Cell Identifier
NSString * const CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_3_TABLE_VIEW_CELL = @"CFCGameBetPlayClassOfficial3TableViewCellIdentifier";


@interface CFCGameBetPlayClassOfficial3TableViewCell ()

@end


@implementation CFCGameBetPlayClassOfficial3TableViewCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createViewAtuoLayout];
    }
    return self;
}


#pragma mark 创建子控件
- (void) createViewAtuoLayout
{
    // 根容器
    UIView *rootContainerView = ({
        UIView *view = [[UIView alloc] init];
        [self.contentView insertSubview:view atIndex:0];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@0.0f);
            make.top.equalTo(@0.0f);
            make.right.equalTo(@0.0f);
            make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
        }];
        
        view;
    });
    self.rootContainerView = rootContainerView;
    self.rootContainerView.mas_key = @"rootContainerView";
    
    // 公共容器
    UIView *publicContainerView = ({
        UIView *view = [[UIView alloc] init];
        [view setBackgroundColor:COLOR_GAME_BET_MAINAREA_BACKGROUND_DEFAULT];
        [rootContainerView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(rootContainerView.mas_left).offset(0.0f);
            make.top.equalTo(rootContainerView.mas_top).offset(0.0f);
            make.right.equalTo(rootContainerView.mas_right).offset(0.0f);
            make.bottom.equalTo(rootContainerView.mas_bottom).offset(0.0f);
        }];
        
        view;
    });
    self.publicContainerView = publicContainerView;
    self.publicContainerView.mas_key = @"publicContainerView";
    
}


#pragma mark - 设置数据模型
- (void)setModel:(CFCGameBetPlayClassSectionModel *)model
{
    // 类型安全检查
    if (![model isKindOfClass:[CFCGameBetPlayClassSectionModel class]]) {
        return;
    }
    
    // 数据赋值
    _model = (CFCGameBetPlayClassSectionModel *)model;
    
    // 删除控件
    [self.publicContainerView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    // 创建控件
    {
        // 大小间距
        NSInteger column = self.model.columnsCount;
        CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
        CGFloat margin_top = margin * 2.00f;
        CGFloat margin_left = margin * 1.50f;
        CGFloat margin_right = margin * 1.50f;
        CGFloat margin_bottom = margin * 2.00f;
        // 操作按钮
        CGFloat operationButtonCount = 6.0f; // 操作按钮（全、大、小、单、双、清）
        CGFloat btn_count_all = operationButtonCount + 1.85f; // 操作宽度 + 分组标签宽度
        CGFloat btn_margin_left = margin * 1.0f;
        CGFloat btn_margin_horizontal = margin * 0.10f;
        CGFloat btn_size_width = (SCREEN_WIDTH - margin_left - margin_right - btn_margin_left - btn_margin_horizontal*(operationButtonCount-1)) / btn_count_all;
        // 分组标签
        CGFloat section_title_width = btn_size_width * (btn_count_all - operationButtonCount);
        // 投注按钮
        CGFloat item_margin_horizontal = margin * 0.30f;;
        CGFloat item_margin_vertical = margin * 1.5f;
        CGFloat item_margin_left = margin_left + section_title_width + btn_margin_left - section_title_width - btn_margin_left;
        CGFloat item_size_width = (SCREEN_WIDTH - item_margin_left - margin_right - item_margin_horizontal*(column-1)) / column;
        CGFloat item_size_height = item_size_width * 0.45;
        
        // 按钮
        CFCGameBetPlayClassCheckBox *lastItemButton = nil;
        self.checkBoxButtonArray = @[].mutableCopy;
        for (int idx = 0; idx < self.model.list.count; idx ++) {
            
            CFCGameBetPlayClassModel *classModel = self.model.list[idx];
            
            CFCGameBetPlayClassCheckBox *itemCheckBoxButton = ({
                CGRect frame = CGRectMake(0, 0, item_size_width, item_size_height);
                CFCGameBetPlayClassCheckBox *itemCheckbox = [[CFCGameBetPlayClassCheckBox alloc] initWithFrame:frame];
                [itemCheckbox setTag:8000+idx];
                [itemCheckbox setChecked:classModel.isSelected];
                [itemCheckbox setText:[CFCSysUtil stringByTrimmingWhitespaceAndNewline:classModel.name]];
                [itemCheckbox setTextFont:[UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(14.0f)]];
                [itemCheckbox setTextColor:COLOR_SYSTEM_MAIN_FONT_ASSIST_DEFAULT];
                [itemCheckbox setNormalBgImage:ICON_GAME_CHECK_BOX];
                [itemCheckbox setSelectBgImage:ICON_GAME_CHECK_BOX_SEL];
                [itemCheckbox setNormalBgColor:GAME_PLAY_OFFICI_BUTTON_BACKGROUND_COLOR_NORMAL];
                [itemCheckbox setSelectBgColor:GAME_PLAY_OFFICI_BUTTON_BACKGROUND_COLOR_SELECT];
                [itemCheckbox setBackgroundColor:[UIColor whiteColor]];
                [itemCheckbox addTarget:self action:@selector(doPlayClassOfficial3CheckBoxButtonAction:) forControlEvents:UIControlEventTouchUpInside];
                [self.publicContainerView addSubview:itemCheckbox];
                
                [itemCheckbox mas_remakeConstraints:^(MASConstraintMaker *make) {
                    make.width.equalTo(@(item_size_width));
                    make.height.equalTo(@(item_size_height));
                    
                    if (!lastItemButton) {
                        make.top.equalTo(self.publicContainerView.mas_top).offset(margin_top);
                        make.left.equalTo(self.publicContainerView.mas_left).offset(item_margin_left);
                    } else {
                        if (idx % column == 0) {
                            make.top.equalTo(lastItemButton.mas_bottom).offset(item_margin_vertical);
                            make.left.equalTo(self.publicContainerView.mas_left).offset(item_margin_left);
                        } else {
                            make.top.equalTo(lastItemButton.mas_top);
                            make.left.equalTo(lastItemButton.mas_right).offset(item_margin_horizontal);
                        }
                    }
                }];
                itemCheckbox.mas_key = [NSString stringWithFormat:@"itemCheckBoxButton%d", idx];
                
                itemCheckbox;
            });

            lastItemButton = itemCheckBoxButton;
        }
        
        // 分割线
        UIView *separatorLineView = ({
            UIView *view = [[UIView alloc] init];
            [self.publicContainerView addSubview:view];
            [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
            
            [view mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(lastItemButton.mas_bottom).offset(margin_bottom);
                make.left.equalTo(self.publicContainerView.mas_left).offset(0.0f);
                make.right.equalTo(self.publicContainerView.mas_right).offset(0.0f);
                make.height.equalTo(@(SEPARATOR_LINE_HEIGHT));
            }];
            
            view;
        });
        separatorLineView.mas_key = @"separatorLineView";
        
        // 约束的完整性
        [self.publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(separatorLineView.mas_bottom).offset(0.0f).priority(749);
        }];
        
    }
    
}


#pragma mark - 操作事件 - 操作按钮
- (void)doPlayClassOfficial3CheckBoxButtonAction:(CFCGameBetPlayClassCheckBox *)checkBoxButton
{
    NSUInteger index = checkBoxButton.tag - 8000;
    
    if (index >= self.model.list.count) {
        CFCLog(@"数组越界，请检测代码。");
        return;
    }
    
    // 更新数据
    CFCGameBetPlayClassModel *itemModel = self.model.list[index];
    
    // 执行代理
    if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectPlayClassOfficial3TableViewCellRowAtIndexPath:itemModels:itemIndexs:)]) {
        [self.delegate didSelectPlayClassOfficial3TableViewCellRowAtIndexPath:self.indexPath
                                                                   itemModels:@[itemModel]
                                                                   itemIndexs:@[[NSNumber numberWithInteger:index]] ];
    }
    
}


@end
