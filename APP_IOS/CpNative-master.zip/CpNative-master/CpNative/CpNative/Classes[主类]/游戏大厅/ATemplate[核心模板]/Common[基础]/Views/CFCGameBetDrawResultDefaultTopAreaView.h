//
// 游戏 - 投注区 - 开奖结果头部区域
//


#import <UIKit/UIKit.h>
@class CFCGameBetDrawResultModel;

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, CFCGameBetDrawResultAnimationType) {
    CFCGameBetDrawResultAnimationType1 = 101, // 类型1 -> 文字开奖中
    CFCGameBetDrawResultAnimationType2 = 102, // 类型2 -> 开奖号动画
};

@protocol CFCGameBetDrawResultDefaultTopAreaViewProtocol <NSObject>
@required
- (void)createViewAtuoLayout;
- (instancetype)initWithFrame:(CGRect)frame
                       gameId:(NSString *)gameId
                     gameName:(NSString *)gameName
               gameIdentifier:(NSString *)gameIdentifier
                     playMode:(CFCGameCorePlayModeClass)playModeClass
             drawResultsModel:(CFCGameBetDrawResultModel *)drawResultModel;
- (CGSize)itemSizeOfWinnerNumber;
- (void)animationWithDrawResultWinnerNumber:(CFCGameBetDrawResultModel *)drawResultModel;
- (void)startAnimationForDrawResultWinnerNumber:(CFCGameBetDrawResultModel *)drawResultModel;
- (void)endAnimationForDrawResultWinnerNumber:(CFCGameBetDrawResultModel *)drawResultModel;
+ (CGFloat)heightForHeaderDrawResultsAreaWithModel:(CFCGameBetDrawResultModel *)drawResultModel;
@end

@interface CFCGameBetDrawResultDefaultTopAreaView : UIView <CFCGameBetDrawResultDefaultTopAreaViewProtocol>

@property (nonatomic, copy) NSString *gameId; // 游戏主键
@property (nonatomic, copy) NSString *gameName; // 游戏名称
@property (nonatomic, copy) NSString *gameIdentifier; // 游戏标识
@property (nonatomic, assign) CFCGameCorePlayModeClass playModeClass; // 玩法模式

@property (nonatomic, strong) UIView *leftWinnerContainerView; // 左边开奖结果
@property (nonatomic, strong) UILabel *rightIssueNumberLabel; // 右边开奖期号
@property (nonatomic, strong) NSMutableArray<CFCScrollStringLabel *> *leftWinnerLabelArray; // 开奖控件列表
@property (nonatomic, strong) CFCGameBetDrawResultModel *drawResultModel; // 数据模型
@property (nonatomic, assign) BOOL isStartWinnerAnimation; // 开奖动画


/**
 * 开奖结果构造函数
 */
- (instancetype)initWithFrame:(CGRect)frame
                       gameId:(NSString *)gameId
                     gameName:(NSString *)gameName
               gameIdentifier:(NSString *)gameIdentifier
                     playMode:(CFCGameCorePlayModeClass)playModeClass
             drawResultsModel:(CFCGameBetDrawResultModel *)drawResultModel;
/**
 * 开奖结果重新加载
 */
- (void)reloadDrawResult;
/**
 * 开奖结果重新加载
 */
- (void)reloadDrawResult:(CFCGameBetDrawResultModel *)drawResultModel;
/**
 * 开奖结果号码大小
 */
- (CGSize)itemSizeOfWinnerNumber;
/**
 * 最大宽度开奖期号
 */
- (NSString *)maxWidthOfIssueNumberString;
/**
 * 开奖结果动画效果 - 动画类型
 */
- (CFCGameBetDrawResultAnimationType)animationOfDrawResultAnimationType;
/**
 * 开奖结果动画效果 - 开始动画
 */
- (void)startAnimationForDrawResultWinnerNumber:(CFCGameBetDrawResultModel *)drawResultModel;
/**
 * 开奖结果动画效果 - 结束动画
 */
- (void)endAnimationForDrawResultWinnerNumber:(CFCGameBetDrawResultModel *)drawResultModel;
/**
 * 开奖结果动画效果 - 动画过程
 */
- (void)animationWithDrawResultWinnerNumber:(CFCGameBetDrawResultModel *)drawResultModel;


@end

NS_ASSUME_NONNULL_END
