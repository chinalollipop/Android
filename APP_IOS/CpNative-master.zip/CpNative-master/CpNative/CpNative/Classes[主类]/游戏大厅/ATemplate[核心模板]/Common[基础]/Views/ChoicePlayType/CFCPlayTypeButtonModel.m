//
//  游戏 - 投注页面头部区域 - 玩法选择 - 确定按钮
//

#import "CFCPlayTypeButtonModel.h"

@implementation CFCPlayTypeButtonModel

@end
