//
// 游戏 - 投注区 - 信用模式 - 极速3D
//

#import "CFCJS3DCreditViewController.h"

@interface CFCJS3DCreditViewController ()

@end

@implementation CFCJS3DCreditViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
