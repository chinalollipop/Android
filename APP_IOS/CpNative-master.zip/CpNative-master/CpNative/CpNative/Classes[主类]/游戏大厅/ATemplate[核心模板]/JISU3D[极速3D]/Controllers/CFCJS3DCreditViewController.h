//
// 游戏 - 投注区 - 信用模式 - 极速3D
//

#import "CFCGameBetCreditViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCJS3DCreditViewController : CFCGameBetCreditViewController

@end

NS_ASSUME_NONNULL_END
