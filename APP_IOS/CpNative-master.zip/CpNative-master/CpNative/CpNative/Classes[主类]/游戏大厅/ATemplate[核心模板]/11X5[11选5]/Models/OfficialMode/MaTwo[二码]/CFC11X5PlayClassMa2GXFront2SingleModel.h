//
// 游戏 - 投注区 - 官方模式 - 11选5 - 二码 - 组选 - 前二组选单式
//

#import "CFCGameBetPlayClassModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFC11X5PlayClassMa2GXFront2SingleModel : CFCGameBetPlayClassModel

+ (NSMutableArray *) buildingDataModlesForSection1;

@end


@interface CFC11X5PlayClassMa2GXFront2SingleSectionModel : CFCGameBetPlayClassSectionModel

+ (NSMutableArray *) buildingDataModles;

@end

NS_ASSUME_NONNULL_END
