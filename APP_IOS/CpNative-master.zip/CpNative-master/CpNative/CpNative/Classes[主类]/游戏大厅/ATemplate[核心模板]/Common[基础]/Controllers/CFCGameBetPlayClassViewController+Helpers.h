//
// 游戏 - 投注区 - 选注页面（帮助工具）
//

#import "CFCGameBetPlayClassViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCGameBetPlayClassViewController (Helpers)


#pragma mark -
#pragma mark 帮助工具 - 分组类型 - 分组内容是否是投注号码
- (BOOL)isNormalSectionModel:(CFCGameBetPlayClassSectionModel *)sectionModel;
#pragma mark 帮助工具 - 分组类型 - 分组内容是否是复选按钮
- (BOOL)isCheckboxSectionModel:(CFCGameBetPlayClassSectionModel *)sectionModel;
#pragma mark 帮助工具 - 分组类型 - 分组内容是否是单式号码
- (BOOL)isSingleSectionModel:(CFCGameBetPlayClassSectionModel *)sectionModel;


#pragma mark -
#pragma mark 帮助工具 - 投注总数 - 排列注数
- (NSInteger)numberOfBettingRecordsForArrangement:(NSInteger)m;
#pragma mark 帮助工具 - 投注总数 - 组合注数
- (NSInteger)numberOfBettingRecordsForCombination:(NSInteger)m;


#pragma mark -
#pragma mark 帮助工具 - 投注内容 - 排列内容
- (NSArray<NSString *> *)contentOfBettingRecordsForArrangement:(NSInteger)m;
#pragma mark 帮助工具 - 投注内容 - 组合内容
- (NSArray<NSString *> *)contentOfBettingRecordsForCombination:(NSInteger)m;


#pragma mark -
#pragma mark 帮助工具 - 投注结果 - 结果模板N01 - 号码格式（01 02 03 04 05 06 07 08 09 10|01 02 03 04 05 06 07 08 09 10）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsTemplateN01:(NSDictionary *)dictOfBetSetting;
#pragma mark 帮助工具 - 投注结果 - 结果模板N02 - 号码格式（01|02|03|04|05|06|07|08|09|10*01|02|03|04|05|06|07|08|09|10）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsTemplateN02:(NSDictionary *)dictOfBetSetting;
#pragma mark 帮助工具 - 投注结果 - 结果模板N03 - 号码格式（012345678910|012345678910|012345678910|012345678910）
- (NSArray<CFCGameBetRecordModel *> *)bettingResultModelsForBettingRecordsTemplateN03:(NSDictionary *)dictOfBetSetting;


@end


NS_ASSUME_NONNULL_END

