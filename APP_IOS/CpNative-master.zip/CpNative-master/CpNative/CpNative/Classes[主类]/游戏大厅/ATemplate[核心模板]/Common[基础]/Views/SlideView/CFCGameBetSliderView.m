

#import "CFCGameBetSliderView.h"
#import "CFCGameSliderTimer.h"
#import "CFCSliderView.h"

@interface CFCGameBetSliderView () <CFCSliderViewDelegate>

@property (nonatomic, strong) CFCSliderView *sliderView;

@property (nonatomic, strong) UILabel *leftValueLabel;

@property (nonatomic, strong) UILabel *rightValueLabel;

@property (nonatomic, strong) UIButton *symbolPlusButton;
@property (nonatomic, strong) UIButton *symbolPlusBackButton;

@property (nonatomic, strong) UIButton *symbolMinusButton;
@property (nonatomic, strong) UIButton *symbolMinusBackButton;

@property (nonatomic, strong) NSString *allMinValue;
@property (nonatomic, strong) NSString *allMaxValue;
@property (nonatomic, strong) NSDictionary<NSString *, NSString *> *allKeyValueDict;

@end


@implementation CFCGameBetSliderView


- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self createViewAtuoLayout];
    }
    return self;
}


#pragma mark - 创建子控件
- (void)createViewAtuoLayout
{
    CGFloat margin = CFC_AUTOSIZING_MARGIN(MARGIN);
    CGFloat width_symbol = self.height * 0.55f;
    UIFont *labelFont = [UIFont boldSystemFontOfSize:CFC_AUTOSIZING_FONT(14.0f)];
    UIColor *labelColor = COLOR_GAME_DRAW_RESULT_ISSUE_CHINESE;

    // 左边滑条的值
    UILabel *leftValueLabel = ({
        CGFloat width = [@"88.88%" widthWithFont:labelFont constrainedToHeight:MAXFLOAT];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, self.height)];
        [self addSubview:label];
        [label setText:@"0.00%"];
        [label setTextAlignment:NSTextAlignmentRight];
        [label setUserInteractionEnabled:YES];
        [label setFont:labelFont];
        [label setTextColor:labelColor];
        
        label;
    });
    self.leftValueLabel = leftValueLabel;
    self.leftValueLabel.mas_key = @"leftValueLabel";
    
    // 右边滑条的值
    UILabel *rightValueLabel = ({
        CGFloat width = [@"0000" widthWithFont:labelFont constrainedToHeight:MAXFLOAT];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(self.width-margin*0.2f-width, 0, width, self.height)];
        [self addSubview:label];
        [label setText:@"0000"];
        [label setTextAlignment:NSTextAlignmentLeft];
        [label setFont:labelFont];
        [label setTextColor:labelColor];

        label;
    });
    self.rightValueLabel = rightValueLabel;
    self.rightValueLabel.mas_key = @"rightValueLabel";
    
    // 左边滑条减号
    UIButton *symbolMinusButton = ({
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake(CGRectGetMaxX(leftValueLabel.frame)+margin*0.2f, (self.height-width_symbol)/2.0f, width_symbol, width_symbol)];
        [self addSubview:button];
        [button setBackgroundImage:[UIImage imageNamed:ICON_SYSBOL_MINUS] forState:UIControlStateNormal];
        [button setBackgroundImage:[UIImage imageNamed:ICON_SYSBOL_MINUS] forState:UIControlStateSelected];
        [button addTarget:self action:@selector(pressSymbolMinusButton:forEvent:) forControlEvents:UIControlEventAllTouchEvents];
    
        button;
    });
    self.symbolMinusButton = symbolMinusButton;
    self.symbolMinusButton.mas_key = @"symbolMinusButton";
    
    // 左边滑条减号 - 背景
    UIButton *symbolMinusBackButton = ({
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake(0, 0, CGRectGetMaxX(symbolMinusButton.frame), self.height)];
        [self insertSubview:button belowSubview:symbolMinusButton];
        [button addTarget:self action:@selector(pressSymbolMinusButton:forEvent:) forControlEvents:UIControlEventAllTouchEvents];
        
        button;
    });
    self.symbolMinusBackButton = symbolMinusBackButton;
    self.symbolMinusBackButton.mas_key = @"symbolMinusBackButton";
    
    // 右边滑条减号
    UIButton *symbolPlusButton = ({
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake(CGRectGetMinX(rightValueLabel.frame)-margin*0.2f-width_symbol, (self.height-width_symbol)/2.0f, width_symbol, width_symbol)];
        [self addSubview:button];
        [button setBackgroundImage:[UIImage imageNamed:ICON_SYSBOL_PLUS] forState:UIControlStateNormal];
        [button setBackgroundImage:[UIImage imageNamed:ICON_SYSBOL_PLUS] forState:UIControlStateSelected];
        [button addTarget:self action:@selector(pressSymbolPlusButton:forEvent:) forControlEvents:UIControlEventAllTouchEvents];
 
        button;
    });
    self.symbolPlusButton = symbolPlusButton;
    self.symbolPlusButton.mas_key = @"symbolPlusButton";
    
    // 右边滑条加号 - 背景
    UIButton *symbolPlusBackButton = ({
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake(CGRectGetMinX(symbolPlusButton.frame), 0, self.width-CGRectGetMinX(symbolPlusButton.frame), self.height)];
        [self insertSubview:button belowSubview:symbolPlusButton];
        [button addTarget:self action:@selector(pressSymbolPlusButton:forEvent:) forControlEvents:UIControlEventAllTouchEvents];
        
        button;
    });
    self.symbolPlusBackButton = symbolPlusBackButton;
    self.symbolPlusBackButton.mas_key = @"symbolPlusBackButton";
    
    // 中间滑条控件
    CFCSliderView *sliderView = ({
        CGFloat width = self.width-width_symbol*2.0f-leftValueLabel.width-rightValueLabel.width-margin*1.0f;
        CGRect frame = CGRectMake(CGRectGetMaxX(symbolMinusButton.frame)+margin*0.2f, 0, width, self.height);
        CFCSliderView *sliderView = [[CFCSliderView alloc] initWithFrame:frame];
        sliderView.delegate = self;
        sliderView.minValue = 0;
        sliderView.maxValue = 1000;
        sliderView.value = 1000;
        sliderView.normalColor = COLOR_HEXSTRING(@"#C0C0C0");
        sliderView.trackColors = @[(__bridge id)COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT.CGColor, (__bridge id)COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT.CGColor];
        sliderView.trackSize = CGSizeMake(width, 4);
        sliderView.thumbSize = CGSizeMake(16, 10);
        sliderView.thumbImage = [UIImage imageNamed:ICON_SYSBOL_HANDLE];
        [self addSubview:sliderView];

        sliderView;
    });
    self.sliderView = sliderView;
    self.sliderView.mas_key = @"sliderView";
    
    // 设置默认值
    [self setSliderRateValue:@"0.00"];
    [self setSliderPrizeValue:@"0"];
}


#pragma mark -
#pragma mark 触发事件 - 减号按钮
- (void)pressSymbolMinusButton:(UIButton *)button forEvent:(UIEvent *)event
{
    UITouchPhase touchPhase = event.allTouches.anyObject.phase;
    if (touchPhase == UITouchPhaseBegan) {
        // 开定时器
        [[CFCGameSliderTimer sharedGameSliderTimer] countDownWithBlock:^{
            [self pressSymbolMinusButtonLogic];
        } timer:0.2f];
    } else if (UITouchPhaseEnded == touchPhase || UITouchPhaseCancelled == touchPhase) {
        // 关定时器
        [[CFCGameSliderTimer sharedGameSliderTimer] destoryTimer];
    } else {
        [[CFCGameSliderTimer sharedGameSliderTimer] countDownWithBlock:^{
            [self pressSymbolMinusButtonLogic];
        } timer:0.01f];
    }
}

#pragma mark 逻辑处理 - 减号按钮
- (void)pressSymbolMinusButtonLogic
{
    CGFloat value = self.sliderView.value - 1;
    
    // 验证数值的合法性
    NSString *max_value_expression = [NSString stringWithFormat:@"%@-%@", self.allMaxValue, self.allMinValue];
    NSString *max_value = [NSString stringWithFormat:@"%d", [CFCStringMathsUtil calcComplexFormulaString:max_value_expression].intValue];
    if (value <= 0.0f) {
        value = 0.0f;
    } else if (value >= max_value.floatValue) {
        value = max_value.floatValue;
    }
    
    // 更新滑条控件界面
    [self.sliderView reloadData:value];
}


#pragma mark -
#pragma mark 触发事件 - 加号按钮
- (void)pressSymbolPlusButton:(UIButton *)button forEvent:(UIEvent *)event
{
    UITouchPhase touchPhase = event.allTouches.anyObject.phase;
    if (touchPhase == UITouchPhaseBegan) {
        [[CFCGameSliderTimer sharedGameSliderTimer] countDownWithBlock:^{
            // 开定时器
            [self pressSymbolPlusButtonLogic];
        } timer:0.2f];
    } else if (UITouchPhaseEnded == touchPhase || UITouchPhaseCancelled == touchPhase) {
        // 关定时器
        [[CFCGameSliderTimer sharedGameSliderTimer] destoryTimer];
    } else {
        [[CFCGameSliderTimer sharedGameSliderTimer] countDownWithBlock:^{
            [self pressSymbolPlusButtonLogic];
        } timer:0.01f];
    }
}

#pragma mark 逻辑处理 - 加号按钮
- (void)pressSymbolPlusButtonLogic
{
    CGFloat value = self.sliderView.value + 1;
    
    // 验证数值的合法性
    NSString *max_value_expression = [NSString stringWithFormat:@"%@-%@", self.allMaxValue, self.allMinValue];
    NSString *max_value = [NSString stringWithFormat:@"%d", [CFCStringMathsUtil calcComplexFormulaString:max_value_expression].intValue];
    if (value <= 0.0f) {
        value = 0.0f;
    } else if (value >= max_value.floatValue) {
        value = max_value.floatValue;
    }
    
    // 更新滑条控件界面
    [self.sliderView reloadData:value];
}


#pragma mark -
#pragma mark 触发事件 - 滑动事件
- (void)slider:(CFCSliderView *)slider changeValue:(NSString *)value
{
    // 计算 - 右边值
    NSString *right_slider_value_expression = [NSString stringWithFormat:@"%@+%@", self.allMinValue, value];
    NSString *right_slider_value = [NSString stringWithFormat:@"%d", [CFCStringMathsUtil calcComplexFormulaString:right_slider_value_expression].intValue];

    // 计算 - 左边值
    NSString *left_value = [self.allKeyValueDict stringForKey:right_slider_value];
    NSString *left_slider_value_expression = [NSString stringWithFormat:@"%@*%@", left_value, @"100"];
    NSString *left_slider_value = [NSString stringWithFormat:@"%.2f%%", [CFCStringMathsUtil calcComplexFormulaString:left_slider_value_expression].floatValue];

    // 更新界面 - 右边显示值
    [self.leftValueLabel setText:left_slider_value];
    [self.rightValueLabel setText:right_slider_value];
    
    // 保存价格与赔率
    [self setSliderRateValue:left_value];
    [self setSliderPrizeValue:right_slider_value];
    
    // 代理执行
    if (self.delegate && [self.delegate respondsToSelector:@selector(sliderView:sliderPrizeValue:sliderRateValue:)]) {
        [self.delegate sliderView:self sliderPrizeValue:right_slider_value sliderRateValue:left_value];
    }
}


#pragma mark - 设置数据源
- (void)setAllSliderData:(NSArray<NSDictionary *> *)allSliderData
{
    if ([CFCSysUtil validateObjectIsNull:allSliderData]) {
        self.sliderView.minValue = 0;
        self.sliderView.maxValue = 1000;
        self.sliderView.value = 1000;
        return;
    }
    
    _allSliderData = allSliderData;
    
    // 计算滑条的范围
    __block NSMutableArray<NSString *> *allKeyArray = [NSMutableArray<NSString *> array];
    __block NSMutableDictionary<NSString *, NSString *> *allKeyValueDict = [NSMutableDictionary<NSString *, NSString *> dictionary];
    [allSliderData enumerateObjectsUsingBlock:^(NSDictionary * _Nonnull dict, NSUInteger idx, BOOL * _Nonnull stop) {
        NSString *key = [dict stringForKey:@"prize_group"];
        NSString *value = [dict stringForKey:@"rate"];
        if (![CFCSysUtil validateStringEmpty:key] && ![CFCSysUtil validateStringEmpty:value]) {
            [allKeyArray addObject:key];
            [allKeyValueDict setObject:value forKey:key];
        }
    }];
    self.allKeyValueDict = [NSDictionary<NSString *, NSString *> dictionaryWithDictionary:allKeyValueDict];
    
    // 设置滑条的范围
    NSArray<NSString *> *allSortedKeyArray = [CFCStringMathsUtil sortedArray:allKeyArray];
    self.allMinValue = allSortedKeyArray.firstObject;
    self.allMaxValue = allSortedKeyArray.lastObject;
    NSString *max_slider_value_expression = [NSString stringWithFormat:@"%@-%@", self.allMaxValue, self.allMinValue];
    NSString *max_slider_value = [NSString stringWithFormat:@"%d", [CFCStringMathsUtil calcComplexFormulaString:max_slider_value_expression].intValue];
    if ([CFCStringMathsUtil validateNumberCharacters:max_slider_value]) {
        [self.sliderView setMinValue:0.0f];
        [self.sliderView setMaxValue:max_slider_value.floatValue];
        [self.sliderView reloadData:max_slider_value.floatValue];
    } else {
        [self.sliderView setMinValue:0.0f];
        [self.sliderView setMaxValue:1000.0f];
        [self.sliderView reloadData:1000.0f];
    }
}


@end

