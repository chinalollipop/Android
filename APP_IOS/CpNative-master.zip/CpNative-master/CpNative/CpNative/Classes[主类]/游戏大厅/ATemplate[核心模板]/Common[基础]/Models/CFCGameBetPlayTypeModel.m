//
// 游戏 - 投注区 - 玩法数据模型的基类
//

#import "CFCGameBetPlayTypeModel.h"


@implementation CFCGameBetPlayTypeModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{
             @"uuid" : @"id",
             @"name" : @"name_cn",
             @"code" : @"name_en",
             @"childrenGroup" : @"children"
             };
}

@end


@implementation CFCGameBetPlayTypeGroupModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{
             @"uuid" : @"id",
             @"name" : @"name_cn",
             @"code" : @"name_en",
             @"childrenClass" : @"children"
             };
}

@end


@implementation CFCGameBetPlayTypeClassModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{
             @"uuid" : @"id",
             @"name" : @"name_cn",
             @"code" : @"name_en"
             };
}

@end
