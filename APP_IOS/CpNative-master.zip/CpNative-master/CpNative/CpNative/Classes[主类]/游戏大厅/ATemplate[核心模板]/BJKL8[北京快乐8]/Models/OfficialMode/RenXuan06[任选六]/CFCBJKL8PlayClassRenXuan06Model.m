//
// 游戏 - 投注区 - 官方模式 - 北京快乐8 - 任选六 - 任选六 - 复式
//

#import "CFCBJKL8PlayClassRenXuan06Model.h"

@implementation CFCBJKL8PlayClassRenXuan06Model

+ (NSMutableArray *) buildingDataModlesForSection1
{
    NSMutableArray<CFCBJKL8PlayClassRenXuan06Model *> *models = [NSMutableArray array];
    {
        for (int index = 1; index <= 80; index ++) {
            CFCBJKL8PlayClassRenXuan06Model *model = [[CFCBJKL8PlayClassRenXuan06Model alloc] init];
            // 名称
            [model setName:[NSString stringWithFormat:@"%02d", index]];
            [model setNameNormalFont:NAME_FONT_GAME_PLAY_MODEL_NUMBER_NORMAL];
            [model setNameSelectFont:NAME_FONT_GAME_PLAY_MODEL_NUMBER_SELECT];
            [model setNameNormalColor:NAME_COLOR_GAME_PLAY_MODEL_NORMAL];
            [model setNameSelectColor:NAME_COLOR_GAME_PLAY_MODEL_SELECT];
            [model setNameBackgroundColor:NAME_COLOR_GAME_PLAY_BACKGROUND_DEFAULT];
            // 赔率
            [model setOdds:ODDS_STRI_GAME_PLAY_MODEL_DEFAULT];
            [model setOddsNormalFont:ODDS_FONT_GAME_PLAY_MODEL_NORMAL];
            [model setOddsSelectFont:ODDS_FONT_GAME_PLAY_MODEL_SELECT];
            [model setOddsNormalColor:ODDS_COLOR_GAME_PLAY_MODEL_NORMAL];
            [model setOddsSelectColor:ODDS_COLOR_GAME_PLAY_MODEL_SELECT];
            [model setOddsBackgroundColor:ODDS_COLOR_GAME_PLAY_BACKGROUND_DEFAULT];
            // 号码
            [model setClassNumber:[NSString stringWithFormat:@"%02d", index]];
            [model setClassRemark:REMARK_STRI_GAME_PLAY_MODEL_DEFAULT];
            // 其它
            [model setType:CFCGameBetPlayClassItemType01];
            [model setIsSelected:GAME_PLAY_MODEL_SELECTED_DEFAULT];
            //
            [models addObject:model];
        }
    }
    return models;
}

+ (NSMutableArray *) buildingDataModlesForSection2
{
    NSMutableArray<CFCBJKL8PlayClassRenXuan06Model *> *models = [NSMutableArray array];
    {
        for (int index = 41; index <= 80; index ++) {
            CFCBJKL8PlayClassRenXuan06Model *model = [[CFCBJKL8PlayClassRenXuan06Model alloc] init];
            // 名称
            [model setName:[NSString stringWithFormat:@"%02d", index]];
            [model setNameNormalFont:NAME_FONT_GAME_PLAY_MODEL_NUMBER_NORMAL];
            [model setNameSelectFont:NAME_FONT_GAME_PLAY_MODEL_NUMBER_SELECT];
            [model setNameNormalColor:NAME_COLOR_GAME_PLAY_MODEL_NORMAL];
            [model setNameSelectColor:NAME_COLOR_GAME_PLAY_MODEL_SELECT];
            [model setNameBackgroundColor:NAME_COLOR_GAME_PLAY_BACKGROUND_DEFAULT];
            // 赔率
            [model setOdds:ODDS_STRI_GAME_PLAY_MODEL_DEFAULT];
            [model setOddsNormalFont:ODDS_FONT_GAME_PLAY_MODEL_NORMAL];
            [model setOddsSelectFont:ODDS_FONT_GAME_PLAY_MODEL_SELECT];
            [model setOddsNormalColor:ODDS_COLOR_GAME_PLAY_MODEL_NORMAL];
            [model setOddsSelectColor:ODDS_COLOR_GAME_PLAY_MODEL_SELECT];
            [model setOddsBackgroundColor:ODDS_COLOR_GAME_PLAY_BACKGROUND_DEFAULT];
            // 号码
            [model setClassNumber:[NSString stringWithFormat:@"%02d", index]];
            [model setClassRemark:REMARK_STRI_GAME_PLAY_MODEL_DEFAULT];
            // 其它
            [model setType:CFCGameBetPlayClassItemType01];
            [model setIsSelected:GAME_PLAY_MODEL_SELECTED_DEFAULT];
            //
            [models addObject:model];
        }
    }
    return models;
}

@end


@implementation CFCBJKL8PlayClassRenXuan06SectionModel

+ (NSMutableArray *) buildingDataModles
{
    NSMutableArray<CFCBJKL8PlayClassRenXuan06SectionModel *> *models = [NSMutableArray array];
    {
        // 第一个分组
        CFCBJKL8PlayClassRenXuan06SectionModel *model1 = [[CFCBJKL8PlayClassRenXuan06SectionModel alloc] init];
        [model1 setTitle:@"任选六"];
        [model1 setType:CFCGameBetPlayClassSectionTypeOfficial5];
        [model1 setColumnsCount:GAME_PLAY_MODEL_SECTION_COLUMN_N005];
        [model1 setIsShowHeader:GAME_PLAY_MODEL_SECTION_HEADER_SHOW_NO];
        [model1 setIsShowFooter:GAME_PLAY_MODEL_SECTION_FOOTER_SHOW_NO];
        [model1 setList:[CFCBJKL8PlayClassRenXuan06Model buildingDataModlesForSection1]];
        [models addObject:model1];
        
        /*
        // 第二个分组
        CFCBJKL8PlayClassRenXuan06SectionModel *model2 = [[CFCBJKL8PlayClassRenXuan06SectionModel alloc] init];
        [model2 setTitle:@"下"];
        [model2 setType:CFCGameBetPlayClassSectionTypeOfficial5];
        [model2 setColumnsCount:GAME_PLAY_MODEL_SECTION_COLUMN_N005];
        [model2 setIsShowHeader:GAME_PLAY_MODEL_SECTION_HEADER_SHOW_NO];
        [model2 setIsShowFooter:GAME_PLAY_MODEL_SECTION_FOOTER_SHOW_NO];
        [model2 setList:[CFCBJKL8PlayClassRenXuan06Model buildingDataModlesForSection2]];
        [models addObject:model2];
        */
    }
    return models;
}

@end


