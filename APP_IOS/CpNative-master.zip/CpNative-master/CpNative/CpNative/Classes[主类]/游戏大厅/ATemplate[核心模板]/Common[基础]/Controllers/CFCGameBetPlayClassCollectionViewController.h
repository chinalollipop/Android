//
// 游戏 - 投注区 - 选注页面（Collection）
//

#import "CFCGameBetPlayClassViewController.h"
#import "CFCGameBetPlayClassModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFCGameBetPlayClassCollectionViewController : CFCGameBetPlayClassViewController

@property (nonatomic, strong) UICollectionView *collectionView; // 表格

#pragma mark 投注表格 - 对投注表格进行配置（子类继承实现）
- (void)collectionViewSettingRegisterInitialize:(UICollectionView *)collectionView;
#pragma mark 投注表格 - 自定义投注表格每一个分组的列数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfColumnsInSectionForIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model;
#pragma mark 投注表格 - 自定义投注表格的 UICollectionViewCell 的控件
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model;
#pragma mark 投注表格 - 自定义投注表格每一行的高度
- (CGFloat)collectionView:(UICollectionView *)collectionView heightForItemAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model;
#pragma mark 投注表格 - 自定义投注表格的 SectionHeader 的视图
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForHeaderAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model;
#pragma mark 投注表格 - 自定义投注表格的 SectionFooter 的视图
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForFooterAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model;
#pragma mark 投注表格 - 自定义投注表格的 SectionHeader 的高度
- (CGFloat)collectionView:(UICollectionView *)collectionView heightForHeaderAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model;
#pragma mark 投注表格 - 自定义投注表格的 SectionFooter 的高度
- (CGFloat)collectionView:(UICollectionView *)collectionView heightForFooterAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model;

@end

NS_ASSUME_NONNULL_END
