//
// 游戏 - 投注区 - 信用模式
//

#import "CFCGameBetCreditViewController.h"

@interface CFCGameBetCreditViewController ()
/**
 * 头部区域开奖结果容器
 */
@property (nonatomic, strong) UIView *drawResultTopContainerView;
/**
 * 头部区域倒计时区容器
 */
@property (nonatomic, strong) UIView *countDownTopContainerView;


@end

@implementation CFCGameBetCreditViewController


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
}


#pragma mark -
#pragma mark CFCGameBetPlayScrollViewControllerProtocol
#pragma mark 界面元素 - 滑动菜单栏控件高度
- (CGFloat)heightOfScrollSegmentView
{
    return CFC_GAME_PLAY_CREDIT_SCROLL_SEGMENT_HEIGHT;
}

#pragma mark 界面元素 - 底部区域的视图高度
- (CGFloat)heightOfBottomAreaMainView
{
    return CFC_GAME_PLAY_CREDIT_SCROLL_BOTTOM_AREA_HEIGHT;
}

#pragma mark 界面元素 - 表格头部的视图高度
- (CGFloat)heightOfTableHeaderView
{
    return CFC_GAME_PLAY_CREDIT_SCROLL_TABLEVIEW_HEADER_HEIGHT;
}

#pragma mark 界面元素 - 表格头部信息的视图
- (UIView *)viewOfTableHeaderView
{
    CGFloat heightOfTableHeaderView = [self heightOfTableHeaderView];
    CFCGameBetDrawResultItemType drawResultItemType = [self getDrawResultItemType];
    CFCGameBetPlayScrollViewCreditHeader *tableHeaderView = [[CFCGameBetPlayScrollViewCreditHeader alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, heightOfTableHeaderView)
                                                                                                                 gameId:self.gameId
                                                                                                               gameName:self.gameName
                                                                                                         gameIdentifier:self.gameIdentifier
                                                                                                               playMode:self.playModeClass
                                                                                                     drawResultItemType:drawResultItemType
                                                                                                   parentViewController:self];
    tableHeaderView.backgroundColor = COLOR_SYSTEM_MAIN_UI_BACKGROUND_WHITE;
    tableHeaderView.heightOfBottomAreaMainView = [self heightOfBottomAreaMainView];
    self.delegate_betting_header = tableHeaderView;
    return tableHeaderView;
}


@end

