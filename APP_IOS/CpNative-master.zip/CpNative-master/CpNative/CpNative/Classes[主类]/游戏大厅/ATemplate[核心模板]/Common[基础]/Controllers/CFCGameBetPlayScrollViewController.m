//
// 游戏 - 投注区 - 抽象基类
//

#import "CFCGameBetPlayScrollViewController.h"
#import "CFCGameBetPlayClassViewController.h"


// Cell Identifier
static NSString * const CELL_IDENTIFIER_GAME_BET_PLAY_SCROLL_TABLEVIEW_BETTING_CONTENT = @"CFCGameBetPlayScrollViewControllerBettingContentCellIdentifier";


#pragma mark -
#pragma mark 自定义 TableView 控件
@interface CFCGamePlayScrollTableView : UITableView
@end
@implementation CFCGamePlayScrollTableView
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return [gestureRecognizer isKindOfClass:[UIPanGestureRecognizer class]] && [otherGestureRecognizer isKindOfClass:[UIPanGestureRecognizer class]];
}
@end


@interface CFCGameBetPlayScrollViewController () <UITableViewDelegate, UITableViewDataSource, UIScrollViewDelegate, ZJScrollPageViewDelegate, CFCGameBetPlayClassViewControllerDelegate, CFCGameBetPlayScrollViewHeaderDelegate>
@property (strong, nonatomic) ZJContentView *contentView;
@property (strong, nonatomic) ZJScrollSegmentView *segmentView;
@property (strong, nonatomic) CFCGamePlayScrollTableView *tableView;
@property (assign, nonatomic) BOOL isShowProgressHUD; // 是否显示加载菊花
@property (assign, nonatomic) BOOL hasLoadCacheDataOnce; // 是否已加载过缓存
@property (strong, nonatomic) UIScrollView *childScrollView;
@property (strong, nonatomic) UIView *tableHeaderView;

@property (strong, nonatomic) NSMutableArray *tabTitles;
@property (strong, nonatomic) NSMutableArray *tabTitleCodes;
@property (strong, nonatomic) NSMutableArray *viewControllers;

@end


@implementation CFCGameBetPlayScrollViewController


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        _isShowProgressHUD = YES; // 第一加载数据显示
    }
    return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // 必须设置
    [self setAutomaticallyAdjustsScrollViewInsets:NO];
    
}

#pragma mark 确保子控制器的系统生命周期方法被正确的调用
- (BOOL)shouldAutomaticallyForwardAppearanceMethods
{
    return NO;
}

#pragma mark 在切换具体玩法页面后保存选中的具体玩法下标 selectedIndexOfPlayClass
- (void)doChangeSelectedIndexOfPlayClassForPlayScrollViewController:(NSInteger)selectedIndex
{
    // 在主页面保存玩法下标
    if (self.delegate_betting_core && [self.delegate_betting_core respondsToSelector:@selector(changeSelectedIndexOfPlayClassForMainGameCoreViewController:tabMarkCode:)]) {
        NSString *tabMarkCode = STR_SELECT_PLAY_CLASS_MARK_CODE(self.gameId, self.gameName, self.gameIdentifier);
        if (![self.delegate_betting_core changeSelectedIndexOfPlayClassForMainGameCoreViewController:selectedIndex tabMarkCode:tabMarkCode]) {
            CFCLog(@"[changeSelectedIndexOfPlayClassForMainGameCoreViewController:tabMarkCode:]更玩法下标失败");
        }
    } else {
        NSAssert(NO, @"[CFCGameCoreViewController]类必须实现代理方法[changeSelectedIndexOfPlayClassForMainGameCoreViewController:tabMarkCode:]");
    }
    
    // 在主页面保存玩法标识
    if (self.delegate_betting_core && [self.delegate_betting_core respondsToSelector:@selector(changeSelectedPlayCodeOfPlayClassForMainGameCoreViewController:tabMarkCode:)]) {
        NSString *selectedTabPlayCode = (selectedIndex >=0 && selectedIndex < self.tabTitleCodes.count) ? self.tabTitleCodes[selectedIndex] : INIT_SETTING_SELECTED_PLAY_CODE_OF_PLAY_CLASS;
        NSString *tabMarkCode = STR_SELECT_PLAY_CLASS_MARK_CODE(self.gameId, self.gameName, self.gameIdentifier);
        if (![self.delegate_betting_core changeSelectedPlayCodeOfPlayClassForMainGameCoreViewController:selectedTabPlayCode tabMarkCode:tabMarkCode]) {
            CFCLog(@"[changeSelectedPlayCodeOfPlayClassForMainGameCoreViewController:tabMarkCode:]更玩法标识失败");
        }
    } else {
        NSAssert(NO, @"[CFCGameCoreViewController]类必须实现代理方法[changeSelectedPlayCodeOfPlayClassForMainGameCoreViewController:tabMarkCode:]");
    }
    
    // 更新主玩法弹出框标识
    if (self.delegate_betting_core && [self.delegate_betting_core respondsToSelector:@selector(changeSelectedPlayTypeDictionaryForMainGameCoreViewController:playTypeKey:)]) {
        NSString *selectedTabPlayCode = (selectedIndex >=0 && selectedIndex < self.tabTitleCodes.count) ? self.tabTitleCodes[selectedIndex] : INIT_SETTING_SELECTED_PLAY_CODE_OF_PLAY_CLASS;
        // 分割当前选中的页面标识
        NSArray<NSString *> *split = [selectedTabPlayCode split:STR_SPLIT];
        NSString *selectedGameIdentifier = ([CFCSysUtil validateStringEmpty:self.gameIdentifier] ? @"" : self.gameIdentifier.uppercaseString);
        NSString *selectedTypeIdentifier = (split.count > 0 ? split[0] : @"");
        NSString *selectedGroupIdentifier = (split.count > 1 ? split[1] : @"");
        NSString *selectedClassIdentifier = (split.count > 2 ? split[2] : @"");
        // 玩法弹出框标识(KEY,VALUE)
        NSString *playTypeKey = STR_PLAY_TYPE_KEY(selectedGameIdentifier,selectedTypeIdentifier);
        NSString *playTypeValue = STR_PLAY_TYPE_VALUEE(selectedGroupIdentifier,selectedClassIdentifier);
        // 更新主玩法弹出框标识操作
        if (![self.delegate_betting_core changeSelectedPlayTypeDictionaryForMainGameCoreViewController:playTypeValue playTypeKey:playTypeKey]) {
            CFCLog(@"[changeSelectedPlayTypeDictionaryForMainGameCoreViewController:playTypeKey:]玩法弹出框标识失败");
        }
    } else {
        NSAssert(NO, @"[CFCGameCoreViewController]类必须实现代理方法[changeSelectedPlayTypeDictionaryForMainGameCoreViewController:playTypeKey:]");
    }
}


#pragma mark -
#pragma mark 重载页面
- (void)reloadData
{
    [self setViewControllers:[NSMutableArray array]];
    [self setTabTitleCodes:[NSMutableArray array]];
    [self setTabTitles:[NSMutableArray array]];
    
    // 获取玩法的名称与相对应的子控制器
    for (int i = 0; i < [[self dataSource] numberOfViewControllers]; i++) {
        UIViewController *viewController;
        
        if ((viewController = [[self dataSource] viewControllerForIndex:i]) != nil) {
            [[self viewControllers] addObject:viewController];
        }
        
        if ([[self dataSource] respondsToSelector:@selector(titleForTabAtIndex:)]) {
            NSString *title;
            if ((title = [[self dataSource] titleForTabAtIndex:i]) != nil) {
                [[self tabTitles] addObject:title];
            }
        }
        
        if ([[self dataSource] respondsToSelector:@selector(titleCodeForTabAtIndex:)]) {
            NSString *titleCode;
            if ((titleCode = [[self dataSource] titleCodeForTabAtIndex:i]) != nil) {
                [[self tabTitleCodes] addObject:titleCode];
            }
        }
    }
    
    // 创建玩法标签控件与子控制器的容器
    {
        // 删除界面所有控件
        [self.view.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
        
        // 删除界面表格控件
        if (_tableView) {
            [_tableView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
            [_tableView removeFromSuperview];
            [self setTableView:nil];
        }
        
        // 重新创建界面表格
        [self.view addSubview:self.tableView];
        
        // 表格添加下拉刷新
        CFCRefreshHeader *refreshHeader = [CFCRefreshHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadDataForPlayClassViewController)];
        [refreshHeader setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_BACK];
        [self.tableView setMj_header:refreshHeader];
    }
    
    // 初始化默认选项
    if (self.delegate_betting_core && [self.delegate_betting_core respondsToSelector:@selector(selectedIndexOfPlayClassFromMainGameCoreViewController:)]) {
        NSString *tabMarkCode = STR_SELECT_PLAY_CLASS_MARK_CODE(self.gameId, self.gameName, self.gameIdentifier);
        NSInteger selectedIndexOfPlayClass = [self.delegate_betting_core selectedIndexOfPlayClassFromMainGameCoreViewController:tabMarkCode];
        [self.segmentView setSelectedIndex:selectedIndexOfPlayClass animated:NO firstSeting:YES];
    } else {
        NSAssert(NO, @"[ZLLLotteryPlayTabPagerViewController]类必须实现代理方法[selectedIndexOfPlayClassFromPlayTabPagerViewController:]");
    }

}


#pragma mark -
#pragma mark 主页数据 - 刷新加载数据
- (void)loadDataForPlayClassViewController
{
    // 加载更多子控制器的数据
    [self loadMoreDataForPlayClassViewController];
}

#pragma mark 主页数据 - 加载更多数据
- (void)loadMoreDataForPlayClassViewController
{
    WEAKSELF(weakSelf);
    
    // 加载完数据前，其它操作
    [self viewDidLoadBeforeLoadPlayClassViewControllerNetworkDataOrCacheData];
    
    // 验证网络状态，无网则直接返回
    if (![CFCNetworkReachabilityUtil isNetworkAvailable]) {
        
        // 请求数据
        [self loadPlayClassViewControllerNetworkDataThen:^(BOOL success, NSUInteger count){
            
            // 下拉刷新控件，结束刷新状态
            [weakSelf.tableView.mj_header endRefreshing];
            
            // 上拉刷新控件，结束刷新状态
            [weakSelf.tableView.mj_footer endRefreshing];
            
            // 加载完数据后，其它操作
            [weakSelf viewDidLoadAfterLoadPlayClassViewControllerNetworkDataOrCacheData];
            
        }];
        
    } else {
        
        // 请求数据
        [self loadPlayClassViewControllerNetworkDataThen:^(BOOL success, NSUInteger count){
            
            // 下拉刷新控件，结束刷新状态
            [weakSelf.tableView.mj_header endRefreshing];
            
            // 上拉刷新控件，结束刷新状态
            [weakSelf.tableView.mj_footer endRefreshing];
            
            // 加载完数据后，其它操作
            [weakSelf viewDidLoadAfterLoadPlayClassViewControllerNetworkDataOrCacheData];
            
        }];
        
    }
    
}

#pragma mark 主页数据 - 请求网络数据
- (void)loadPlayClassViewControllerNetworkDataThen:(void (^)(BOOL success, NSUInteger count))then
{
    WEAKSELF(weakSelf);
    
    // 请求数据是否成功
    __block BOOL isSuccess = NO;
    __block NSUInteger listCount = 0;
    
    // 请求地址与参数
    NSString *url = URL_API_GAME_SETTING_REFRESH;
    NSMutableDictionary *params = [CFCNetworkParamsUtil getGameSettingRefreshParameters:self.gameId];
    CFCLog(@"\n请求地址：%@ \n请求参数：%@", url, params);
    
    // 验证请求连接的正确性
    if ([CFCSysUtil validateStringEmpty:url]) {
        !then ?: then(isSuccess, listCount);
        return ;
    }

    // 请求网络数据
    [CFCNetworkHTTPSessionUtil GET:url parameters:params responseCache:^(id responseCache) {
        
        /*
        if (!self.hasLoadCacheDataOnce) {
            
            // 加载解析缓存数据
            NSDictionary *responseData = [weakSelf loadPlayClassViewControllerNetworkDataOrCacheData:responseCache isCacheData:YES];
            
            // 更新请求数据状态（用于刷新数据表格）
            listCount = responseData.count;
            if (listCount > 0) {
                isSuccess = YES;
                CFCLog(@"加载解析缓存数据成功");
            } else {
                isSuccess = YES;
                CFCLog(@"没有更多缓存数据");
            }
            
            // 刷新界面
            !then ?: then(isSuccess, listCount);
            
            // 已经加载缓存
            self.hasLoadCacheDataOnce = YES;
        }
        */
        
    } success:^(id responseObject) {
        
        // 加载解析网络数据
        NSDictionary *responseData = [weakSelf loadPlayClassViewControllerNetworkDataOrCacheData:responseObject isCacheData:NO];
        
        // 更新请求数据状态（用于刷新数据表格）
        listCount = responseData.count;
        if (listCount > 0) {
            isSuccess = YES;
            CFCLog(@"加载请求网络数据成功");
        } else {
            isSuccess = YES;
            CFCLog(@"没有更多网络数据");
        }
        
        // 刷新界面
        !then ?: then(isSuccess, listCount);
        
        // 第一次加载数据后禁止显示菊花
        self.isShowProgressHUD = NO;
        
    } failure:^(NSError *error) {
        
        CFCLog(@"加载请求网络数据异常：%@", error);
        
        // 刷新界面
        !then ?: then(isSuccess, listCount);
        
        // 第一次加载数据后禁止显示菊花
        self.isShowProgressHUD = NO;
        
    }  showMessage:nil showProgressHUD:self.isShowProgressHUD isHideErrorMessage:YES];

}

#pragma mark 主页数据 - 加载网络或缓存数据
- (NSDictionary *)loadPlayClassViewControllerNetworkDataOrCacheData:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData
{
    NSDictionary *responseData = (NSDictionary *)responseDataOrCacheData;
    // CFCLog(@"主页数据 => %@\n%@", CFC_DATA_TYPE(isCacheData), responseData);
    
    // 请求成功，解析数据
    NSArray *data = [responseData objectForKey:CFC_REQUEST_KEY_DATA];
    NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
    if (![CFCSysUtil validateResultCodeIsSuccess:status] || [CFCSysUtil validateObjectIsNull:data]) {
        return [NSDictionary dictionary];
    }
    
    // 保存主页面接口的所有数据
    self.allResponseDataOrCacheData = responseData;

    // 保存主页面数据至叶子页面
    self.playClassVCData = responseData;

    // 返回叶子页面数据
    return self.playClassVCData;
}

#pragma mark 主页数据 - 加载完数据前操作，每次刷新加载数据前都会执行
- (void)viewDidLoadBeforeLoadPlayClassViewControllerNetworkDataOrCacheData
{
    
}

#pragma mark 主页数据 - 加载完数据后操作，每次刷新加载数据后都会执行
- (void)viewDidLoadAfterLoadPlayClassViewControllerNetworkDataOrCacheData
{
    // 更新开奖和倒计时区域数据
    if (self.delegate_betting_header && [self.delegate_betting_header respondsToSelector:@selector(doRefreshRequestDataForPlayScrollViewHeader:)]) {
        [self.delegate_betting_header doRefreshRequestDataForPlayScrollViewHeader:self.allResponseDataOrCacheData];
    } else {
        NSAssert(NO, @"[CFCGameBetPlayScrollViewHeader]类必须实现代理方法[doRefreshRequestDataForPlayScrollViewHeader:]");
    }
    
    // 更新赔率数据到子结点页面
    if (self.delegate_betting_playclass && [self.delegate_betting_playclass respondsToSelector:@selector(doRefreshRequestOddsDataForPlayClassViewController:)]) {
        [self.delegate_betting_playclass doRefreshRequestOddsDataForPlayClassViewController:self.playClassVCData];
    } else {
        NSAssert(NO, @"[CFCGameBetPlayClassViewController]类必须实现代理方法[doRefreshRequestOddsDataForPlayClassViewController:]");
    }
}



#pragma mark -
#pragma mark CFCGameBetPlayClassViewControllerDelegate
#pragma mark 投注总数 - 在主页面更新用户的投注总数
- (BOOL)changeSumNumberOfBettingForMainGameBetViewController:(NSInteger)number
{
    // TODO: 子类必须继承此方法，并在子类中更新用记投注总数
    
    return NO;
}

#pragma mark 投注内容 - 在主页面更新用户的投注内容
- (BOOL)changeContentsOfBettingForMainGameCoreViewController:(NSArray<NSString *> *)contents
{
    // TODO: 子类必须继承此方法，并在子类中更新用记投注内空
    
    return YES;
}

#pragma mark 投注标识 - 获取已保存的具体玩法投注标识(选中或不选中)
- (NSArray *)selectedDataMarkOfBettingFromMainGameCoreViewController:(NSString *)tabClassCode
{
    if (self.delegate_betting_core && [self.delegate_betting_core respondsToSelector:@selector(selectedDataMarkOfBettingFromMainGameCoreViewController:)]) {
        NSString *dataMarkCode = STR_SELECT_PLAY_DATA_MARK_CODE(self.gameId, self.gameIdentifier, tabClassCode);
        return [self.delegate_betting_core selectedDataMarkOfBettingFromMainGameCoreViewController:dataMarkCode];
    } else {
//        NSAssert(NO, @"[CFCGameCoreViewController]类必须实现代理方法[selectedDataMarkOfBettingFromMainGameCoreViewController:]");
    }
    return nil;
}

#pragma mark 投注标识 - 在主页面更新具体玩法投注标识(选中或不选中)
- (BOOL)changeSelectedDataMarkOfBettingForMainGameCoreViewController:(NSArray *)selectedDataMark tabClassCode:(NSString *)tabClassCode
{
    if (self.delegate_betting_core && [self.delegate_betting_core respondsToSelector:@selector(changeSelectedDataMarkOfBettingForMainGameCoreViewController:dataMarkCode:)]) {
        NSString *dataMarkCode = STR_SELECT_PLAY_DATA_MARK_CODE(self.gameId, self.gameIdentifier, tabClassCode);
        return [self.delegate_betting_core changeSelectedDataMarkOfBettingForMainGameCoreViewController:selectedDataMark dataMarkCode:dataMarkCode];
    } else {
//        NSAssert(NO, @"[CFCGameCoreViewController]类必须实现代理方法[changeSelectedDataMarkOfBettingForMainGameCoreViewController:dataMarkCode:]");
    }
    return NO;
}

#pragma mark 投注备注 - 获取已保存的具体玩法投注备注
- (NSArray *)selectedDataRemarkOfBettingFromMainGameCoreViewController:(NSString *)tabClassCode
{
    if (self.delegate_betting_core && [self.delegate_betting_core respondsToSelector:@selector(selectedDataRemarkOfBettingFromMainGameCoreViewController:)]) {
        NSString *dataMarkCode = STR_SELECT_PLAY_DATA_MARK_CODE(self.gameId, self.gameIdentifier, tabClassCode);
        return [self.delegate_betting_core selectedDataRemarkOfBettingFromMainGameCoreViewController:dataMarkCode];
    } else {
//        NSAssert(NO, @"[CFCGameCoreViewController]类必须实现代理方法[selectedDataRemarkOfBettingFromMainGameCoreViewController:]");
    }
    return nil;
}

#pragma mark 投注备注 - 在主页面更新具体玩法投注备注
- (BOOL)changeSelectedDataRemarkOfBettingForMainGameCoreViewController:(NSArray *)selectedDataRemark tabClassCode:(NSString *)tabClassCode
{
    if (self.delegate_betting_core && [self.delegate_betting_core respondsToSelector:@selector(changeSelectedDataRemarkOfBettingForMainGameCoreViewController:dataMarkCode:)]) {
        NSString *dataMarkCode = STR_SELECT_PLAY_DATA_MARK_CODE(self.gameId, self.gameIdentifier, tabClassCode);
        return [self.delegate_betting_core changeSelectedDataRemarkOfBettingForMainGameCoreViewController:selectedDataRemark dataMarkCode:dataMarkCode];
    } else {
//        NSAssert(NO, @"[CFCGameCoreViewController]类必须实现代理方法[changeSelectedDataRemarkOfBettingForMainGameCoreViewController:dataMarkCode:]");
    }
    return NO;
}

#pragma mark 玩法标识 - 获取当前页面具体玩法标识 currentSelectedPlayCodeOfPlayClass
- (NSString *)currentSelectedPlayCodeOfPlayClassFromMainGameCoreViewController
{
    if (self.delegate_betting_core && [self.delegate_betting_core respondsToSelector:@selector(currentSelectedPlayCodeOfPlayClassFromMainGameCoreViewController)]) {
        return [self.delegate_betting_core currentSelectedPlayCodeOfPlayClassFromMainGameCoreViewController];
    } else {
//        NSAssert(NO, @"[CFCGameCoreViewController]类必须实现代理方法[currentSelectedPlayCodeOfPlayClassFromMainGameCoreViewController]");
    }
    return nil;
}

#pragma mark 玩法标识 - 获取已保存的具体玩法标识 selectedPlayCodeOfPlayClass
- (NSString *)selectedPlayCodeOfPlayClassFromMainGameCoreViewController:(NSString *)tabMarkCode
{
    if (self.delegate_betting_core && [self.delegate_betting_core respondsToSelector:@selector(selectedPlayCodeOfPlayClassFromMainGameCoreViewController:)]) {
        return [self.delegate_betting_core selectedPlayCodeOfPlayClassFromMainGameCoreViewController:tabMarkCode];
    } else {
//        NSAssert(NO, @"[CFCGameCoreViewController]类必须实现代理方法[selectedPlayCodeOfPlayClassFromMainGameCoreViewController]");
    }
    return nil;
}

#pragma mark 玩法标识 - 获取已保存的玩法弹出框标识 selectedPlayTypeDictionary
- (NSMutableDictionary<NSString *, NSString *> *)selectedPlayTypeDictionaryFromMainGameCoreViewController
{
    if (self.delegate_betting_core && [self.delegate_betting_core respondsToSelector:@selector(selectedPlayTypeDictionaryFromMainGameCoreViewController)]) {
        return [self.delegate_betting_core selectedPlayTypeDictionaryFromMainGameCoreViewController];
    } else {
//        NSAssert(NO, @"[CFCGameCoreViewController]类必须实现代理方法[selectedPlayTypeDictionaryFromMainGameCoreViewController]");
    }
    return nil;
}

#pragma mark 玩法模式 - 获取当前主页面的玩法模式 currentPlayModeClass
- (CFCGameCorePlayModeClass)currentPlayModeClassForMainGameCoreViewController
{
    if (self.delegate_betting_core && [self.delegate_betting_core respondsToSelector:@selector(currentPlayModeClassForMainGameCoreViewController)]) {
        return [self.delegate_betting_core currentPlayModeClassForMainGameCoreViewController];
    } else {
//        NSAssert(NO, @"[CFCGameCoreViewController]类必须实现代理方法[currentPlayModeClassForMainGameCoreViewController]");
    }
    return -1;
}

#pragma mark 倒计时间 - 在倒计时间结束后是否可以弹提示信息框
- (BOOL)canAlertTipInfoDialogAfterCounting
{
    if (self.delegate_betting_core && [self.delegate_betting_core respondsToSelector:@selector(canAlertTipInfoDialogAfterCounting)]) {
        return [self.delegate_betting_core canAlertTipInfoDialogAfterCounting];
    } else {
//        NSAssert(NO, @"[CFCGameCoreViewController]类必须实现代理方法[canAlertTipInfoDialogAfterCounting]");
    }
    return NO;
}


#pragma mark 投注赔率 - 在主页面请求加载投注赔率数据
- (void)doLoadRefreshOddsDataFromPlayScrollViewController
{
    // 显示下拉请求加载动画
    // [self.tableView.mj_header beginRefreshing];
    
    // 隐藏下拉请求加载动画
    [self loadDataForPlayClassViewController];
}


#pragma mark -
#pragma mark CFCGameBetPlayScrollToPlayClassViewControllerProtocol
#pragma mark 清空操作 - 清空按钮事件传递至叶子结点页面
- (void)doClearButtonActionForPlayClassViewController
{
    if (self.delegate_betting_playclass && [self.delegate_betting_playclass respondsToSelector:@selector(doClearButtonActionForPlayClassViewController)]) {
        return [self.delegate_betting_playclass doClearButtonActionForPlayClassViewController];
    } else {
        NSAssert(NO, @"[CFCGameBetPlayClassViewController]类必须实现代理方法[doClearButtonActionForPlayClassViewController]");
    }
}

#pragma mark 投注操作 - 投注按钮事件传递至叶子结点页面
- (void)doBettingButtonActionForPlayClassViewController
{
    if (self.delegate_betting_playclass && [self.delegate_betting_playclass respondsToSelector:@selector(doBettingButtonActionForPlayClassViewController)]) {
        return [self.delegate_betting_playclass doBettingButtonActionForPlayClassViewController];
    } else {
        NSAssert(NO, @"[CFCGameBetPlayClassViewController]类必须实现代理方法[doBettingButtonActionForPlayClassViewController]");
    }
}


#pragma mark -
#pragma mark  ZJScrollPageViewDelegate

- (NSInteger)numberOfChildViewControllers
{
    return self.tabTitles.count;
}

- (UIViewController<ZJScrollPageViewChildVcDelegate> *)childViewController:(UIViewController<ZJScrollPageViewChildVcDelegate> *)reuseViewController forIndex:(NSInteger)index
{
    UIViewController<ZJScrollPageViewChildVcDelegate> *childViewController = reuseViewController;
    
    // 判断是否是为空
    if (!childViewController) {
        // 根据对应的下标获取相应控件器
        childViewController = self.viewControllers[index];
        // 子控制器必须是CFCGameBetPlayClassViewController的子类
        if ([childViewController isKindOfClass:[CFCGameBetPlayClassViewController class]]) {
            // 将控件器类强制类型转换成基类
            CFCGameBetPlayClassViewController<CFCGameBetPlayScrollToPlayClassViewControllerProtocol> *viewController = (CFCGameBetPlayClassViewController *)childViewController;
            // 根据主界面设置子控制器的高度
            {
                // 控制器的高度
                CGRect frame = [self frameOfScrollContentView:NO];
                [viewController setScrollViewSize:frame.size];
            }
            // 设置代理, 处理子控制器的滚动
            viewController.delegate = self;
        } else {
            // 强制抛出异常
            NSString *message = [NSString stringWithFormat:@"[%@]玩法的基类必须是[CFCGameBetPlayClassViewController]，请进行修改。", self.tabTitles[index]];
            NSAssert(NO, message);
        }
    }
    
    // 设置代理, 更新 [CFCGameBetPlayClassViewController] 叶子结点页面的相关数据
    CFCGameBetPlayClassViewController<CFCGameBetPlayScrollToPlayClassViewControllerProtocol> *viewController = (CFCGameBetPlayClassViewController *)childViewController;
    self.delegate_betting_playclass = viewController;
    
    return childViewController;
}


#pragma mark - CFCGameBetCoreToPlayScrollViewHeaderProtocol
#pragma mark 释放资源 - 切换游戏释放资源
- (void)doDestoryTimerForPlayScrollViewHeader:(NSString *)gameId gameName:(NSString *)gameName gameIdentifier:(NSString *)gameIdentifier
{
    if (self.delegate_betting_header && [self.delegate_betting_header respondsToSelector:@selector(doDestoryTimerForPlayScrollViewHeader:gameName:gameIdentifier:)]) {
        return [self.delegate_betting_header doDestoryTimerForPlayScrollViewHeader:self.gameId gameName:self.gameName gameIdentifier:self.gameIdentifier];
    } else {
        NSAssert(NO, @"[CFCGameBetPlayScrollViewHeader]类必须实现代理方法[doDestoryTimerForPlayScrollViewHeader:gameIdentifier:]");
    }
}


#pragma mark -
#pragma mark UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CFCLog(@"%@", NSStringFromCGPoint(scrollView.contentOffset));
    
    /*
    CGFloat heightOfTableHeaderView = [self heightOfTableHeaderView];
    if (self.childScrollView && self.childScrollView.contentOffset.y > 0) {
        self.tableView.contentOffset = CGPointMake(0.0f, heightOfTableHeaderView);
    }
    
    CGFloat offsetY = scrollView.contentOffset.y;
    if(offsetY < heightOfTableHeaderView) {
        [[NSNotificationCenter defaultCenter] postNotificationName:CFCGameBetPlayClassParentTableViewDidLeaveFromTopNotification object:nil];
    } else {
        self.tableView.contentOffset = CGPointMake(0.0f, heightOfTableHeaderView);
    }
    */
    
    if (self.childScrollView.contentSize.height <= self.childScrollView.frame.size.height) {
        CGFloat heightOfTableHeaderView = [self heightOfTableHeaderView];
        CGFloat heightOfSegment = self.tabTitles.count > 1 ? [self heightOfScrollSegmentView] : 0.0f;
        [self.tableView setContentSize:CGSizeMake(self.tableView.frame.size.width,
                                                  self.childScrollView.contentSize.height + heightOfTableHeaderView + heightOfSegment)];
        [[NSNotificationCenter defaultCenter] postNotificationName:CFCGameBetPlayClassParentTableViewDidLeaveFromTopNotification object:nil];
    } else {
        CGFloat heightOfTableHeaderView = [self heightOfTableHeaderView];
        CGFloat heightOfSegment = self.tabTitles.count > 1 ? [self heightOfScrollSegmentView] : 0.0f;
        [self.tableView setContentSize:CGSizeMake(self.tableView.frame.size.width,
                                                  self.childScrollView.contentSize.height + heightOfTableHeaderView + heightOfSegment)];
        
        if (self.childScrollView && self.childScrollView.contentOffset.y > 0) {
            self.tableView.contentOffset = CGPointMake(0.0f, heightOfTableHeaderView);
        }
        
        CGFloat offsetY = scrollView.contentOffset.y;
        if(offsetY < heightOfTableHeaderView) {
            [[NSNotificationCenter defaultCenter] postNotificationName:CFCGameBetPlayClassParentTableViewDidLeaveFromTopNotification object:nil];
        } else {
            self.tableView.contentOffset = CGPointMake(0.0f, heightOfTableHeaderView);
        }
    }
}


#pragma mark -
#pragma mark CFCGameBetPlayClassViewControllerDelegate
- (void)scrollViewIsScrolling:(UIScrollView *)scrollView
{
    _childScrollView = scrollView;
    if (_childScrollView.contentSize.height > _childScrollView.frame.size.height) {
        CGFloat heightOfTableHeaderView = [self heightOfTableHeaderView];
        if (self.tableView.contentOffset.y < heightOfTableHeaderView) {
            scrollView.contentOffset = CGPointZero;
            scrollView.showsVerticalScrollIndicator = NO;
        } else {
            self.tableView.contentOffset = CGPointMake(0.0f, heightOfTableHeaderView);
            scrollView.showsVerticalScrollIndicator = NO;
        }
    } else {
        scrollView.contentOffset = CGPointZero;
        scrollView.showsVerticalScrollIndicator = NO;
    }
}

#pragma mark -
#pragma mark  UITableViewDelegate, UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_SCROLL_TABLEVIEW_BETTING_CONTENT];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_SCROLL_TABLEVIEW_BETTING_CONTENT];
    }
    [cell.contentView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [cell.contentView addSubview:self.contentView];
    return cell;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    return self.tabTitles.count > 1 ? self.segmentView : nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return self.tabTitles.count > 1 ? [self heightOfScrollSegmentView] : 0.0f;
}


#pragma mark -
#pragma mark CFCGameBetPlayScrollViewControllerProtocol
#pragma mark 界面元素 - 滑动菜单栏控件高度
- (CGFloat)heightOfScrollSegmentView
{
    // TODO: 请在子类中重载该方法，并设置滑动菜单栏控件高度
    
    return CFC_GAME_PLAY_SCROLL_SEGMENT_HEIGHT;
}

#pragma mark 界面元素 - 底部区域的视图高度
- (CGFloat)heightOfBottomAreaMainView
{
    // TODO: 请在子类中重载该方法，并设置底部区域的视图高度
    
    return CFC_GAME_PLAY_SCROLL_BOTTOM_AREA_HEIGHT;
}

#pragma mark 界面元素 - 表格头部的视图高度
- (CGFloat)heightOfTableHeaderView
{
    // TODO: 请在子类中重载该方法，并设置表格头部的视图高度
    
    return CFC_GAME_PLAY_SCROLL_TABLEVIEW_HEADER_HEIGHT;
}

#pragma mark 界面元素 - 表格头部信息的视图
- (UIView *)viewOfTableHeaderView
{
    // TODO: 请在子类中重载该方法，并设置表格头部信息的视图
    
    CGFloat heightOfTableHeaderView = [self heightOfTableHeaderView];
    CFCGameBetDrawResultItemType drawResultItemType = [self getDrawResultItemType];
    CFCGameBetPlayScrollViewHeader *tableHeaderView = [[CFCGameBetPlayScrollViewHeader alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, heightOfTableHeaderView)
                                                                                                     gameId:self.gameId
                                                                                                   gameName:self.gameName
                                                                                             gameIdentifier:self.gameIdentifier
                                                                                                   playMode:self.playModeClass
                                                                                         drawResultItemType:drawResultItemType
                                                                                       parentViewController:self];
    tableHeaderView.backgroundColor = COLOR_SYSTEM_MAIN_UI_BACKGROUND_WHITE;
    tableHeaderView.heightOfBottomAreaMainView = [self heightOfBottomAreaMainView];
    self.delegate_betting_header = tableHeaderView;
    return tableHeaderView;
}

#pragma mark 界面元素 - 表格的位置宽高大小
- (CGRect)frameOfScrollTableView
{
    // TODO: 请在子类中重载该方法，并设置表格的位置宽高大小
    
    // 底部区域高度
    CGFloat heightOfBottom = [self heightOfBottomAreaMainView];
    // 计算 TableView 大小
    CGFloat frameHeight = self.view.bounds.size.height - STATUS_NAVIGATION_BAR_HEIGHT - SCROLL_GAME_SUB_TAB_HEIGHT - heightOfBottom;
    // 返回 frame
    return CGRectMake(0.0f, 0.0f, self.view.bounds.size.width, frameHeight);
}

#pragma mark 界面元素 - 投注内容的宽高大小
- (CGRect)frameOfScrollContentView:(BOOL)isFirst
{
    // TODO: 请在子类中重载该方法，并设置表格的位置宽高大小

    // 底部区域高度
    CGFloat heightOfBottom = [self heightOfBottomAreaMainView];
    // 滑动菜单高度
    CGFloat heightOfSegment = self.tabTitles.count > 1 ? [self heightOfScrollSegmentView] : 0.0f;
    // 计算 ContentView 的大小
    CGFloat frameHeight = self.view.bounds.size.height - heightOfSegment - heightOfBottom;
    if (isFirst) {
        frameHeight = self.view.bounds.size.height - STATUS_NAVIGATION_BAR_HEIGHT - SCROLL_GAME_SUB_TAB_HEIGHT;
    }
    // 返回 ZJContentView 的大小
    return CGRectMake(0.0f, 0.0f, self.view.bounds.size.width, frameHeight);
}

#pragma mark 开奖结果 - 开奖类型
- (CFCGameBetDrawResultItemType)getDrawResultItemType
{
    // TODO: 请在子类中重载该方法，并设置开奖结果类型
    
    return CFCGameBetDrawResultItemTypeDefault;
}


#pragma mark -
#pragma mark 事件处理 - 切换玩法 - 验证玩法的页面是否存在 - CFCGameBetPlayScrollViewHeaderDelegate
- (BOOL)canSelectedPlayClassViewController:(NSString *)classCode
                    selectedGameIdentifier:(NSString *)selectedGameIdentifier
                    selectedTypeIdentifier:(NSString *)selectedTypeIdentifier
                   selectedGroupIdentifier:(NSString *)selectedGroupIdentifier
                   selectedClassIdentifier:(NSString *)selectedClassIdentifier
                    selectedClassTitleName:(NSString *)selectedClassTitleName
{
    NSInteger selectedIndex = [self.tabTitleCodes indexOfObject:classCode];
    if (0 <= selectedIndex && selectedIndex < self.tabTitleCodes.count) {
        return YES;
    }
    return NO;
}

#pragma mark 事件处理 - 切换玩法 - 玩法页面存在则切换 - CFCGameBetPlayScrollViewHeaderDelegate
- (void)didSelectedPlayClassViewController:(NSString *)classCode
                    selectedGameIdentifier:(NSString *)selectedGameIdentifier
                    selectedTypeIdentifier:(NSString *)selectedTypeIdentifier
                   selectedGroupIdentifier:(NSString *)selectedGroupIdentifier
                   selectedClassIdentifier:(NSString *)selectedClassIdentifier
                    selectedClassTitleName:(NSString *)selectedClassTitleName
                     selectedPlayTypeModel:(CFCGameBetPlayTypeModel *)selectedGameBetPlayTypeModel
                selectedPlayTypeGroupModel:(CFCGameBetPlayTypeGroupModel *)selectedGameBetPlayTypeGroupModel
                selectedPlayTypeClassModel:(CFCGameBetPlayTypeClassModel *)selectedGameBetPlayTypeClassModel
{
    NSInteger selectedIndex = [self.tabTitleCodes indexOfObject:classCode];
    if (0 <= selectedIndex && selectedIndex < self.tabTitleCodes.count) {
        if (self.segmentView.getCurrentIndex != selectedIndex) {
            [self.segmentView setSelectedIndex:selectedIndex animated:NO];
        }
    } else {
        [Tools alertWithTitle:@"玩法页面出错，请稍后再试！" message:nil handle:nil cancel:nil confirm:@"确定"];
    }
}


#pragma mark -
#pragma mark Setter & Getter
- (CFCGamePlayScrollTableView *)tableView
{
    if (!_tableView) {
        // 计算 TableView 大小
        CGRect frame = [self frameOfScrollTableView];
        // 创建 TableView
        CFCGamePlayScrollTableView *tableView = [[CFCGamePlayScrollTableView alloc] initWithFrame:frame
                                                                                            style:UITableViewStylePlain];
        // 设置 TableView 的 HeadView
        tableView.tableHeaderView = self.tableHeaderView;
        tableView.tableFooterView = [UIView new];
        // 设置 TableView 的 sectionHeadHeight
        tableView.sectionHeaderHeight = [self heightOfScrollSegmentView];
        tableView.sectionFooterHeight = FLOAT_MIN;
        // 设置 TableView 的 Cell 行高为 contentView 的高度
        tableView.rowHeight = self.contentView.bounds.size.height;
        // 设置 TableView 的代理与数据源
        tableView.delegate = self;
        tableView.dataSource = self;
        tableView.showsVerticalScrollIndicator = NO;
        tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        // 设置 TableView 自动算高
        tableView.fd_debugLogEnabled = YES;
        // 设置 TableView 的背景视图
        UIView *backgroundView = [[UIView alloc] init];
        [backgroundView setBackgroundColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT];
        [tableView setBackgroundView:backgroundView];
        // 设置 TableView 实例
        _tableView = tableView;
    }
    return _tableView;
}

- (UIView *)tableHeaderView
{
    if (!_tableHeaderView) {
        _tableHeaderView = [self viewOfTableHeaderView];
    }
    return _tableHeaderView;
}


- (ZJScrollSegmentView *)segmentView
{
    if (_segmentView == nil) {
        //
        CGFloat height_percent = 0.65f;
        CGFloat height = [self heightOfScrollSegmentView];
        // 屏幕宽度显示菜单数
        CGFloat column = 3.0f;
        // 间隔变量值
        CGFloat margin =CFC_AUTOSIZING_MARGIN(MARGIN);
        // 菜单样式设置
        ZJSegmentStyle *style = [[ZJSegmentStyle alloc] init];
        // 是否显示图片
        style.showImage = NO;
        // 是否显示滚动条
        style.showLine = NO;
        // 是否缩放标题
        style.scaleTitle = NO;
        // 是否有弹性
        style.segmentViewBounces = NO;
        // 是否颜色渐变
        style.gradualChangeTitleColor = YES;
        // 是否显示遮盖
        style.showCover = YES;
        // 遮盖的圆角
        style.coverCornerRadius = margin*0.50f;
        // 遮盖的高度
        style.coverHeight = height * height_percent;
        // 遮盖背景颜色
        style.coverBackgroundColor = COLOR_SYSTEM_MAIN_BUTTON_BACKGROUND_SELECT_DEFAULT;
        // 标题的字体
        style.titleFont = [UIFont boldSystemFontOfSize:14];
        // 标题背景
        style.titleBackgroundColor = [UIColor colorWithRed:255.0/255.0 green:255.0/255.0 blue:255.0/255.0 alpha:1.0];
        // 标题之间的间隙
        style.titleMargin = margin*0.50f;
        // 标题的最小宽度
        style.titleMinWidth = (SCREEN_WIDTH-style.titleMargin*(column+1)) / column;
        // 标题宽度自动扩展长度
        style.titleAdjustWidthGap = margin*2.0f;
        // 标题圆角半径
        style.titleCornerRadius = margin*0.50f;
        // 标题边框宽度
        style.titleBorderWidth = 1.0f;
        // 标题控件高度
        style.titleHeight = height * height_percent;
        // 标题边框颜色
        style.titleBorderColor = [UIColor colorWithRed:0.90 green:0.90 blue:0.90 alpha:1.00];
        // 标题一般状态颜色 - 注意:此处一定要使用RGB空间的颜色值
        style.normalTitleColor = [UIColor colorWithRed:0.0/255.0 green:0.0/255.0 blue:0.0/255.0 alpha:1.0];
        // 标题选中状态颜色 - 注意:此处一定要使用RGB空间的颜色值
        style.selectedTitleColor = [UIColor colorWithRed:255.0/255.0 green:255.0/255.0 blue:255.0/255.0 alpha:1.0];
        // 点击标题切换的时候,标题是否会有动画
        style.adjustUIWhenBtnOnClickWithAnimate = NO;
        // 点击标题切换的时候,内容是否会有动画
        style.animatedContentViewWhenTitleClicked = YES;
        // 关联的contentView是否能滑动
        style.scrollContentView = NO;
        // 关联的contentView是否有弹性
        style.contentViewBounces = NO;
        
        // 注意: 一定要避免循环引用
        __weak __typeof(&*self)weakSelf = self;
        CGRect frame = CGRectMake(0, 0, self.view.bounds.size.width, height);
        ZJScrollSegmentView *segment = [[ZJScrollSegmentView alloc] initWithFrame:frame segmentStyle:style delegate:self titles:self.tabTitles titleDidClick:^(ZJTitleView *titleView, NSInteger index) {
            // 调整对应内容的位置
            [weakSelf.contentView setContentOffSet:CGPointMake(weakSelf.contentView.bounds.size.width * index, 0.0f) animated:NO];
            // 重置页面内容的位置
            [weakSelf.childScrollView setContentOffset:CGPointMake(0.0f, 0.0f) animated:NO];
            [weakSelf.tableView setContentOffset:CGPointMake(0.0f, 0.0f) animated:NO];
            // 主页面保存玩法下标
            [weakSelf doChangeSelectedIndexOfPlayClassForPlayScrollViewController:index];
        }];
        [segment setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_WHITE];
        [segment addBorderWithColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT cornerRadius:0.0f andWidth:1.0f];
        _segmentView = segment;
    }
    return _segmentView;
}

- (ZJContentView *)contentView
{
    if (_contentView == nil) {
        CGRect frame = [self frameOfScrollContentView:YES];
        ZJContentView *content = [[ZJContentView alloc] initWithFrame:frame segmentView:self.segmentView parentViewController:self delegate:self];
        _contentView = content;
    }
    return _contentView;
}


@end
