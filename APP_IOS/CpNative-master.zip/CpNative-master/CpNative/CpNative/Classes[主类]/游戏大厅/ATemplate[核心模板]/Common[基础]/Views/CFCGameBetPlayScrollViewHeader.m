//
//  游戏 - 投注页面头部区域 - 基类
//

#import "CFCGameBetPlayScrollViewHeader.h"
#import "CFCCountPopNoticeView.h"
#import "CFCCountDownObject.h"


@interface CFCGameBetPlayScrollViewHeader ()

/**
 * 是否已加载过缓存（刷新数据）
 */
@property (nonatomic, assign) BOOL hasLoadCacheDataOncOfRefresh;
/**
 * 是否已加载过缓存（玩法选择）
 */
@property (nonatomic, assign) BOOL hasLoadCacheDataOncOfPlayType;
/**
 * 是否已加载过缓存（开奖结果）
 */
@property (nonatomic, assign) BOOL hasLoadCacheDataOncOfDrawResult;


/**
 * 当前期的期号
 */
@property (nonatomic, strong) NSString *currentIssueNumber;
/**
 * 下一期的期号
 */
@property (nonatomic, strong) NSString *currentNextIssueNumber;
/**
 * 当前盘口时间
 */
@property (nonatomic, assign) NSNumber *currentIssueFinishTime;


@end


@implementation CFCGameBetPlayScrollViewHeader


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _playModeClass = CFCGameCorePlayModeClassOfficial; // 默认官方模式
    }
    return self;
}

#pragma mark 视图生命周期（初始化）
- (instancetype)initWithFrame:(CGRect)frame
                       gameId:(NSString *)gameId
                     gameName:(NSString *)gameName
               gameIdentifier:(NSString *)gameIdentifier
                     playMode:(CFCGameCorePlayModeClass)playModeClass
           drawResultItemType:(CFCGameBetDrawResultItemType)drawResultItemType
         parentViewController:(CFCGameBetBaseViewController<CFCGameBetPlayScrollViewHeaderDelegate> *)parentViewController
{
    self = [self initWithFrame:frame];
    if (self) {
        _gameId = gameId;
        _gameName = gameName;
        _gameIdentifier = gameIdentifier;
        _playModeClass = playModeClass;
        _drawResultItemType = drawResultItemType;
        _parentViewController = parentViewController;
        _delegate = parentViewController;
        [self createViewAtuoLayout];
    }
    return self;
}


#pragma mark -
#pragma mark 创建子类控件
- (void) createViewAtuoLayout
{
    // TODO: 在子类中实现并创建页面
    
}

#pragma mark 创建开奖结果
- (void)createViewOfDrawResultsAtuoLayout:(BOOL)isForce
{
    // TODO: 在子类中实现并创建页面
    
}

#pragma mark 创建玩法选择
- (void)createViewOfPlayTypeButtonAtuoLayout:(BOOL)isForce
{
    // TODO: 在子类中实现并创建页面
    
}


#pragma mark -
#pragma mark 刷新数据 - 请求数据
- (void)loadNetworkDataOfRefresh
{
    // 加载完数据前，其它操作
    [self viewDidLoadBeforeRequestRefreshNetworkDataOrCacheData];
    
    // 验证网络状态，无网则直接返回
    if (![CFCNetworkReachabilityUtil isNetworkAvailable]) {
        
        // 请求数据
        [self loadNetworkDataSourceOfRefreshThen:^(BOOL success, NSUInteger count){

            // 加载完数据后，其它操作
            [self viewDidLoadAfterRequestRefreshNetworkDataOrCacheData];
            
        }];
        
    } else {
        
        // 请求数据
        [self loadNetworkDataSourceOfRefreshThen:^(BOOL success, NSUInteger count){

            // 加载完数据后，其它操作
            [self viewDidLoadAfterRequestRefreshNetworkDataOrCacheData];
            
        }];
        
    }
    
}

#pragma mark 刷新数据 - 请求数据 - 加载请求网络数据
- (void)loadNetworkDataSourceOfRefreshThen:(void (^)(BOOL success, NSUInteger count))then
{
    WEAKSELF(weakSelf);
    
    // 请求数据是否成功
    __block BOOL isSuccess = NO;
    __block NSUInteger listCount = 0;
    
    // 请求地址与参数
    NSString *url = URL_API_GAME_SETTING_REFRESH;
    NSMutableDictionary *params = [CFCNetworkParamsUtil getGameSettingRefreshParameters:self.gameId];
    CFCLog(@"\n请求地址：%@ \n请求参数：%@", url, params);
    
    // 请求网络数据
    [CFCNetworkHTTPSessionUtil GET:url parameters:params responseCache:^(id responseCache) {
        
        /*
        if (!self.hasLoadCacheDataOncOfRefresh) {
            
            // 加载解析网络数据
            NSMutableArray *responseTableData = [weakSelf loadNetworkDataOrCacheDataOfRefresh:responseCache isCacheData:YES];
            
            // 更新请求数据状态（用于刷新数据表格）
            listCount = responseTableData.count;
            if (listCount > 0) {
                isSuccess = YES;
                CFCLog(@"加载请求刷新数据列表数据成功");
            } else {
                isSuccess = YES;
                CFCLog(@"没有更多刷新数据列表数据");
            }
            
            // 刷新界面
            !then ?: then(isSuccess,listCount);
            
            // 已经加载缓存
            self.hasLoadCacheDataOncOfRefresh = YES;
        }
        */
        
    } success:^(id responseObject) {
        
        // 加载解析网络数据
        NSMutableArray *responseTableData = [weakSelf loadNetworkDataOrCacheDataOfRefresh:responseObject isCacheData:NO];
        
        // 更新请求数据状态（用于刷新数据表格）
        listCount = responseTableData.count;
        if (listCount > 0) {
            isSuccess = YES;
            CFCLog(@"加载请求刷新数据列表数据成功");
        } else {
            isSuccess = YES;
            CFCLog(@"没有更多刷新数据列表数据");
        }
        
        // 刷新界面
        !then ?: then(isSuccess,listCount);
        
    } failure:^(NSError *error) {
        
        CFCLog(@"加载请求刷新数据列表数据异常：%@", error);
        
        // 刷新界面
        !then ?: then(isSuccess,listCount);
        
    } showMessage:nil showProgressHUD:NO isHideErrorMessage:YES];
    
}

#pragma mark 刷新数据 - 请求数据 - 加载请求玩法标签网络或缓存数据
- (NSMutableArray *)loadNetworkDataOrCacheDataOfRefresh:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData
{
    NSDictionary *responseData = (NSDictionary *)responseDataOrCacheData;
    // CFCLog(@"刷新数据列表 => %@\n%@", CFC_DATA_TYPE(isCacheData), responseData);
    
    // 请求成功，解析数据
    NSDictionary *data = [responseData objectForKey:CFC_REQUEST_KEY_DATA];
    NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
    if (![CFCSysUtil validateResultCodeIsSuccess:status] || [CFCSysUtil validateObjectIsNull:data]) {
        return [NSMutableArray array];
    }
    
    // 保存主页面接口的所有数据
    self.allResponseDataOrCacheData = responseDataOrCacheData;
    
    // 开奖的结果
    {
        NSDictionary *dictOfIssueHistory = [data objectForKey:@"issueHistory"];
        NSArray *arrayOfDrawResult = [dictOfIssueHistory objectForKey:@"issues"];
        NSMutableArray<CFCGameBetDrawResultModel *> *drawResultDetailModels = [self doWithNetworkDataOrCacheDataOfDrawResult:arrayOfDrawResult];
        self.drawResultDetailModels = drawResultDetailModels;
    }

    
    // 盘口倒计时
    {
        NSNumber *currentTime = [data numberForKey:@"currentTime"];
        NSNumber *currentNumberTime = [data numberForKey:@"currentNumberTime"];
        NSDate *begin_date = [NSDate dateWithTimeIntervalSince1970:currentTime.doubleValue];
        NSDate *finish_date = [NSDate dateWithTimeIntervalSince1970:currentNumberTime.doubleValue];
        NSTimeInterval timeInterval = [finish_date timeIntervalSinceDate:begin_date];
        [self setCurrentIssueFinishTime:currentNumberTime];
        if (timeInterval > 0) {
            [self setCountDownTimeFinishDate:finish_date andBeginDate:begin_date];
        } else {
            [self setCountDownTimeMinuteValue:1.0/60.0];
        }
    }

    
    // 当前期期号
    {
        NSString *currentNumber = [data stringForKey:@"currentNumber"];
        [self setCurrentIssueNumber:currentNumber];
        [self setCurrentIssueNumberLabelValue:currentNumber];
    }

    
    // 下一期期号
    {
        // 获取追号期号列表
        __block NSMutableArray<NSString *> *nextNumbers = [NSMutableArray<NSString *> array];
        NSArray *arrayOfNextNumbers = [data arrayForKey:@"gameNumbers"];
        [arrayOfNextNumbers enumerateObjectsUsingBlock:^(NSDictionary * _Nonnull dict, NSUInteger idx, BOOL * _Nonnull stop) {
            NSString *number = [dict stringForKey:@"number"];
            [nextNumbers addObject:number];
        }];
        NSArray<NSString *> *sortedNextNumbers = [CFCStringMathsUtil sortedArray:nextNumbers];
        // 获取下一期的期号
        __block NSString *currentNextNumber = nil;
        NSString *currentNumber = [data stringForKey:@"currentNumber"];
        [sortedNextNumbers enumerateObjectsUsingBlock:^(NSString * _Nonnull number, NSUInteger idx, BOOL * _Nonnull stop) {
            if (number.integerValue > currentNumber.integerValue) {
                currentNextNumber = number;
                *stop = YES;
            }
        }];
        [self setCurrentNextIssueNumber:currentNextNumber];
    }

    // 数据列表
    return self.drawResultDetailModels;
}

#pragma mark 刷新数据 - 请求数据 - 加载完数据前操作，每次刷新加载数据前都会执行
- (void)viewDidLoadBeforeRequestRefreshNetworkDataOrCacheData
{
    
    
}

#pragma mark 刷新数据 - 请求数据 - 加载完数据后操作，每次刷新加载数据后都会执行
- (void)viewDidLoadAfterRequestRefreshNetworkDataOrCacheData
{
    // 如果盘口间隔小于零则数据异常，重新加载数据
    {
        long long currentDateSecond = [CFCDateUtil getCurrentDateSecond];
        NSDate *begin_date = [[NSDate alloc] initWithTimeIntervalSince1970:currentDateSecond];
        NSDate *finish_date = [NSDate dateWithTimeIntervalSince1970:self.currentIssueFinishTime.doubleValue];
        NSTimeInterval timeInterval = [finish_date timeIntervalSinceDate:begin_date];
        if (timeInterval <= 0) {
            WEAKSELF(weakSelf);
            [[CFCGameDataTimerUtil sharedGameDataTimerUtil] countDownWithBlock:^{
                [weakSelf loadNetworkDataOfRefresh];
            } gameId:self.gameId gameName:self.gameName gameIdentifier:self.gameIdentifier];
        } else{
            [[CFCGameDataTimerUtil sharedGameDataTimerUtil] destoryTimer];
        }
    }
    
    // 创建开奖结果（头部开奖结果、下拉开奖列表）
    if ([self isDrawingFromDrawResultList:self.drawResultDetailModels]) {
        [self createViewOfDrawResultsAtuoLayout:NO];
    } else {
        [self createViewOfDrawResultsAtuoLayout:YES];
    }
    
    // 判断是否有正在开奖中的数据
    if ([self isDrawingFromDrawResultList:self.drawResultDetailModels]) {
        WEAKSELF(weakSelf);
        [[CFCGameTimerUtil sharedGameTimerUtil] countDownWithBlock:^{
            [weakSelf loadNetworkDataOfRefresh];
        } gameId:self.gameId gameName:self.gameName gameIdentifier:self.gameIdentifier];
    } else {
        [[CFCGameTimerUtil sharedGameTimerUtil] destoryTimer];
    }
}


#pragma mark -
#pragma mark 玩法选择 - 加载请求网络数据
- (void)loadNetworkDataSourceOfPlayTypeSelectThen:(void (^)(BOOL success, NSUInteger count))then
{
    WEAKSELF(weakSelf);
    
    // 请求数据是否成功
    __block BOOL isSuccess = NO;
    __block NSUInteger listCount = 0;
    
    // 请求地址与参数
    NSString *url = URL_API_GAME_SETTING_REFRESH;
    NSMutableDictionary *params = [CFCNetworkParamsUtil getGameSettingRefreshParameters:self.gameId];
    CFCLog(@"\n请求地址：%@ \n请求参数：%@", url, params);
    
    // 请求网络数据
    [CFCNetworkHTTPSessionUtil GET:url parameters:params responseCache:^(id responseCache) {
        
        if (!self.hasLoadCacheDataOncOfPlayType) {
            
            // 加载解析网络数据
            NSMutableArray *responseTableData = [weakSelf loadNetworkDataOrCacheDataOfPlayTypeSelect:responseCache isCacheData:YES];
            
            // 更新请求数据状态（用于刷新数据表格）
            listCount = responseTableData.count;
            if (listCount > 0) {
                isSuccess = YES;
                CFCLog(@"加载请求游戏玩法列表数据成功");
            } else {
                isSuccess = YES;
                CFCLog(@"没有更多游戏玩法列表数据");
            }
            
            // 刷新界面
            !then ?: then(isSuccess,listCount);
            
            // 已经加载缓存
            self.hasLoadCacheDataOncOfPlayType = YES;
        }

    } success:^(id responseObject) {
        
        // 加载解析网络数据
        NSMutableArray *responseTableData = [weakSelf loadNetworkDataOrCacheDataOfPlayTypeSelect:responseObject isCacheData:NO];
        
        // 更新请求数据状态（用于刷新数据表格）
        listCount = responseTableData.count;
        if (listCount > 0) {
            isSuccess = YES;
            CFCLog(@"加载请求游戏玩法列表数据成功");
        } else {
            isSuccess = YES;
            CFCLog(@"没有更多游戏玩法列表数据");
        }
        
        // 刷新界面
        !then ?: then(isSuccess,listCount);
        
    } failure:^(NSError *error) {
        
        CFCLog(@"加载请求游戏玩法列表数据异常：%@", error);
        
        // 刷新界面
        !then ?: then(isSuccess,listCount);
        
    } showMessage:nil showProgressHUD:YES isHideErrorMessage:YES];
    
}

#pragma mark 玩法选择 - 加载请求玩法标签网络或缓存数据
- (NSMutableArray<CFCGameBetPlayTypeModel *> *)loadNetworkDataOrCacheDataOfPlayTypeSelect:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData
{
    NSDictionary *responseData = (NSDictionary *)responseDataOrCacheData;
    // CFCLog(@"游戏玩法列表 => %@\n%@", CFC_DATA_TYPE(isCacheData), responseData);
    
    // 请求成功，解析数据
    NSDictionary *data = [responseData objectForKey:CFC_REQUEST_KEY_DATA];
    NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
    if (![CFCSysUtil validateResultCodeIsSuccess:status] || [CFCSysUtil validateObjectIsNull:data]) {
        return [NSMutableArray array];
    }
    
    // 请求成功，玩法选择
    NSArray<NSDictionary *> *arrayOfPlayType = [data objectForKey:@"wayGroups"];
    if ([CFCSysUtil validateObjectIsNull:arrayOfPlayType]) {
        return [NSMutableArray array];
    }
    
    
    /////////////////////////////////////////////////////////////////
    // A、组装数据 -> 开始
    /////////////////////////////////////////////////////////////////
    
    NSMutableArray<CFCGameBetPlayTypeModel *> *allGamePlayTypeModels = [NSMutableArray array];
    for (NSInteger idx0 = 0; idx0 < arrayOfPlayType.count ; idx0 ++) {
        // 玩法
        NSDictionary *dictPlayType = [arrayOfPlayType objectAtIndex:idx0];
        CFCGameBetPlayTypeModel *playTypeModel = [CFCGameBetPlayTypeModel mj_objectWithKeyValues:dictPlayType];
        // 分组
        NSArray *playGroupData = [dictPlayType arrayForKey:@"children"];
        NSMutableArray<CFCGameBetPlayTypeGroupModel *> *playGroupModels = [NSMutableArray array];
        for (NSInteger idx1 = 0; idx1 < playGroupData.count ; idx1 ++) {
            // 分组
            NSDictionary *dictPlayGroup = [playGroupData objectAtIndex:idx1];
            CFCGameBetPlayTypeGroupModel *playGroupModel = [CFCGameBetPlayTypeGroupModel mj_objectWithKeyValues:dictPlayGroup];
            // 玩法
            NSArray *playClassData = [dictPlayGroup arrayForKey:@"children"];
            NSMutableArray<CFCGameBetPlayTypeClassModel *> *playClassModels = [NSMutableArray array];
            for (NSInteger idx2 = 0; idx2 < playClassData.count ; idx2 ++) {
                // 玩法
                NSDictionary *dictPlayClass = [playClassData objectAtIndex:idx2];
                CFCGameBetPlayTypeClassModel *playClassModel = [CFCGameBetPlayTypeClassModel mj_objectWithKeyValues:dictPlayClass];
                if (0 == idx1 && 0 == idx2) {
                    [playClassModel setIsSelected:YES];
                }
                [playClassModels addObject:playClassModel];
            }
            if (0 == idx1) {
                [playGroupModel setIsSelected:YES];
            }
            [playGroupModel setChildrenClass:[NSArray arrayWithArray:playClassModels]];
            [playGroupModels addObject:playGroupModel];
        }
        if (0 == idx0) {
            [playTypeModel setIsSelected:YES];
        }
        [playTypeModel setChildrenGroup:[NSArray arrayWithArray:playGroupModels]];
        [allGamePlayTypeModels addObject:playTypeModel];
    }
    
    /////////////////////////////////////////////////////////////////
    // A、组装数据 -> 结束
    /////////////////////////////////////////////////////////////////
    
    
    /////////////////////////////////////////////////////////////////
    // B、配置数据源  -> 开始
    /////////////////////////////////////////////////////////////////
    self.allGamePlayTypeModels = allGamePlayTypeModels.mutableCopy;
    /////////////////////////////////////////////////////////////////
    // B、配置数据源  -> 结束
    /////////////////////////////////////////////////////////////////
    
    return self.allGamePlayTypeModels;
}


#pragma mark -
#pragma mark 开奖结果 - 请求数据 - 加载请求网络数据
- (void)loadNetworkDataSourceOfDrawResultThen:(void (^)(BOOL success, NSUInteger count))then
{
    WEAKSELF(weakSelf);
    
    // 请求数据是否成功
    __block BOOL isSuccess = NO;
    __block NSUInteger listCount = 0;
  
    // 请求地址与参数
    NSString *url = URL_API_GAME_DRAW_RESULT_LIST;
    NSMutableDictionary *params = [CFCNetworkParamsUtil getGameDrawResultListParameters:self.gameId count:@"5"];
    CFCLog(@"\n请求地址：%@ \n请求参数：%@", url, params);
    
    // 请求网络数据
    [CFCNetworkHTTPSessionUtil GET:url parameters:params responseCache:^(id responseCache) {
        
        if (!self.hasLoadCacheDataOncOfDrawResult) {
            
            // 加载解析网络数据
            NSMutableArray *responseTableData = [weakSelf loadNetworkDataOrCacheDataOfDrawResult:responseCache isCacheData:YES];
            
            // 更新请求数据状态（用于刷新数据表格）
            listCount = responseTableData.count;
            if (listCount > 0) {
                isSuccess = YES;
                CFCLog(@"加载请求开奖结果列表数据成功");
            } else {
                isSuccess = YES;
                CFCLog(@"没有更多开奖结果列表数据");
            }
            
            // 刷新界面
            !then ?: then(isSuccess,listCount);
            
            // 已经加载缓存
            self.hasLoadCacheDataOncOfDrawResult = YES;
        }

    } success:^(id responseObject) {
        
        // 加载解析网络数据
        NSMutableArray *responseTableData = [weakSelf loadNetworkDataOrCacheDataOfDrawResult:responseObject isCacheData:NO];
        
        // 更新请求数据状态（用于刷新数据表格）
        listCount = responseTableData.count;
        if (listCount > 0) {
            isSuccess = YES;
            CFCLog(@"加载请求开奖结果列表数据成功");
        } else {
            isSuccess = YES;
            CFCLog(@"没有更多开奖结果列表数据");
        }
        
        // 刷新界面
        !then ?: then(isSuccess,listCount);
        
    } failure:^(NSError *error) {
        
        CFCLog(@"加载请求开奖结果列表数据异常：%@", error);
        
        // 刷新界面
        !then ?: then(isSuccess,listCount);
        
    } showMessage:nil showProgressHUD:YES isHideErrorMessage:YES];
    
}

#pragma mark 开奖结果 - 请求数据 - 加载请求玩法标签网络或缓存数据
- (NSMutableArray<CFCGameBetDrawResultModel *> *)loadNetworkDataOrCacheDataOfDrawResult:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData
{
    NSDictionary *responseData = (NSDictionary *)responseDataOrCacheData;
    // CFCLog(@"开奖结果列表 => %@\n%@", CFC_DATA_TYPE(isCacheData), responseData);
    
    // 请求成功，解析数据
    NSArray *data = [responseData objectForKey:CFC_REQUEST_KEY_DATA];
    NSInteger status = [[responseData objectForKey:CFC_REQUEST_KEY_STATUS] integerValue];
    if (![CFCSysUtil validateResultCodeIsSuccess:status] || [CFCSysUtil validateObjectIsNull:data]) {
        return [NSMutableArray array];
    }

    // 处理并组装开奖结果数据模型
    return [self doWithNetworkDataOrCacheDataOfDrawResult:data];
}

#pragma mark 开奖结果 - 处理数据 - 组装开奖结果详情列表数据模型
- (NSMutableArray<CFCGameBetDrawResultModel *> *)doWithNetworkDataOrCacheDataOfDrawResult:(NSArray<NSDictionary *> *)dataOfDrawResult
{
    /////////////////////////////////////////////////////////////////
    // A、组装数据 -> 开始
    /////////////////////////////////////////////////////////////////
    
    NSMutableArray<CFCGameBetDrawResultModel *> *dropDownMenuOfDrawResultModels = [NSMutableArray array];
    [dataOfDrawResult enumerateObjectsUsingBlock:^(NSDictionary *  _Nonnull dict, NSUInteger idx, BOOL * _Nonnull stop) {
        CFCGameBetDrawResultModel *model = [CFCGameBetDrawResultModel mj_objectWithKeyValues:dict];
        [dropDownMenuOfDrawResultModels addObject:model];
    }];
    
    /////////////////////////////////////////////////////////////////
    // A、组装数据 -> 结束
    /////////////////////////////////////////////////////////////////
    
    
    /////////////////////////////////////////////////////////////////
    // B、配置数据源  -> 开始
    /////////////////////////////////////////////////////////////////
    self.drawResultDetailModels = [NSMutableArray array];
    if (dropDownMenuOfDrawResultModels && 0 < dropDownMenuOfDrawResultModels.count) {
        NSArray<CFCGameBetDrawResultModel *> *models = [self buildingDrawResultModelsForDropDownMenu:dropDownMenuOfDrawResultModels
                                                                                            itemType:self.drawResultItemType
                                                                                              itemId:self.gameIdentifier];
        [self.drawResultDetailModels addObjectsFromArray:models];
    }
    /////////////////////////////////////////////////////////////////
    // B、配置数据源  -> 结束
    /////////////////////////////////////////////////////////////////
    
    return self.drawResultDetailModels;
}


#pragma mark -
#pragma mark 开奖结果 - 头部区域 - 头部开奖详情视图
- (CFCGameBetDrawResultDefaultTopAreaView *)viewForHeaderDrawResultsAreaFrame:(CGRect)frame
{
    CFCGameBetDrawResultModel *drawResultsModel = [self buildingDataModleForHeaderArea:self.drawResultDetailModels.firstObject
                                                                              itemType:self.drawResultItemType
                                                                                itemId:self.gameIdentifier];
    
    switch (self.drawResultItemType) {
            // 类型 -> Default -> 开奖结果类型 -> 默认
        case CFCGameBetDrawResultItemTypeDefault: {
            return [[CFCGameBetDrawResultDefaultTopAreaView alloc] initWithFrame:frame
                                                                          gameId:self.gameId
                                                                        gameName:self.gameName
                                                                  gameIdentifier:self.gameIdentifier
                                                                        playMode:self.playModeClass
                                                                drawResultsModel:drawResultsModel];
        }
            // 类型 -> Official1 -> 开奖结果类型 -> 官方玩法 -> 时时彩（重庆时时彩、官网分分彩、官网三分彩、官网五分彩）
        case CFCGameBetDrawResultItemTypeOfficial01: {
            return [[CFCSSCOfficialDrawResultTopAreaView alloc] initWithFrame:frame
                                                                       gameId:self.gameId
                                                                     gameName:self.gameName
                                                               gameIdentifier:self.gameIdentifier
                                                                     playMode:self.playModeClass
                                                             drawResultsModel:drawResultsModel];
        }
            // 类型 -> Official2 -> 开奖结果类型 -> 官方玩法 -> 11选5（广东11选5、官网11选、11选5三分彩）
        case CFCGameBetDrawResultItemTypeOfficial02: {
            return [[CFC11X5OfficialDrawResultTopAreaView alloc] initWithFrame:frame
                                                                        gameId:self.gameId
                                                                      gameName:self.gameName
                                                                gameIdentifier:self.gameIdentifier
                                                                      playMode:self.playModeClass
                                                              drawResultsModel:drawResultsModel];
        }
            // 类型 -> Official3 -> 开奖结果类型 -> 官方玩法 -> PK10（幸运飞艇、北京PK10、极速PK10）
        case CFCGameBetDrawResultItemTypeOfficial03: {
            return [[CFCPK10OfficialDrawResultTopAreaView alloc] initWithFrame:frame
                                                                        gameId:self.gameId
                                                                      gameName:self.gameName
                                                                gameIdentifier:self.gameIdentifier
                                                                      playMode:self.playModeClass
                                                              drawResultsModel:drawResultsModel];
        }
            // 类型 -> Official4 -> 开奖结果类型 -> 官方玩法 -> 快三（江苏快三、官网快三分分彩）
        case CFCGameBetDrawResultItemTypeOfficial04: {
            return [[CFCKuai3OfficialDrawResultTopAreaView alloc] initWithFrame:frame
                                                                         gameId:self.gameId
                                                                       gameName:self.gameName
                                                                 gameIdentifier:self.gameIdentifier
                                                                       playMode:self.playModeClass
                                                               drawResultsModel:drawResultsModel];
        }
            // 类型 -> Official5 -> 开奖结果类型 -> 官方玩法 -> 极速3D（官网极速3D）
        case CFCGameBetDrawResultItemTypeOfficial05: {
            return [[CFCJS3DOfficialDrawResultTopAreaView alloc] initWithFrame:frame
                                                                        gameId:self.gameId
                                                                      gameName:self.gameName
                                                                gameIdentifier:self.gameIdentifier
                                                                      playMode:self.playModeClass
                                                              drawResultsModel:drawResultsModel];
        }
            // 类型 -> Official6 -> 开奖结果类型 -> 官方玩法 -> 北京快乐8（北京快乐8）
        case CFCGameBetDrawResultItemTypeOfficial06: {
            return [[CFCBJKL8OfficialDrawResultTopAreaView alloc] initWithFrame:frame
                                                                         gameId:self.gameId
                                                                       gameName:self.gameName
                                                                 gameIdentifier:self.gameIdentifier
                                                                       playMode:self.playModeClass
                                                               drawResultsModel:drawResultsModel];
        }
        default: {
            // 类型 -> Default -> 开奖结果类型 -> 默认
            return [[CFCGameBetDrawResultDefaultTopAreaView alloc] initWithFrame:frame
                                                                          gameId:self.gameId
                                                                        gameName:self.gameName
                                                                  gameIdentifier:self.gameIdentifier
                                                                        playMode:self.playModeClass
                                                                drawResultsModel:drawResultsModel];
        }
    }
}

#pragma mark 开奖结果 - 头部区域 - 头部开奖详情数据
- (CFCGameBetDrawResultModel *) buildingDataModleForHeaderArea:(CFCGameBetDrawResultModel *)dataModel
                                                      itemType:(CFCGameBetDrawResultItemType)drawResultItemType
                                                        itemId:(NSString *)itemId
{
    switch (drawResultItemType) {
            // 类型 -> Default -> 开奖结果类型 -> 默认
        case CFCGameBetDrawResultItemTypeDefault: {
            return [CFCGameBetDrawResultModel buildingDataModleForHeaderArea:dataModel itemType:drawResultItemType itemId:itemId];
        }
            // 类型 -> Official1 -> 开奖结果类型 -> 官方玩法 -> 时时彩（重庆时时彩、官网分分彩、官网三分彩、官网五分彩）
        case CFCGameBetDrawResultItemTypeOfficial01: {
            return [CFCSSCDrawResultModel buildingDataModleForHeaderArea:dataModel itemType:drawResultItemType itemId:itemId];
        }
            // 类型 -> Official2 -> 开奖结果类型 -> 官方玩法 -> 11选5（广东11选5、官网11选、11选5三分彩）
        case CFCGameBetDrawResultItemTypeOfficial02: {
            return [CFC11X5DrawResultModel buildingDataModleForHeaderArea:dataModel itemType:drawResultItemType itemId:itemId];
        }
            // 类型 -> Official3 -> 开奖结果类型 -> 官方玩法 -> PK10（幸运飞艇、北京PK10、极速PK10）
        case CFCGameBetDrawResultItemTypeOfficial03: {
            return [CFCPK10DrawResultModel buildingDataModleForHeaderArea:dataModel itemType:drawResultItemType itemId:itemId];
        }
            // 类型 -> Official4 -> 开奖结果类型 -> 官方玩法 -> 快三（江苏快三、官网快三分分彩）
        case CFCGameBetDrawResultItemTypeOfficial04: {
            return [CFCKuai3DrawResultModel buildingDataModleForHeaderArea:dataModel itemType:drawResultItemType itemId:itemId];
        }
            // 类型 -> Official5 -> 开奖结果类型 -> 官方玩法 -> 极速3D（官网极速3D）
        case CFCGameBetDrawResultItemTypeOfficial05: {
            return [CFCJS3DDrawResultModel buildingDataModleForHeaderArea:dataModel itemType:drawResultItemType itemId:itemId];
        }
            // 类型 -> Official6 -> 开奖结果类型 -> 官方玩法 -> 北京快乐8（北京快乐8）
        case CFCGameBetDrawResultItemTypeOfficial06: {
            return [CFCBJKL8DrawResultModel buildingDataModleForHeaderArea:dataModel itemType:drawResultItemType itemId:itemId];
        }
        default: {
            // 类型 -> Default -> 开奖结果类型 -> 默认
            return [CFCGameBetDrawResultModel buildingDataModleForHeaderArea:dataModel itemType:drawResultItemType itemId:itemId];
        }
    }
}


#pragma mark -
#pragma mark 开奖结果 - 详情列表 - 根据游戏类型标识处理网络或缓存数据
- (NSArray<CFCGameBetDrawResultModel *> *)buildingDrawResultModelsForDropDownMenu:(NSMutableArray<CFCGameBetDrawResultModel *> *)dataModels
                                                                         itemType:(CFCGameBetDrawResultItemType)drawResultItemType
                                                                           itemId:(NSString *)itemId
{
    switch (drawResultItemType) {
            // 类型 -> Default -> 开奖结果类型 -> 默认
        case CFCGameBetDrawResultItemTypeDefault: {
            NSMutableArray<CFCGameBetDrawResultModel *> *drawResultModels = [CFCGameBetDrawResultModel buildingDataModles:dataModels
                                                                                                                 itemType:drawResultItemType
                                                                                                                   itemId:itemId];
            return [NSArray<CFCGameBetDrawResultModel *> arrayWithArray:drawResultModels];
        }
            // 类型 -> Official1 -> 开奖结果类型 -> 官方玩法 -> 时时彩（重庆时时彩、官网分分彩、官网三分彩、官网五分彩）
        case CFCGameBetDrawResultItemTypeOfficial01: {
            NSMutableArray<CFCSSCDrawResultModel *> *drawResultModels = [CFCSSCDrawResultModel buildingDataModles:(NSMutableArray<CFCSSCDrawResultModel *> *)dataModels
                                                                                                         itemType:drawResultItemType
                                                                                                           itemId:itemId];
            return [NSArray<CFCSSCDrawResultModel *> arrayWithArray:drawResultModels];
        }
            // 类型 -> Official2 -> 开奖结果类型 -> 官方玩法 -> 11选5（广东11选5、官网11选、11选5三分彩）
        case CFCGameBetDrawResultItemTypeOfficial02: {
            NSMutableArray<CFC11X5DrawResultModel *> *drawResultModels = [CFC11X5DrawResultModel buildingDataModles:(NSMutableArray<CFC11X5DrawResultModel *> *)dataModels
                                                                                                           itemType:drawResultItemType
                                                                                                             itemId:itemId];
            return [NSArray<CFC11X5DrawResultModel *> arrayWithArray:drawResultModels];
        }
            // 类型 -> Official3 -> 开奖结果类型 -> 官方玩法 -> PK10（幸运飞艇、北京PK10、极速PK10）
        case CFCGameBetDrawResultItemTypeOfficial03: {
            NSMutableArray<CFCPK10DrawResultModel *> *drawResultModels = [CFCPK10DrawResultModel buildingDataModles:(NSMutableArray<CFCPK10DrawResultModel *> *)dataModels
                                                                                                           itemType:drawResultItemType
                                                                                                             itemId:itemId];
            return [NSArray<CFCPK10DrawResultModel *> arrayWithArray:drawResultModels];
        }
            // 类型 -> Official4 -> 开奖结果类型 -> 官方玩法 -> 快三（江苏快三、官网快三分分彩）
        case CFCGameBetDrawResultItemTypeOfficial04: {
            NSMutableArray<CFCKuai3DrawResultModel *> *drawResultModels = [CFCKuai3DrawResultModel buildingDataModles:(NSMutableArray<CFCKuai3DrawResultModel *> *)dataModels
                                                                                                             itemType:drawResultItemType
                                                                                                               itemId:itemId];
            return [NSArray<CFCKuai3DrawResultModel *> arrayWithArray:drawResultModels];
        }
            // 类型 -> Official5 -> 开奖结果类型 -> 官方玩法 -> 极速3D（官网极速3D）
        case CFCGameBetDrawResultItemTypeOfficial05: {
            NSMutableArray<CFCJS3DDrawResultModel *> *drawResultModels = [CFCJS3DDrawResultModel buildingDataModles:(NSMutableArray<CFCJS3DDrawResultModel *> *)dataModels
                                                                                                           itemType:drawResultItemType
                                                                                                             itemId:itemId];
            return [NSArray<CFCJS3DDrawResultModel *> arrayWithArray:drawResultModels];
        }
            // 类型 -> Official6 -> 开奖结果类型 -> 官方玩法 -> 北京快乐8（北京快乐8）
        case CFCGameBetDrawResultItemTypeOfficial06: {
            NSMutableArray<CFCBJKL8DrawResultModel *> *drawResultModels = [CFCBJKL8DrawResultModel buildingDataModles:(NSMutableArray<CFCBJKL8DrawResultModel *> *)dataModels
                                                                                                             itemType:drawResultItemType
                                                                                                               itemId:itemId];
            return [NSArray<CFCBJKL8DrawResultModel *> arrayWithArray:drawResultModels];
        }
        default: {
            // 类型 -> Default -> 开奖结果类型 -> 默认
            NSMutableArray<CFCGameBetDrawResultModel *> *drawResultModels = [CFCGameBetDrawResultModel buildingDataModles:dataModels
                                                                                                                 itemType:drawResultItemType
                                                                                                                   itemId:itemId];
            return [NSArray<CFCGameBetDrawResultModel *> arrayWithArray:drawResultModels];
        }
    }
}

#pragma mark 开奖结果 - 详情列表 - 根据开奖类型标识获取对应的表格名称
- (NSString *)buildingDrawResultTableViewCellClassNameForDropDownMenuItemType:(CFCGameBetDrawResultItemType)drawResultItemType
                                                                       itemId:(NSString *)itemId
{
    switch (drawResultItemType) {
            // 类型 -> Default -> 开奖结果类型 -> 默认
        case CFCGameBetDrawResultItemTypeDefault: {
            return @"CFCGameBetDrawResultDefaultTableViewCell";
        }
            // 类型 -> Official1 -> 开奖结果类型 -> 官方玩法 -> 时时彩（重庆时时彩、官网分分彩、官网三分彩、官网五分彩）
        case CFCGameBetDrawResultItemTypeOfficial01: {
            return @"CFCSSCOfficialDrawResultTableViewCell";
        }
            // 类型 -> Official2 -> 开奖结果类型 -> 官方玩法 -> 11选5（广东11选5、官网11选、11选5三分彩）
        case CFCGameBetDrawResultItemTypeOfficial02: {
            return @"CFC11X5OfficialDrawResultTableViewCell";
        }
            // 类型 -> Official3 -> 开奖结果类型 -> 官方玩法 -> PK10（幸运飞艇、北京PK10、极速PK10）
        case CFCGameBetDrawResultItemTypeOfficial03: {
            return @"CFCPK10OfficialDrawResultTableViewCell";
        }
            // 类型 -> Official4 -> 开奖结果类型 -> 官方玩法 -> 快三（江苏快三、官网快三分分彩）
        case CFCGameBetDrawResultItemTypeOfficial04: {
            return @"CFCKuai3OfficialDrawResultTableViewCell";
        }
            // 类型 -> Official5 -> 开奖结果类型 -> 官方玩法 -> 极速3D（官网极速3D）
        case CFCGameBetDrawResultItemTypeOfficial05: {
            return @"CFCJS3DOfficialDrawResultTableViewCell";
        }
            // 类型 -> Official6 -> 开奖结果类型 -> 官方玩法 -> 北京快乐8（北京快乐8）
        case CFCGameBetDrawResultItemTypeOfficial06: {
            return @"CFCBJKL8OfficialDrawResultTableViewCell";
        }
        default: {
            // 类型 -> Default -> 开奖结果类型 -> 默认
            return @"CFCGameBetDrawResultDefaultTableViewCell";
        }
    }
}


#pragma mark -
#pragma mark CFCGameBetPlayScrollToPlayScrollViewHeaderProtocol
#pragma mark 主页数据 - 更新开奖结果数据至开奖结果倒计时区域
- (void)doRefreshRequestDataForPlayScrollViewHeader:(NSDictionary *)responseData
{
    // 加载完数据前，其它操作
    [self viewDidLoadBeforeRequestRefreshNetworkDataOrCacheData];
    
    // 保存主页面接口的所有数据
    self.allResponseDataOrCacheData = responseData;
    
    // 处理主页面接口的数据
    [self loadNetworkDataOrCacheDataOfRefresh:responseData isCacheData:NO];
    
    // 加载完数据后，其它操作
    [self viewDidLoadAfterRequestRefreshNetworkDataOrCacheData];
}

#pragma mark 投注期号 - 当前盘口投注期号
- (NSString *)currentBettingIssueNumberFromPlayScrollViewHeader
{
    return self.currentIssueNumber;
}

#pragma mark 释放资源 - 切换游戏释放资源
- (void)doDestoryTimerForPlayScrollViewHeader:(NSString *)gameId gameName:(NSString *)gameName gameIdentifier:(NSString *)gameIdentifier
{
    [self destoryAlloc];
}


#pragma mark -
#pragma mark  CFCCountTimerViewDelegate
#pragma mark 倒计时间 - 开奖结果倒计时区域结束事件
- (void)doAfterCountDownTimerComplete
{
    // 弹出提示信息框
    if (self.delegate && [self.delegate respondsToSelector:@selector(canAlertTipInfoDialogAfterCounting)]) {
        BOOL canAlertTipInfoDialogAfterCounting = [self.delegate canAlertTipInfoDialogAfterCounting];
        if (canAlertTipInfoDialogAfterCounting) {
            CFCCountPopNoticeView *popNoticeView = [CFCCountPopNoticeView sharePopNoticeView];
            [popNoticeView setCount:3.0f];
            [popNoticeView setContent:self.currentNextIssueNumber];
            [popNoticeView setAfterDismissBlock:^{
                
            }];
            [popNoticeView show];
        }
    } else {
        NSAssert(NO, @"[CFCGameBetPlayScrollViewController]类必须实现代理方法[canAlertTipInfoDialogAfterCounting]");
    }
    
    // 重请求页面数据
    [self loadNetworkDataOfRefresh];
}


#pragma mark -
#pragma mark Private
#pragma mark 设置倒计时控件值（分钟）
- (void)setCountDownTimeMinuteValue:(CGFloat)minute
{
    long long currentDateSecond = [CFCDateUtil getCurrentDateSecond];
    NSDate *beginDate = [[NSDate alloc] initWithTimeIntervalSince1970:currentDateSecond];
    NSDate *finishDate = [[NSDate alloc] initWithTimeIntervalSince1970:currentDateSecond + minute*60];
    [self setCountDownTimeFinishDate:finishDate andBeginDate:beginDate];
}

#pragma mark 设置倒计时控件值（结束日期-开始日期）
- (void)setCountDownTimeFinishDate:(NSDate *)finishDate andBeginDate:(NSDate *)beginDate
{
    [self.countDownTimeView setFinishDate:finishDate andBeginDate:beginDate gameId:self.gameId gameName:self.gameName gameIdentifier:self.gameIdentifier];
}

#pragma mark 设置当前期号的值
- (void)setCurrentIssueNumberLabelValue:(NSString *)issueNumber
{
    if ([CFCSysUtil validateStringEmpty:issueNumber]) {
        issueNumber = GAME_DRAW_RESULT_ISSUE_NUMBER(self.gameIdentifier);
    }
    
    NSDictionary *attributesText = @{ NSFontAttributeName:[UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(14.0f)],
                                      NSForegroundColorAttributeName:COLOR_GAME_DRAW_RESULT_ISSUE_CHINESE };
    NSDictionary *attributesNumber = @{ NSFontAttributeName:[UIFont fontWithName:@"NotoMono" size:CFC_AUTOSIZING_FONT(15)],
                                        NSForegroundColorAttributeName:COLOR_SYSTEM_MAIN_FONT_ASSIST_RED_DEFAULT };
    NSAttributedString *attributedString = [CFCSysUtil attributedString:@[ @"第", issueNumber, @"期 投注时间" ]
                                                         attributeArray:@[ attributesText, attributesNumber, attributesText]];
    [self.currentIssueNumberLabel setAttributedText:attributedString];
}

#pragma mark 判断是否有正开奖中的号码
- (BOOL)isDrawingFromDrawResultList:(NSMutableArray<CFCGameBetDrawResultModel *> *)drawResultDetailModels
{
    __block BOOL isDrawing = NO;
    [drawResultDetailModels enumerateObjectsUsingBlock:^(CFCGameBetDrawResultModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if (!obj.isDrawed) {
            isDrawing = YES;
            *stop = YES;
        }
    }];
    return isDrawing;
}

#pragma mark 释放资源
- (void)destoryAlloc
{
    // 释放倒计时视图
    if (self.countDownTimeView) {
        [self.countDownTimeView timer_cancel];
        [self setCountDownTimeView:nil];
    }
    
    // 释放定时器对象 - 开奖结果
    [[CFCGameTimerUtil sharedGameTimerUtil] destoryTimer];
    
    // 释放定时器对象 - 盘口计时
    [[CFCCountTimerUtil sharedCountTimerUtil] destoryTimer];
    
    // 释放定时器对象 - 主页数据
    [[CFCGameDataTimerUtil sharedGameDataTimerUtil] destoryTimer];
}

@end

