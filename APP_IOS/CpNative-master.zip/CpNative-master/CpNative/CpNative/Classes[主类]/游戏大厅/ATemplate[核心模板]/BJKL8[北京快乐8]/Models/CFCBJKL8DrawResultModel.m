//
// 游戏 - 开奖结果 - 北京快乐8
//

#import "CFCBJKL8DrawResultModel.h"

@implementation CFCBJKL8DrawResultModel

/**
 * 开奖结果 - 动态数据 - 头部区域
 */
+ (CFCGameBetDrawResultModel *) buildingDataModleForHeaderArea:(CFCGameBetDrawResultModel *)dataModel
                                                      itemType:(CFCGameBetDrawResultItemType)itemType
                                                        itemId:(NSString *)itemId
{
    // 空处理 - 开奖期号
    if ([CFCSysUtil validateStringEmpty:dataModel.issueNumber]) {
        [dataModel setIssue:GAME_DRAW_RESULT_ISSUE_NUMBER(itemId)];
        [dataModel setIssueNumber:GAME_DRAW_RESULT_ISSUE_NUMBER(itemId)];
    }
    // 空处理 - 开奖号码
    if ([CFCSysUtil validateStringEmpty:dataModel.winnerNumber]) {
        [dataModel setWinnum:GAME_DRAW_RESULT_WINNER_NUMBER(itemId)];
        [dataModel setWinnerNumber:GAME_DRAW_RESULT_WINNER_NUMBER(itemId)];
    }
    // 已开奖
    CFCGameBetDrawResultModel *model_building = [[CFCGameBetDrawResultModel alloc] init];
    NSString *shortIssueString = dataModel.issueNumber;
    if (dataModel.issueNumber.length > GAME_DRAW_RESULT_ISSUE_NUMBER(itemId).length) {
        shortIssueString = [dataModel.issueNumber substringFromIndex:dataModel.issueNumber.length-GAME_DRAW_RESULT_ISSUE_NUMBER(itemId).length];
    }
    [model_building setType:itemType]; // 开奖结果类型
    [model_building setIsDrawed:GAME_DRAW_RESULT_STATUS(itemId,dataModel.winnerNumber)];
    [model_building setIssue:dataModel.issue]; // 开奖期号 - 后台完整
    [model_building setWinnum:dataModel.winnum]; // 开奖号码 - 后台完整
    [model_building setIssueNumber:shortIssueString]; // 开奖期号 - 界面显示
    [model_building setWinnerNumber:dataModel.winnerNumber]; // 开奖号码 - 界面显示
    
    // 开奖号码
    NSArray<NSString *> *winnerNumbers = [model_building.winnerNumber split:GAME_DRAW_RESULT_SPLIT_SYMBOL_COMMA];
    
    // 字体颜色背景
    {
        NSArray<NSString *> *winnerNumberArray = [[self class] buildingBJKL8WinnerResultNumbers:winnerNumbers];  // 开奖号码
        NSMutableArray<UIFont *> *winnerNumberFontArray = @[].mutableCopy;  // 开奖号码字体
        NSMutableArray<UIColor *> *winnerNumberColorArray = @[].mutableCopy; // 开奖号码颜色
        NSMutableArray<UIColor *> *winnerNumberBackgroundColorArray = @[].mutableCopy; // 开奖号码背景颜色
        NSMutableArray<NSNumber *> *winnerNumberTypeArray = @[].mutableCopy; // 开奖号码类型列表
        // 开奖号码
        for (int idx = 0; idx < winnerNumbers.count; idx ++) {
            [winnerNumberFontArray addObject:FONT_GAME_DRAW_RESULT_WINNER_NUMBER];
            [winnerNumberColorArray addObject:COLOR_GAME_DRAW_RESULT_WINNER_NUMBER];
            [winnerNumberBackgroundColorArray addObject:COLOR_GAME_DRAW_RESULT_WINNER_BACKGROUND_RED];
            [winnerNumberTypeArray addObject:[NSNumber numberWithInt:CFCGameBetDrawResultWinNumberType1]];
        }
        // 特殊处理
        for (NSInteger idx = winnerNumbers.count; idx < winnerNumberArray.count; idx ++) {
            [winnerNumberFontArray addObject:FONT_GAME_DRAW_RESULT_WINNER_CHINESE];
            [winnerNumberColorArray addObject:COLOR_GAME_DRAW_RESULT_WINNER_CHINESE];
            [winnerNumberBackgroundColorArray addObject:COLOR_GAME_DRAW_RESULT_WINNER_BACKGROUND_LIGHT];
            [winnerNumberTypeArray addObject:[NSNumber numberWithInt:CFCGameBetDrawResultWinNumberType2]];
        }
        [model_building setWinnerNumberArray:winnerNumberArray];
        [model_building setWinnerNumberFontArray:winnerNumberFontArray];
        [model_building setWinnerNumberColorArray:winnerNumberColorArray];
        [model_building setWinnerNumberBackgroundColorArray:winnerNumberBackgroundColorArray];
        [model_building setWinnerNumberTypeArray:winnerNumberTypeArray];
    }
    return model_building;
}

/**
 * 开奖结果 - 动态数据 - 动态表格
 */
+ (NSMutableArray<CFCBJKL8DrawResultModel *> *) buildingDataModles:(NSMutableArray<CFCBJKL8DrawResultModel *> *)dataModels
                                                         itemType:(CFCGameBetDrawResultItemType)itemType
                                                           itemId:(NSString *)itemId
{
    NSMutableArray<CFCBJKL8DrawResultModel *> *models = [NSMutableArray array];
    {
        for (int index = 0; index < dataModels.count; index ++) {
            CFCBJKL8DrawResultModel *model_original = [dataModels objectAtIndex:index];
            // 空处理 - 开奖期号
            if ([CFCSysUtil validateStringEmpty:model_original.issueNumber]) {
                [model_original setIssue:GAME_DRAW_RESULT_ISSUE_NUMBER(itemId)];
                [model_original setIssueNumber:GAME_DRAW_RESULT_ISSUE_NUMBER(itemId)];
            }
            // 空处理 - 开奖号码
            if ([CFCSysUtil validateStringEmpty:model_original.winnerNumber]) {
                [model_original setWinnum:GAME_DRAW_RESULT_WINNER_NUMBER(itemId)];
                [model_original setWinnerNumber:GAME_DRAW_RESULT_WINNER_NUMBER(itemId)];
            }
            // 已开奖
            CFCBJKL8DrawResultModel *model_building = [[CFCBJKL8DrawResultModel alloc] init];
            NSString *shortIssueString = model_original.issueNumber;
            if (model_original.issueNumber.length > GAME_DRAW_RESULT_ISSUE_NUMBER(itemId).length) {
                shortIssueString = [model_original.issueNumber substringFromIndex:model_original.issueNumber.length-GAME_DRAW_RESULT_ISSUE_NUMBER(itemId).length];
            }
            [model_building setType:itemType]; // 开奖结果类型
            [model_building setIsDrawed:GAME_DRAW_RESULT_STATUS(itemId,model_original.winnerNumber)];
            [model_building setIssue:model_original.issue]; // 开奖期号 - 后台完整
            [model_building setWinnum:model_original.winnum]; // 开奖号码 - 后台完整
            [model_building setIssueNumber:shortIssueString]; // 开奖期号 - 界面显示
            [model_building setWinnerNumber:model_original.winnerNumber]; // 开奖号码 - 界面显示
            
            // 开奖号码
            NSArray<NSString *> *winnerNumbers = [model_building.winnerNumber split:GAME_DRAW_RESULT_SPLIT_SYMBOL_COMMA];
            
            // 字体颜色背景
            {
                NSArray<NSString *> *winnerNumberArray = [[self class] buildingBJKL8WinnerResultNumbers:winnerNumbers];  // 开奖号码
                NSMutableArray<UIFont *> *winnerNumberFontArray = @[].mutableCopy;  // 开奖号码字体
                NSMutableArray<UIColor *> *winnerNumberColorArray = @[].mutableCopy; // 开奖号码颜色
                NSMutableArray<UIColor *> *winnerNumberBackgroundColorArray = @[].mutableCopy; // 开奖号码背景颜色
                NSMutableArray<NSNumber *> *winnerNumberTypeArray = @[].mutableCopy; // 开奖号码类型列表
                // 开奖号码
                for (int idx = 0; idx < winnerNumbers.count; idx ++) {
                    [winnerNumberFontArray addObject:FONT_GAME_DRAW_RESULT_WINNER_NUMBER];
                    [winnerNumberColorArray addObject:COLOR_GAME_DRAW_RESULT_WINNER_NUMBER];
                    [winnerNumberBackgroundColorArray addObject:COLOR_GAME_DRAW_RESULT_WINNER_BACKGROUND_RED];
                    [winnerNumberTypeArray addObject:[NSNumber numberWithInt:CFCGameBetDrawResultWinNumberType1]];
                }
                // 特殊处理
                for (NSInteger idx = winnerNumbers.count; idx < winnerNumberArray.count; idx ++) {
                    [winnerNumberFontArray addObject:FONT_GAME_DRAW_RESULT_WINNER_CHINESE];
                    [winnerNumberColorArray addObject:COLOR_GAME_DRAW_RESULT_WINNER_CHINESE];
                    [winnerNumberBackgroundColorArray addObject:COLOR_GAME_DRAW_RESULT_WINNER_BACKGROUND_LIGHT];
                    [winnerNumberTypeArray addObject:[NSNumber numberWithInt:CFCGameBetDrawResultWinNumberType2]];
                }
                [model_building setWinnerNumberArray:winnerNumberArray];
                [model_building setWinnerNumberFontArray:winnerNumberFontArray];
                [model_building setWinnerNumberColorArray:winnerNumberColorArray];
                [model_building setWinnerNumberBackgroundColorArray:winnerNumberBackgroundColorArray];
                [model_building setWinnerNumberTypeArray:winnerNumberTypeArray];
            }
            [models addObject:model_building];
        }
    }
    return models;
}

/**
 * 开奖结果 -工具方法 - 开奖号码
 */
+ (NSArray<NSString *> *)buildingBJKL8WinnerResultNumbers:(NSArray<NSString *> *)winnerNumbers
{
    // 安全验证
    if (winnerNumbers.count < 3) {
        return winnerNumbers;
    }
    
    NSMutableArray<NSString *> *winnerNumberArray = [NSMutableArray arrayWithArray:winnerNumbers];
    
    
    return [NSArray arrayWithArray:winnerNumberArray];
}

@end
