//
// 游戏 - 投注区 - 官方模式 - 11选5 - 任选胆拖 - 任选胆拖 - 任选八中五胆拖
//

#import "CFCGameBetPlayClassModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFC11X5PlayClassRXDTRenXuan08Model : CFCGameBetPlayClassModel

+ (NSMutableArray *) buildingDataModlesForSection1;

+ (NSMutableArray *) buildingDataModlesForSection2;

@end


@interface CFC11X5PlayClassRXDTRenXuan08SectionModel : CFCGameBetPlayClassSectionModel

+ (NSMutableArray *) buildingDataModles;

@end

NS_ASSUME_NONNULL_END
