

#import <UIKit/UIKit.h>
@class CFCGameBetSliderView;

NS_ASSUME_NONNULL_BEGIN

@protocol CFCGameBetSliderViewDelegate <NSObject>
@optional
- (void)sliderView:(CFCGameBetSliderView *)slider sliderPrizeValue:(NSString *)sliderPrizeValue sliderRateValue:(NSString *)sliderRateValue;
@end

@interface CFCGameBetSliderView : UIView

@property (nonatomic, strong) NSString *sliderRateValue;
@property (nonatomic, strong) NSString *sliderPrizeValue;
@property (nonatomic, strong) NSArray<NSDictionary *> *allSliderData;

@property (nonatomic, weak) id<CFCGameBetSliderViewDelegate> delegate;

- (instancetype)initWithFrame:(CGRect)frame;

@end


NS_ASSUME_NONNULL_END

