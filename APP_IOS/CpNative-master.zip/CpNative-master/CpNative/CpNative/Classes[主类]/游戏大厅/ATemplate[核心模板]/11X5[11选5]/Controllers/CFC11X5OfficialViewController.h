//
// 游戏 - 投注区 - 官方模式 - 11选5
//

#import "CFCGameBetOfficialViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CFC11X5OfficialViewController : CFCGameBetOfficialViewController

@end

NS_ASSUME_NONNULL_END
