//
// 游戏 - 开奖结果 - 北京快乐8
//

#import "CFCGameBetDrawResultDefaultTableViewCell.h"
@class CFCBJKL8DrawResultModel;

NS_ASSUME_NONNULL_BEGIN

@protocol CFCBJKL8OfficialDrawResultTableViewCellDelegate <CFCGameBetDrawResultDefaultTableViewCellDelegate>
@optional
- (void)didSelectRowAtBJKL8DrawResultModel:(CFCBJKL8DrawResultModel *)model;
@end

@interface CFCBJKL8OfficialDrawResultTableViewCell : CFCGameBetDrawResultDefaultTableViewCell

@end

NS_ASSUME_NONNULL_END
