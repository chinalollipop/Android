//
// 游戏 - 投注区 - 选注页面（Table）
//

#import "CFCGameBetPlayClassTableViewController.h"
#import "CFCGameBetPlayClassTableSectionHeaderView.h"
#import "CFCGameBetPlayClassTableSectionFooterView.h"
#import "CFCGameBetPlayClassDefaultTableViewCell.h"
#import "CFCGameBetPlayClassOfficial1TableViewCell.h"
#import "CFCGameBetPlayClassOfficial2TableViewCell.h"
#import "CFCGameBetPlayClassOfficial3TableViewCell.h"
#import "CFCGameBetPlayClassOfficial4TableViewCell.h"
#import "CFCGameBetPlayClassOfficial5TableViewCell.h"
#import "CFCGameBetPlayClassOfficial6TableViewCell.h"
#import "CFCGameBetPlayClassOfficial7TableViewCell.h"
#import "CFCGameBetPlayClassModel.h"


@interface CFCGameBetPlayClassTableViewController () <UITableViewDelegate, UITableViewDataSource, DZNEmptyDataSetSource, DZNEmptyDataSetDelegate, CFCGameBetPlayClassOfficial1TableViewCellDelegate, CFCGameBetPlayClassOfficial2TableViewCellDelegate, CFCGameBetPlayClassOfficial3TableViewCellDelegate, CFCGameBetPlayClassOfficial4TableViewCellDelegate, CFCGameBetPlayClassOfficial5TableViewCellDelegate, CFCGameBetPlayClassOfficial6TableViewCellDelegate, CFCGameBetPlayClassOfficial7TableViewCellDelegate>

@end

@implementation CFCGameBetPlayClassTableViewController

#pragma mark -
#pragma mark 事件处理 - 选择具体游戏项目事件N01 - CFCGameBetPlayClassOfficial1TableViewCellProtocol
- (void)didSelectPlayClassOfficial1TableViewCellRowAtIndexPath:(NSIndexPath *)indexPath itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels itemIndexs:(NSArray<NSNumber *> *)itemIndexs
{
    [self didSelectPlayClassCellRowAtIndexPath:indexPath itemModels:itemModels itemIndexs:itemIndexs itemReload:YES];
}

#pragma mark 事件处理 - 选择具体游戏项目事件N02 - CFCGameBetPlayClassOfficial2TableViewCellProtocol
- (void)didSelectPlayClassOfficial2TableViewCellRowAtIndexPath:(NSIndexPath *)indexPath itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels itemIndexs:(NSArray<NSNumber *> *)itemIndexs
{
    [self didSelectPlayClassCellRowAtIndexPath:indexPath itemModels:itemModels itemIndexs:itemIndexs itemReload:YES];
}

#pragma mark 事件处理 - 选择具体游戏项目事件N03 - CFCGameBetPlayClassOfficial3TableViewCellProtocol
- (void)didSelectPlayClassOfficial3TableViewCellRowAtIndexPath:(NSIndexPath *)indexPath itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels itemIndexs:(NSArray<NSNumber *> *)itemIndexs
{
    [self didSelectPlayClassCellRowAtIndexPath:indexPath itemModels:itemModels itemIndexs:itemIndexs itemReload:YES];
}

#pragma mark 事件处理 - 选择具体游戏项目事件N04 - CFCGameBetPlayClassOfficial4TableViewCellProtocol
- (void)didSelectPlayClassOfficial4TableViewCellRowAtIndexPath:(NSIndexPath *)indexPath itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels itemIndexs:(NSArray<NSNumber *> *)itemIndexs
{
    [self didSelectPlayClassCellRowAtIndexPath:indexPath itemModels:itemModels itemIndexs:itemIndexs itemReload:YES];
}

#pragma mark 事件处理 - 选择具体游戏项目事件N05 - CFCGameBetPlayClassOfficial5TableViewCellProtocol
- (void)didSelectPlayClassOfficial5TableViewCellRowAtIndexPath:(NSIndexPath *)indexPath itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels itemIndexs:(NSArray<NSNumber *> *)itemIndexs
{
    [self didSelectPlayClassCellRowAtIndexPath:indexPath itemModels:itemModels itemIndexs:itemIndexs itemReload:NO];
}

#pragma mark 事件处理 - 选择具体游戏项目事件N06 - CFCGameBetPlayClassOfficial6TableViewCellProtocol
- (void)didSelectPlayClassOfficial6TableViewCellRowAtIndexPath:(NSIndexPath *)indexPath itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels itemIndexs:(NSArray<NSNumber *> *)itemIndexs
{
    [self didSelectPlayClassCellRowAtIndexPath:indexPath itemModels:itemModels itemIndexs:itemIndexs itemReload:YES];
}


#pragma mark 事件处理 - 选择具体游戏项目事件N07 - CFCGameBetPlayClassOfficial7TableViewCellProtocol
- (void)didSelectPlayClassOfficial7TableViewCellRowAtIndexPath:(NSIndexPath *)indexPath itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels itemIndexs:(NSArray<NSNumber *> *)itemIndexs
{
    [self didSelectPlayClassCellRowAtIndexPath:indexPath itemModels:itemModels itemIndexs:itemIndexs itemReload:YES];
}


#pragma mark -
#pragma mark 事件处理 - 点击投注表格后更新数据
- (NSArray<NSIndexPath *> *)doUpdatePlayClassCellModelsAtIndexPath:(NSIndexPath *)indexPath itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels itemIndexs:(NSArray<NSNumber *> *)itemIndexs
{
    CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[indexPath.section];
    if (itemIndexs.count > 1) {
        // 全、大、小、单、双、清
        [itemIndexs enumerateObjectsUsingBlock:^(NSNumber * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSInteger itemIndex = obj.integerValue;
            if (itemIndex >= 0 && itemIndex < sectionModel.list.count) {
                CFCGameBetPlayClassModel *elem = sectionModel.list[itemIndex];
                elem.isSelected = elem.isSelected;
            }
        }];
    } else if (itemIndexs.count > 0) {
        // 项目
        NSInteger itemIndex = [itemIndexs objectAtIndex:0].integerValue;
        if (itemIndex >= 0 && itemIndex < sectionModel.list.count) {
            CFCGameBetPlayClassModel *elem = sectionModel.list[itemIndex];
            elem.isSelected = !elem.isSelected;
        }
    }
    
    __block NSMutableArray<NSIndexPath *> *indexPaths = [NSMutableArray<NSIndexPath *> arrayWithCapacity:itemIndexs.count];
    [itemIndexs enumerateObjectsUsingBlock:^(NSNumber * _Nonnull row, NSUInteger idx, BOOL * _Nonnull stop) {
        NSIndexPath *itemIndexPath = [NSIndexPath indexPathForRow:row.integerValue inSection:indexPath.section];
        [indexPaths addObject:itemIndexPath];
    }];
    
    return [NSArray<NSIndexPath *> arrayWithArray:indexPaths];
}

#pragma mark 事件处理 - 点击投注表格后刷新表格
- (void)doReloadPlayClassSectionModelRowsAtIndexPaths:(NSArray<NSIndexPath *> *)indexPaths
{
    [super doReloadPlayClassSectionModelRowsAtIndexPaths:indexPaths];
    
    CFCPlayClassAfterSelectedItemOfRefreshMode refreshMode = [self doReloadPlayClassAfterSelectedItemOfRefreshMode];
    
    switch (refreshMode) {
            // 刷新单元 Cell
        case CFCPlayClassAfterSelectedItemOfRefreshModeRows:{
            [self.tableView reloadRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationNone];
            return;
        }
            // 刷新分组 Section
        case CFCPlayClassAfterSelectedItemOfRefreshModeSections:{
            __block NSMutableIndexSet *sections = [[NSMutableIndexSet alloc] init];
            [indexPaths enumerateObjectsUsingBlock:^(NSIndexPath * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                if (![sections containsIndex:obj.section]) {
                    [sections addIndex:obj.section];
                }
            }];
            [self.tableView reloadSections:sections withRowAnimation:UITableViewRowAnimationNone];
            return;
        }
            // 刷新控件 UITableView
        case CFCPlayClassAfterSelectedItemOfRefreshModeAll:{
            [self.tableView reloadData];
            return;
        }
        default: {
            return;
        }
    }
}

#pragma mark 事件处理 - 点击投注表格后刷新表格 - 刷新类型模式
- (CFCPlayClassAfterSelectedItemOfRefreshMode)doReloadPlayClassAfterSelectedItemOfRefreshMode
{
    return CFCPlayClassAfterSelectedItemOfRefreshModeSections;
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)zj_viewDidLoadForIndex:(NSInteger)index
{
    // 设置背景
    [self.view setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_BACK];
}


#pragma mark -
#pragma mark 创建界面表格
- (void)createUIRefreshView:(BOOL)force
{
    [super createUIRefreshView:force];
    
    [self createUIRefreshTableView:force];
}

#pragma mark 刷新界面表格 - TableView
- (void)reloadRefreshViewData
{
    [super reloadRefreshViewData];
    
    [self.tableView reloadData];
}

#pragma mark 创建界面表格 - TableView
- (void)createUIRefreshTableView:(BOOL)force
{
    // 表格已经存在则无需创建，直接返回；否则强制创建表格
    if (self.tableView && !force) {
        return;
    }
    
    // 创建表格
    {
        // 创建集合视图
        CGRect frame = CGRectMake(0.0f, 0.0f, self.scrollViewSize.width, self.scrollViewSize.height);
        self.tableView = [[UITableView alloc] initWithFrame:frame style:[self tableViewRefreshStyle]];
        [self.view addSubview:self.tableView];
        [self.tableView setContentSize:self.tableView.frame.size];
        [self.tableView setDelegate:self];
        [self.tableView setDataSource:self];
        [self.tableView setEstimatedRowHeight:200.0f];
        [self.tableView setShowsVerticalScrollIndicator:NO];
        [self.tableView setFd_debugLogEnabled:YES];
        [self.tableView setSectionHeaderHeight:FLOAT_MIN];
        [self.tableView setSectionFooterHeight:FLOAT_MIN];
        [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        [self.tableView setBackgroundColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT];
        [self.tableView setTableHeaderView:[[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, FLOAT_MIN)]];
        [self.tableView setTableFooterView:[[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, FLOAT_MIN)]];
        
        // 空白页展示页
        self.tableView.emptyDataSetSource = self;
        self.tableView.emptyDataSetDelegate = self;
        
        // 支持侧滑返回
        [self tz_addPopGestureToView:self.tableView];
        
        // 配置表格信息
        [self createUIRefreshTableViewSetting];
    }
    
}

#pragma mark 创建界面表格 - 配置表格
- (void)createUIRefreshTableViewSetting
{
    // 注册 CFCGameBetPlayClassDefaultTableViewCell（必须）
    [self.tableView registerClass:[CFCGameBetPlayClassDefaultTableViewCell class] forCellReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_DEFAULT_TABLE_VIEW_CELL];
    
    // 注册 CFCGameBetPlayClassOfficial1TableViewCell（必须）
    [self.tableView registerClass:[CFCGameBetPlayClassOfficial1TableViewCell class] forCellReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_1_TABLE_VIEW_CELL];

    // 注册 CFCGameBetPlayClassOfficial2TableViewCell（必须）
    [self.tableView registerClass:[CFCGameBetPlayClassOfficial2TableViewCell class] forCellReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_2_TABLE_VIEW_CELL];

    // 注册 CFCGameBetPlayClassOfficial3TableViewCell（必须）
    [self.tableView registerClass:[CFCGameBetPlayClassOfficial3TableViewCell class] forCellReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_3_TABLE_VIEW_CELL];
    
    // 注册 CFCGameBetPlayClassOfficial4TableViewCell（必须）
    [self.tableView registerClass:[CFCGameBetPlayClassOfficial4TableViewCell class] forCellReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_4_TABLE_VIEW_CELL];

    // 注册 CFCGameBetPlayClassOfficial5TableViewCell（必须）
    [self.tableView registerClass:[CFCGameBetPlayClassOfficial5TableViewCell class] forCellReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_5_TABLE_VIEW_CELL];
    
    // 注册 CFCGameBetPlayClassOfficial6TableViewCell（必须）
    [self.tableView registerClass:[CFCGameBetPlayClassOfficial6TableViewCell class] forCellReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_6_TABLE_VIEW_CELL];

    // 注册 CFCGameBetPlayClassOfficial7TableViewCell（必须）
    [self.tableView registerClass:[CFCGameBetPlayClassOfficial7TableViewCell class] forCellReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_7_TABLE_VIEW_CELL];
    
    // 需在子类中重载该方法，并对投注表格进行配置
    [self tableViewSettingRegisterInitialize:self.tableView];
}

#pragma mark 创建界面表格 - 表格类型
- (UITableViewStyle)tableViewRefreshStyle
{
    return UITableViewStyleGrouped;
}


#pragma mark -
#pragma mark DZNEmptyDataSetDelegate
- (BOOL)emptyDataSetShouldDisplay:(UIScrollView *)scrollView {
    return YES;
}

- (BOOL)emptyDataSetShouldAllowScroll:(UIScrollView *)scrollView {
    return YES;
}

- (BOOL) emptyDataSetShouldAllowImageViewAnimate:(UIScrollView *)scrollView {
    return YES;
}

#pragma mark DZNEmptyDataSetSource
- (NSAttributedString *)titleForEmptyDataSet:(UIScrollView *)scrollView
{
    NSString *text = @"没有查找到相关数据";
    
    NSDictionary *attributes = @{ NSFontAttributeName : [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)],
                                  NSForegroundColorAttributeName : [UIColor colorWithRed:0.78 green:0.78 blue:0.78 alpha:1.00]};
    
    return [[NSAttributedString alloc] initWithString:text attributes:attributes];
}

- (NSAttributedString *)descriptionForEmptyDataSet:(UIScrollView *)scrollView
{
    NSMutableParagraphStyle *paragraph = [NSMutableParagraphStyle new];
    paragraph.lineBreakMode = NSLineBreakByWordWrapping;
    paragraph.alignment = NSTextAlignmentCenter;
    
    NSString *text = @"";
    NSDictionary *attributes = @{ NSFontAttributeName: [UIFont systemFontOfSize:CFC_AUTOSIZING_FONT(16.0f)],
                                  NSForegroundColorAttributeName:[UIColor colorWithRed:0.78 green:0.78 blue:0.78 alpha:1.00],
                                  NSParagraphStyleAttributeName: paragraph};
    
    return [[NSAttributedString alloc] initWithString:text attributes:attributes];
}

- (UIImage *)imageForEmptyDataSet:(UIScrollView *)scrollView {
    return [UIImage imageNamed:ICON_SCROLLVIEW_EMPTY_DATASET_RESULT];
}


- (CGFloat)verticalOffsetForEmptyDataSet:(UIScrollView *)scrollView
{
    return -[CFCAutosizingUtil getAutosizeViewHeight:50.0f];
}

- (UIColor *)backgroundColorForEmptyDataSet:(UIScrollView *)scrollView
{
    return [UIColor whiteColor];
}


#pragma mark -
#pragma mark UITableViewDelegate, UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (self.dataOfSectionModelArray && self.dataOfSectionModelArray.count > 0) {
        
        return self.dataOfSectionModelArray.count;
    }
    
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.dataOfSectionModelArray && self.dataOfSectionModelArray.count > 0 && self.dataOfSectionModelArray.count > section) {
        
        if ([self.dataOfSectionModelArray[section] isKindOfClass:[CFCGameBetPlayClassSectionModel class]]) {
            
            return 1;
            
        }
    }
    
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (!self.dataOfSectionModelArray
        || self.dataOfSectionModelArray.count <= 0
        || self.dataOfSectionModelArray.count <= indexPath.section
        || ![self.dataOfSectionModelArray[indexPath.section] isKindOfClass:[CFCGameBetPlayClassSectionModel class]]) {
        return nil;
    }
    
    CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[indexPath.section];
    if (!sectionModel.isShowSectionContent) {
        [sectionModel setType:CFCGameBetPlayClassSectionTypeDefault];
    }
    return [self tableView:tableView cellForRowAtIndexPath:indexPath cellModel:sectionModel];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (!self.dataOfSectionModelArray
        || self.dataOfSectionModelArray.count <= 0
        || self.dataOfSectionModelArray.count <= indexPath.section
        || ![self.dataOfSectionModelArray[indexPath.section] isKindOfClass:[CFCGameBetPlayClassSectionModel class]]) {
        return FLOAT_MIN;
    }
    
    CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[indexPath.section];
    if (!sectionModel.isShowSectionContent) {
        [sectionModel setType:CFCGameBetPlayClassSectionTypeDefault];
    }
    return [self tableView:tableView heightForRowAtIndexPath:indexPath cellModel:sectionModel];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (!self.dataOfSectionModelArray
        || self.dataOfSectionModelArray.count <= 0
        || self.dataOfSectionModelArray.count <= section
        || ![self.dataOfSectionModelArray[section] isKindOfClass:[CFCGameBetPlayClassSectionModel class]]) {
        return nil;
    }
    
    CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[section];
    if (!sectionModel.isShowSectionContent) {
        [sectionModel setType:CFCGameBetPlayClassSectionTypeDefault];
    }
    return [self tableView:tableView viewForHeaderInSection:section cellModel:sectionModel];
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    if (!self.dataOfSectionModelArray
        || self.dataOfSectionModelArray.count <= 0
        || self.dataOfSectionModelArray.count <= section
        || ![self.dataOfSectionModelArray[section] isKindOfClass:[CFCGameBetPlayClassSectionModel class]]) {
        return nil;
    }
    
    CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[section];
    if (!sectionModel.isShowSectionContent) {
        [sectionModel setType:CFCGameBetPlayClassSectionTypeDefault];
    }
    return [self tableView:tableView viewForFooterInSection:section cellModel:sectionModel];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (!self.dataOfSectionModelArray
        || self.dataOfSectionModelArray.count <= 0
        || self.dataOfSectionModelArray.count <= section
        || ![self.dataOfSectionModelArray[section] isKindOfClass:[CFCGameBetPlayClassSectionModel class]]) {
        return FLOAT_MIN;
    }
    
    CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[section];
    if (!sectionModel.isShowSectionContent) {
        [sectionModel setType:CFCGameBetPlayClassSectionTypeDefault];
    }
    return [self tableView:tableView heightForHeaderInSection:section cellModel:sectionModel];
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if (!self.dataOfSectionModelArray
        || self.dataOfSectionModelArray.count <= 0
        || self.dataOfSectionModelArray.count <= section
        || ![self.dataOfSectionModelArray[section] isKindOfClass:[CFCGameBetPlayClassSectionModel class]]) {
        return FLOAT_MIN;
    }
    
    CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[section];
    if (!sectionModel.isShowSectionContent) {
        [sectionModel setType:CFCGameBetPlayClassSectionTypeDefault];
    }
    return [self tableView:tableView heightForFooterInSection:section cellModel:sectionModel];
}


#pragma mark -
#pragma mark 投注表格 - 对投注表格进行配置（子类继承实现）
- (void)tableViewSettingRegisterInitialize:(UITableView *)tableView
{
    // TODO: 请在子类中重载该方法，并对投注表格进行配置
    
}

#pragma mark 投注表格 - 自定义投注表格的 UITableViewCell 的控件
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model
{
    // TODO: 请在子类中重载该方法，并返回自定义投注表格的 UITableViewCell 的实例
    
    switch (model.type) {
            // 类型 -> Default -> 分组内容为 -> 默认为空
        case CFCGameBetPlayClassSectionTypeDefault: {
            CFCGameBetPlayClassDefaultTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_DEFAULT_TABLE_VIEW_CELL];
            if (!cell) {
                cell = [[CFCGameBetPlayClassDefaultTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_DEFAULT_TABLE_VIEW_CELL];
            }
            cell.indexPath = indexPath;
            cell.model = model;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
            // 类型 -> Official1 -> 分组内容为 -> 官方玩法 -> 投注项目，有操作按钮 -> 如：时时彩官方玩法中<五星、四星>
        case CFCGameBetPlayClassSectionTypeOfficial1: {
            CFCGameBetPlayClassOfficial1TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_1_TABLE_VIEW_CELL];
            if (!cell) {
                cell = [[CFCGameBetPlayClassOfficial1TableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_1_TABLE_VIEW_CELL];
            }
            cell.delegate = self;
            cell.indexPath = indexPath;
            cell.model = model;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
            // 类型 -> Official2 -> 分组内容为 -> 官方玩法 -> 投注项目，无操作按钮 -> 如：时时彩官方玩法中<大小单双>
        case CFCGameBetPlayClassSectionTypeOfficial2: {
            CFCGameBetPlayClassOfficial2TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_2_TABLE_VIEW_CELL];
            if (!cell) {
                cell = [[CFCGameBetPlayClassOfficial2TableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_2_TABLE_VIEW_CELL];
            }
            cell.delegate = self;
            cell.indexPath = indexPath;
            cell.model = model;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
            // 类型 -> Official3 -> 分组内容为 -> 官方玩法 -> 投注项目，有复选按钮 -> 如：时时彩官方玩法中<任选二、任选三>玩法中的复选按钮
        case CFCGameBetPlayClassSectionTypeOfficial3: {
            CFCGameBetPlayClassOfficial3TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_3_TABLE_VIEW_CELL];
            if (!cell) {
                cell = [[CFCGameBetPlayClassOfficial3TableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_3_TABLE_VIEW_CELL];
            }
            cell.delegate = self;
            cell.indexPath = indexPath;
            cell.model = model;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
            // 类型 -> Official4 -> 分组内容为 -> 官方玩法 -> 投注项目，无操作按钮 -> 如：江苏快三官方玩法中<快三和值>
        case CFCGameBetPlayClassSectionTypeOfficial4: {
            CFCGameBetPlayClassOfficial4TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_4_TABLE_VIEW_CELL];
            if (!cell) {
                cell = [[CFCGameBetPlayClassOfficial4TableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_4_TABLE_VIEW_CELL];
            }
            cell.delegate = self;
            cell.indexPath = indexPath;
            cell.model = model;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
            // 类型 -> Official5 -> 分组内容为 -> 官方玩法 -> 投注项目，无操作按钮 -> 如：北京快乐八官方玩法中<任选一、任选二>
        case CFCGameBetPlayClassSectionTypeOfficial5: {
            CFCGameBetPlayClassOfficial5TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_5_TABLE_VIEW_CELL];
            if (!cell) {
                cell = [[CFCGameBetPlayClassOfficial5TableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_5_TABLE_VIEW_CELL];
            }
            cell.delegate = self;
            cell.indexPath = indexPath;
            cell.model = model;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
            // 类型 -> Official6 -> 分组内容为 -> 官方玩法 -> 投注项目，有操作按钮 -> 如：时时彩、极速3D官方玩法中<单式、混合组选>
        case CFCGameBetPlayClassSectionTypeOfficial6: {
            CFCGameBetPlayClassOfficial6TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_6_TABLE_VIEW_CELL];
            if (!cell) {
                cell = [[CFCGameBetPlayClassOfficial6TableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_6_TABLE_VIEW_CELL];
            }
            cell.delegate = self;
            cell.indexPath = indexPath;
            cell.model = model;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
            // 类型 -> Official7 -> 分组内容为 -> 官方玩法 -> 投注项目，有操作按钮 -> 如：北京PK拾、11选5官方玩法中<单式、混合组选>
        case CFCGameBetPlayClassSectionTypeOfficial7: {
            CFCGameBetPlayClassOfficial7TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_7_TABLE_VIEW_CELL];
            if (!cell) {
                cell = [[CFCGameBetPlayClassOfficial7TableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_7_TABLE_VIEW_CELL];
            }
            cell.delegate = self;
            cell.indexPath = indexPath;
            cell.model = model;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
        default: {
            // 类型 -> Default -> 分组内容为 -> 默认为空
            CFCGameBetPlayClassDefaultTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_DEFAULT_TABLE_VIEW_CELL];
            if (!cell) {
                cell = [[CFCGameBetPlayClassDefaultTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_DEFAULT_TABLE_VIEW_CELL];
            }
            cell.indexPath = indexPath;
            cell.model = model;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
    }
    
}

#pragma mark 投注表格 - 自定义投注表格的 UITableViewCell 的高度
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model
{
    // TODO: 请在子类中重载该方法，并返回自定义投注表格的 UITableViewCell 的高度
    
    switch (model.type) {
            // 类型 -> Default -> 分组内容为 -> 默认为空
        case CFCGameBetPlayClassSectionTypeDefault: {
            return [self.tableView fd_heightForCellWithIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_DEFAULT_TABLE_VIEW_CELL cacheByIndexPath:indexPath configuration:^(CFCGameBetPlayClassDefaultTableViewCell *cell) {
                cell.model = model;
            }];
        }
            // 类型 -> Official1 -> 分组内容为 -> 官方玩法 -> 投注项目，有操作按钮 -> 如：时时彩官方玩法中<五星、四星>
        case CFCGameBetPlayClassSectionTypeOfficial1: {
            return [self.tableView fd_heightForCellWithIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_1_TABLE_VIEW_CELL cacheByIndexPath:indexPath configuration:^(CFCGameBetPlayClassOfficial1TableViewCell *cell) {
                cell.model = model;
            }];
        }
            // 类型 -> Official2 -> 分组内容为 -> 官方玩法 -> 投注项目，无操作按钮 -> 如：时时彩官方玩法中<大小单双>
        case CFCGameBetPlayClassSectionTypeOfficial2: {
            return [self.tableView fd_heightForCellWithIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_2_TABLE_VIEW_CELL cacheByIndexPath:indexPath configuration:^(CFCGameBetPlayClassOfficial2TableViewCell *cell) {
                cell.model = model;
            }];
        }
            // 类型 -> Official3 -> 分组内容为 -> 官方玩法 -> 投注项目，有复选按钮 -> 如：时时彩官方玩法中<任选二、任选三>玩法中的复选按钮
        case CFCGameBetPlayClassSectionTypeOfficial3: {
            return [self.tableView fd_heightForCellWithIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_3_TABLE_VIEW_CELL cacheByIndexPath:indexPath configuration:^(CFCGameBetPlayClassOfficial3TableViewCell *cell) {
                cell.model = model;
            }];
        }
            // 类型 -> Official4 -> 分组内容为 -> 官方玩法 -> 投注项目，无操作按钮 -> 如：江苏快三官方玩法中<快三和值>
        case CFCGameBetPlayClassSectionTypeOfficial4: {
            return [self.tableView fd_heightForCellWithIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_4_TABLE_VIEW_CELL cacheByIndexPath:indexPath configuration:^(CFCGameBetPlayClassOfficial4TableViewCell *cell) {
                cell.model = model;
            }];
        }
            // 类型 -> Official5 -> 分组内容为 -> 官方玩法 -> 投注项目，无操作按钮 -> 如：北京快乐八官方玩法中<任选一、任选二>
        case CFCGameBetPlayClassSectionTypeOfficial5: {
            return [self.tableView fd_heightForCellWithIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_5_TABLE_VIEW_CELL cacheByIndexPath:indexPath configuration:^(CFCGameBetPlayClassOfficial5TableViewCell *cell) {
                cell.model = model;
            }];
        }
            // 类型 -> Official6 -> 分组内容为 -> 官方玩法 -> 投注项目，有操作按钮 -> 如：时时彩、极速3D官方玩法中<单式、混合组选>
        case CFCGameBetPlayClassSectionTypeOfficial6: {
            return [self.tableView fd_heightForCellWithIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_6_TABLE_VIEW_CELL cacheByIndexPath:indexPath configuration:^(CFCGameBetPlayClassOfficial6TableViewCell *cell) {
                cell.model = model;
            }];
        }
            // 类型 -> Official7 -> 分组内容为 -> 官方玩法 -> 投注项目，有操作按钮 -> 如：北京PK拾、11选5官方玩法中<单式、混合组选>
        case CFCGameBetPlayClassSectionTypeOfficial7: {
            return [self.tableView fd_heightForCellWithIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_OFFICIAL_7_TABLE_VIEW_CELL cacheByIndexPath:indexPath configuration:^(CFCGameBetPlayClassOfficial7TableViewCell *cell) {
                cell.model = model;
            }];
        }
        default: {
            // 类型 -> Default -> 分组内容为 -> 默认为空
            return [self.tableView fd_heightForCellWithIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_DEFAULT_TABLE_VIEW_CELL cacheByIndexPath:indexPath configuration:^(CFCGameBetPlayClassDefaultTableViewCell *cell) {
                cell.model = model;
            }];
        }
    }
    
}

#pragma mark 投注表格 - 自定义投注表格的 SectionHeader 的视图
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section cellModel:(CFCGameBetPlayClassSectionModel *)model
{
    // TODO: 请在子类中重载该方法，并返回自定义投注表格的 SectionHeader 的视图
    
    if (model.isShowHeader) {
        CGFloat height = CFC_AUTOSIZING_HEIGTH(30.0f);
        if (0 == section && model.isShowHeader) {
            height = CFC_AUTOSIZING_HEIGTH(35.0f) + CFC_AUTOSIZING_MARGIN(MARGIN);
        }
        CFCGameBetPlayClassTableSectionHeaderView *headerView = [[CFCGameBetPlayClassTableSectionHeaderView alloc]
                                                                 initWithFrame:CGRectMake(0,
                                                                                          0,
                                                                                          self.tableView.frame.size.width,
                                                                                          height)
                                                                 title:model.title
                                                                 tableSecion:section];
        return headerView;
    }
    
    return nil;
}

#pragma mark 投注表格 - 自定义投注表格的 SectionFooter 的视图
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section cellModel:(CFCGameBetPlayClassSectionModel *)model
{
    // TODO: 请在子类中重载该方法，并返回自定义投注表格的 SectionFooter 的视图
    
    if (model.isShowFooter) {
        CFCGameBetPlayClassTableSectionFooterView *footerView = [[CFCGameBetPlayClassTableSectionFooterView alloc]
                                                                 initWithFrame:CGRectMake(0,
                                                                                          0,
                                                                                          self.tableView.frame.size.width,
                                                                                          CFC_AUTOSIZING_MARGIN(MARGIN))
                                                                 tableSecion:section];
        return footerView;
    }
    
    return nil;
}

#pragma mark 投注表格 - 自定义投注表格的 SectionHeader 的高度
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section cellModel:(CFCGameBetPlayClassSectionModel *)model
{
    // TODO: 请在子类中重载该方法，并返回自定义投注表格的 SectionHeader 的高度
    
    if (model.isShowHeader) {
        if (0 == section) {
            return model.heightOfHeader + model.heightOfFooter + GAME_PLAY_COLLECTION_EDGEINSET;
        }
        return model.heightOfHeader + GAME_PLAY_COLLECTION_EDGEINSET;
    }
    
    return FLOAT_MIN;
}

#pragma mark 投注表格 - 自定义投注表格的 SectionFooter 的高度
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section cellModel:(CFCGameBetPlayClassSectionModel *)model
{
    // TODO: 请在子类中重载该方法，并返回自定义投注表格的 SectionFooter 的高度
    
    if (model.isShowFooter) {
        if (section == self.dataOfSectionModelArray.count-1) {
            return model.heightOfFooter + GAME_PLAY_COLLECTION_EDGEINSET;
        }
        return model.heightOfFooter;
    }
    
    return FLOAT_MIN;
}

@end

