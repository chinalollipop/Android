//
// 游戏 - 投注区 - 选注页面（Collection）
//

#import "CFCGameBetPlayClassCollectionViewController.h"
#import "CFCGameBetPlayClassCollectionViewFlowLayout.h"
#import "CFCGameBetPlayClassDefaultCollectionViewCell.h"
#import "CFCGameBetPlayClassCredit1CollectionViewCell.h"
#import "CFCGameBetPlayClassCredit2CollectionViewCell.h"
#import "CFCGameBetPlayClassCollectionSectionHeaderView.h"
#import "CFCGameBetPlayClassCollectionSectionFooterView.h"
#import "CFCGameBetPlayClassCollectionSectionNULLHeaderView.h"
#import "CFCGameBetPlayClassCollectionSectionNULLFooterView.h"


@interface CFCGameBetPlayClassCollectionViewController () <UICollectionViewDataSource, UICollectionViewDelegate, DZNEmptyDataSetSource, DZNEmptyDataSetDelegate, CFCGameBetPlayClassCollectionViewFlowLayoutDelegate, CFCGameBetPlayClassCredit1CollectionViewCellDelegate, CFCGameBetPlayClassCredit2CollectionViewCellDelegate>

@end


@implementation CFCGameBetPlayClassCollectionViewController


#pragma mark -
#pragma mark 事件处理 - 选择具体彩票项目事件N01 - CFCGameBetPlayClassCredit1CollectionViewCellDelegate
- (void)didSelectPlayClassCredit1CollectionViewCellRowAtIndexPath:(NSIndexPath *)indexPath
                                                       itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels
                                                       itemIndexs:(NSArray<NSNumber *> *)itemIndexs
{
    [self didSelectPlayClassCellRowAtIndexPath:indexPath itemModels:itemModels itemIndexs:itemIndexs itemReload:YES];
}

#pragma mark 事件处理 - 选择具体彩票项目事件N02 - CFCGameBetPlayClassCredit2CollectionViewCellDelegate
- (void)didSelectPlayClassCredit2CollectionViewCellRowAtIndexPath:(NSIndexPath *)indexPath
                                                       itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels
                                                       itemIndexs:(NSArray<NSNumber *> *)itemIndexs
{
    [self didSelectPlayClassCellRowAtIndexPath:indexPath itemModels:itemModels itemIndexs:itemIndexs itemReload:YES];
}


#pragma mark -
#pragma mark 事件处理 - 点击投注表格后更新数据
- (NSArray<NSIndexPath *> *)doUpdatePlayClassCellModelsAtIndexPath:(NSIndexPath *)indexPath itemModels:(NSArray<CFCGameBetPlayClassModel *> *)itemModels itemIndexs:(NSArray<NSNumber *> *)itemIndexs
{
    CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[indexPath.section];
    if (itemIndexs.count > 1) {
        // 项目 - 多个
        [itemIndexs enumerateObjectsUsingBlock:^(NSNumber * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSInteger itemIndex = obj.integerValue;
            if (itemIndex >= 0 && itemIndex < sectionModel.list.count) {
                CFCGameBetPlayClassModel *elem = sectionModel.list[itemIndex];
                elem.isSelected = !elem.isSelected;
            }
        }];
    } else if (itemIndexs.count > 0) {
        // 项目 - 单个
        NSInteger itemIndex = [itemIndexs objectAtIndex:0].integerValue;
        if (itemIndex >= 0 && itemIndex < sectionModel.list.count) {
            CFCGameBetPlayClassModel *elem = sectionModel.list[itemIndex];
            elem.isSelected = !elem.isSelected;
        }
    }
    
    __block NSMutableArray<NSIndexPath *> *indexPaths = [NSMutableArray<NSIndexPath *> arrayWithCapacity:itemIndexs.count];
    [itemIndexs enumerateObjectsUsingBlock:^(NSNumber * _Nonnull row, NSUInteger idx, BOOL * _Nonnull stop) {
        NSIndexPath *itemIndexPath = [NSIndexPath indexPathForRow:row.integerValue inSection:indexPath.section];
        [indexPaths addObject:itemIndexPath];
    }];
    
    return [NSArray<NSIndexPath *> arrayWithArray:indexPaths];
}

#pragma mark 事件处理 - 点击投注表格后刷新表格
- (void)doReloadPlayClassSectionModelRowsAtIndexPaths:(NSArray<NSIndexPath *> *)indexPaths
{
    [super doReloadPlayClassSectionModelRowsAtIndexPaths:indexPaths];
    
    WEAKSELF(weakSelf);
    
    CFCPlayClassAfterSelectedItemOfRefreshMode refreshMode = [self doReloadPlayClassAfterSelectedItemOfRefreshMode];
    
    switch (refreshMode) {
            // 刷新单元 Cell
        case CFCPlayClassAfterSelectedItemOfRefreshModeRows:{
            [UIView performWithoutAnimation:^{
                [weakSelf.collectionView reloadItemsAtIndexPaths:indexPaths];
            }];
            return;
        }
            // 刷新分组 Section
        case CFCPlayClassAfterSelectedItemOfRefreshModeSections:{
            __block NSMutableIndexSet *sections = [[NSMutableIndexSet alloc] init];
            [indexPaths enumerateObjectsUsingBlock:^(NSIndexPath * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                if (![sections containsIndex:obj.section]) {
                    [sections addIndex:obj.section];
                }
            }];
            [UIView performWithoutAnimation:^{
                [weakSelf.collectionView reloadSections:sections];
            }];
            return;
        }
            // 刷新控件 UICollectionView
        case CFCPlayClassAfterSelectedItemOfRefreshModeAll:{
            [UIView performWithoutAnimation:^{
                [weakSelf.collectionView reloadData];
            }];
            return;
        }
        default: {
            return;
        }
    }
}

#pragma mark 事件处理 - 点击投注表格后刷新表格 - 刷新类型模式
- (CFCPlayClassAfterSelectedItemOfRefreshMode)doReloadPlayClassAfterSelectedItemOfRefreshMode
{
    return CFCPlayClassAfterSelectedItemOfRefreshModeRows;
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

#pragma mark 视图生命周期（加载视图）
- (void)zj_viewDidLoadForIndex:(NSInteger)index
{
    // 设置背景
    [self.view setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_BACK];
}


#pragma mark -
#pragma mark 创建界面表格
- (void)createUIRefreshView:(BOOL)force
{
    [super createUIRefreshView:force];
    
    [self createUIRefreshCollection:force];
}

#pragma mark 刷新界面表格 - CollectionView
- (void)reloadRefreshViewData
{
    [super reloadRefreshViewData];
    
    [self.collectionView reloadData];
}

#pragma mark 创建界面表格 - CollectionView
- (void)createUIRefreshCollection:(BOOL)force
{
    // 表格已经存在则无需创建，直接返回；否则强制创建表格
    if (self.collectionView && !force) {
        return;
    }
    
    // 创建表格
    {
        // 创建布局信息
        CFCGameBetPlayClassCollectionViewFlowLayout *flowLayout = [[CFCGameBetPlayClassCollectionViewFlowLayout alloc] init];
        flowLayout.delegate = self;
        flowLayout.margin = GAME_PLAY_COLLECTION_ITEM_MARGIN;
        flowLayout.sectionInset = UIEdgeInsetsMake(GAME_PLAY_COLLECTION_EDGEINSET,
                                                   GAME_PLAY_COLLECTION_EDGEINSET,
                                                   GAME_PLAY_COLLECTION_EDGEINSET,
                                                   GAME_PLAY_COLLECTION_EDGEINSET);
        
        // 创建集合视图
        CGRect frame = CGRectMake(0.0f, 0.0f, self.scrollViewSize.width, self.scrollViewSize.height);
        self.collectionView = [[UICollectionView alloc] initWithFrame:frame collectionViewLayout:flowLayout];
        [self.view addSubview:self.collectionView];
        [self.collectionView setDelegate:self];
        [self.collectionView setDataSource:self];
        [self.collectionView setShowsVerticalScrollIndicator:NO];
        [self.collectionView setBackgroundColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT];
        [self.collectionView setContentSize:self.collectionView.frame.size];
        
        // 空白页展示页
        self.collectionView.emptyDataSetSource = self;
        self.collectionView.emptyDataSetDelegate = self;
        
        // UICollectionView 支持侧滑返回
        [self tz_addPopGestureToView:self.collectionView];
        
        // 必须被注册到 UICollectionView 中
        [self createUIRefreshCollectionSetting];
    }
    
}

#pragma mark 创建界面表格 - 配置表格
- (void)createUIRefreshCollectionSetting
{
    // 注册 UICollectionReusableView Section Header（必须）
    [self.collectionView registerClass:[CFCGameBetPlayClassCollectionSectionHeaderView class]
            forSupplementaryViewOfKind:UICollectionElementKindSectionHeader
                   withReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_COLLECTION_SECTION_HEADER];
    
    // 注册 UICollectionReusableView Section Footer（必须）
    [self.collectionView registerClass:[CFCGameBetPlayClassCollectionSectionFooterView class]
            forSupplementaryViewOfKind:UICollectionElementKindSectionFooter
                   withReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_COLLECTION_SECTION_FOOTER];
    
    // 注册 UICollectionReusableView Section Header（必须）
    [self.collectionView registerClass:[CFCGameBetPlayClassCollectionSectionNULLHeaderView class]
            forSupplementaryViewOfKind:UICollectionElementKindSectionHeader
                   withReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_COLLECTION_SECTION_NULL_HEADER];
    
    // 注册 UICollectionReusableView Section Footer（必须）
    [self.collectionView registerClass:[CFCGameBetPlayClassCollectionSectionNULLFooterView class]
            forSupplementaryViewOfKind:UICollectionElementKindSectionFooter
                   withReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_COLLECTION_SECTION_NULL_FOOTER];
    
    // 注册 CFCGameBetPlayClassDefaultCollectionViewCell（必须）
    [self.collectionView registerClass:[CFCGameBetPlayClassDefaultCollectionViewCell class]
            forCellWithReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_DEFAULT_COLLECTION_VIEW_CELL];
    
    // 注册 CFCGameBetPlayClassCredit1CollectionViewCell（必须）
    [self.collectionView registerClass:[CFCGameBetPlayClassCredit1CollectionViewCell class]
            forCellWithReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_CREDIT_1_COLLECTION_VIEW_CELL];
    
    // 注册 CFCGameBetPlayClassCredit2CollectionViewCell（必须）
    [self.collectionView registerClass:[CFCGameBetPlayClassCredit2CollectionViewCell class]
            forCellWithReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_CREDIT_2_COLLECTION_VIEW_CELL];
    
    // 需在子类中重载该方法，并对投注表格进行配置
    [self collectionViewSettingRegisterInitialize:self.collectionView];
}


#pragma mark -
#pragma mark DZNEmptyDataSetDelegate Methods
- (BOOL)emptyDataSetShouldDisplay:(UIScrollView *)scrollView {
    return YES;
}

- (BOOL)emptyDataSetShouldAllowScroll:(UIScrollView *)scrollView {
    return YES;
}

- (BOOL) emptyDataSetShouldAllowImageViewAnimate:(UIScrollView *)scrollView {
    return YES;
}

#pragma mark DZNEmptyDataSetSource Methods
- (NSAttributedString *)titleForEmptyDataSet:(UIScrollView *)scrollView
{
    NSString *text = @"没有查找到相关数据";
    
    NSDictionary *attributes = @{ NSFontAttributeName : [UIFont systemFontOfSize:[CFCAutosizingUtil getAutosizeFontSize:16.0]],
                                  NSForegroundColorAttributeName : [UIColor colorWithRed:0.78 green:0.78 blue:0.78 alpha:1.00]};
    
    return [[NSAttributedString alloc] initWithString:text attributes:attributes];
}

- (NSAttributedString *)descriptionForEmptyDataSet:(UIScrollView *)scrollView
{
    NSMutableParagraphStyle *paragraph = [NSMutableParagraphStyle new];
    paragraph.lineBreakMode = NSLineBreakByWordWrapping;
    paragraph.alignment = NSTextAlignmentCenter;
    
    NSString *text = @"";
    NSDictionary *attributes = @{ NSFontAttributeName: [UIFont systemFontOfSize:[CFCAutosizingUtil getAutosizeFontSize:16.0]],
                                  NSForegroundColorAttributeName:[UIColor colorWithRed:0.78 green:0.78 blue:0.78 alpha:1.00],
                                  NSParagraphStyleAttributeName: paragraph};
    
    return [[NSAttributedString alloc] initWithString:text attributes:attributes];
}

- (UIImage *)imageForEmptyDataSet:(UIScrollView *)scrollView {
    return [UIImage imageNamed:ICON_SCROLLVIEW_EMPTY_DATASET_RESULT];
}


- (CGFloat)verticalOffsetForEmptyDataSet:(UIScrollView *)scrollView
{
    return -[CFCAutosizingUtil getAutosizeViewHeight:50.0f];
}

- (UIColor *)backgroundColorForEmptyDataSet:(UIScrollView *)scrollView
{
    return [UIColor whiteColor];
}


#pragma mark -
#pragma mark UICollectionViewDataSource
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    if (self.dataOfSectionModelArray && self.dataOfSectionModelArray.count > 0) {
        return self.dataOfSectionModelArray.count;
    }
    return 0;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (self.dataOfSectionModelArray && self.dataOfSectionModelArray.count > 0 && self.dataOfSectionModelArray.count > section) {
        
        if ([self.dataOfSectionModelArray[section] isKindOfClass:[CFCGameBetPlayClassSectionModel class]]) {
            
            CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[section];
            
            NSArray<CFCGameBetPlayClassModel *> *group = sectionModel.list;
            
            if ([group isKindOfClass:[NSArray class]]) {
                
                return group.count;
                
            }
        }
    }
    
    return 0;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (!self.dataOfSectionModelArray
        || self.dataOfSectionModelArray.count <= 0
        || self.dataOfSectionModelArray.count <= indexPath.section
        || ![self.dataOfSectionModelArray[indexPath.section] isKindOfClass:[CFCGameBetPlayClassSectionModel class]]) {
        return nil;
    }
    
    CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[indexPath.section];
    if (!sectionModel.isShowSectionContent) {
        [sectionModel setType:CFCGameBetPlayClassSectionTypeDefault];
    }
    return [self collectionView:collectionView cellForItemAtIndexPath:indexPath cellModel:sectionModel];
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    if (!self.dataOfSectionModelArray
        || self.dataOfSectionModelArray.count <= 0
        || self.dataOfSectionModelArray.count <= indexPath.section
        || ![self.dataOfSectionModelArray[indexPath.section] isKindOfClass:[CFCGameBetPlayClassSectionModel class]]) {
        return nil;
    }
    
    CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[indexPath.section];
    
    if (kind == UICollectionElementKindSectionHeader) {
        
        return [self collectionView:collectionView viewForHeaderAtIndexPath:indexPath cellModel:sectionModel];
        
    } else if (kind == UICollectionElementKindSectionFooter) {
        
        return [self collectionView:collectionView viewForFooterAtIndexPath:indexPath cellModel:sectionModel];
        
    }
    
    return nil;
}


#pragma mark -
#pragma mark CFCGameBetPlayClassCollectionViewFlowLayoutDelegate

#pragma mark 投注表格 - 自定义投注表格每一个分组的列数
- (NSInteger)numberOfColumnsInSectionForIndexPath:(NSIndexPath *)indexPath
{
    if (!self.dataOfSectionModelArray
        || self.dataOfSectionModelArray.count <= 0
        || self.dataOfSectionModelArray.count <= indexPath.section
        || ![self.dataOfSectionModelArray[indexPath.section] isKindOfClass:[CFCGameBetPlayClassSectionModel class]]) {
        return FLOAT_MIN;
    }
    
    CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[indexPath.section];
    if (!sectionModel.isShowSectionContent) {
        [sectionModel setType:CFCGameBetPlayClassSectionTypeDefault];
    }
    return [self collectionView:self.collectionView numberOfColumnsInSectionForIndexPath:indexPath cellModel:sectionModel];
}

#pragma mark 投注表格 - 自定义投注表格每一行的高度
- (CGFloat)heightOfCellItemForCollectionViewAtIndexPath:(NSIndexPath *)indexPath
{
    if (!self.dataOfSectionModelArray
        || self.dataOfSectionModelArray.count <= 0
        || self.dataOfSectionModelArray.count <= indexPath.section
        || ![self.dataOfSectionModelArray[indexPath.section] isKindOfClass:[CFCGameBetPlayClassSectionModel class]]) {
        return FLOAT_MIN;
    }
    
    CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[indexPath.section];
    if (!sectionModel.isShowSectionContent) {
        [sectionModel setType:CFCGameBetPlayClassSectionTypeDefault];
    }
    return [self collectionView:self.collectionView heightForItemAtIndexPath:indexPath cellModel:sectionModel];
}

#pragma mark 投注表格 - 自定义投注表格的 SectionHeader 的高度
- (CGFloat)heightOfSectionHeaderForIndexPath:(NSIndexPath *)indexPath
{
    if (!self.dataOfSectionModelArray
        || self.dataOfSectionModelArray.count <= 0
        || self.dataOfSectionModelArray.count <= indexPath.section
        || ![self.dataOfSectionModelArray[indexPath.section] isKindOfClass:[CFCGameBetPlayClassSectionModel class]]) {
        return FLOAT_MIN;
    }
    
    CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[indexPath.section];
    if (!sectionModel.isShowSectionContent) {
        [sectionModel setType:CFCGameBetPlayClassSectionTypeDefault];
    }
    return [self collectionView:self.collectionView heightForHeaderAtIndexPath:indexPath cellModel:sectionModel];
}

#pragma mark 投注表格 - 自定义投注表格的 SectionFooter 的高度
- (CGFloat)heightOfSectionFooterForIndexPath:(NSIndexPath *)indexPath
{
    if (!self.dataOfSectionModelArray
        || self.dataOfSectionModelArray.count <= 0
        || self.dataOfSectionModelArray.count <= indexPath.section
        || ![self.dataOfSectionModelArray[indexPath.section] isKindOfClass:[CFCGameBetPlayClassSectionModel class]]) {
        return FLOAT_MIN;
    }
    
    CFCGameBetPlayClassSectionModel *sectionModel = self.dataOfSectionModelArray[indexPath.section];
    if (!sectionModel.isShowSectionContent) {
        [sectionModel setType:CFCGameBetPlayClassSectionTypeDefault];
    }
    return [self collectionView:self.collectionView heightForFooterAtIndexPath:indexPath cellModel:sectionModel];
}


#pragma mark -
#pragma mark 投注表格 - 对投注表格进行配置（子类继承实现）
- (void)collectionViewSettingRegisterInitialize:(UICollectionView *)collectionView
{
    // TODO: 请在子类中重载该方法，并对投注表格进行配置
    
}

#pragma mark 投注表格 - 自定义投注表格每一个分组的列数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfColumnsInSectionForIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model
{
    // TODO: 请在子类中重载该方法，并返回自定义投注表格的每一个分组的列数
    
    return model.columnsCount;
}

#pragma mark 投注表格 - 自定义投注表格的 UICollectionViewCell 的控件
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model
{
    // TODO: 请在子类中重载该方法，并返回自定义投注表格的 UICollectionViewCell 的实例
    
    switch (model.type) {
            // 类型 -> Default -> 分组内容为 -> 默认为空
        case CFCGameBetPlayClassSectionTypeDefault: {
            CFCGameBetPlayClassDefaultCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_DEFAULT_COLLECTION_VIEW_CELL forIndexPath:indexPath];
            if (!cell) {
                cell = [[CFCGameBetPlayClassDefaultCollectionViewCell alloc] init];
            }
            cell.indexPath = indexPath;
            cell.model = model.list[indexPath.row];
            return cell;
        }
            // 类型 -> Credit1 -> 分组内容为 -> 信用玩法 -> 投注项目，常规 -> 如：时时彩信用玩法中<双面、跨度>
        case CFCGameBetPlayClassSectionTypeCredit1: {
            CFCGameBetPlayClassCredit1CollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_CREDIT_1_COLLECTION_VIEW_CELL forIndexPath:indexPath];
            if (!cell) {
                cell = [[CFCGameBetPlayClassCredit1CollectionViewCell alloc] init];
            }
            cell.delegate = self;
            cell.indexPath = indexPath;
            cell.model = model.list[indexPath.row];
            return cell;
        }
            // 类型 -> Credit2 -> 分组内容为 -> 信用玩法 -> 投注项目，生肖 -> 如：六合彩信用玩法中<半波、特肖>
        case CFCGameBetPlayClassSectionTypeCredit2: {
            CFCGameBetPlayClassCredit2CollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_CREDIT_2_COLLECTION_VIEW_CELL forIndexPath:indexPath];
            if (!cell) {
                cell = [[CFCGameBetPlayClassCredit2CollectionViewCell alloc] init];
            }
            cell.delegate = self;
            cell.indexPath = indexPath;
            cell.model = model.list[indexPath.row];
            return cell;
        }
        default: {
            // 类型 -> Default -> 分组内容为 -> 默认为空
            CFCGameBetPlayClassDefaultCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_DEFAULT_COLLECTION_VIEW_CELL forIndexPath:indexPath];
            if (!cell) {
                cell = [[CFCGameBetPlayClassDefaultCollectionViewCell alloc] init];
            }
            cell.indexPath = indexPath;
            cell.model = model.list[indexPath.row];
            return cell;
        }
    }
    
}

#pragma mark 投注表格 - 自定义投注表格每一行的高度
- (CGFloat)collectionView:(UICollectionView *)collectionView heightForItemAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model
{
    // TODO: 请在子类中重载该方法，并返回自定义投注表格的 UICollectionViewCell 的高度
    
    switch (model.type) {
            // 类型 -> Default -> 分组内容为 -> 默认为空
        case CFCGameBetPlayClassSectionTypeDefault: {
            return [CFCGameBetPlayClassDefaultCollectionViewCell heightForCellAtIndexPath:indexPath cellModel:model];
        }
            // 类型 -> Credit1 -> 分组内容为 -> 信用玩法 -> 投注项目，常规 -> 如：时时彩信用玩法中<双面、跨度>
        case CFCGameBetPlayClassSectionTypeCredit1: {
            return [CFCGameBetPlayClassCredit1CollectionViewCell heightForCellAtIndexPath:indexPath cellModel:model];
        }
            // 类型 -> Credit2 -> 分组内容为 -> 信用玩法 -> 投注项目，生肖 -> 如：六合彩信用玩法中<半波、特肖>
        case CFCGameBetPlayClassSectionTypeCredit2: {
            return [CFCGameBetPlayClassCredit2CollectionViewCell heightForCellAtIndexPath:indexPath cellModel:model];
        }
        default: {
            // 类型 -> Default -> 分组内容为 -> 默认为空
            return [CFCGameBetPlayClassDefaultCollectionViewCell heightForCellAtIndexPath:indexPath cellModel:model];
        }
    }
    
}

#pragma mark 投注表格 - 自定义投注表格的 SectionHeader 的视图
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForHeaderAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model
{
    // TODO: 请在子类中重载该方法，并返回自定义投注表格的 SectionHeader 的视图
    
    if (model.isShowHeader) {
        CFCGameBetPlayClassCollectionSectionHeaderView *sectionHeaderView
        = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader
                                             withReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_COLLECTION_SECTION_HEADER
                                                    forIndexPath:indexPath];
        [sectionHeaderView setModel:model];
        return sectionHeaderView;
    }
    
    // 默认返回空视图
    CFCGameBetPlayClassCollectionSectionNULLHeaderView *sectionHeaderView
    = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader
                                         withReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_COLLECTION_SECTION_NULL_HEADER
                                                forIndexPath:indexPath];
    return sectionHeaderView;
}

#pragma mark 投注表格 - 自定义投注表格的 SectionFooter 的视图
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForFooterAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model
{
    // TODO: 请在子类中重载该方法，并返回自定义投注表格的 SectionFooter 的视图
    
    if (model.isShowFooter) {
        CFCGameBetPlayClassCollectionSectionFooterView *sectionFooterView
        = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionFooter
                                             withReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_COLLECTION_SECTION_FOOTER
                                                    forIndexPath:indexPath];
        return sectionFooterView;
    }
    
    // 默认返回空视图
    CFCGameBetPlayClassCollectionSectionNULLFooterView *sectionFooterView
    = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionFooter
                                         withReuseIdentifier:CELL_IDENTIFIER_GAME_BET_PLAY_CLASS_COLLECTION_SECTION_NULL_FOOTER
                                                forIndexPath:indexPath];
    return sectionFooterView;
}

#pragma mark 投注表格 - 自定义投注表格的 SectionHeader 的高度
- (CGFloat)collectionView:(UICollectionView *)collectionView heightForHeaderAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model
{
    // TODO: 请在子类中重载该方法，并返回自定义投注表格的 SectionHeader 的高度
    
    if (model.isShowHeader) {
        if (0 == indexPath.section) {
            return model.heightOfHeader + model.heightOfFooter;
        }
        return model.heightOfHeader;
    }
    
    return FLOAT_MIN;
}

#pragma mark 投注表格 - 自定义投注表格的 SectionFooter 的高度
- (CGFloat)collectionView:(UICollectionView *)collectionView heightForFooterAtIndexPath:(NSIndexPath *)indexPath cellModel:(CFCGameBetPlayClassSectionModel *)model
{
    // TODO: 请在子类中重载该方法，并返回自定义投注表格的 SectionFooter 的高度
    
    if (model.isShowFooter) {
        return model.heightOfFooter;
    }
    
    return FLOAT_MIN;
}


@end





