//
//  OnlineChatViewController.m
//  CpNative
//
//  Created by david on 2019/3/10.
//  Copyright © 2019 david. All rights reserved.
//

#import "OnlineChatViewController.h"

@interface OnlineChatViewController ()

@end

@implementation OnlineChatViewController {
    NSInteger countdownCount;
}

- (instancetype)init
{
    self = [super initWithHTMLUrlString:ChatRoomUrl];
    if (self) {
        _isHiddenHeader = NO;
        countdownCount = 0;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(on1SecondCountdown) name:Noti_Timer_1second object:nil];
}

- (void)reloadChatRoom {
    self.htmlUrlString = ChatRoomUrl;//注意：这行不能删！刷新，必须重新赋值！
    NSLog(@"进入聊天室，完整地址：%@",self.htmlUrlString);
    [self startLoadRequestWebHtml];
    countdownCount = 0;//重新加载后，复位计数
}

/*每隔一定时间刷新一次聊天室，每次刷新复位计数=0 */
- (void)on1SecondCountdown {
    ++countdownCount;
    if (countdownCount >= (5*60)) {  //刷新间隔
        [self reloadChatRoom];
    }
}

#pragma mark -
#pragma mark JS与OC处理交互
- (void)webViewJavascriptBridgeRegisterHandler
{
    /*
     * 含义：JS调用OC
     * @param registerHandler 要注册的事件名称（比如这里我们为testJavascriptCallObjcHandler）
     * @param handler 回调block函数，当后台触发这个事件的时候会执行block里面的代码
     */

    NSString *jsMethodName = @"chatRoomUserLoginInfo"; //JS函数名
    [self.bridge registerHandler:jsMethodName handler:^(id data, WVJBResponseCallback responseCallback) {
        // data JS页面传过来的参数
//        NSLog(@"接收到聊天室的js调用:%@",data);
        
        /*注意: 这部分必须是动态的*/
        NSString *string = @"NOT LOGIN";
        if ([Singleton shared].loginState == LoginStateNone) {
            
        } else {
            NSString *username = [[Singleton shared].loginDict stringForKey:@"username"];
            NSString *token = [[Singleton shared].loginDict stringForKey:@"token"];
            NSString *parent = [[Singleton shared].loginDict stringForKey:@"parent"];
            NSString *type = @"1";    //1 是登陆 2 是退出
            NSString *api_id = @"1";  //写死1
            NSString *roomid = @"0";  //默认是0
            NSString *hiddenHeader = _isHiddenHeader?@"1":@"0"; //0不隐藏头部，1隐藏
            NSString *pass = [NSString stringWithFormat:@"%@%@651651798",[Singleton shared].account,[Singleton shared].accountPass];
            pass = [pass substringToIndex:7];
            
            NSDictionary *dictionary = @{
                                         @"username":username,
                                         @"password":pass,
                                         @"token":token,
                                         @"type":type,
                                         @"api_id":api_id,
                                         @"parent":parent,
                                         @"roomid":roomid,
                                         @"hiddenheader":hiddenHeader
                                         };
            string = dictionary.JSONString;
            
        }
        NSLog(@"返回给网页端的字符串是:%@",string);
        responseCallback(string);
    }];
    
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Noti_Timer_1second object:nil];
}
@end
