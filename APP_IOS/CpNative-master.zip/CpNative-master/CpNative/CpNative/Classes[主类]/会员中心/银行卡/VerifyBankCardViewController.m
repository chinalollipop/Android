//
//  VerifyBankCardViewController.m
//  CpNative
//
//  Created by david on 2019/3/6.
//  Copyright © 2019 david. All rights reserved.
//  1、如果不是第一次绑卡，则需要验证卡信息。
//  2、如果是修改卡信息，则需要验证旧卡信息。

#import "VerifyBankCardViewController.h"
#import "BindCardViewController.h"
#import "ModifyCardInfoViewController.h"

@interface VerifyBankCardViewController ()<UITextFieldDelegate>

@end

@implementation VerifyBankCardViewController {
    UITextField *tfName;
    UITextField *tfAccount;
    UITextField *tfFunPass;
    
    NSDictionary *thisCard;
    NSString *thisAccount;
    NSString *thisId;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    topbar.titleLabel.text = @"验证银行卡";
    if (_verifyType == 2) {
        topbar.titleLabel.text = @"删除银行卡";
    }
    
    CGFloat offY = topbar.bottom;
    CGFloat left = widthTo4_7(12);
    UIColor *color = ColorHex(0x161616);
    UIFont *font = SystemFontBy4(13.0);
    
    
    if (_verifyType == 1 || _verifyType == 2) {
        thisCard = _bankcards[_bankcardsIndex];
        thisAccount = [thisCard stringForKey:@"account"];
        thisId = [thisCard stringForKey:@"id"];
        
        NSString *last4 = thisAccount;
        if (thisAccount.length >= 4) {
            last4 = [thisAccount substringFromIndex:thisAccount.length-4];
        }
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(left, offY, self.view.width, widthTo4_7(52))];
        label.text = [NSString stringWithFormat:@"卡号: **** **** **** %@",last4];
        label.textColor = ColorHex(0xEEAD0E);
        label.font = SystemFontBy4(13.6);
        [self.view addSubview:label];
        offY = label.bottom-widthTo4_7(8);
    }
    
    UILabel *text0 = [[UILabel alloc] initWithFrame:CGRectMake(left, offY+widthTo4_7(8), self.view.width, widthTo4_7(34))];
    text0.text = @"开户人姓名(请输入旧的银行卡开户人姓名):";
    text0.textColor = color;
    text0.font = font;
    [self.view addSubview:text0];
    
    tfName = [[UITextField alloc] initWithFrame:CGRectMake(left, text0.bottom, self.view.width-left*2, widthTo4_7(44))];
    tfName.layer.borderColor = ColorHex(0x777777).CGColor;
    tfName.layer.borderWidth = widthTo4_7(1.0);
    tfName.layer.cornerRadius = widthTo4_7(3.4);
    tfName.layer.masksToBounds = YES;
    UIView *v = [[UIView alloc] initWithFrame:CGRectMake(0, 0, widthTo4_7(12), tfName.height)];
    tfName.leftView = v;
    tfName.leftViewMode = UITextFieldViewModeAlways;
    tfName.placeholder = @"请输入开户人姓名";
    tfName.clearButtonMode = UITextFieldViewModeWhileEditing;
    tfName.font = SystemFontBy4(13.6);
    [self.view addSubview:tfName];
    
    UILabel *text1 = [[UILabel alloc] initWithFrame:CGRectMake(left, tfName.bottom+widthTo4_7(8), self.view.width, widthTo4_7(34))];
    text1.text = @"银行账号(请输入旧的银行卡卡号):";
    text1.textColor = color;
    text1.font = font;
    [self.view addSubview:text1];
    
    tfAccount = [[UITextField alloc] initWithFrame:CGRectMake(left, text1.bottom, self.view.width-left*2, widthTo4_7(44))];
    tfAccount.layer.borderColor = ColorHex(0x777777).CGColor;
    tfAccount.layer.borderWidth = widthTo4_7(1.0);
    tfAccount.layer.cornerRadius = widthTo4_7(3.4);
    tfAccount.layer.masksToBounds = YES;
    v = [[UIView alloc] initWithFrame:CGRectMake(0, 0, widthTo4_7(12), tfName.height)];
    tfAccount.leftView = v;
    tfAccount.leftViewMode = UITextFieldViewModeAlways;
    tfAccount.placeholder = @"请输入旧的银行卡卡号";
    tfAccount.clearButtonMode = UITextFieldViewModeWhileEditing;
    tfAccount.font = SystemFontBy4(13.6);
    tfAccount.delegate = self;
    [self.view addSubview:tfAccount];
    
    UILabel *text2 = [[UILabel alloc] initWithFrame:CGRectMake(left, tfAccount.bottom+widthTo4_7(8), self.view.width, widthTo4_7(34))];
    text2.text = @"资金密码(请输入您的资金密码):";
    text2.textColor = color;
    text2.font = font;
    [self.view addSubview:text2];
    
    tfFunPass = [[UITextField alloc] initWithFrame:CGRectMake(left, text2.bottom, self.view.width-left*2, widthTo4_7(44))];
    tfFunPass.layer.borderColor = ColorHex(0x777777).CGColor;
    tfFunPass.layer.borderWidth = widthTo4_7(1.0);
    tfFunPass.layer.cornerRadius = widthTo4_7(3.4);
    tfFunPass.layer.masksToBounds = YES;
    v = [[UIView alloc] initWithFrame:CGRectMake(0, 0, widthTo4_7(12), tfName.height)];
    tfFunPass.leftView = v;
    tfFunPass.leftViewMode = UITextFieldViewModeAlways;
    tfFunPass.placeholder = @"请输入资金密码";
    tfFunPass.secureTextEntry = YES;
    tfFunPass.clearButtonMode = UITextFieldViewModeWhileEditing;
    tfFunPass.font = SystemFontBy4(13.6);
    [self.view addSubview:tfFunPass];
    
    CGFloat heig = widthTo4_7(44);
    CGFloat gap = left;
    UIButton *submit = [[UIButton alloc] initWithFrame:CGRectMake(gap, tfFunPass.bottom+widthTo4_7(40), (self.view.width-gap*3)/2, heig)];
    [submit setTitle:@"下一步" forState:0];
    [submit setTitleColor:ColorHex(0xffffff) forState:0];
    submit.titleLabel.font = SystemFontBy4(14.6);
    submit.backgroundColor = ColorSubmit;
    submit.layer.cornerRadius = 0.1*heig;
    submit.layer.masksToBounds = YES;
    [submit addTarget:self action:@selector(onSubmit) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:submit];
    
    UIButton *reset = [[UIButton alloc] initWithFrame:CGRectMake(submit.right+gap, submit.top, (self.view.width-gap*3)/2, heig)];
    [reset setTitle:@"重置" forState:0];
    [reset setTitleColor:ColorHex(0xffffff) forState:0];
    reset.titleLabel.font = SystemFontBy4(14.6);
    reset.backgroundColor = ColorReset;
    reset.layer.cornerRadius = 0.1*heig;
    reset.layer.masksToBounds = YES;
    [reset addTarget:self action:@selector(onReset) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:reset];
    
    if (_verifyType == 2) {
        [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [NetworkBusiness destroyCardId:thisId Block:^(NSError *error, int code, id response) {
            [MBProgressHUD hideHUDForView:self.view animated:NO];
            
            /*判断是否重新登录*/
            if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
                return;
            }
            
            if (code == 200) {
                NSInteger err = [response integerForKey:@"errno"];
                if (err == 0) {
                    
                } else {
                    NSString *str = [response stringForKey:@"error"];
                    if (!str.length) {
                        str = @"请求失败,请稍后再试。";
                    }
                    [Tools alertWithTitle:str message:nil handle:^(UIAlertAction * _Nonnull action) {
                        [self.navigationController popViewControllerAnimated:YES];
                    } cancel:nil confirm:@"确定"];
                }
            } else {
                [Tools showText:@"请求失败,请稍后再试."];
            }
        }];
    }
    
}

- (void)onSubmit {
    if (!tfName.text.length) {
        [Tools showText:@"请输入开户人姓名"];
        return;
    }
    if (!tfAccount.text.length) {
        [Tools showText:@"请输入旧的银行卡号"];
        return;
    }
    
    NSString *bankNum = [tfAccount.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSString *_id = nil;
    for (int i = 0; i < _bankcards.count; i++) {
        NSDictionary *bank = _bankcards[i];
        if ([[bank stringForKey:@"account"] isEqualToString:bankNum]) {
            _id = [bank stringForKey:@"id"];
            break;
        }
    }

    if (!_id) {
        [Tools showText:@"旧的卡号输入错误"];
        return;
    }
    
    if (_verifyType == 1 || _verifyType == 2) {//修改或删除，需要填写正确的卡号
        if (![bankNum isEqualToString:thisAccount]) {
            [Tools showText:@"您输入的不是当前要提交的卡号，请确认。"];
            return;
        }
    }
    
    
    
    if (!tfFunPass.text.length) {
        [Tools showText:@"请输入资金密码"];
        return;
    }
    
    
    
    
    
    
    if (_verifyType == 0) {
        [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [NetworkBusiness addMoreCardVerify:_id name:tfName.text account:bankNum funPass:tfFunPass.text Block:^(NSError *error, int code, id response) {
            [MBProgressHUD hideHUDForView:self.view animated:NO];
            
            /*判断是否重新登录*/
            if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
                return;
            }
            
            if (code == 200) {
                NSInteger err = [response integerForKey:@"errno"];
                if (err == 0) {
                    BindCardViewController *bind = [[BindCardViewController alloc] init];
                    [self.navigationController pushViewController:bind animated:YES];
                } else {
                    NSString *str = [response stringForKey:@"error"];
                    if (!str.length) {
                        str = @"验证失败";
                    }
                    [Tools alertWithTitle:str message:nil handle:nil cancel:nil confirm:@"确定"];
                }
            } else {
                [Tools showText:@"请求失败,请稍后再试."];
            }
        }];
    }
    if (_verifyType == 1) {
        [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [NetworkBusiness modifyCardVerify:_id name:tfName.text account:bankNum funPass:tfFunPass.text Block:^(NSError *error, int code, id response) {
            [MBProgressHUD hideHUDForView:self.view animated:NO];
            
            /*判断是否重新登录*/
            if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
                return;
            }
            
            if (code == 200) {
                NSInteger err = [response integerForKey:@"errno"];
                if (err == 0) {
                    ModifyCardInfoViewController *bind = [[ModifyCardInfoViewController alloc] init];
                    bind._id = _id;
                    [self.navigationController pushViewController:bind animated:YES];
                } else {
                    NSString *str = [response stringForKey:@"error"];
                    if (!str.length) {
                        str = @"验证失败";
                    }
                    [Tools alertWithTitle:str message:nil handle:nil cancel:nil confirm:@"确定"];
                }
            } else {
                [Tools showText:@"请求失败,请稍后再试."];
            }
        }];
    }
    if (_verifyType == 2) {
        [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [NetworkBusiness destroyConfirmFor:thisId name:tfName.text account:thisAccount funPass:tfFunPass.text Block:^(NSError *error, int code, id response) {
            [MBProgressHUD hideHUDForView:self.view animated:NO];
            
            /*判断是否重新登录*/
            if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
                return;
            }
            
            if (code == 200) {
                NSInteger err = [response integerForKey:@"errno"];
                if (err == 0) {
                    [Tools alertWithTitle:@"删除成功!" message:nil handle:^(UIAlertAction * _Nonnull action) {
                        [self.navigationController popViewControllerAnimated:YES];
                    } cancel:nil confirm:@"返回"];
                } else {
                    NSString *str = [response stringForKey:@"error"];
                    if (!str.length) {
                        str = @"删除失败";
                    }
                    [Tools alertWithTitle:str message:nil handle:nil cancel:nil confirm:@"确定"];
                }
            } else {
                [Tools showText:@"请求失败,请稍后再试."];
            }
        }];
    }
}

- (void)onReset {
    tfName.text = @"";
    tfAccount.text = @"";
    tfFunPass.text = @"";
}



- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString *value = [textField.text stringByReplacingCharactersInRange:range withString:string];
    textField.text = [Tools addBlankForBankCarNum:value];
    return NO;
}
@end
