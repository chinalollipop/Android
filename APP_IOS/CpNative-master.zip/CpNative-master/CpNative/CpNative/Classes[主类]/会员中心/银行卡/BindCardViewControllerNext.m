//
//  BindCardViewControllerNext.m
//  CpNative
//
//  Created by david on 2019/3/1.
//  Copyright © 2019 david. All rights reserved.
//

#import "BindCardViewControllerNext.h"

@interface BindCardViewControllerNext ()

@end

@implementation BindCardViewControllerNext

- (void)viewDidLoad {
    [super viewDidLoad];
    
    topbar.titleLabel.text = @"确认添加";
    
    NSArray *array = @[@"开户银行:",@"支行名称:",@"开户人姓名:",@"银行账号:",];
    NSArray *tttt = @[_bank,_branch,_name,_account];
    
    CGFloat heigH = widthTo4_7(48);
    for (int i = 0; i < array.count; i++) {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(10), topbar.bottom+heigH*i, 150, heigH)];
        label.text = array[i];
        label.textColor = ColorHex(0x161616);
        label.font = SystemFontBy4(14.4);
        [self.view addSubview:label];
        
        UILabel *aaaa = [[UILabel alloc] initWithFrame:CGRectMake(0.35*self.view.width, topbar.bottom+heigH*i, 300, heigH)];
        aaaa.text = tttt[i];
        aaaa.textColor = label.textColor;
        aaaa.font = label.font;
        [self.view addSubview:aaaa];
    }
    
    CGFloat heig = widthTo4_7(44);
    CGFloat gap = 0.06*self.view.width;
    UIButton *submit = [[UIButton alloc] initWithFrame:CGRectMake(gap, topbar.bottom+heigH*4.6, (self.view.width-gap*3)/2, heig)];
    [submit setTitle:@"确认提交" forState:0];
    [submit setTitleColor:ColorHex(0xffffff) forState:0];
    submit.titleLabel.font = SystemFontBy4(14.6);
    submit.backgroundColor = ColorSubmit;
    submit.layer.cornerRadius = 0.1*heig;
    submit.layer.masksToBounds = YES;
    [submit addTarget:self action:@selector(onSubmit) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:submit];
    
    UIButton *reset = [[UIButton alloc] initWithFrame:CGRectMake(submit.right+gap, submit.top, (self.view.width-gap*3)/2, heig)];
    [reset setTitle:@"返回上一步" forState:0];
    [reset setTitleColor:ColorHex(0xffffff) forState:0];
    reset.titleLabel.font = SystemFontBy4(14.6);
    reset.backgroundColor = ColorHex(0x444443);
    reset.layer.cornerRadius = 0.1*heig;
    reset.layer.masksToBounds = YES;
    [reset addTarget:self action:@selector(onReset) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:reset];
    
    
    
}

- (void)onSubmit {
    [MBProgressHUD showHUDAddedTo:mainDelegate.window animated:NO];
    NSString *acc = [_account stringByReplacingOccurrencesOfString:@" " withString:@""];
    [NetworkBusiness commit:_bank id:__id branch:_branch name:_name account:acc Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:mainDelegate.window animated:NO];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            NSString *errstr = [response stringForKey:@"error"];
            if (err == 0) {
                if (errstr.length < 2) {
                    errstr = @"添加成功!";
                }
                [Tools alertWithTitle:errstr message:nil handle:^(UIAlertAction * _Nonnull action) {
                    
                    UIViewController *controller = nil;
                    for (UIViewController *con in self.navigationController.viewControllers) {
                        if ([con isKindOfClass:NSClassFromString(@"BankCardViewController")]) {
                            controller = con;
                            break;
                        }
                    }
                    if (controller) {
                        [self.navigationController popToViewController:controller animated:YES];
                    } else {
                        [self.navigationController popToRootViewControllerAnimated:YES];
                    }
                    
                } cancel:nil confirm:@"确定"];
            } else {
                [Tools alertWithTitle:errstr message:nil handle:nil cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求服务失败,请稍后再试."];
        }
        
    }];
}

- (void)onReset {
    [self.navigationController popViewControllerAnimated:YES];
}
@end
