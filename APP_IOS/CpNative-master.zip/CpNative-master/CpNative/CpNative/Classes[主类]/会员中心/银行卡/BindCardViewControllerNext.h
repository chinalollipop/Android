//
//  BindCardViewControllerNext.h
//  CpNative
//
//  Created by david on 2019/3/1.
//  Copyright © 2019 david. All rights reserved.
//

#import "BasicWithNaviBarViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface BindCardViewControllerNext : BasicWithNaviBarViewController

@property(nonatomic, copy) NSString *bank;
@property(nonatomic, copy) NSString *branch;
@property(nonatomic, copy) NSString *name;
@property(nonatomic, copy) NSString *account;
@property(nonatomic, copy) NSString *_id;

@end

NS_ASSUME_NONNULL_END
