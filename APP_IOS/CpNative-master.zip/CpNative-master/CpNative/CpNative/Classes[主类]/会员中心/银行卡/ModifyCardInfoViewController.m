//
//  ModifyCardInfoViewController.m
//  CpNative
//
//  Created by david on 2019/3/6.
//  Copyright © 2019 david. All rights reserved.
//

#import "ModifyCardInfoViewController.h"
#import "ModifyCardConfirmViewController.h"

@interface ModifyCardInfoViewController ()<UITextFieldDelegate>

@end

@implementation ModifyCardInfoViewController {
    NSDictionary *card;
    
    UITextField *tfBank;
    UITextField *tfBranch;
    UITextField *tfName;
    UITextField *tfAccount;
    UITextField *tfAccount2;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    topbar.titleLabel.text = @"修改银行卡";
    
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];;
    [NetworkBusiness modifyInfoForId:__id Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                NSDictionary *data = [response dictionaryForKey:@"data"];
                card = [data dictionaryForKey:@"BankCard"];
                [self buildUI];
            } else {
                [Tools alertWithTitle:@"连接出错,请稍后再试." message:nil handle:^(UIAlertAction * _Nonnull action) {
                    [self.navigationController popViewControllerAnimated:YES];
                } cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求失败,请稍后再试."];
        }
    }];
}

- (void)buildUI {
    CGFloat offY = topbar.bottom;
    CGFloat left = widthTo4_7(12);
    UIColor *color = ColorHex(0x161616);
    UIFont *font = SystemFontBy4(13.0);
    
    UILabel *text0 = [[UILabel alloc] initWithFrame:CGRectMake(left, offY+widthTo4_7(8), self.view.width, widthTo4_7(34))];
    text0.text = @"开户银行:";
    text0.textColor = color;
    text0.font = font;
    [self.view addSubview:text0];
    
    tfBank = [[UITextField alloc] initWithFrame:CGRectMake(left, text0.bottom, self.view.width-left*2, widthTo4_7(44))];
    tfBank.layer.borderColor = ColorHex(0x777777).CGColor;
    tfBank.layer.borderWidth = widthTo4_7(1.0);
    tfBank.layer.cornerRadius = widthTo4_7(3.4);
    tfBank.layer.masksToBounds = YES;
    UIView *v = [[UIView alloc] initWithFrame:CGRectMake(0, 0, widthTo4_7(12), tfBank.height)];
    tfBank.leftView = v;
    tfBank.leftViewMode = UITextFieldViewModeAlways;
    tfBank.clearButtonMode = UITextFieldViewModeAlways;
    tfBank.font = SystemFontBy4(13.6);
    tfBank.text = [card stringForKey:@"bank"];
    [self.view addSubview:tfBank];
    offY = tfBank.bottom;
    
    text0 = [[UILabel alloc] initWithFrame:CGRectMake(left, offY+widthTo4_7(8), self.view.width, widthTo4_7(34))];
    text0.text = @"支行名称:";
    text0.textColor = color;
    text0.font = font;
    [self.view addSubview:text0];
    
    tfBranch = [[UITextField alloc] initWithFrame:CGRectMake(left, text0.bottom, self.view.width-left*2, widthTo4_7(44))];
    tfBranch.layer.borderColor = ColorHex(0x777777).CGColor;
    tfBranch.layer.borderWidth = widthTo4_7(1.0);
    tfBranch.layer.cornerRadius = widthTo4_7(3.4);
    tfBranch.layer.masksToBounds = YES;
    v = [[UIView alloc] initWithFrame:CGRectMake(0, 0, widthTo4_7(12), tfBank.height)];
    tfBranch.leftView = v;
    tfBranch.leftViewMode = UITextFieldViewModeAlways;
    tfBranch.clearButtonMode = UITextFieldViewModeAlways;
    tfBranch.font = SystemFontBy4(13.6);
    tfBranch.text = [card stringForKey:@"branch"];
    [self.view addSubview:tfBranch];
    offY = tfBranch.bottom;
    
    text0 = [[UILabel alloc] initWithFrame:CGRectMake(left, offY+widthTo4_7(8), self.view.width, widthTo4_7(34))];
    text0.text = @"开户人姓名:";
    text0.textColor = color;
    text0.font = font;
    [self.view addSubview:text0];
    
    tfName = [[UITextField alloc] initWithFrame:CGRectMake(left, text0.bottom, self.view.width-left*2, widthTo4_7(44))];
    tfName.layer.borderColor = ColorHex(0x777777).CGColor;
    tfName.layer.borderWidth = widthTo4_7(1.0);
    tfName.layer.cornerRadius = widthTo4_7(3.4);
    tfName.layer.masksToBounds = YES;
    v = [[UIView alloc] initWithFrame:CGRectMake(0, 0, widthTo4_7(12), tfName.height)];
    tfName.leftView = v;
    tfName.leftViewMode = UITextFieldViewModeAlways;
    tfName.clearButtonMode = UITextFieldViewModeAlways;
    tfName.font = SystemFontBy4(13.6);
    tfName.text = [card stringForKey:@"account_name"];
    [self.view addSubview:tfName];
    offY = tfName.bottom;
    
    text0 = [[UILabel alloc] initWithFrame:CGRectMake(left, offY+widthTo4_7(8), self.view.width, widthTo4_7(34))];
    text0.text = @"账号号码:";
    text0.textColor = color;
    text0.font = font;
    [self.view addSubview:text0];
    
    tfAccount = [[UITextField alloc] initWithFrame:CGRectMake(left, text0.bottom, self.view.width-left*2, widthTo4_7(44))];
    tfAccount.delegate = self;
    tfAccount.layer.borderColor = ColorHex(0x777777).CGColor;
    tfAccount.layer.borderWidth = widthTo4_7(1.0);
    tfAccount.layer.cornerRadius = widthTo4_7(3.4);
    tfAccount.layer.masksToBounds = YES;
    v = [[UIView alloc] initWithFrame:CGRectMake(0, 0, widthTo4_7(12), tfName.height)];
    tfAccount.leftView = v;
    tfAccount.leftViewMode = UITextFieldViewModeAlways;
    tfAccount.clearButtonMode = UITextFieldViewModeAlways;
    tfAccount.font = SystemFontBy4(13.6);
    tfAccount.text = [Tools addBlankForBankCarNum:[card stringForKey:@"account"]];
    [self.view addSubview:tfAccount];
    offY = tfAccount.bottom;
    
    text0 = [[UILabel alloc] initWithFrame:CGRectMake(left, offY+widthTo4_7(8), self.view.width, widthTo4_7(34))];
    text0.text = @"请确认账号号码:";
    text0.textColor = color;
    text0.font = font;
    [self.view addSubview:text0];
    
    tfAccount2 = [[UITextField alloc] initWithFrame:CGRectMake(left, text0.bottom, self.view.width-left*2, widthTo4_7(44))];
    tfAccount2.delegate = self;
    tfAccount2.layer.borderColor = ColorHex(0x777777).CGColor;
    tfAccount2.layer.borderWidth = widthTo4_7(1.0);
    tfAccount2.layer.cornerRadius = widthTo4_7(3.4);
    tfAccount2.layer.masksToBounds = YES;
    v = [[UIView alloc] initWithFrame:CGRectMake(0, 0, widthTo4_7(12), tfName.height)];
    tfAccount2.leftView = v;
    tfAccount2.leftViewMode = UITextFieldViewModeAlways;
    tfAccount2.clearButtonMode = UITextFieldViewModeAlways;
    tfAccount2.font = SystemFontBy4(13.6);
    tfAccount2.placeholder = @"请再次输入账号号码";
    [self.view addSubview:tfAccount2];
    offY = tfAccount2.bottom;
    
    CGFloat heig = widthTo4_7(44);
    CGFloat gap = left;
    UIButton *submit = [[UIButton alloc] initWithFrame:CGRectMake(gap, offY+widthTo4_7(44), (self.view.width-gap*2), heig)];
    [submit setTitle:@"下一步" forState:0];
    [submit setTitleColor:ColorHex(0xffffff) forState:0];
    submit.titleLabel.font = SystemFontBy4(14.6);
    submit.backgroundColor = ColorSubmit;
    submit.layer.cornerRadius = 0.1*heig;
    submit.layer.masksToBounds = YES;
    [submit addTarget:self action:@selector(onSubmit) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:submit];
}

- (void)onSubmit {
    if (!tfBank.text.length) {
        [Tools showText:@"请输入开户行名称"];
        return;
    }
    if (!tfBranch.text.length) {
        [Tools showText:@"请输入支行名称"];
        return;
    }
    if (!tfName.text.length) {
        [Tools showText:@"请输入开户人姓名"];
        return;
    }
    if (!tfAccount.text.length) {
        [Tools showText:@"请输入账号号码"];
        return;
    }
    
    if (![tfAccount.text isEqualToString:tfAccount2.text]) {
        [Tools showText:@"两次输入的账号号码不一致"];
        return;
    }
    
    
    
    
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness modifyValidationForId:__id Bank:tfBank.text bankId:[card stringForKey:@"bank_id"] branch:tfBranch.text name:tfName.text account:tfAccount.text Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                ModifyCardConfirmViewController *confirm = [[ModifyCardConfirmViewController alloc] init];
                confirm._id = __id;
                confirm.bank = tfBank.text;
                confirm.bankId = [card stringForKey:@"bank_id"];
                confirm.branch = tfBranch.text;
                confirm.name = tfName.text;
                confirm.account = tfAccount.text;
                [self.navigationController pushViewController:confirm animated:YES];
                
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"验证失败";
                }
                [Tools alertWithTitle:str message:nil handle:nil cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求失败,请稍后再试."];
        }
    }];
    
    
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString *value = [textField.text stringByReplacingCharactersInRange:range withString:string];
    textField.text = [Tools addBlankForBankCarNum:value];
    return NO;
}

@end
