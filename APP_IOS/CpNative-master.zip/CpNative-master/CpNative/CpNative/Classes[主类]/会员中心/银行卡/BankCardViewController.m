//
//  BankCardViewController.m
//  CpNative
//
//  Created by david on 2019/2/28.
//  Copyright © 2019 david. All rights reserved.
//

#import "BankCardViewController.h"
#import "BindCardViewController.h"
#import "ModifyFundPassViewController.h"
#import "UserDetailViewController.h"
#import "VerifyBankCardViewController.h"


@interface BankCardViewController ()

@end

@implementation BankCardViewController {
    UIView *topView;
    
    BasicScrollView *downView;
    
    NSDictionary *data;
    NSArray *bankcards;
    
    int currentBankIndex;//当前用户点击了那张卡
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    topbar.titleLabel.text = @"银行卡";
    
    CGFloat heig = widthTo4_7(44);
    topView = [[UIView alloc] initWithFrame:CGRectMake(0, topbar.bottom, self.view.width, heig)];
    topView.backgroundColor = ColorReset;
    [self.view addSubview:topView];
    
    downView = [[BasicScrollView alloc] initWithFrame:CGRectMake(0, topView.bottom, self.view.width, self.view.height-topView.bottom)];
    [self.view addSubview:downView];
    
    NSArray *arr = @[@"用户名",@"开户行",@"状态",@"操作",];
    CGFloat wid = self.view.width/arr.count;
    for (int i = 0; i < arr.count; i++) {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(wid*i, 0, wid, heig)];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = SystemFontBy4(13.0);
        label.text = arr[i];
        label.textColor = [UIColor whiteColor];
        [topView addSubview:label];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness getBankCardListBlock:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                data = [response dictionaryForKey:@"data"];
                bankcards = [data arrayForKey:@"aBankCards"];
                if (bankcards.count) { //有卡
                    currentBankIndex = -1;
                    [self buildHasCardUI];
                } else { //无卡
                    [self buildNoCardUI];
                }
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools alertWithTitle:str message:nil handle:^(UIAlertAction * _Nonnull action) {
                    [self.navigationController popViewControllerAnimated:YES];
                } cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求服务失败,请稍后再试."];
        }
    }];
}

/*构建没有银行卡的视图*/
- (void)buildNoCardUI {
    [downView removeAllSubviews];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.view.width, widthTo4_7(60))];
    label.text = @"您还没有提款银行卡。";
    label.textColor = ColorHex(0xaaaaaa);
    label.font = SystemFontBy4(13.6);
    label.textAlignment = NSTextAlignmentCenter;
    [downView addSubview:label];
    
    UIButton *bind = [[UIButton alloc] initWithFrame:CGRectMake(widthTo4_7(12), label.bottom, self.view.width-widthTo4_7(24), widthTo4_7(42))];
    [bind setTitle:@"添加银行卡" forState:0];
    [bind setTitleColor:[UIColor whiteColor] forState:0];
    bind.titleLabel.font = SystemFontBy4(14.6);
    bind.backgroundColor = ColorSubmit;
    bind.layer.cornerRadius = widthTo4_7(4);
    bind.layer.masksToBounds = YES;
    [downView addSubview:bind];
    [bind addTarget:self action:@selector(onBind:) forControlEvents:UIControlEventTouchUpInside];
}

/*构建有银行卡的视图*/
- (void)buildHasCardUI {
    [downView removeAllSubviews];
    NSInteger limitNum = [data integerForKey:@"iLimitCardsNum"];
    BOOL canBindMore = (limitNum > bankcards.count);
    CGFloat heig = widthTo4_7(56);
    NSArray *statusNames = @[@"未使用",@"使用中",@"已删除",@"黑名单",];
    CGFloat offY = 0;
    UIFont *font = SystemFontBy4(13.0);
    for (int i = 0; i < bankcards.count; i++) {
        NSDictionary *card = bankcards[i];
        UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0, offY, downView.width, heig)];
        button.tag = i;
        [button addTarget:self action:@selector(onBankcard:) forControlEvents:UIControlEventTouchUpInside];
        [downView addSubview:button];
        
        NSString *name = [card stringForKey:@"account_name"];
        NSString *bank = [card stringForKey:@"bank"];
        NSInteger sta = [card integerForKey:@"status"];
        NSString *status = statusNames[sta];
        
        UILabel *lbel0 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, button.width/4, button.height)];
        lbel0.textAlignment = NSTextAlignmentCenter;
        lbel0.font = font;
        lbel0.textColor = ColorHex(0x262626);
        lbel0.text = name;
        [button addSubview:lbel0];
        
        UILabel *lbel1 = [[UILabel alloc] initWithFrame:CGRectMake(button.width/4, 0, button.width/4, button.height)];
        lbel1.textAlignment = NSTextAlignmentCenter;
        lbel1.font = font;
        lbel1.textColor = ColorHex(0x262626);
        lbel1.text = bank;
        [button addSubview:lbel1];
        lbel1.left -= 0.05*button.width;
        lbel1.width += 0.1*button.width;
        
        UILabel *lbel2 = [[UILabel alloc] initWithFrame:CGRectMake(button.width/2, 0, button.width/4, button.height)];
        lbel2.textAlignment = NSTextAlignmentCenter;
        lbel2.font = font;
        lbel2.textColor = ColorHex(0x262626);
        lbel2.text = status;
        [button addSubview:lbel2];
        
        UIButton *modify = [[UIButton alloc] initWithFrame:CGRectMake(button.width/4*3, 0, button.width/8, button.height)];
        [modify setTitle:@"修改" forState:0];
        modify.tag = i;
        [modify setTitleColor:ColorHex(0x497bb2) forState:0];
        modify.titleLabel.font = font;
        [button addSubview:modify];
        [modify addTarget:self action:@selector(onModify:) forControlEvents:UIControlEventTouchUpInside];
        
        UIView *shu = [[UIView alloc] initWithFrame:CGRectMake(modify.right-widthTo4_7(0.6), (button.height-widthTo4_7(14))/2, widthTo4_7(1.2), widthTo4_7(14))];
        shu.backgroundColor = ColorHex(0x262626);
        [button addSubview:shu];
        
        UIButton *delete = [[UIButton alloc] initWithFrame:CGRectMake(button.width/8*7, 0, button.width/8, button.height)];
        [delete setTitle:@"删除" forState:0];
        delete.tag = i;
        [delete setTitleColor:ColorHex(0x497bb2) forState:0];
        delete.titleLabel.font = font;
        [button addSubview:delete];
        [delete addTarget:self action:@selector(onDelete:) forControlEvents:UIControlEventTouchUpInside];
        offY = button.bottom;
        
        if (i == currentBankIndex) {
            NSString *carNum = [card stringForKey:@"account"];
            if (carNum.length > 4) {
                carNum = [carNum substringFromIndex:carNum.length-4];
                carNum = [@"**** **** **** " stringByAppendingString:carNum];
            } else {
                carNum = @"****";
            }
            NSString *time = [card stringForKey:@"created_at"];
            
            UIView *kView = [[UIView alloc] initWithFrame:CGRectMake(0, offY, button.width, button.height)];
            kView.backgroundColor = ColorHex(0xf0f0f0);
            [downView addSubview:kView];
            
            UILabel *kahao = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(20), 0, kView.width, kView.height)];
            kahao.text = @"卡号:";
            kahao.textColor = lbel0.textColor;
            kahao.font = lbel0.font;
            [kView addSubview:kahao];
            
            UILabel *numm = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, kView.width-widthTo4_7(20), kView.height)];
            numm.text = carNum;
            numm.textColor = kahao.textColor;
            numm.font = kahao.font;
            numm.textAlignment = NSTextAlignmentRight;
            [kView addSubview:numm];
            
            UIView *tView = [[UIView alloc] initWithFrame:CGRectMake(0, kView.bottom+widthTo4_7(0.8), button.width, button.height)];
            tView.backgroundColor = ColorHex(0xf0f0f0);
            [downView addSubview:tView];
            
            UILabel *bshi = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(20), 0, kView.width, kView.height)];
            bshi.text = @"绑定时间:";
            bshi.textColor = lbel0.textColor;
            bshi.font = lbel0.font;
            [tView addSubview:bshi];
            
            UILabel *tttt = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, kView.width-widthTo4_7(20), kView.height)];
            tttt.text = time;
            tttt.textColor = kahao.textColor;
            tttt.font = kahao.font;
            tttt.textAlignment = NSTextAlignmentRight;
            [tView addSubview:tttt];
            
            offY = tView.bottom;
        }
        
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, offY, downView.width, widthTo4_7(1.0))];
        line.backgroundColor = LineColor;
        [downView addSubview: line];
        offY = line.bottom;
    }
    
    if (canBindMore) {
        UIButton *bind = [[UIButton alloc] initWithFrame:CGRectMake(widthTo4_7(12), offY + widthTo4_7(44), self.view.width-widthTo4_7(24), widthTo4_7(42))];
        bind.tag = 110;
        [bind setTitle:@"添加银行卡" forState:0];
        [bind setTitleColor:[UIColor whiteColor] forState:0];
        bind.titleLabel.font = SystemFontBy4(14.6);
        bind.backgroundColor = ColorSubmit;
        bind.layer.cornerRadius = widthTo4_7(4);
        bind.layer.masksToBounds = YES;
        [downView addSubview:bind];
        [bind addTarget:self action:@selector(onBind:) forControlEvents:UIControlEventTouchUpInside];
        offY = bind.bottom;
    }
    
    NSString *limit = [NSString stringWithFormat:@"%li",limitNum];
    NSString *alread = [NSString stringWithFormat:@"%li",bankcards.count];
    NSString *left = [NSString stringWithFormat:@"%li",(limitNum-bankcards.count)];
    
    NSString *text = [NSString stringWithFormat:@"一个账号最多可以绑定 %@ 张银行卡，您目前绑定了 %@ 张卡，还可以绑定 %@ 张。\n银行卡信息在绑定后,不能修改和删除。",limit,alread,left];
    NSMutableAttributedString *mstr = [[NSMutableAttributedString alloc] initWithString:text];
    [mstr setFont:SystemFontBy4(12) inRange:NSMakeRange(0, text.length)];
    [mstr setForegroundColor:ColorHex(0xff0000) inRange:NSMakeRange(0, text.length)];
    [mstr setForegroundColor:ColorHex(0xff00ff) inRange:[text rangeOfString:limit]];
    [mstr setForegroundColor:ColorHex(0xff00ff) inRange:[text rangeOfString:alread options:NSBackwardsSearch]];
    [mstr setForegroundColor:ColorHex(0xff00ff) inRange:[text rangeOfString:left options:NSBackwardsSearch]];
    
    UILabel *message = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(20), offY + widthTo4_7(26), downView.width-widthTo4_7(40), widthTo4_7(66))];
    message.numberOfLines = 0;
    message.attributedText = mstr;
    [downView addSubview:message];
    offY = message.bottom;
    
    downView.contentSize = CGSizeMake(downView.width, offY);
}

- (void)onBankcard:(UIButton *)button {
    if (((int)button.tag) == currentBankIndex) {
        currentBankIndex = -1;
    } else {
        currentBankIndex = (int)(button.tag);
    }
    [self buildHasCardUI];
}

- (void)onModify:(UIButton *)button {
    VerifyBankCardViewController *verify = [[VerifyBankCardViewController alloc] init];
    verify.verifyType = 1;
    verify.bankcards = bankcards;
    verify.bankcardsIndex = button.tag;
    [self.navigationController pushViewController:verify animated:YES];
}

- (void)onDelete:(UIButton *)button {
    
    VerifyBankCardViewController *verify = [[VerifyBankCardViewController alloc] init];
    verify.verifyType = 2;
    verify.bankcards = bankcards;
    verify.bankcardsIndex = button.tag;
    [self.navigationController pushViewController:verify animated:YES];
}


- (void)onBind:(UIButton *)button {
    if (button.tag == 110) {
        VerifyBankCardViewController *verify = [[VerifyBankCardViewController alloc] init];
        verify.verifyType = 0;
        verify.bankcards = bankcards;
        [self.navigationController pushViewController:verify animated:YES];
    } else {
        BOOL fundExist = [[Singleton shared].loginDict boolForKey:@"fund_password_exist"];
        if (fundExist) {
            BOOL realNameExist = ([[Singleton shared].loginDict stringForKey:@"name"].length > 1);
            if (realNameExist) {
                BindCardViewController *bind = [[BindCardViewController alloc] init];
                [self.navigationController pushViewController:bind animated:YES];
            } else {
                UserDetailViewController *user = [[UserDetailViewController alloc] init];
                user.isBindBankCard = YES;
                [user setupShowWarn:YES];
                [self.navigationController pushViewController:user animated:YES];
            }
        } else {
            ModifyFundPassViewController *bind = [[ModifyFundPassViewController alloc] init];
            bind.isBindBankCard = YES;
            [self.navigationController pushViewController:bind animated:YES];
        }
    }
}
@end
