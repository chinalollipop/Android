//
//  ModifyCardConfirmViewController.h
//  CpNative
//
//  Created by david on 2019/3/6.
//  Copyright © 2019 david. All rights reserved.
//

#import "BasicWithNaviBarViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ModifyCardConfirmViewController : BasicWithNaviBarViewController

@property(nonatomic, copy) NSString *_id;
@property(nonatomic, copy) NSString *bank;
@property(nonatomic, copy) NSString *bankId;
@property(nonatomic, copy) NSString *branch;
@property(nonatomic, copy) NSString *name;
@property(nonatomic, copy) NSString *account;

@end

NS_ASSUME_NONNULL_END
