//
//  ModifyCardConfirmViewController.m
//  CpNative
//
//  Created by david on 2019/3/6.
//  Copyright © 2019 david. All rights reserved.
//

#import "ModifyCardConfirmViewController.h"

@interface ModifyCardConfirmViewController ()

@end

@implementation ModifyCardConfirmViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    topbar.titleLabel.text = @"提交修改";
    
    CGFloat left = widthTo4_7(12);
    CGFloat top = topbar.bottom+widthTo4_7(20);
    CGFloat height = widthTo4_7(52);
    UIFont *font = SystemFontBy4(14.6);
    UIColor *color = ColorHex(0x161616);
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(left, top, 400, height)];
    label.text = @"开户行:";
    label.textColor = color;
    label.font = font;
    [self.view addSubview:label];
    top = label.bottom;
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(0.38*self.view.width, label.top, 400, height)];
    label.text = _bank;
    label.textColor = color;
    label.font = font;
    [self.view addSubview:label];
    top = label.bottom;
    
    
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left, top, 400, height)];
    label.text = @"支行名称:";
    label.textColor = color;
    label.font = font;
    [self.view addSubview:label];
    top = label.bottom;
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(0.38*self.view.width, label.top, 400, height)];
    label.text = _branch;
    label.textColor = color;
    label.font = font;
    [self.view addSubview:label];
    top = label.bottom;
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left, top, 400, height)];
    label.text = @"开户人姓名:";
    label.textColor = color;
    label.font = font;
    [self.view addSubview:label];
    top = label.bottom;
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(0.38*self.view.width, label.top, 400, height)];
    label.text = _name;
    label.textColor = color;
    label.font = font;
    [self.view addSubview:label];
    top = label.bottom;
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left, top, 400, height)];
    label.text = @"账号号码:";
    label.textColor = color;
    label.font = font;
    [self.view addSubview:label];
    top = label.bottom;
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(0.38*self.view.width, label.top, 400, height)];
    label.text = _account;
    label.textColor = color;
    label.font = font;
    [self.view addSubview:label];
    top = label.bottom;
    
    CGFloat heig = widthTo4_7(44);
    CGFloat gap = left;
    UIButton *submit = [[UIButton alloc] initWithFrame:CGRectMake(gap, top+height*0.3, (self.view.width-gap*3)/2, heig)];
    [submit setTitle:@"确认提交" forState:0];
    [submit setTitleColor:ColorHex(0xffffff) forState:0];
    submit.titleLabel.font = SystemFontBy4(14.6);
    submit.backgroundColor = ColorSubmit;
    submit.layer.cornerRadius = 0.1*heig;
    submit.layer.masksToBounds = YES;
    [submit addTarget:self action:@selector(onSubmit) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:submit];
    
    UIButton *reset = [[UIButton alloc] initWithFrame:CGRectMake(submit.right+gap, submit.top, (self.view.width-gap*3)/2, heig)];
    [reset setTitle:@"返回修改" forState:0];
    [reset setTitleColor:ColorHex(0xffffff) forState:0];
    reset.titleLabel.font = SystemFontBy4(14.6);
    reset.backgroundColor = ColorHex(0x444443);
    reset.layer.cornerRadius = 0.1*heig;
    reset.layer.masksToBounds = YES;
    [reset addTarget:self action:@selector(onReset) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:reset];
    
    
}

- (void)onSubmit {
    [MBProgressHUD showHUDAddedTo:mainDelegate.window animated:NO];
    [NetworkBusiness modifySubmitForId:__id bank:_bank bankId:_bankId branch:_branch name:_name account:_account Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:mainDelegate.window animated:NO];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                
                [Tools alertWithTitle:@"银行卡已修改成功!" message:nil handle:^(UIAlertAction * _Nonnull action) {
                    UIViewController *controller = nil;
                    for (UIViewController *con in self.navigationController.viewControllers) {
                        if ([con isKindOfClass:NSClassFromString(@"BankCardViewController")]) {
                            controller = con;
                            break;
                        }
                    }
                    if (controller) {
                        [self.navigationController popToViewController:controller animated:YES];
                    } else {
                        [self.navigationController popToRootViewControllerAnimated:YES];
                    }
                } cancel:nil confirm:@"返回"];

                //修改成功之后，要清缓存
                [NetworkBusiness modifyCleanCacheForId:__id Block:^(NSError *error, int code, id response) {
                    
                }];
                
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"提交失败";
                }
                [Tools alertWithTitle:str message:nil handle:nil cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求失败,请稍后再试."];
        }
    }];
    
    
    
}

- (void)onReset {
    [self.navigationController popViewControllerAnimated:YES];
}
@end
