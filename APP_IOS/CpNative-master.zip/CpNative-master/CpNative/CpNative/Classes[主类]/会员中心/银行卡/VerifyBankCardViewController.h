//
//  VerifyBankCardViewController.h
//  CpNative
//
//  Created by david on 2019/3/6.
//  Copyright © 2019 david. All rights reserved.
//

#import "BasicWithNaviBarViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface VerifyBankCardViewController : BasicWithNaviBarViewController

@property(nonatomic, assign) NSInteger verifyType;//0添加更多银行卡  1修改银行卡  2删除银行卡

@property(nonatomic, strong) NSArray *bankcards;
@property(nonatomic, assign) NSInteger bankcardsIndex;

@end

NS_ASSUME_NONNULL_END
