//
//  BindCardViewController.m
//  CpNative
//
//  Created by david on 2019/2/18.
//  Copyright © 2019 david. All rights reserved.
//

#import "BindCardViewController.h"
#import "BindCardViewControllerNext.h"

@interface BindCardViewController ()<UITextFieldDelegate>

@end

@implementation BindCardViewController {
    NSArray *banks;
    CGFloat lineHeight;
    CGFloat beginLeft;
    
    IQPreviousNextView *iqView;
    UILabel *typeLabel;
    NSInteger selectedTypeIndex;
    UITextField *tfBankName;//支行名称
    UITextField *tfName;//开户人姓名
    UITextField *tfAccount;//银行账号
    UITextField *tfAccount2;//确认银行账号
    __block NSMutableArray *types;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    topbar.titleLabel.text = @"添加银行卡";
    
    selectedTypeIndex = -1;
    [self request];
}

- (void)request {
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness getBankNameListBlock:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                NSDictionary *data = [response dictionaryForKey:@"data"];
                banks = [data arrayForKey:@"aBanks"];
                [self setUI];
            } else {
                NSString *s = [response stringForKey:@"error"];
                if (!s.length) {
                    s = @"请求出错,请稍后再试.";
                }
                [Tools alertWithTitle:s message:nil handle:^(UIAlertAction * _Nonnull action) {
                    [self.navigationController popViewControllerAnimated:YES];
                } cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求服务失败,请稍后再试."];
        }
    }];
}

- (void)setUI {
    lineHeight = widthTo4_7(56);
    beginLeft = 0.35*self.view.width;
    CGFloat offY = topbar.bottom;
    [self.view addSubview:[self typeLabelWithText:@"开户银行:" y:offY]];
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(beginLeft, offY, self.view.width-beginLeft, lineHeight)];
    [btn addTarget:self action:@selector(onTypeSelect) forControlEvents:UIControlEventTouchUpInside];
    btn.backgroundColor = ColorHex(0xeaeaea);
    btn.layer.cornerRadius = 0.09*btn.height;
    btn.layer.masksToBounds = YES;
    [self.view addSubview:btn];
    btn.top += widthTo4_7(6);
    btn.height -= widthTo4_7(12);
    btn.width -= widthTo4_7(6);
    typeLabel = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(10), 0, 180, btn.height)];
    typeLabel.font = SystemFontBy4(14.6);
    typeLabel.textColor = ColorHex(0x262626);
    typeLabel.text = @"请选择开户银行";
    [btn addSubview:typeLabel];
    UILabel *draw1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, btn.height*1.0, btn.height)];
    draw1.font = FontForSize(17);
    draw1.text = Down_Arrow;
    draw1.textColor = ColorHex(0x161616);
    [btn addSubview:draw1];
    draw1.textAlignment = NSTextAlignmentCenter;
    draw1.right = btn.width;
    offY += lineHeight;
    
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, offY, self.view.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [self.view addSubview:line];
    offY = line.bottom;
    
    iqView = [[IQPreviousNextView alloc] initWithFrame:CGRectMake(0, offY, self.view.width, lineHeight*4+4.0)];
    [self.view addSubview:iqView];
    offY = iqView.bottom;
    
    //支行名称
    [iqView addSubview:[self typeLabelWithText:@"支行名称:" y:0]];
    tfBankName = [[UITextField alloc] initWithFrame:CGRectMake(beginLeft, 0, self.view.width-beginLeft-widthTo4_7(5), lineHeight)];
    tfBankName.clearButtonMode = UITextFieldViewModeWhileEditing;
    tfBankName.textColor = ColorHex(0x262626);
    tfBankName.font = SystemFontBy4(14.6);
    tfBankName.placeholder = @"请输入支行名称";
    [iqView addSubview:tfBankName];
    line = [[UIView alloc] initWithFrame:CGRectMake(0, lineHeight, self.view.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [iqView addSubview:line];
    
    //开户人姓名
    [iqView addSubview:[self typeLabelWithText:@"开户人姓名:" y:line.bottom]];
    tfName = [[UITextField alloc] initWithFrame:CGRectMake(beginLeft, line.bottom, self.view.width-beginLeft-widthTo4_7(5), lineHeight)];
    tfName.clearButtonMode = UITextFieldViewModeWhileEditing;
    tfName.textColor = ColorHex(0x262626);
    tfName.font = SystemFontBy4(14.6);
    tfName.placeholder = @"请输入开户人姓名";
    [iqView addSubview:tfName];
    line = [[UIView alloc] initWithFrame:CGRectMake(0, tfName.bottom, self.view.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [iqView addSubview:line];
    
    //银行账号
    [iqView addSubview:[self typeLabelWithText:@"银行账号:" y:line.bottom]];
    tfAccount = [[UITextField alloc] initWithFrame:CGRectMake(beginLeft, line.bottom, self.view.width-beginLeft-widthTo4_7(5), lineHeight)];
    tfAccount.clearButtonMode = UITextFieldViewModeWhileEditing;
    tfAccount.textColor = ColorHex(0x262626);
    tfAccount.font = SystemFontBy4(14.6);
    tfAccount.placeholder = @"请输入银行账号";
    tfAccount.delegate = self;
    [iqView addSubview:tfAccount];
    line = [[UIView alloc] initWithFrame:CGRectMake(0, tfAccount.bottom, self.view.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [iqView addSubview:line];
    
    //确认银行账号
    [iqView addSubview:[self typeLabelWithText:@"确认银行账号:" y:line.bottom]];
    tfAccount2 = [[UITextField alloc] initWithFrame:CGRectMake(beginLeft, line.bottom, self.view.width-beginLeft-widthTo4_7(5), lineHeight)];
    tfAccount2.clearButtonMode = UITextFieldViewModeWhileEditing;
    tfAccount2.textColor = ColorHex(0x262626);
    tfAccount2.font = SystemFontBy4(14.6);
    tfAccount2.placeholder = @"请再次输入银行账号";
    tfAccount2.delegate = self;
    [iqView addSubview:tfAccount2];
    line = [[UIView alloc] initWithFrame:CGRectMake(0, tfAccount2.bottom, self.view.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [iqView addSubview:line];
    
    CGFloat heig = widthTo4_7(44);
    CGFloat gap = 0.04*self.view.width;
    UIButton *submit = [[UIButton alloc] initWithFrame:CGRectMake(gap, offY+lineHeight*0.72, (self.view.width-gap*3)/2, heig)];
    [submit setTitle:@"下一步" forState:0];
    [submit setTitleColor:ColorHex(0xffffff) forState:0];
    submit.titleLabel.font = SystemFontBy4(14.6);
    submit.backgroundColor = ColorSubmit;
    submit.layer.cornerRadius = 0.1*heig;
    submit.layer.masksToBounds = YES;
    [submit addTarget:self action:@selector(onSubmit) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:submit];
    
    UIButton *reset = [[UIButton alloc] initWithFrame:CGRectMake(submit.right+gap, submit.top, (self.view.width-gap*3)/2, heig)];
    [reset setTitle:@"重置" forState:0];
    [reset setTitleColor:ColorHex(0xffffff) forState:0];
    reset.titleLabel.font = SystemFontBy4(14.6);
    reset.backgroundColor = ColorReset;
    reset.layer.cornerRadius = 0.1*heig;
    reset.layer.masksToBounds = YES;
    [reset addTarget:self action:@selector(onReset) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:reset];
}

- (void)onSubmit {
    if (selectedTypeIndex < 0) {
        [Tools showText:@"请选择开户银行"];
        return;
    }
    if (tfBankName.text.length < 1) {
        [Tools showText:@"请输入支行名称"];
        return;
    }
    if (tfName.text.length < 1) {
        [Tools showText:@"请输入开户人姓名"];
        return;
    }
    
    NSString *account = [tfAccount.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSString *account2 = [tfAccount2.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    if (account.length < 1) {
        [Tools showText:@"请输入银行账号"];
        return;
    }
    if (account2.length < 1) {
        [Tools showText:@"请再次输入银行账号"];
        return;
    }
    if (![account isEqualToString:account2]) {
        [Tools showText:@"两次输入的账号不一致"];
        return;
    }
    
    NSDictionary *dict = banks[selectedTypeIndex];
    NSString *_id = [dict stringForKey:@"id"];
    [MBProgressHUD showHUDAddedTo:mainDelegate.window animated:NO];
    [NetworkBusiness verifyBankCard:typeLabel.text bankId:_id branch:tfBankName.text name:tfName.text account:account Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:mainDelegate.window animated:NO];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            NSString *errstr = [response stringForKey:@"error"];
            if (err == 0) {
                BindCardViewControllerNext *next = [[BindCardViewControllerNext alloc] init];
                next.bank = typeLabel.text;
                next._id = _id;
                next.branch = tfBankName.text;
                next.name = tfName.text;
                next.account = tfAccount.text;
                [self.navigationController pushViewController:next animated:YES];
            } else {
                [Tools alertWithTitle:errstr message:nil handle:nil cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求服务失败,请稍后再试."];
        }
    }];
    
}

- (void)onReset {
    selectedTypeIndex = -1;
    typeLabel.text = @"请选择开户银行";
    tfBankName.text = @"";
    tfName.text = @"";
    tfAccount.text = @"";
    tfAccount2.text = @"";
}

/*选择开户银行*/
- (void)onTypeSelect {
    if (!types) {
        types = [[NSMutableArray alloc] init];
        for (int i = 0; i < banks.count; i++) {
            NSDictionary *dict = banks[i];
            NSString *name = [dict stringForKey:@"name"];
            [types safeAddObject:(name?:@"")];
        }
    }
    
    if (!types.count) {
        return;
    }

    NSInteger scrollIndex = selectedTypeIndex;
    if (scrollIndex < 0) {
        scrollIndex = 0;
    }
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    WSDatePickerView *datepicker = [[WSDatePickerView alloc] initWithDateStyle:DateStyleShowBank data:types scrollToIndex:scrollIndex CompleteBlock:^(NSInteger tag, BOOL cancel) {
        if (cancel) {
            NSLog(@"CANCEL.....");
        } else {
            selectedTypeIndex = tag;
            NSString *title = types[selectedTypeIndex];
            typeLabel.text = title;
        }
    }];
    
    datepicker.dateLabelColor = ColorHex(0xff5733);//年-月-日-时-分 颜色
    datepicker.datePickerColor = ColorHex(0x286be8);//滚轮日期颜色
    datepicker.doneButtonColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;//确定按钮的颜色
    [datepicker setHideBackgroundYearLabel:YES];
    [datepicker show];
}



- (UILabel *)typeLabelWithText:(NSString *)text y:(CGFloat)y {
    UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(8), y, 120, lineHeight)];
    lbl.font = SystemFontBy4(14.6);
    lbl.textColor = ColorHex(0x262626);
    lbl.text = text;
    return lbl;
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString *value = [textField.text stringByReplacingCharactersInRange:range withString:string];
    textField.text = [Tools addBlankForBankCarNum:value];
    return NO;
}






@end
