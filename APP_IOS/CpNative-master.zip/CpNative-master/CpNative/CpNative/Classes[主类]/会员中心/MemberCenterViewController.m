//
//  MemberCenterViewController.m
//  CpNative
//
//  Created by david on 2019/3/16.
//  Copyright © 2019 david. All rights reserved.
//

#import "MemberCenterViewController.h"
#import "RegisterManageViewController.h"
#import "LoginViewController.h"
#import "PayViewController.h"
#import "WithdrawViewController.h"
#import "GameRecordViewController.h"
#import "FollowNumViewController.h"
#import "PersonalChartViewController.h"
#import "TeamChartViewController.h"
#import "BillSummaryViewController.h"
#import "ChargeAndWithdrawViewController.h"
#import "CouponViewController.h"
#import "UserDetailViewController.h"
#import "BankCardViewController.h"
#import "ModifyLoginPassViewController.h"
#import "ModifyFundPassViewController.h"
#import "LotteryInfoViewController.h"
#import "LotteryResultViewController.h"
#import "UserListViewController.h"
#import "MessageBoxViewController.h"
#import "TGViewController.h"

@interface MemberCenterViewController ()

@end

@implementation MemberCenterViewController {
    UILabel *page4nameMoney;
    BasicScrollView *page4Scroll;
    UIButton *page4registManage;//注册管理
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self updateBalance];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onNoti_MemberCenterShouldRenewBalance) name:Noti_MemberCenterShouldRenewBalance object:nil];
}

/*此时需要刷新余额，一般是从开元等平台中退出后，需要更新账变*/
- (void)onNoti_MemberCenterShouldRenewBalance {
    [self updateBalance];
}

- (void)updateBalance {
    NSLog(@"刷新会员中心余额。");
    
    if ([Singleton shared].loginState == LoginStateNone) {
        return;
    }
    
    [NetworkBusiness getUserBalanceBlock:^(NSError *error, int code, id response) {
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:nil]) {
            return;
        }
        
        if (code == 200) {
            NSDictionary *data = [response dictionaryForKey:@"data"];
            NSString *balance = [data stringForKey:@"available"];
            [Singleton shared].balance = balance;
            [self setMoney];
        }
    }];
}

- (void)setupUI {
    UIImageView *page4topbg = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.view.width, widthTo4_7((ScreenX?(226):(200))))];
    page4topbg.image = [UIImage imageNamed:@"centrebg"];
    page4topbg.userInteractionEnabled = YES;
    [self.view addSubview:page4topbg];
    
    page4registManage = [[UIButton alloc] initWithFrame:CGRectMake(0.09*page4topbg.width, widthTo4_7((ScreenX?(82):(60))), 0.17*page4topbg.width, widthTo4_7(68))];
    [page4registManage addTarget:self action:@selector(onPage4Register) forControlEvents:UIControlEventTouchUpInside];
    [page4topbg addSubview:page4registManage];
    UIImageView *reimg = [[UIImageView alloc] initWithFrame:CGRectMake(0.25*page4registManage.width, 0, 0.5*page4registManage.width, 0.5*page4registManage.width)];
    reimg.image = [UIImage imageNamed:@"c24"];
    [page4registManage addSubview:reimg];
    UILabel *relab = [[UILabel alloc] initWithFrame:CGRectMake(0, page4registManage.height-0.8*page4registManage.width, page4registManage.width, page4registManage.height-(page4registManage.height-0.8*page4registManage.width))];
    relab.textAlignment = NSTextAlignmentCenter;
    relab.text = @"注册管理";
    relab.font = SystemFontBy4(11.4);
    relab.textColor = ColorHex(0xffffff);
    [page4registManage addSubview:relab];
    
    //logo
    UIImage *imglogo = [UIImage imageNamed:@"logo"];
    CGFloat imgwid = widthTo4_7(90);
    CGFloat imgheig = imglogo.size.height/imglogo.size.width*imgwid;
    UIImageView *logo = [[UIImageView alloc] initWithFrame:CGRectMake((self.view.width-imgwid)/2, widthTo4_7((ScreenX?(62):(40))), imgwid, imgheig)];
    [page4topbg addSubview:logo];
    logo.image = imglogo;
    
    page4nameMoney = [[UILabel alloc] initWithFrame:CGRectMake(0, logo.bottom+widthTo4_7((ScreenX?(2.2):(0))), page4topbg.width, widthTo4_7(36))];
    page4nameMoney.textAlignment = NSTextAlignmentCenter;
    page4nameMoney.font = SystemFontBy4(12.6);
    page4nameMoney.textColor = ColorHex(0xffffff);
    [page4topbg addSubview:page4nameMoney];
    [self setPage4Name:@"test123" money:@"123.05"];
    
    //退出登录
    UIButton *page4quitBtn = [[UIButton alloc] initWithFrame:CGRectMake(0.74*page4topbg.width, page4registManage.top, 0.17*page4topbg.width, widthTo4_7(68))];
    [page4quitBtn addTarget:self action:@selector(onPage4Quit) forControlEvents:UIControlEventTouchUpInside];
    [page4topbg addSubview:page4quitBtn];
    UIImageView *requit = [[UIImageView alloc] initWithFrame:CGRectMake(0.25*page4quitBtn.width, 0, 0.5*page4quitBtn.width, 0.5*page4quitBtn.width)];
    requit.image = [UIImage imageNamed:@"c23"];
    [page4quitBtn addSubview:requit];
    UILabel *quitlab = [[UILabel alloc] initWithFrame:CGRectMake(0, page4quitBtn.height-0.8*page4quitBtn.width, page4quitBtn.width, page4quitBtn.height-(page4quitBtn.height-0.8*page4quitBtn.width))];
    quitlab.textAlignment = NSTextAlignmentCenter;
    quitlab.text = @"退出登录";
    quitlab.font = SystemFontBy4(11.4);
    quitlab.textColor = ColorHex(0xffffff);
    [page4quitBtn addSubview:quitlab];
    
    CGFloat chargeButtonHeight = widthTo4_7(40);//充值、提现的按钮高度
    
    //版本号
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];//app版本号 Version
    NSString *build = [infoDictionary objectForKey:@"CFBundleVersion"];//app的build号
    if (Environment == 1) {//如果是线上环境，则显示0，以便知道是什么环境
        build = @"0";
    }
    NSString *showVersion = [NSString stringWithFormat:@"v%@(%@)",version,build];
    UILabel *versionLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, page4topbg.height-widthTo4_7(25)-chargeButtonHeight, 0.972*page4topbg.width, widthTo4_7(25))];
    versionLabel.text = showVersion;
    versionLabel.textAlignment = NSTextAlignmentRight;
    versionLabel.textColor = ColorHex(0xffffff);
    versionLabel.font = SystemFontBy4(9);
    [page4topbg addSubview:versionLabel];
    
    //充值、提现
    UIButton *page4charge = [[UIButton alloc] initWithFrame:CGRectMake(0, page4topbg.height-chargeButtonHeight, 0.5*page4topbg.width-0.6, chargeButtonHeight)];
    page4charge.backgroundColor = ColorHexWithAlpha(0x000000, 0.44);
    [page4charge addTarget:self action:@selector(onPage4Charge) forControlEvents:UIControlEventTouchUpInside];
    [page4topbg addSubview:page4charge];
    UIImageView *charImgv = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 0.6*page4charge.height, 0.6*page4charge.height)];
    charImgv.image = [UIImage imageNamed:@"p4charge"];
    [page4charge addSubview:charImgv];
    UILabel *charlab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, widthTo4_7(60), page4charge.height)];
    charlab.text = @"充值";
    charlab.textColor = ColorHex(0xffffff);
    charlab.textAlignment = NSTextAlignmentCenter;
    charlab.font = SystemFontBy4(12);
    [page4charge addSubview:charlab];
    charImgv.center = CGPointMake(0.4*page4charge.width, 0.5*page4charge.height);
    charlab.center = CGPointMake(0.6*page4charge.width, 0.5*page4charge.height);
    
    UIButton *page4tixian = [[UIButton alloc] initWithFrame:CGRectMake(0.5*page4topbg.width+0.6, page4topbg.height-chargeButtonHeight, 0.5*page4topbg.width-0.6, chargeButtonHeight)];
    page4tixian.backgroundColor = ColorHexWithAlpha(0x000000, 0.44);
    [page4tixian addTarget:self action:@selector(onPage4Tixian) forControlEvents:UIControlEventTouchUpInside];
    [page4topbg addSubview:page4tixian];
    UIImageView *tixianImgv = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 0.6*page4charge.height, 0.6*page4charge.height)];
    tixianImgv.image = [UIImage imageNamed:@"p4tixian"];
    [page4tixian addSubview:tixianImgv];
    UILabel *tixianlab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, widthTo4_7(60), page4charge.height)];
    tixianlab.text = @"提现";
    tixianlab.textColor = ColorHex(0xffffff);
    tixianlab.textAlignment = NSTextAlignmentCenter;
    tixianlab.font = SystemFontBy4(12);
    [page4tixian addSubview:tixianlab];
    tixianImgv.center = CGPointMake(0.4*page4charge.width, 0.47*page4charge.height);
    tixianlab.center = CGPointMake(0.6*page4charge.width, 0.5*page4charge.height);
    
    page4Scroll = [[BasicScrollView alloc] initWithFrame:CGRectMake(0, page4topbg.bottom, self.view.width, self.view.height-page4topbg.height)];
    [self.view addSubview:page4Scroll];
}

- (void)setPage4Name:(NSString *)name money:(NSString *)money {
    if (!money || !money.length) {
        return;
    }
    page4nameMoney.text = [NSString stringWithFormat:@"%@  余额 %@ 元",name,money];
}

#pragma mark page4会员中心页面相关按钮
- (void)onPage4Register {//注册管理
    RegisterManageViewController *manage = [[RegisterManageViewController alloc] init];
    [self.navigationController pushViewController:manage animated:YES];
}
- (void)onPage4Quit {
    [Tools alertWithTitle:@"退出当前账号" message:nil handle:^(UIAlertAction * _Nonnull action) {
        [MBProgressHUD showHUDAddedTo:mainDelegate.window animated:NO];
        [Singleton shared].loginState = LoginStateNone;
        runBlockAfter(0.3, ^{
            [MBProgressHUD hideHUDForView:mainDelegate.window animated:NO];
            LoginViewController *login = [[LoginViewController alloc] init];
            [self.navigationController pushViewController:login animated:YES];
            [Tools showText:@"你已退出当前账号"];
        });
    } cancel:@"取消" confirm:@"退出"];
}
- (void)onPage4Charge {
    NSLog(@"点击了会员中心充值按钮");
    if ([Singleton shared].loginState == LoginStateShiwan) {
        [Tools showText:@"试玩账户不能充值"];
        return;
    }
    PayViewController *pay = [[PayViewController alloc] init];
    [self.navigationController pushViewController:pay animated:YES];
}
- (void)onPage4Tixian {
    NSLog(@"点击了会员中心提现按钮");
    if ([Singleton shared].loginState == LoginStateShiwan) {
        [Tools showText:@"试玩账户不能提现"];
        return;
    }
    BOOL fundPassExist = [[Singleton shared].loginDict boolForKey:@"fund_password_exist"];
    if (!fundPassExist) {
        ModifyFundPassViewController *fun = [[ModifyFundPassViewController alloc] init];
        [self.navigationController pushViewController:fun animated:YES];
        return;
    }
    WithdrawViewController *pay = [[WithdrawViewController alloc] init];
    [self.navigationController pushViewController:pay animated:YES];
}
- (void)onPage4Button:(UIButton *)button {
    NSLog(@"点击了Page4按钮:%li",(long)button.tag);
    
    BOOL isAgent = [[Singleton shared].loginDict boolForKey:@"is_agent"];
    UIViewController *vc;
    if (button.tag == 0) {
        vc = [[GameRecordViewController alloc] init];
    } else
    if (button.tag == 1) {
        vc = [[FollowNumViewController alloc] init];
    } else
    if (button.tag == 2) {
        vc = [[PersonalChartViewController alloc] init];
    } else
    if (button.tag == 3) {
        if (isAgent) {
            vc = [[TeamChartViewController alloc] init];
        } else {
            vc = [[BillSummaryViewController alloc] init];
        }
    } else
    if (button.tag == 4) {
        if (isAgent) {
            vc = [[BillSummaryViewController alloc] init];
        } else {
            vc = [[ChargeAndWithdrawViewController alloc] init];
        }
    } else
    if (button.tag == 5) {
        if (isAgent) {
            vc = [[ChargeAndWithdrawViewController alloc] init];
        } else {
            CouponViewController *vv = [[CouponViewController alloc] init];
            vv.initRefresh = YES;
            vc = vv;
        }
    } else
    if (button.tag == 6) {
        if (isAgent) {
            CouponViewController *vv = [[CouponViewController alloc] init];
            vv.initRefresh = YES;
            vc = vv;
        } else {
            UserDetailViewController *vv = [[UserDetailViewController alloc] init];
            [vv setupShowWarn:NO];
            vc = vv;
        }
        
    } else
    if (button.tag == 7) {
        if (isAgent) {
            UserDetailViewController *vv = [[UserDetailViewController alloc] init];
            [vv setupShowWarn:NO];
            vc = vv;
        } else {
           vc = [[BankCardViewController alloc] init];
        }
    } else
    if (button.tag == 8) {
        if (isAgent) {
            vc = [[BankCardViewController alloc] init];
        } else {
            vc = [[ModifyLoginPassViewController alloc] init];
        }
    } else
    if (button.tag == 9) {
        if (isAgent) {
            vc = [[ModifyLoginPassViewController alloc] init];
        } else {
            vc = [[ModifyFundPassViewController alloc] init];
        }
    } else
    if (button.tag == 10) {
        if (isAgent) {
            vc = [[ModifyFundPassViewController alloc] init];
        } else {
            LotteryInfoViewController *viewcontroller = [[LotteryInfoViewController alloc] init];
            viewcontroller.myTitle = @"彩种信息";
            vc = viewcontroller;
        }
    } else
    if (button.tag == 11) {
        if (isAgent) {
            LotteryInfoViewController *viewcontroller = [[LotteryInfoViewController alloc] init];
            viewcontroller.myTitle = @"彩种信息";
            vc = viewcontroller;
        } else {
            vc = [[LotteryResultViewController alloc] init];
        }
    } else
    if (button.tag == 12) {
        if (isAgent) {
            vc = [[LotteryResultViewController alloc] init];
        } else {
            LotteryResultViewController *lotteryResult = [[LotteryResultViewController alloc] init];
            lotteryResult.initShowZoushi = YES;//是否进入后显示走势图
            vc = lotteryResult;
        }
    } else
    if (button.tag == 13) {
        if (isAgent) {
            LotteryResultViewController *lotteryResult = [[LotteryResultViewController alloc] init];
            lotteryResult.initShowZoushi = YES;//是否进入后显示走势图
            vc = lotteryResult;
        } else {
            vc = [[MessageBoxViewController alloc] init];
        }
    } else
    if (button.tag == 14) {
        if (isAgent) {
            vc = [[UserListViewController alloc] init];
        } else {
            [[NSNotificationCenter defaultCenter] postNotificationName:Noti_ShowNotices object:nil];
        }
    } else
    if (button.tag == 15) {
        vc = [[TGViewController alloc] init];
    } else
    if (button.tag == 16) {
        vc = [[MessageBoxViewController alloc] init];
    } else
    if (button.tag == 17) {
        [[NSNotificationCenter defaultCenter] postNotificationName:Noti_ShowNotices object:nil];
    }
    
    if (vc) {
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (void)updateStates {
    [self setMoney];
    BOOL isAgent = [[Singleton shared].loginDict boolForKey:@"is_agent"];
    page4registManage.hidden = !(isAgent);
    
    [page4Scroll removeAllSubviews];
    NSArray *names;
    NSArray *images;
    if (isAgent) {
        names = @[@"游戏记录",@"追号记录",@"个人报表",@"团队报表",@"账单报表",@"充提记录",@"优惠活动",@"用户资料",@"银行卡",@"修改登录密码",@"修改资金密码",@"彩种信息",@"开奖结果",@"走势图",@"用户列表",@"推广链接",@"站内信",@"网站公告",];
        images = @[@"p41",@"p42",@"p43",@"p44",@"p45",@"p46",@"p47",@"p48",@"p49",@"p410",@"p411",@"p412",@"p413",@"p414",@"p415",@"p416",@"p417",@"p418",@"p419",@"",@"",];
    } else {
        names = @[@"游戏记录",@"追号记录",@"个人报表",@"账单报表",@"充提记录",@"优惠活动",@"用户资料",@"银行卡",@"修改登录密码",@"修改资金密码",@"彩种信息",@"开奖结果",@"走势图",@"站内信",@"网站公告",];
        images = @[@"p41",@"p42",@"p43",@"p45",@"p46",@"p47",@"p48",@"p49",@"p410",@"p411",@"p412",@"p413",@"p414",@"p417",@"p418",@"p419",@"",@"",];
    }
    
    CGFloat width = page4Scroll.width/3;
    CGFloat height = width*0.64;
    CGFloat offY = 0;
    for (int i = 0; i < names.count; i++) {
        UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(width*(i%3), height*(i/3), width, height)];
        button.tag = i;
        [page4Scroll addSubview:button];
        [button addTarget:self action:@selector(onPage4Button:) forControlEvents:UIControlEventTouchUpInside];
        UIImageView *imgv = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, widthTo4_7(36), widthTo4_7(36))];
        imgv.image = [UIImage imageNamed:images[i]];
        [button addSubview:imgv];
        imgv.center = CGPointMake(0.5*button.width, 0.38*button.height);
        
        UILabel *lab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, button.width, widthTo4_7(20))];
        lab.text = names[i];
        lab.textAlignment = NSTextAlignmentCenter;
        lab.textColor = ColorHex(0x222222);
        lab.font = SystemFontBy4(11.0);
        [button addSubview:lab];
        lab.center = CGPointMake(0.5*button.width, 0.8*button.height);
        
        UIView *liner = [[UIView alloc] initWithFrame:CGRectMake(button.right, button.top, widthTo4_7(1.0), button.height)];
        liner.backgroundColor = LineColorHomepage;
        [page4Scroll addSubview:liner];
        UIView *lineb = [[UIView alloc] initWithFrame:CGRectMake(button.left, button.bottom, button.width, widthTo4_7(1.0))];
        lineb.backgroundColor = LineColorHomepage;
        [page4Scroll addSubview:lineb];
        offY = lineb.bottom;
    }
    page4Scroll.contentSize = CGSizeMake(page4Scroll.width, offY+widthTo4_7(24));
}

- (void)setMoney {
    [self setPage4Name:[Singleton shared].account money:[[Singleton shared].balance addMoneyDot]];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Noti_MemberCenterShouldRenewBalance object:nil];
}
@end
