//
//  LotteryInfoViewController.h
//  CpNative
//
//  Created by david on 2019/3/10.
//  Copyright © 2019 david. All rights reserved.
//

#import "BasicWithNaviBarViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface LotteryInfoViewController : BasicWithNaviBarViewController

@property(nonatomic, copy) NSString *myTitle;
@property(nonatomic, assign) NSInteger page3GameType;

@end

NS_ASSUME_NONNULL_END
