//
//  LotteryInfoViewController.m
//  CpNative
//
//  Created by david on 2019/3/10.
//  Copyright © 2019 david. All rights reserved.
//

#import "LotteryInfoViewController.h"

@interface LotteryInfoViewController ()<WKNavigationDelegate>

@end

@implementation LotteryInfoViewController {
    NSMutableArray *lotteryNames;//彩种名字
    NSInteger page3SelectedGameIndex;//当前选中
    
    UILabel *page3GameLal;
    WKWebView *web;
    UIActivityIndicatorView *indicator;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    topbar.titleLabel.text = _myTitle;
    
    lotteryNames = [NSMutableArray array];
    for (int i = 0; i < [Singleton shared].gamesArrayGF.count; i++) {
        NSDictionary *dict = [Singleton shared].gamesArrayGF[i];
        NSString *name = [dict stringForKey:@"name"];
        name = [name stringByAppendingString:@"[官]"];
        [lotteryNames safeAddObject:name];
        
        if (!_page3GameType && i == 0) { //没有传入游戏，则指定游戏为第一个游戏
            _page3GameType = [dict integerForKey:@"lottery_id"];
        }
        else //如果传过来已有指定游戏，则找出这个指定的游戏
        {
            NSInteger lottery_id = [dict integerForKey:@"lottery_id"];
            if (_page3GameType == lottery_id) {
                page3SelectedGameIndex = i;
            }
        }
    }
    
    UIButton *page3TypeSelectButton = [[UIButton alloc] initWithFrame:CGRectMake(widthTo4_7(5), widthTo4_7(5)+topbar.bottom, self.view.width-widthTo4_7(10), widthTo4_7(39))];
    page3TypeSelectButton.layer.borderColor = LineColor.CGColor;
    page3TypeSelectButton.layer.borderWidth = widthTo4_7(1.0);
    page3TypeSelectButton.layer.cornerRadius = 0.1*page3TypeSelectButton.height;
    [page3TypeSelectButton addTarget:self action:@selector(onPage3GameSelect) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:page3TypeSelectButton];
    page3GameLal = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(10), 0, 250, page3TypeSelectButton.height)];
    page3GameLal.font = SystemFontBy4(14.);
    page3GameLal.textColor = ColorHex(0x262626);
    page3GameLal.text = lotteryNames[page3SelectedGameIndex];//默认值
    [page3TypeSelectButton addSubview:page3GameLal];
    UILabel *draw1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, page3TypeSelectButton.height*1.0, page3TypeSelectButton.height)];
    draw1.font = FontForSize(17);
    draw1.text = Down_Arrow;
    draw1.textColor = ColorHex(0x161616);
    [page3TypeSelectButton addSubview:draw1];
    draw1.textAlignment = NSTextAlignmentCenter;
    draw1.right = page3TypeSelectButton.width;
    
    web = [[WKWebView alloc] initWithFrame:CGRectMake(0, page3TypeSelectButton.bottom+widthTo4_7(5), self.view.width, self.view.height-(page3TypeSelectButton.bottom+widthTo4_7(5)))];
    web.navigationDelegate = self;
    [self.view addSubview:web];
    indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    indicator.hidesWhenStopped = YES;
    indicator.center = CGPointMake(0.5*web.width, 0.5*web.height);
    [web addSubview:indicator];
    
    [self loadInfo];
}

- (void)onPage3GameSelect {
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    WSDatePickerView *datepicker = [[WSDatePickerView alloc] initWithDateStyle:DateStyleShowBank data:lotteryNames scrollToIndex:page3SelectedGameIndex CompleteBlock:^(NSInteger tag, BOOL cancel) {
        if (cancel) {
            NSLog(@"CANCEL.....");
        } else {
            page3SelectedGameIndex = tag;
            
            //彩种名称
            NSString *title = lotteryNames[page3SelectedGameIndex];
            page3GameLal.text = title;
            
            //彩种类型
            NSDictionary *dict = [Singleton shared].gamesArrayGF[page3SelectedGameIndex];
            _page3GameType = [dict integerForKey:@"lottery_id"];
            
            NSLog(@"page3从selectview选了了游戏:%li",(long)_page3GameType);
            
            [self loadInfo];
        }
    }];
    
    datepicker.dateLabelColor = ColorHex(0xff5733);//年-月-日-时-分 颜色
    datepicker.datePickerColor = ColorHex(0x286be8);//滚轮日期颜色
    datepicker.doneButtonColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;//确定按钮的颜色
    [datepicker setHideBackgroundYearLabel:YES];
    [datepicker show];
}

- (void)loadInfo {
    NSString *lotteryId = [NSString stringWithFormat:@"%li",_page3GameType];
    NSString *urlstring = LotteryInfoForId(lotteryId);
    NSURL *url = [NSURL URLWithString:urlstring];
    NSURLRequest *urlrequest = [NSURLRequest requestWithURL:url];
    [web loadRequest:urlrequest];
}


//WKNavigationDelegate
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    
    NSLog(@"是否允许这个导航：允许");
    decisionHandler(WKNavigationActionPolicyAllow);
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler {
    //    Decides whether to allow or cancel a navigation after its response is known.
    
    NSLog(@"知道返回内容之后，是否允许加载：允许加载");
    decisionHandler(WKNavigationResponsePolicyAllow);
}
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(null_unspecified WKNavigation *)navigation {
    NSLog(@"开始加载");
    //    self.progress.alpha  = 1;
    
    NSLog(@"开始加载地址===>%@",webView.URL.absoluteString);
    [indicator startAnimating];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    
}

- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(null_unspecified WKNavigation *)navigation {
    NSLog(@"跳转到其他的服务器");
    NSLog(@"跳转到其他的服务器===>%@",webView.URL.absoluteString);
    [indicator startAnimating];
}

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error {
    NSLog(@"网页由于某些原因加载失败");
    NSLog(@"网页由于某些原因加载失败===>%@",webView.URL.absoluteString);
    [indicator stopAnimating];
    if (!webView.URL.absoluteString || !webView.URL.absoluteString.length) {
        [Tools alertWithTitle:@"加载失败,请稍后再试。" message:nil handle:^(UIAlertAction *action) {
        } cancel:nil confirm:@"确定"];
    }
    
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
}
- (void)webView:(WKWebView *)webView didCommitNavigation:(null_unspecified WKNavigation *)navigation {
    NSLog(@"网页开始接收网页内容");
    NSLog(@"网页开始接收网页内容===>%@",webView.URL.absoluteString);
}
- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation {
    NSLog(@"网页导航加载完毕");
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    
    [indicator stopAnimating];
    [webView evaluateJavaScript:@"document.title" completionHandler:^(id _Nullable ss, NSError * _Nullable error) {
        NSLog(@"网页导航加载完毕,加载----document.title:%@---webView title:%@",ss,webView.title);
    }];
}

- (void)webView:(WKWebView *)webView didFailNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error {
    NSLog(@"加载失败,失败原因:%@",[error description]);
    [indicator stopAnimating];
}
- (void)webViewWebContentProcessDidTerminate:(WKWebView *)webView {
    NSLog(@"网页加载内容进程终止");
    [indicator stopAnimating];
}
@end
