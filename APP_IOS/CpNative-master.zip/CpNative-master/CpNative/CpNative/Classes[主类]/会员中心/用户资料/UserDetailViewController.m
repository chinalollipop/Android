//
//  UserDetailViewController.m
//  CpNative
//
//  Created by david on 2019/2/21.
//  Copyright © 2019 david. All rights reserved.
//

#import "UserDetailViewController.h"
#import "BindCardViewController.h"

@interface UserDetailViewController ()

@end

@implementation UserDetailViewController {
    BOOL exist;//是否存在真实姓名
    
    UITextField *tfName;
    bool showWarn;
    
    UILabel *nickname;
    UILabel *yonghuming;
    UILabel *shoujihao;
    UILabel *youxiangt;
    UILabel *qqHao;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    topbar.titleLabel.text = @"用户资料";
    exist = ([[Singleton shared].loginDict stringForKey:@"name"].length > 1);
    
    
    CGFloat top = topbar.bottom;
    CGFloat gap = 0.04*self.view.width;
    CGFloat wid = self.view.width-gap*2;
    CGFloat heig = widthTo4_7(60);
    UIColor *color = ColorHex(0x161616);
    UIFont *font = SystemFontBy4(14.4);
    CGFloat begin = 0.32*self.view.width;
    if (showWarn) {
        UILabel *warn = [[UILabel alloc] initWithFrame:CGRectMake(gap, topbar.bottom, wid, heig)];
        warn.text = @"⚠️为了您的资金安全，请先设置真实姓名。";
        warn.textColor = ColorHex(0xf79a00);
        warn.font = font;
        [self.view addSubview:warn];
        top = warn.bottom-heig*0.2;
    }
    
    UILabel *nick = [[UILabel alloc] initWithFrame:CGRectMake(gap, top, 200, heig)];
    nick.text = @"用户昵称:";
    nick.font = font;
    nick.textColor = color;
    [self.view addSubview:nick];
    
    nickname = [[UILabel alloc] initWithFrame:CGRectMake(begin, top, 200, heig)];
    nickname.text = [[Singleton shared].loginDict stringForKey:@"nickname"];
    nickname.font = font;
    nickname.textColor = color;
    [self.view addSubview:nickname];
    
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, nickname.bottom, self.view.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [self.view addSubview:line];
    
    UILabel *yonghu = [[UILabel alloc] initWithFrame:CGRectMake(gap, line.bottom, 200, heig)];
    yonghu.text = @"用户名:";
    yonghu.font = font;
    yonghu.textColor = color;
    [self.view addSubview:yonghu];
    
    yonghuming = [[UILabel alloc] initWithFrame:CGRectMake(begin, line.bottom, 200, heig)];
    yonghuming.text = [[Singleton shared].loginDict stringForKey:@"username"];
    yonghuming.font = font;
    yonghuming.textColor = color;
    [self.view addSubview:yonghuming];
    
    line = [[UIView alloc] initWithFrame:CGRectMake(0, yonghuming.bottom, self.view.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [self.view addSubview:line];
    
    UILabel *shouji = [[UILabel alloc] initWithFrame:CGRectMake(gap, line.bottom, 200, heig)];
    shouji.text = @"用户手机:";
    shouji.font = font;
    shouji.textColor = color;
    [self.view addSubview:shouji];
    
    NSString *mobile = [[Singleton shared].loginDict stringForKey:@"mobile"];
    shoujihao = [[UILabel alloc] initWithFrame:CGRectMake(begin, line.bottom, 200, heig)];
    shoujihao.text = (mobile.length?mobile:@"(暂缺)");
    shoujihao.font = font;
    shoujihao.textColor = (mobile.length?color:(ColorHex(0xa2a2a2)));
    [self.view addSubview:shoujihao];
    
    line = [[UIView alloc] initWithFrame:CGRectMake(0, shoujihao.bottom, self.view.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [self.view addSubview:line];
    
    UILabel *zhenshi = [[UILabel alloc] initWithFrame:CGRectMake(gap, line.bottom, 200, heig)];
    zhenshi.text = @"真实姓名:";
    zhenshi.font = font;
    zhenshi.textColor = color;
    [self.view addSubview:zhenshi];
    
    tfName = [[UITextField alloc] initWithFrame:CGRectMake(begin, line.bottom, 0.58*self.view.width, heig)];
    tfName.placeholder = @"点击输入";
    tfName.text = exist?([[Singleton shared].loginDict stringForKey:@"name"] ):(@"");
    tfName.font = font;
    tfName.textColor = color;
    tfName.userInteractionEnabled = !exist;
    tfName.clearButtonMode = UITextFieldViewModeWhileEditing;
    [self.view addSubview:tfName];
    
    UILabel *alert = [[UILabel alloc] initWithFrame:CGRectMake(gap, line.bottom+0.5*heig, 320, heig)];
    alert.text = @"(必须与提款的银行开户名相同,否则无法提款!)";
    alert.font = SystemFontBy4(12.4);
    alert.textColor = ColorHex(0xff0000);
    [self.view addSubview:alert];
    
    line = [[UIView alloc] initWithFrame:CGRectMake(0, alert.bottom, self.view.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [self.view addSubview:line];
    
    UILabel *youxiang = [[UILabel alloc] initWithFrame:CGRectMake(gap, line.bottom, 200, heig)];
    youxiang.text = @"用户邮箱:";
    youxiang.font = font;
    youxiang.textColor = color;
    [self.view addSubview:youxiang];
    
    youxiangt = [[UILabel alloc] initWithFrame:CGRectMake(begin, line.bottom, 200, heig)];
    NSString *yx = [[Singleton shared].loginDict stringForKey:@"email"];
    NSString *yxText = (yx.length?yx:@"(暂缺)");
    youxiangt.text = yxText;
    youxiangt.font = font;
    youxiangt.textColor = (yx.length?color:(ColorHex(0xa2a2a2)));
    [self.view addSubview:youxiangt];
    
    line = [[UIView alloc] initWithFrame:CGRectMake(0, youxiangt.bottom, self.view.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [self.view addSubview:line];
    
    UILabel *qq = [[UILabel alloc] initWithFrame:CGRectMake(gap, line.bottom, 200, heig)];
    qq.text = @"用户QQ:";
    qq.font = font;
    qq.textColor = color;
    [self.view addSubview:qq];
    
    qqHao = [[UILabel alloc] initWithFrame:CGRectMake(begin, line.bottom, 200, heig)];
    NSString *q = [[Singleton shared].loginDict stringForKey:@"qq"];
    NSString *qqText = (q.length?q:@"(暂缺)");
    qqHao.text = qqText;
    qqHao.font = font;
    qqHao.textColor = (q.length?color:(ColorHex(0xa2a2a2)));;
    [self.view addSubview:qqHao];
    
    line = [[UIView alloc] initWithFrame:CGRectMake(0, qqHao.bottom, self.view.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [self.view addSubview:line];
    
    if (!exist) {
        UIButton *submit = [[UIButton alloc] initWithFrame:CGRectMake(gap, line.bottom+heig, wid, heig*0.8)];
        [submit setTitle:@"提交" forState:0];
        submit.layer.cornerRadius = 0.08*submit.height;
        submit.layer.masksToBounds = YES;
        [submit setBackgroundColor:ColorGreen];
        submit.titleLabel.font = SystemFontBy4(14.6);
        [submit setTitleColor:ColorHex(0xffffff) forState:0];
        [self.view addSubview:submit];
        [submit addTarget:self action:@selector(onSubmit) forControlEvents:UIControlEventTouchUpInside];
    }
    
    if (_user_id.length) {
        tfName.userInteractionEnabled = NO;
        tfName.placeholder = @"";
        tfName.text = @"";
        nickname.text = @"";
        yonghuming.text = @"";
        shoujihao.text = @"";
        youxiangt.text = @"";
        qqHao.text = @"";
        
        [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [NetworkBusiness childrenDetailForId:_user_id Block:^(NSError *error, int code, id response) {
            [MBProgressHUD hideHUDForView:self.view animated:NO];
            
            /*判断是否重新登录*/
            if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
                return;
            }
            
            if (code == 200) {
                NSInteger err = [response integerForKey:@"errno"];
                if (err == 0) {
                    NSDictionary *data = [response dictionaryForKey:@"data"];
                    nickname.text = [data stringForKey:@"nickname"];
                    yonghuming.text = [data stringForKey:@"username"];
                    shoujihao.text = [data stringForKey:@"mobile"];
                    tfName.text = [data stringForKey:@"name"];
                    youxiangt.text = [data stringForKey:@"email"];
                    qqHao.text = [data stringForKey:@"qq"];
                    if (!shoujihao.text.length) {
                        shoujihao.text = @"(暂缺)";
                        shoujihao.textColor = ColorHex(0xa2a2a2);
                    }
                    if (!tfName.text.length) {
                        tfName.text = @"(暂缺)";
                        tfName.textColor = ColorHex(0xa2a2a2);
                    }
                    if (!youxiangt.text.length) {
                        youxiangt.text = @"(暂缺)";
                        youxiangt.textColor = ColorHex(0xa2a2a2);
                    }
                    if (!qqHao.text.length) {
                        qqHao.text = @"(暂缺)";
                        qqHao.textColor = ColorHex(0xa2a2a2);
                    }
                    
                } else {
                    NSString *str = [response stringForKey:@"error"];
                    if (!str.length) {
                        str = @"请求失败,请稍后再试。";
                    }
                    [Tools alertWithTitle:str message:nil handle:^(UIAlertAction * _Nonnull action) {
                        
                    } cancel:nil confirm:@"确定"];
                }
            } else {
                [Tools showText:@"请求服务失败,请稍后再试."];
            }
        }];
    }
}

- (void)setupShowWarn:(BOOL)show {
    showWarn = show;
}

- (void)onSubmit {
    if (!tfName.text.length) {
        [Tools showText:@"请输入真实姓名"];
        return;
    }
    if ([tfName.text isEqualToString:[[Singleton shared].loginDict stringForKey:@"name"]]) {
        return;
    }
    
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    [MBProgressHUD showHUDAddedTo:mainDelegate.window animated:NO];
    [NetworkBusiness modifyRealName:tfName.text Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:mainDelegate.window animated:NO];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            if ([response integerForKey:@"errno"] == 0) {
                [[Singleton shared].loginDict setString:tfName.text forKey:@"name"];
                [Tools alertWithTitle:@"设置真实姓名成功!" message:nil handle:^(UIAlertAction * _Nonnull action) {
                    [self ok];
                } cancel:nil confirm:@"确定"];
            } else {
                if (exist) {
                    [Tools alertWithTitle:@"您已设置过姓名,不能重复设置。如需修改，请联系客服。" message:nil handle:nil cancel:nil confirm:@"确定"];
                } else {
                    NSString *str = [response stringForKey:@"error"];
                    [Tools alertWithTitle:str message:nil handle:nil cancel:nil confirm:@"确定"];
                }
            }
        }
    }];
}

- (void)ok {
    if (_isBindBankCard) {
        BindCardViewController *bind = [[BindCardViewController alloc] init];
        [self.navigationController pushViewController:bind animated:YES];
    }
}

@end
