//
//  UserDetailViewController.h
//  CpNative
//
//  Created by david on 2019/2/21.
//  Copyright © 2019 david. All rights reserved.
//

#import "BasicWithNaviBarViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface UserDetailViewController : BasicWithNaviBarViewController

@property(nonatomic, copy) NSString *user_id;
@property(nonatomic, assign) BOOL isBindBankCard;

- (void)setupShowWarn:(BOOL)show;

@end

NS_ASSUME_NONNULL_END
