//
//  GameRecordViewController.m
//  CpNative
//
//  Created by david on 2019/2/11.
//  Copyright © 2019 david. All rights reserved.
//

#import "FollowNumViewController.h"
#import "FollowNumDetailViewController.h"

@interface FollowNumViewController ()

@end

@implementation FollowNumViewController {
    BasicScrollView *recordScroll;
    
    UILabel *beginDateLbl;//开始日期
    UILabel *endDateLbl;//接受日期
    UILabel *typeDateLbl;
    
    /*参数  重要！！！*/
    NSInteger typeIndex;//游戏类型的索引
    NSInteger currentPage;//当前第几页
    NSInteger totalCount;//当前条件下总共有多少条数据
    NSInteger pagesize;//每页请求多少条数据
    NSMutableArray *allRecords;//返回的数组
    
    NSMutableArray *gameNames;//所有的游戏名称
    
    UIView *breakLine;//分割title和下部记录的线
    UIView *recordView;//游戏记录
    NSArray *statusNames;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    topbar.titleLabel.text = @"追号记录";
    currentPage = 1;//初始化当前页码为第1页.
    pagesize = 20;//每页请求的数据条数
    
    recordScroll = [[BasicScrollView alloc] initWithFrame:CGRectMake(0, topbar.bottom, self.view.width, self.view.height-topbar.height)];
    [self.view addSubview:recordScroll];
    
    
    CGFloat wid = recordScroll.width/3;
    NSArray *titles = @[@"开始日期",@"截止日期",@"游戏类型",];
    for (int i = 0; i < titles.count; i++) {
        UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(wid*i, 0, wid, widthTo4_7(60))];
        btn.tag = i;
        [btn addTarget:self action:@selector(onDateOrTypeSelection:) forControlEvents:UIControlEventTouchUpInside];
        [recordScroll addSubview:btn];
        
        UILabel *lal = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, wid, widthTo4_7(38))];
        lal.text = titles[i];
        lal.textAlignment = NSTextAlignmentCenter;
        lal.font = SystemFontBy4(12.6);
        lal.textColor = ColorHex(0x333333);
        [btn addSubview:lal];
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, widthTo4_7(30), wid, widthTo4_7(30))];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = SystemFontBy4(12.6);
        label.textColor = ColorHex(0x333333);
        [btn addSubview:label];
        
        UILabel *sign = [[UILabel alloc] initWithFrame:CGRectMake(0.84*wid, widthTo4_7(30), 0.1*wid, widthTo4_7(30))];
        sign.font = FontForSize(14);
        sign.text = UpDown1;
        sign.textColor = ColorHex(0x555555);
        sign.textAlignment = NSTextAlignmentCenter;
        [btn addSubview:sign];
        
        if (i == 0) {
            beginDateLbl = label;
            beginDateLbl.text = [[NSDate date] stringWithFormat:DateFormat_record];
        }
        if (i == 1) {
            endDateLbl = label;
            endDateLbl.text = [[NSDate dateTomorrow] stringWithFormat:DateFormat_record];
        }
        if (i == 2) {
            typeDateLbl = label;
            if (!gameNames) {
                gameNames = [NSMutableArray array];
                [gameNames addObject:@"全部游戏"];
                for (NSDictionary *dict in [Singleton shared].gamesArrayGF) {
                    NSString *name = [[dict stringForKey:@"name"] stringByAppendingString:@"[官]"];
                    [gameNames addObject:name];
                }
            }
            typeDateLbl.text = gameNames[0];
        }
    }
    
    breakLine = [[UIView alloc] initWithFrame:CGRectMake(0, widthTo4_7(66), recordScroll.width, widthTo4_7(1.2))];
    breakLine.backgroundColor = LineColor;
    [recordScroll addSubview:breakLine];
    
    recordView = [[UIView alloc] initWithFrame:CGRectMake(0, breakLine.bottom, recordScroll.width, recordScroll.height-breakLine.bottom)];
    [recordScroll addSubview:recordView];
    
    recordScroll.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        currentPage = 1;//刷新，页码重置为1
        [self requestDataIsRefresh:YES];
    }];
    
    recordScroll.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        ++currentPage;//加载更多，页码+1
        [self requestDataIsRefresh:NO];
    }];
    
    [recordScroll.mj_header beginRefreshing];
}

- (void)requestDataIsRefresh:(BOOL)isRefresh {
    
    if (!isRefresh) {
        if (allRecords.count >= totalCount) { //没有更多数据了
            [recordScroll.mj_footer endRefreshingWithNoMoreData];
            return;
        }
    }
    
    NSString *_id = @"";
    if (typeIndex > 0) {
        NSDictionary *lottery = [Singleton shared].gamesArrayGF[typeIndex-1];
        _id = [lottery stringForKey:@"lottery_id"];
    }
    
    NSString *page = [NSString stringWithFormat:@"%li",(long)currentPage];
    NSString *sizeOfPage = [NSString stringWithFormat:@"%li",(long)pagesize];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness zhuihaoForLotteryId:_id page:page pagesize:sizeOfPage begin_date:beginDateLbl.text end_date:endDateLbl.text Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        [recordScroll.mj_header endRefreshing];
        [recordScroll.mj_footer endRefreshing];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                NSDictionary *data = [response dictionaryForKey:@"data"];
                NSArray *games = [data arrayForKey:@"traces"];
                totalCount = [data integerForKey:@"count"];
                if (!allRecords) {
                    allRecords = [[NSMutableArray alloc] init];
                }
                if (isRefresh) {
                    [allRecords removeAllObjects];
                }
                if (games.count) {
                    [allRecords addObjectsFromArray:games];
                }
                if (allRecords.count < totalCount) {
                    [recordScroll.mj_footer resetNoMoreData];//还有更多数据可以加载
                }
                [self buildRecords];
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools showText:str];
            }
        } else {
            [Tools showText:@"请求失败,请稍后再试."];
        }
    }];
}

- (void)buildRecords {
    [recordView removeAllSubviews];
    
    if (!allRecords.count) {
        UILabel *no = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, recordScroll.width, widthTo4_7(80))];
        no.textAlignment = NSTextAlignmentCenter;
        no.text = No_Record_Text;
        no.font = SystemFontBy4(13.6);
        no.textColor = ColorHex(0x888888);
        [recordView addSubview:no];
        recordScroll.contentSize = CGSizeMake(recordScroll.width, recordScroll.height);
        return;
    }
    
    CGFloat offY = 0;
    CGFloat lineHeig = widthTo4_7(28);
    CGFloat left = widthTo4_7(10);
    CGFloat left2 = 0.49*recordView.width;
    CGFloat left3 = 0.227*recordView.width;
    CGFloat left4 = 0.69*recordView.width;
    CGFloat top = left*1.5;
    UIFont *font = SystemFontBy4(13.0);
    UIFont *fontb = BoldSystemFontBy4(12.4);
    UIColor *color = ColorHex(0x161616);
    
    if (!statusNames) {
        statusNames = @[@"进行中",@"已投注",@"用户取消",@"",@"系统终止",@"",@"",@"",@"",];
    }
    for (int i = 0; i < allRecords.count; i++) {
        NSDictionary *record = allRecords[i];
        UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0, offY, recordView.width, 1)];
        [recordView addSubview:button];
        button.tag = i;
        [button addTarget:self action:@selector(onRecordButton:) forControlEvents:UIControlEventTouchUpInside];
        
        NSString *lottId = [record stringForKey:@"lottery_id"];
        NSString *updated_at = [record stringForKey:@"updated_at"];
        NSString *way = [record stringForKey:@"way"];
        NSString *total_issues = [record stringForKey:@"total_issues"];
        NSString *start_issue = [record stringForKey:@"start_issue"];
        NSString *finished_issues = [record stringForKey:@"finished_issues"];
        NSString *amount = [record stringForKey:@"amount"];
        NSInteger status = [record integerForKey:@"status"];
        NSString *single_amount = [record stringForKey:@"single_amount"];
        NSString *serial_number = [record stringForKey:@"serial_number"];
        NSString *bet_number = [record stringForKey:@"bet_number"];
        
        NSString *finishAmount = [Tools decimal1:single_amount decimal2:finished_issues by:3];
        NSString *lottName = [Tools nameOfId:lottId isGF:YES];//彩种名字

        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(left, top, 500, lineHeig)];
        label.text = lottName;
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig, 500, lineHeig)];
        label.text = updated_at;
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left2, top+lineHeig, 500, lineHeig)];
        label.text = @"游戏玩法:";
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left4, label.top, 500, lineHeig)];
        label.text = way;
        label.textColor = color;
        label.font = fontb;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig*2, 500, lineHeig)];
        label.text = @"追号期数:";
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left3, label.top, 500, lineHeig)];
        label.text = total_issues;
        label.textColor = color;
        label.font = fontb;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left2, label.top, 100, lineHeig)];
        label.text = @"开始期数:";
        label.numberOfLines = 0;
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left4, label.top, 500, lineHeig)];
        label.text = start_issue;
        label.textColor = color;
        label.font = fontb;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig*3, 100, lineHeig)];
        label.text = @"完成期数:";
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left3, label.top, 500, lineHeig)];
        label.text = finished_issues;
        label.textColor = color;
        label.font = fontb;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left2, label.top, 100, lineHeig)];
        label.text = @"总投金额:";
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left4, label.top, 500, lineHeig)];
        label.text = [amount addMoneyDot];
        label.textColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;
        label.font = fontb;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig*4, 100, lineHeig)];
        label.text = @"状态:";
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left3, label.top, 500, lineHeig)];
        label.text = statusNames[status];
        label.textColor = color;
        label.font = fontb;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left2, label.top, 100, lineHeig)];
        label.text = @"完成金额:";
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left4, label.top, 500, lineHeig)];
        label.text = [finishAmount addMoneyDot];
        label.textColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;
        label.font = fontb;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig*5, 100, lineHeig)];
        label.text = @"用户:";
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left3, label.top, 500, lineHeig)];
        label.text = [Singleton shared].account;
        label.textColor = color;
        label.font = fontb;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig*6, 100, lineHeig)];
        label.text = @"注单编号:";
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left3, label.top, 500, lineHeig)];
        label.text = serial_number;
        label.textColor = color;
        label.font = fontb;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig*7, 100, lineHeig)];
        label.text = @"投注内容:";
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left3, label.top, button.width-left3-left, lineHeig)];
        label.text = bet_number;
        label.textColor = color;
        label.font = fontb;
        label.numberOfLines = 0;
        [label sizeToFit];
        [button addSubview:label];
        
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, label.bottom+top, button.width, widthTo4_7(1.2))];
        [button addSubview: line];
        line.backgroundColor = LineColor;
        
        button.height = line.bottom;
        offY = button.bottom;
    }
    recordView.height = offY;
    
    CGFloat contentH = recordScroll.height;
    if (recordView.bottom > contentH) {
        contentH = recordView.bottom;
    }
    recordScroll.contentSize = CGSizeMake(recordScroll.width, contentH);
}


- (void)onDateOrTypeSelection:(UIButton *)button {
    if (button.tag == 0) {
        [self showPickerWithTag:0 date:[NSDate date:beginDateLbl.text WithFormat:DateFormat_record]];
    }
    if (button.tag == 1) {
        [self showPickerWithTag:1 date:[NSDate date:endDateLbl.text WithFormat:DateFormat_record]];
    }
    if (button.tag == 2) {
        [self showPickForType];
    }
}



- (void)showPickerWithTag:(NSInteger)tag date:(NSDate *)date {
    __block __weak UILabel *wBegin = beginDateLbl;
    __block __weak UILabel *wEnd = endDateLbl;
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    WSDatePickerView *datepicker = [[WSDatePickerView alloc] initWithDateStyle:DateStyleShowYearMonthDay scrollToDate:date CompleteBlock:^(NSDate *selectDate,BOOL cancel) {
        if (!cancel) {
            NSString *dateString = [selectDate stringWithFormat:DateFormat_record];
            NSLog(@"选择的日期：%@",dateString);
            if (tag == 0) {
                wBegin.text = dateString;
            }
            if (tag == 1) {
                wEnd.text = dateString;
            }
            
            currentPage = 1;//页码重置为1
            [self requestDataIsRefresh:YES];
        }
    }];
    datepicker.dateLabelColor = ColorHex(0xff5733);//年-月-日-时-分 颜色
    datepicker.datePickerColor = ColorHex(0x286be8);//滚轮日期颜色
    datepicker.doneButtonColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;//确定按钮的颜色
    [datepicker setHideBackgroundYearLabel:YES];
    [datepicker setOutOfRangeText:@"仅可查询半年内记录"];
    [datepicker setMinLimitDate:[Tools dateOfHalfYearAgo]];
    [datepicker setMaxLimitDate:[NSDate dateTomorrow]];
    [datepicker show];
}

- (void)showPickForType {
    
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    WSDatePickerView *datepicker = [[WSDatePickerView alloc] initWithDateStyle:DateStyleShowBank data:gameNames scrollToIndex:typeIndex CompleteBlock:^(NSInteger tag, BOOL cancel) {
        if (cancel) {
            NSLog(@"CANCEL.....");
        } else {
            typeIndex = tag;
            NSString *name = gameNames[tag];
            typeDateLbl.text = name;
        }
        
        currentPage = 1;//页码重置为1
        [self requestDataIsRefresh:YES];
    }];
    
    datepicker.dateLabelColor = ColorHex(0xff5733);//年-月-日-时-分 颜色
    datepicker.datePickerColor = ColorHex(0x286be8);//滚轮日期颜色
    datepicker.doneButtonColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;//确定按钮的颜色
    [datepicker setHideBackgroundYearLabel:YES];
    [datepicker show];
}


/*点击进入详情*/
- (void)onRecordButton:(UIButton *)button {
    NSArray *arr = allRecords;
    if (!arr || !arr.count || (arr.count<=button.tag)) {
        return;
    }
    NSDictionary *dic = arr[button.tag];
    NSString *_id = [dic stringForKey:@"id"];
    NSString *way = [dic stringForKey:@"way"];
    
    if (_id.length > 0) {
        FollowNumDetailViewController *detail = [[FollowNumDetailViewController alloc] init];
        detail.statusNames = statusNames;
        detail._id = _id;
        detail.way = way;
        [self.navigationController pushViewController:detail animated:YES];
    }
}


@end
