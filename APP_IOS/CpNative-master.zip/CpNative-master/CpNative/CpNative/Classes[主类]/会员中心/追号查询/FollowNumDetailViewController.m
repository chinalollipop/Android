//
//  FollowNumDetailViewController.m
//  CpNative
//
//  Created by david on 2019/3/10.
//  Copyright © 2019 david. All rights reserved.
//

#import "FollowNumDetailViewController.h"
#import "GameRecordDetailViewController.h"

@interface FollowNumDetailViewController ()

@end

@implementation FollowNumDetailViewController {
    BasicScrollView *chaseScroll;
    UIView *contentView;
    NSDictionary *data;
    NSArray *issules;
    NSString *theWay;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    topbar.titleLabel.text = @"追号详情";
    
    chaseScroll = [[BasicScrollView alloc] initWithFrame:CGRectMake(0, topbar.bottom, self.view.width, self.view.height-topbar.bottom)];
    [self.view addSubview:chaseScroll];
    contentView = [[UIView alloc] initWithFrame:chaseScroll.bounds];
    [chaseScroll addSubview:contentView];
    
    chaseScroll.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self request];
    }];

    [chaseScroll.mj_header beginRefreshing];
}

- (void)request {
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness zhuihaoDetailForId:__id Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        [chaseScroll.mj_header endRefreshing];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                data = [response dictionaryForKey:@"data"];
                [self buidUI];
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools showText:str];
            }
        } else {
            [Tools showText:@"请求失败,请稍后再试."];
        }
    }];
}

- (void)buidUI {
    [contentView removeAllSubviews];
    
    CGFloat lineHeig = widthTo4_7(28);
    CGFloat left = widthTo4_7(10);
    CGFloat left2 = 0.49*contentView.width;
    CGFloat left3 = 0.227*contentView.width;
    CGFloat left4 = 0.69*contentView.width;
    CGFloat top = left*1.5;
    UIFont *font = SystemFontBy4(13.0);
    UIFont *fontb = BoldSystemFontBy4(12.4);
    UIColor *color = ColorHex(0x161616);

    NSDictionary *record = [data dictionaryForKey:@"basic"];
    
    NSString *lottId = [record stringForKey:@"lottery_id"];
    NSString *updated_at = [record stringForKey:@"updated_at"];
    theWay = [record stringForKey:@"way"];
    NSString *total_issues = [record stringForKey:@"total_issues"];
    NSString *finished_issues = [record stringForKey:@"finished_issues"];
    NSString *amount = [record stringForKey:@"amount"];
    NSInteger status = [record integerForKey:@"status"];
    NSString *single_amount = [record stringForKey:@"single_amount"];
    NSString *serial_number = [record stringForKey:@"serial_number"];
    NSString *bet_number = [record stringForKey:@"bet_number"];
    NSString *canceled_issues = [record stringForKey:@"canceled_issues"];
    NSString *moshi = [record stringForKey:@"formatted_coefficient"];
    NSString *formatted_stop_on_won = [record stringForKey:@"formatted_stop_on_won"];
    NSString *jump_open_then_stop = [record stringForKey:@"jump_open_then_stop"];
    NSString *canceled_amount_formatted = [record stringForKey:@"canceled_amount_formatted"];
    NSString *start_issue = [record stringForKey:@"start_issue"];
    
    NSString *lottName = [Tools nameOfId:lottId isGF:YES];//彩种名字
    NSString *finishAmount = [Tools decimal1:single_amount decimal2:finished_issues by:3];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(left, top, 500, lineHeig)];
    label.text = @"追号编号:";
    label.textColor = color;
    label.font = font;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left3, top, 500, lineHeig)];
    label.text = serial_number;
    label.textColor = color;
    label.font = fontb;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig, 500, lineHeig)];
    label.text = updated_at;
    label.textColor = color;
    label.font = font;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left2, label.top, 500, lineHeig)];
    label.text = @"游戏用户:";
    label.textColor = color;
    label.font = font;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left4, label.top, 500, lineHeig)];
    label.text = [Singleton shared].account;
    label.textColor = color;
    label.font = fontb;
    [label sizeToFit];
    [contentView addSubview:label];
    
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig*2, 500, lineHeig)];
    label.text = @"游戏彩种:";
    label.textColor = color;
    label.font = font;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left3, label.top, 500, lineHeig)];
    label.text = lottName;
    label.textColor = color;
    label.font = fontb;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left2, label.top, 500, lineHeig)];
    label.text = @"游戏玩法:";
    label.textColor = color;
    label.font = font;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left4, label.top, 500, lineHeig)];
    label.text = theWay;
    label.textColor = color;
    label.font = fontb;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig*3, 500, lineHeig)];
    label.text = @"游戏模式:";
    label.textColor = color;
    label.font = font;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left3, label.top, 500, lineHeig)];
    label.text = moshi;
    label.textColor = color;
    label.font = fontb;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left2, label.top, 500, lineHeig)];
    label.text = @"开始期号:";
    label.textColor = color;
    label.font = font;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left4, label.top, 500, lineHeig)];
    label.text = start_issue;
    label.textColor = color;
    label.font = fontb;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig*4, 500, lineHeig)];
    label.text = @"追号期数:";
    label.textColor = color;
    label.font = font;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left3, label.top, 500, lineHeig)];
    label.text = total_issues;
    label.textColor = color;
    label.font = fontb;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left2, label.top, 500, lineHeig)];
    label.text = @"完成期数:";
    label.textColor = color;
    label.font = font;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left4, label.top, 500, lineHeig)];
    label.text = finished_issues;
    label.textColor = color;
    label.font = fontb;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig*5, 500, lineHeig)];
    label.text = @"取消期数:";
    label.textColor = color;
    label.font = font;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left3, label.top, 500, lineHeig)];
    label.text = canceled_issues;
    label.textColor = color;
    label.font = fontb;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left2, label.top, 500, lineHeig)];
    label.text = @"完成金额:";
    label.textColor = color;
    label.font = font;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left4, label.top, 500, lineHeig)];
    label.text = finishAmount;
    label.textColor = color;
    label.font = fontb;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig*6, 500, lineHeig)];
    label.text = @"追号金额:";
    label.textColor = color;
    label.font = font;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left3, label.top, 500, lineHeig)];
    label.text = [amount addMoneyDot];
    label.textColor = color;
    label.font = fontb;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left2, label.top, 500, lineHeig)];
    label.text = @"取消金额:";
    label.textColor = color;
    label.font = font;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left4, label.top, 500, lineHeig)];
    label.text = canceled_amount_formatted;
    label.textColor = color;
    label.font = fontb;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig*7, 500, lineHeig)];
    label.text = @"追号状态:";
    label.textColor = color;
    label.font = font;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left3, label.top, 500, lineHeig)];
    if (status == 0) {
        label.text = @"等待中";
    } else {
        label.text = _statusNames[status];
    }
    label.textColor = color;
    label.font = fontb;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left2, label.top, 500, lineHeig)];
    label.text = @"官方跳开即停:";
    label.textColor = color;
    label.font = font;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(0.76*contentView.width, label.top, 500, lineHeig)];
    label.text = jump_open_then_stop;
    label.textColor = color;
    label.font = fontb;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig*8, 500, lineHeig)];
    label.text = @"中后停止追号:";
    label.textColor = color;
    label.font = font;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(0.297*contentView.width, label.top, 500, lineHeig)];
    label.text = formatted_stop_on_won;
    label.textColor = color;
    label.font = fontb;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig*9, 100, lineHeig)];
    label.text = @"投注内容:";
    label.textColor = color;
    label.font = font;
    [label sizeToFit];
    [contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left3, label.top, contentView.width-left3-left, lineHeig)];
    label.text = bet_number;
    label.textColor = color;
    label.font = fontb;
    label.numberOfLines = 0;
    [label sizeToFit];
    [contentView addSubview:label];
    

    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, label.bottom+top, contentView.width, widthTo4_7(1.2))];
    [contentView addSubview: line];
    line.backgroundColor = LineColor;
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(0, line.bottom, self.view.width, widthTo4_7(48))];
    label.textColor = color;
    label.font = font;
    label.textAlignment = NSTextAlignmentCenter;
    label.text = @"可能中奖情况";
    [contentView addSubview:label];
    
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectMake(0, label.bottom, contentView.width, widthTo4_7(44))];
    titleView.backgroundColor = ColorHex(0x333333);
    [contentView addSubview:titleView];
    NSArray *names = @[@"奖期",@"追号倍数",@"追号状态",@"详情",];
    CGFloat width = contentView.width/names.count;
    for (int i = 0; i < names.count; i++) {
        UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(width*i, 0, width, titleView.height*0.95)];
        [btn setTitle:names[i] forState:0];
        [titleView addSubview:btn];
        [btn setTitleColor:ColorHex(0xffffff) forState:0];
        btn.titleLabel.font = font;
    }
    
    issules = [data arrayForKey:@"issues"];
    CGFloat issHeig = widthTo4_7(70);
    CGFloat topiss = titleView.bottom;
    for (int k = 0; k < issules.count; k++) {
        NSDictionary *issue = issules[k];
        UILabel *jiangqi = [[UILabel alloc] initWithFrame:CGRectMake(0, topiss, width, issHeig)];
        jiangqi.text = [issue stringForKey:@"issue"];
        jiangqi.numberOfLines = 0;
        jiangqi.textAlignment = NSTextAlignmentCenter;
        jiangqi.font = font;
        jiangqi.textColor = color;
        [contentView addSubview:jiangqi];
        
        UILabel *beishu = [[UILabel alloc] initWithFrame:CGRectMake(width, topiss, width, issHeig)];
        beishu.text = [[issue stringForKey:@"multiple"] stringByAppendingString:@"倍"];;
        beishu.numberOfLines = 0;
        beishu.textAlignment = NSTextAlignmentCenter;
        beishu.font = font;
        beishu.textColor = color;
        [contentView addSubview:beishu];
        
        NSInteger sta = [issue integerForKey:@"status"];
        UILabel *zhui = [[UILabel alloc] initWithFrame:CGRectMake(width*2, topiss, width, issHeig)];
        zhui.text = _statusNames[sta];
        zhui.numberOfLines = 0;
        zhui.textAlignment = NSTextAlignmentCenter;
        zhui.font = font;
        zhui.textColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;
        [contentView addSubview:zhui];
        
        if (sta == 0) {
            UIButton *xiangqing = [[UIButton alloc ] initWithFrame:CGRectMake(width*3, topiss, width, issHeig)];
            xiangqing.tag = k;
            [xiangqing setTitle:@"取消本\n期追号" forState:0];
            xiangqing.titleLabel.numberOfLines = 0;
            [xiangqing setTitleColor:ColorHex(0x487ab2) forState:0];
            xiangqing.titleLabel.font = font;
            [contentView addSubview:xiangqing];
            [xiangqing addTarget:self action:@selector(onCancel:) forControlEvents:UIControlEventTouchUpInside];
        }
        
        
        if (sta == 1) {
            UIButton *xiangqing = [[UIButton alloc ] initWithFrame:CGRectMake(width*3, topiss, width, issHeig)];
            xiangqing.tag = k;
            [xiangqing setTitle:@"详情 >" forState:0];
            [xiangqing setTitleColor:ColorHex(0x487ab2) forState:0];
            xiangqing.titleLabel.font = font;
            [contentView addSubview:xiangqing];
            [xiangqing addTarget:self action:@selector(onXiangqing:) forControlEvents:UIControlEventTouchUpInside];
        }
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, beishu.bottom, contentView.width, widthTo4_7(1.2))];
        line.backgroundColor = LineColor;
        [contentView addSubview:line];
        topiss = line.bottom;
    }
    
    contentView.height = topiss;
    chaseScroll.contentSize = CGSizeMake(chaseScroll.width, contentView.height);
    
    
    
}

- (void)onCancel:(UIButton *)button {
    NSDictionary *dic = issules[button.tag];
    NSString *_id = [dic stringForKey:@"id"];
    NSString *ids = [NSString stringWithFormat:@"[%@]",_id];
    
    if (_id.length > 0) {
        [MBProgressHUD showHUDAddedTo:mainDelegate.window animated:NO];
        [NetworkBusiness zhuihaoCancelForTraceId:__id ids:ids Block:^(NSError *error, int code, id response) {
            [MBProgressHUD hideHUDForView:mainDelegate.window animated:NO];
            [chaseScroll.mj_header endRefreshing];
            
            /*判断是否重新登录*/
            if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
                return;
            }
            
            if (code == 200) {
                NSInteger err = [response integerForKey:@"errno"];
                if (err == 0) {
                    [Tools alertWithTitle:@"取消成功。" message:nil handle:^(UIAlertAction * _Nonnull action) {
                        [chaseScroll.mj_header beginRefreshing];
                    } cancel:nil confirm:@"确定"];
                } else {
                    NSString *str = [response stringForKey:@"error"];
                    if (!str.length) {
                        str = @"请求失败,请稍后再试。";
                    }
                    [Tools showText:str];
                }
            } else {
                [Tools showText:@"请求失败,请稍后再试."];
            }
        }];
        
    }
}

- (void)onXiangqing:(UIButton *)button {
    NSDictionary *dic = issules[button.tag];
    NSString *_id = [dic stringForKey:@"project_id"];
    
    if (_id.length > 0) {
        GameRecordDetailViewController *detail = [[GameRecordDetailViewController alloc] init];
        detail._id = _id;
        detail.way = theWay;
        [self.navigationController pushViewController:detail animated:YES];
    } else {
        [Tools showText:@"注单未生产,请稍后刷新再试。"];
    }
}
@end
