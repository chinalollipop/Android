//
//  UserListViewController.m
//  CpNative
//
//  Created by david on 2019/3/19.
//  Copyright © 2019 david. All rights reserved.
//

#import "UserListViewController.h"
#import "ChargeAndWithdrawViewController.h"
#import "UserDetailViewController.h"
#import "TeamChartViewController.h"
#import "UserListSetPrizeViewController.h"

@interface UserListViewController ()

@end

@implementation UserListViewController {
    BasicScrollView *listscroll;
    UIView *contentView;
    
    UIView *topView;
    UIView *downView;
    NSArray *userList;
    
    NSInteger currentButtonTag;
    UIFont *textfont;
    NSArray *widths;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    topbar.titleLabel.text = @"用户列表";
    
    listscroll = [[BasicScrollView alloc] initWithFrame:CGRectMake(0, topbar.bottom, self.view.width, self.view.height-topbar.height)];
    [self.view addSubview:listscroll];
    
    CGFloat heig = widthTo4_7(44);
    topView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.width, heig)];
    topView.backgroundColor = ColorReset;
    [listscroll addSubview:topView];
    
    contentView = [[UIView alloc] initWithFrame:CGRectMake(0, topView.bottom, listscroll.width, listscroll.height-topView.bottom)];
    [listscroll addSubview:contentView];
    
    
    downView = [[BasicScrollView alloc] initWithFrame:CGRectMake(0, topView.bottom, self.view.width, self.view.height-topView.bottom)];
    [contentView addSubview:downView];
    
    NSArray *arr = @[@"用户名",@"开户类型",@"金额",@"返点类型",@"状态",@"操作",];
    widths = @[@"0.26",@"0.15",@"0.19",@"0.15",@"0.15",@"0.1",];
    textfont = SystemFontBy4(12);
    CGFloat lleft = 0;
    for (int i = 0; i < arr.count; i++) {
        NSString *width = widths[i];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(lleft, 0, width.floatValue*topView.width, heig)];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = textfont;
        label.text = arr[i];
        label.textColor = [UIColor whiteColor];
        [topView addSubview:label];
        lleft = label.right;
    }
    
    listscroll.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self requestList];
    }];
    [listscroll.mj_header beginRefreshing];
}

- (void)requestList {
    NSString *parent_id = _dailiId;
    if (!parent_id || !parent_id.length) {
        parent_id = [[Singleton shared].loginDict stringForKey:@"id"];
    }
    
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness getDirectChildrenOfParentId:parent_id Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        [listscroll.mj_header endRefreshing];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                userList = [response arrayForKey:@"data"];
                currentButtonTag = -1;
                [self updateUI];
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools alertWithTitle:str message:nil handle:^(UIAlertAction * _Nonnull action) {
                    
                } cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求服务失败,请稍后再试."];
        }
    }];
}

- (void)updateUI {
    [contentView removeAllSubviews];
    
    if (!userList.count) {
        UILabel *no = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, contentView.width, widthTo4_7(80))];
        no.textAlignment = NSTextAlignmentCenter;
        no.text = No_Record_Text;
        no.font = SystemFontBy4(13.6);
        no.textColor = ColorHex(0x888888);
        [contentView addSubview:no];
        listscroll.contentSize = CGSizeMake(contentView.width, listscroll.height);
        return;
    }
    
    
    CGFloat height = widthTo4_7(48);
    UIColor *color = ColorHex(0x161616);
    
    CGFloat offY = 0;
    for (int i = 0; i < userList.count; i++) {
        UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0, offY, contentView.width, height)];
        [contentView addSubview:button];
        button.tag = i;
        [button addTarget:self action:@selector(onUser:) forControlEvents:UIControlEventTouchUpInside];
        
        NSDictionary *dict = userList[i];
        NSString *name = [dict stringForKey:@"username"];
        NSString *type = [dict stringForKey:@"user_type_formatted"];
        NSString *money = [[dict stringForKey:@"available"] addMoneyDot];
        NSString *group = [dict stringForKey:@"prize_group"];
        NSInteger children_num = [dict integerForKey:@"children_num"];
        
        CGFloat lleft = 0;
        NSString *width = widths[0];
        UIButton *username = [[UIButton alloc] initWithFrame:CGRectMake(lleft, 0, width.floatValue*contentView.width, button.height)];
        NSMutableAttributedString *mstr = [[NSMutableAttributedString alloc] initWithString:name];
        if ((children_num > 0) || ([type containsString:@"代"])) {
            username.tag = i;
            [mstr setForegroundColor:ColorHex(0x075eda) inRange:NSMakeRange(0, name.length)];
            [mstr setUnderlineStyle:NSUnderlineStyleSingle color:ColorHex(0x075eda) inRange:NSMakeRange(0, name.length)];
            [username addTarget:self action:@selector(onAgent:) forControlEvents:UIControlEventTouchUpInside];
        } else {
            username.userInteractionEnabled = NO;
            [mstr setForegroundColor:color inRange:NSMakeRange(0, name.length)];
        }
        [mstr setFont:textfont inRange:NSMakeRange(0, name.length)];
        [username setAttributedTitle:mstr forState:0];
        [button addSubview:username];
        lleft = username.right;
        
        width = widths[1];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(lleft, 0, width.floatValue*contentView.width, height)];
        label.text = type;
        label.textColor = color;
        label.font = textfont;
        label.textAlignment = NSTextAlignmentCenter;
        [button addSubview:label];
        lleft = label.right;
        
        width = widths[2];
        label = [[UILabel alloc] initWithFrame:CGRectMake(lleft, 0, width.floatValue*contentView.width, height)];
        label.text = money;
        label.textColor = color;
        label.font = textfont;
        label.textAlignment = NSTextAlignmentCenter;
        [button addSubview:label];
        lleft = label.right;
        
        width = widths[3];
        label = [[UILabel alloc] initWithFrame:CGRectMake(lleft, 0, width.floatValue*contentView.width, height)];
        label.text = group;
        label.textColor = color;
        label.font = textfont;
        label.textAlignment = NSTextAlignmentCenter;
        [button addSubview:label];
        lleft = label.right;
        
        width = widths[4];
        label = [[UILabel alloc] initWithFrame:CGRectMake(lleft, 0, width.floatValue*contentView.width, height)];
        label.text = @"启用";
        label.textColor = color;
        label.font = textfont;
        label.textAlignment = NSTextAlignmentCenter;
        [button addSubview:label];
        lleft = label.right;
        
        width = widths[5];
        UIImageView *arrow = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, widthTo4_7(16), widthTo4_7(16))];
        arrow.image = [UIImage imageNamed:@"ceright"];
        [button addSubview:arrow];
        arrow.center = CGPointMake(label.right+width.floatValue*contentView.width/2, 0.5*button.height);
        
        offY = button.bottom;
        if (currentButtonTag == i) {
            [UIView animateWithDuration:0.08 animations:^{
                arrow.transform = CGAffineTransformMakeRotation(M_PI_2);
            }];
            
            UIView *second = [[UIView alloc] initWithFrame:CGRectMake(0, offY, button.width, widthTo4_7(55))];
            second.backgroundColor = ColorHex(0xf6f6f6);
            [contentView addSubview:second];
            NSArray *names = @[@"详情",@"团队总览",@"返点设定",@"账变记录",];
            CGFloat gap = widthTo4_7(7.4);
            CGFloat top = widthTo4_7(9);
            CGFloat bWidth = (second.width-gap*5)/4;
            CGFloat height = second.height-top*2;
            for (int k = 0; k < names.count; k++) {
                UIButton *detail = [[UIButton alloc] initWithFrame:CGRectMake(gap+(gap+bWidth)*k, top, bWidth, height)];
                [detail setTitle:names[k] forState:0];
                [detail setTitleColor:ColorHex(0xff0000) forState:0];
                detail.titleLabel.font = textfont;
                [detail addTarget:self action:@selector(onSubButton:) forControlEvents:UIControlEventTouchUpInside];
                detail.layer.borderWidth = widthTo4_7(1.0);
                detail.layer.borderColor = ColorHex(0x999999).CGColor;
                detail.layer.cornerRadius = widthTo4_7(3.6);
                detail.layer.masksToBounds = YES;
                [second addSubview:detail];
                detail.tag = k;
            }
            
            offY = second.bottom;
        }
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, offY, contentView.width, widthTo4_7(1.0))];
        line.backgroundColor = LineColor;
        [contentView addSubview:line];
        offY = line.bottom;
    }
    
    contentView.height = offY;
    CGFloat hhh = contentView.bottom + widthTo4_7(24);
    if (hhh < listscroll.height) {
        hhh = listscroll.height;
    }
    listscroll.contentSize = CGSizeMake(contentView.width, hhh);
}



- (void)onUser:(UIButton *)button {
    NSLog(@"用户点击了某个用户：%li",button.tag);
    if (currentButtonTag == button.tag) {
        currentButtonTag = -1;
    } else {
        currentButtonTag = button.tag;
    }
    [self updateUI];
}

- (void)onAgent:(UIButton *)button {
    NSLog(@"用户点击了某个代理：%li",button.tag);
    
    NSDictionary *user = userList[button.tag];
    NSString *_id = [user stringForKey:@"id"];
    if (_id.length) {
        UserListViewController *userVC = [[UserListViewController alloc] init];
        userVC.dailiId = _id;
        [self.navigationController pushViewController:userVC animated:YES];
    }
    
}

- (void)onSubButton:(UIButton *)button {
    NSLog(@"用户点击了用户下方按钮：%li",button.tag);
    NSDictionary *dict = userList[currentButtonTag];
    NSString *userid = [dict stringForKey:@"id"];
    NSString *username = [dict stringForKey:@"username"];
    NSString *group_available = [dict stringForKey:@"group_available"];
    NSString *prizegroup = [dict stringForKey:@"prize_group"];
    
    if (button.tag == 0) {
        UserDetailViewController *vc = [[UserDetailViewController alloc] init];
        vc.user_id = userid;
        [self.navigationController pushViewController:vc animated:YES];
    }
    
    if (button.tag == 1) {
        TeamChartViewController *vc = [[TeamChartViewController alloc] init];
        vc.user_id = userid;
        vc.username = username;
        vc.balance = group_available;
        [self.navigationController pushViewController:vc animated:YES];
    }
    
    if (button.tag == 2) { //返点设定
        UserListSetPrizeViewController *vc = [[UserListSetPrizeViewController alloc ] init];
        vc.user_id = userid;
        vc.prizeGroup = prizegroup;
        [self.navigationController pushViewController:vc animated:YES];
    }
    
    if (button.tag == 3) { //账变记录
        ChargeAndWithdrawViewController *vc = [[ChargeAndWithdrawViewController alloc] init];
        vc.user_id = userid;
        vc.userName = username;
        [self.navigationController pushViewController:vc animated:YES];
    }
}
@end
