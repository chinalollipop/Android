//
//  UserListSetPrizeViewController.m
//  CpNative
//
//  Created by david on 2019/3/23.
//  Copyright © 2019 david. All rights reserved.
//

#import "UserListSetPrizeViewController.h"

@interface UserListSetPrizeViewController ()

@end

@implementation UserListSetPrizeViewController {
    BasicScrollView *scrollp;
    UIView *contentview;
    NSDictionary *data;
    NSMutableArray *otherGroupNamesMember;//picker的名字数组
    NSInteger selectedTypeIndex;//选中了哪个
    
    UILabel *bounesLabel;
    NSString *userwater;//当前用户返点等级
    CGFloat lineHeight;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    topbar.titleLabel.text = @"返点设定";
    
    scrollp = [[BasicScrollView alloc] initWithFrame:CGRectMake(0, topbar.bottom, self.view.width, self.view.height-topbar.bottom)];
    [self.view addSubview:scrollp];
    contentview = [[UIView alloc] initWithFrame:scrollp.bounds];
    [scrollp addSubview:contentview];
    
    scrollp.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self requestBase];
    }];
    [scrollp.mj_header beginRefreshing];
}

- (void)requestBase {
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness setUserPrizeForId:_user_id Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        [scrollp.mj_header endRefreshing];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                data = [response dictionaryForKey:@"data"];
                [self updateView];
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools alertWithTitle:str message:nil handle:^(UIAlertAction * _Nonnull action) {
                    [self.navigationController popViewControllerAnimated:YES];
                } cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求服务失败,请稍后再试."];
        }
    }];
}

- (void)updateView {
    [contentview removeAllSubviews];
    
    if (!otherGroupNamesMember) {
        otherGroupNamesMember = [[NSMutableArray alloc] init];
        
        NSArray *array = [data arrayForKey:@"sAllPossiblePrizeGroups"];
        for (int i = 0; i < array.count; i++) {
            NSDictionary *dict = array[i];
            CGFloat water = [dict floatForKey:@"water"];
            NSString *name = [dict stringForKey:@"name"];
            NSString *goup = [NSString stringWithFormat:@"%.2f%% ---- %@",(water*100),name];
            [otherGroupNamesMember addObject:goup];
            
            if ([name isEqualToString:_prizeGroup]) {
                userwater = [NSString stringWithFormat:@"%.2f%%",(water*100)];
                selectedTypeIndex = i;
            }
        }
    }
    
    lineHeight = widthTo4_7(56);
    CGFloat beginLeft = 0.31*self.view.width;
    CGFloat offY = 0;
    
    NSDictionary *userdict = [data dictionaryForKey:@"aUserPrizeSet"];
    
    //用户类型
    [contentview addSubview:[self typeLabelWithText:@"开户账号:" y:offY]];
    UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(beginLeft, offY, 200, lineHeight)];
    nameLabel.textColor = ColorHex(0x202020);
    nameLabel.font = SystemFontBy4(14.6);
    nameLabel.text = [userdict stringForKey:@"username"];
    [contentview addSubview:nameLabel];
    offY += lineHeight;
    
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, offY, contentview.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [contentview addSubview:line];
    offY = line.bottom;
    
    //用户昵称
    [contentview addSubview:[self typeLabelWithText:@"用户昵称:" y:offY]];
    UILabel *nickLabel = [[UILabel alloc] initWithFrame:CGRectMake(beginLeft, offY, 200, lineHeight)];
    nickLabel.textColor = ColorHex(0x202020);
    nickLabel.font = SystemFontBy4(14.6);
    nickLabel.text = [userdict stringForKey:@"nickname"];
    [contentview addSubview:nickLabel];
    offY += lineHeight;
    
    line = [[UIView alloc] initWithFrame:CGRectMake(0, offY, contentview.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [contentview addSubview:line];
    offY = line.bottom;
    
    //返点等级
    [contentview addSubview:[self typeLabelWithText:@"返点等级:" y:offY]];
    UILabel *grade = [[UILabel alloc] initWithFrame:CGRectMake(beginLeft, offY, 200, lineHeight)];
    grade.textColor = ColorHex(0x202020);
    grade.font = SystemFontBy4(14.6);
    grade.text = userwater;
    [contentview addSubview:grade];
    offY += lineHeight;
    
    line = [[UIView alloc] initWithFrame:CGRectMake(0, offY, contentview.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [contentview addSubview:line];
    offY = line.bottom;
    
    //用户返点
    [contentview addSubview:[self typeLabelWithText:@"用户返点:" y:offY]];
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(beginLeft, offY, contentview.width-beginLeft, lineHeight)];
    [btn addTarget:self action:@selector(onOtherBonus) forControlEvents:UIControlEventTouchUpInside];
    btn.backgroundColor = ColorHex(0xeaeaea);
    btn.layer.cornerRadius = 0.09*btn.height;
    btn.layer.masksToBounds = YES;
    [contentview addSubview:btn];
    btn.top += widthTo4_7(6);
    btn.height -= widthTo4_7(12);
    btn.width -= widthTo4_7(6);
    bounesLabel = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(10), 0, 290, btn.height)];
    bounesLabel.font = SystemFontBy4(14.6);
    bounesLabel.textColor = ColorHex(0x202020);
    bounesLabel.text = otherGroupNamesMember[selectedTypeIndex];
    [btn addSubview:bounesLabel];
    UILabel *draw1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, btn.height*1.0, btn.height)];
    draw1.font = FontForSize(17);
    draw1.text = Down_Arrow;
    draw1.textColor = ColorHex(0x161616);
    [btn addSubview:draw1];
    draw1.textAlignment = NSTextAlignmentCenter;
    draw1.right = btn.width;
    offY += lineHeight;
    
    line = [[UIView alloc] initWithFrame:CGRectMake(0, offY, contentview.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [contentview addSubview:line];
    offY = line.bottom;
    
    UILabel *notice = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(8), offY, contentview.width-widthTo4_7(16), lineHeight*0.9)];
    notice.textAlignment = NSTextAlignmentCenter;
    notice.textColor = ColorHex(0xff3333);
    notice.font = SystemFontBy4(12.8);
    notice.numberOfLines = 0;
    notice.text = @"特别提示：调整用户奖金组时，一旦调高并保存后，将不允许恢复或调低，请谨慎操作！";
    [contentview addSubview:notice];
    offY = notice.bottom;
    
    UIButton *registerBtn = [[UIButton alloc] initWithFrame:CGRectMake(widthTo4_7(8), offY+widthTo4_7(20), contentview.width-widthTo4_7(16), widthTo4_7(44))];
    [registerBtn setTitle:@"保存奖金组设置" forState:0];
    [registerBtn addTarget:self action:@selector(onRegiser:) forControlEvents:UIControlEventTouchUpInside];
    [registerBtn setTitleColor:[UIColor whiteColor] forState:0];
    registerBtn.titleLabel.font = BoldSystemFontBy4(14.6);
    registerBtn.backgroundColor = ColorHex(0xe79532);
    registerBtn.layer.cornerRadius = 0.07*registerBtn.height;
    registerBtn.layer.masksToBounds = YES;
    [contentview addSubview:registerBtn];
}

- (void)onRegiser:(UIButton *)button {
    NSArray *array = [data arrayForKey:@"sAllPossiblePrizeGroups"];
    NSDictionary *dict = array[selectedTypeIndex];
    NSString *name = [dict stringForKey:@"name"];
    NSString *prize_group_type = [dict stringForKey:@"type"];
    NSString *series_prize_group_json = [NSString stringWithFormat:@"{\"%@\":%@}",prize_group_type,name];
    NSString *water = [dict stringForKey:@"water"];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness setUserPrizeSubmitForLotteryId:@"" series_id:@"" series_prize_group_json:series_prize_group_json agent_prize_set_quota:@"{}" kickback:water userId:_user_id Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        [scrollp.mj_header endRefreshing];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                [Tools alertWithTitle:@"奖金组设定已保存成功!" message:nil handle:^(UIAlertAction * _Nonnull action) {
                    [self.navigationController popViewControllerAnimated:YES];
                } cancel:nil confirm:@"确定"];
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools alertWithTitle:str message:nil handle:^(UIAlertAction * _Nonnull action) {
                    [self.navigationController popViewControllerAnimated:YES];
                } cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求服务失败,请稍后再试."];
        }
    }];
}

- (UILabel *)typeLabelWithText:(NSString *)text y:(CGFloat)y {
    UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(8), y, 120, lineHeight)];
    lbl.font = SystemFontBy4(14.6);
    lbl.textColor = ColorHex(0x202020);
    lbl.text = text;
    return lbl;
}


/*选择其它奖金组*/
- (void)onOtherBonus {

    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    WSDatePickerView *datepicker = [[WSDatePickerView alloc] initWithDateStyle:DateStyleShowBank data:otherGroupNamesMember scrollToIndex:(selectedTypeIndex) CompleteBlock:^(NSInteger tag, BOOL cancel) {
        if (cancel) {
            NSLog(@"CANCEL.....");
        } else {
            selectedTypeIndex = tag;
            NSString *title = otherGroupNamesMember[selectedTypeIndex];
            bounesLabel.text = title;
        }
    }];
    
    datepicker.dateLabelColor = ColorHex(0xff5733);//年-月-日-时-分 颜色
    datepicker.datePickerColor = ColorHex(0x286be8);//滚轮日期颜色
    datepicker.doneButtonColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;//确定按钮的颜色
    [datepicker setHideBackgroundYearLabel:YES];
    [datepicker show];
}
@end
