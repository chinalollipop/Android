//
//  WithdrawViewController.m
//  CpNative
//
//  Created by david on 2019/2/23.
//  Copyright © 2019 david. All rights reserved.
//

#import "WithdrawViewController.h"
#import "WithdrawNextViewController.h"

@interface WithdrawViewController ()<UITextFieldDelegate>

@end

@implementation WithdrawViewController {
    BasicScrollView *withdrawScroll;
    UIView *contentView;
    BOOL hideDama;
    NSDictionary *beginData;
    
    UILabel  *bankNameLal;
    NSInteger currentIndex;
    NSMutableArray *banknameArr;
    UITextField *tfMoney;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    hideDama = YES;
    topbar.titleLabel.text = @"提款";
    self.view.backgroundColor = ColorHex(0xf6f6f6);
    
    withdrawScroll = [[BasicScrollView alloc] initWithFrame:CGRectMake(0, topbar.height, self.view.width, self.view.height-topbar.height)];
    [self.view addSubview:withdrawScroll];
    contentView = [[UIView alloc] initWithFrame:withdrawScroll.bounds];
    [withdrawScroll addSubview:contentView];
    
    withdrawScroll.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        currentIndex = 0;
        [self requestBase];
    }];
    [withdrawScroll.mj_header beginRefreshing];
    
}

- (void)requestBase {
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness withdrawBeginBlock:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        [withdrawScroll.mj_header endRefreshing];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                beginData = [response dictionaryForKey:@"data"];
                [self buildScroll];
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                if ([str containsString:@"银行卡"]) {
                    str = @"您还没有绑定提款银行卡,请前往(会员中心 -> 银行卡)进行绑定";
                }
                
                [Tools alertWithTitle:str message:nil handle:^(UIAlertAction * _Nonnull action) {
                    [self.navigationController popViewControllerAnimated:YES];
                } cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求失败,请稍后再试."];
        }
    }];
}

- (void)buildScroll {
    [contentView removeAllSubviews];
    
    
    CGFloat left = widthTo4_7(12);
    
    UIView *moneyView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.width, widthTo4_7(67))];
    moneyView.backgroundColor = ColorHex(0xffffff);
    [contentView addSubview:moneyView];
    
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0.5*self.view.width, moneyView.top, widthTo4_7(1.0), moneyView.height)];
    line.backgroundColor = LineColor;
    [contentView addSubview:line];
    
    line = [[UIView alloc] initWithFrame:CGRectMake(0, moneyView.bottom, self.view.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [contentView addSubview:line];
    
    UILabel *keti = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 0.5*self.view.width, 0.6*moneyView.height)];
    keti.text = @"可提金额(元)";
    keti.textAlignment = NSTextAlignmentCenter;
    keti.font = SystemFontBy4(12);
    keti.textColor = ColorHex(0x777777);
    [moneyView addSubview:keti];
    
    UILabel *shouxufei = [[UILabel alloc] initWithFrame:CGRectMake(0.5*self.view.width, 0, 0.5*self.view.width, 0.6*moneyView.height)];
    shouxufei.text = @"手续费";
    shouxufei.textAlignment = NSTextAlignmentCenter;
    shouxufei.font = SystemFontBy4(12);
    shouxufei.textColor = ColorHex(0x777777);
    [moneyView addSubview:shouxufei];
    
    UILabel *money = [[UILabel alloc] initWithFrame:CGRectMake(0, 0.4*moneyView.height, 0.5*self.view.width, 0.6*moneyView.height)];
    money.textAlignment = NSTextAlignmentCenter;
    money.font = BoldSystemFontBy4(14);
    money.textColor = ColorHex(0xde3c35);
    NSString *balance = [Singleton shared].balance;
    money.text = [balance addMoneyDot];
    [moneyView addSubview:money];
    
    UILabel *fei = [[UILabel alloc] initWithFrame:CGRectMake(0.5*self.view.width, 0.4*moneyView.height, 0.5*self.view.width, 0.6*moneyView.height)];
    fei.textAlignment = NSTextAlignmentCenter;
    fei.font = BoldSystemFontBy4(14);
    fei.textColor = ColorHex(0xde3c35);
    fei.text = @"0.00";
    [moneyView addSubview:fei];
    
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(left, line.bottom+widthTo4_7(16), 0.24*self.view.width, widthTo4_7(32))];
    btn.backgroundColor = ColorGreen;
    btn.layer.cornerRadius = widthTo4_7(4);
    btn.layer.masksToBounds = YES;
    [btn setTitle:@"查看打码量" forState:0];
    [btn setTitleColor:ColorHex(0xffffff) forState:0];
    btn.titleLabel.font = BoldSystemFontBy4(12.2);
    [contentView addSubview:btn];
    [btn addTarget:self action:@selector(onDama) forControlEvents:UIControlEventTouchUpInside];
    
    CGFloat offy = btn.bottom + widthTo4_7(8);
    if (!hideDama) {
        NSDictionary *temp = [beginData dictionaryForKey:@"aUserDepositGame"];
        BOOL bEnough = [temp boolForKey:@"bEnough"];
        NSString *still = [temp stringForKey:@"fNeedGameAmount"];
        NSArray *damas = [temp arrayForKey:@"aDepositGame"];
        for (int i = 0; i < damas.count; i++) {
            NSDictionary *data = damas[i];
            UILabel *dama = [[UILabel alloc]initWithFrame:CGRectMake(left, offy, contentView.width-left*2, widthTo4_7(44))];
            dama.numberOfLines = 0;
            dama.textColor = ColorHex(0x404040);
            dama.font = SystemFontBy4(11.6);
            NSString *time = [data stringForKey:@"depositTime"];
            NSString *deposite = [data stringForKey:@"depositAmount"];
            NSString *total = [data stringForKey:@"gameMoney"];
            NSString *gf = [data stringForKey:@"projectAmount"];
            NSString *xy = [data stringForKey:@"betMoney"];
            NSString *qp = [data stringForKey:@"kaiyuanGameCellScore"];
            BOOL isEnough = [data boolForKey:@"isEnough"];
            NSString *str = [NSString stringWithFormat:@"%@ 充值/额外打码: %@ 元，之后打码量: %@(官方盘%@，信用盘%@，棋牌%@)，%@",time,deposite,total,gf,xy,qp,(isEnough?@"达到":@"未达到")];
            dama.text = str;
            [contentView addSubview:dama];
            offy = dama.bottom;
        }
        if (!bEnough) {
            UILabel *dama = [[UILabel alloc]initWithFrame:CGRectMake(left, offy, contentView.width-left*2, widthTo4_7(28))];
            dama.text = [NSString stringWithFormat:@"还需要 %@ 打码量，才能出款",still];
            dama.numberOfLines = 0;
            dama.textColor = ColorHex(0xe7ab18);
            dama.font = SystemFontBy4(11.6);
            [contentView addSubview:dama];
            offy = dama.bottom;
        }
    }
    offy += widthTo4_7(8);
    
    line = [[UIView alloc] initWithFrame:CGRectMake(0, offy, contentView.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [contentView addSubview:line];
    
    UIView *bankview = [[UIView alloc] initWithFrame:CGRectMake(0, line.bottom, contentView.width, widthTo4_7(150))];
    bankview.backgroundColor = ColorHex(0xffffff);
    [contentView addSubview:bankview];
    
    UILabel *yinhangka = [[UILabel alloc] initWithFrame:CGRectMake(left, 0, 100, widthTo4_7(54))];
    yinhangka.text = @"银行卡";
    yinhangka.textColor = ColorHex(0x777777);
    yinhangka.font = SystemFontBy4(13.4);
    [bankview addSubview:yinhangka];
    
    UIButton *bankBtn = [[UIButton alloc] initWithFrame:CGRectMake(0.3*bankview.width, 0, 0.7*bankview.width, yinhangka.height)];
    [bankBtn addTarget:self action:@selector(onBankSelect) forControlEvents:UIControlEventTouchUpInside];
    [bankview addSubview:bankBtn];
    UIImageView *arrow = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, widthTo4_7(20), widthTo4_7(20))];
    arrow.image = [UIImage imageNamed:@"cedown"];
    [bankview addSubview:arrow];
    arrow.center = CGPointMake(0.92*self.view.width, 0.5*yinhangka.height);
    bankNameLal = [[UILabel alloc] initWithFrame:CGRectMake(0.28*self.view.width, 0, 0.6*self.view.width, yinhangka.height)];
    [bankview addSubview:bankNameLal];
    bankNameLal.textColor = ColorHex(0x161616);
    bankNameLal.font = SystemFontBy4(14.4);
    if (!banknameArr) {
        banknameArr = [[NSMutableArray alloc] init];
        NSArray *tt = [beginData arrayForKey:@"aBankCards"];
        for (int k = 0; k < tt.count; k++) {
            NSDictionary *dict = tt[k];
            NSString *ba = [dict stringForKey:@"bank"];
            NSString *account = [dict stringForKey:@"account"];
            NSString *account_name = [dict stringForKey:@"account_name"];
            if (account.length > 4) {
                account = [account substringFromIndex:account.length-4];
            }
            if (account_name.length > 1) {
                account_name = [account_name substringFromIndex:account_name.length-1];
            }
            NSString *str = [NSString stringWithFormat:@"%@ 尾号:%@ [**%@]",ba,account,account_name];
            [banknameArr safeAddObject:str];
        }
    }
    bankNameLal.text = (banknameArr.count>currentIndex)?(banknameArr[currentIndex]):(@"-");
    
    line = [[UIView alloc] initWithFrame:CGRectMake(left, yinhangka.bottom, bankview.width-left*2, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [bankview addSubview:line];
    
    UILabel *tikuanjine = [[UILabel alloc] initWithFrame:CGRectMake(left, line.bottom, 100, widthTo4_7(44))];
    tikuanjine.text = @"提款金额";
    tikuanjine.textColor = ColorHex(0x777777);
    tikuanjine.font = SystemFontBy4(13.4);
    [bankview addSubview:tikuanjine];
    
    UILabel *sign = [[UILabel alloc] initWithFrame:CGRectMake(left*2.6, tikuanjine.top+tikuanjine.height*0.8, widthTo4_7(24), yinhangka.height)];
    sign.text = @"￥";
    [bankview addSubview:sign];
    sign.textColor = bankNameLal.textColor;
    sign.font = SystemFontBy4(20);
    [bankview addSubview:sign];
    
    tfMoney = [[UITextField alloc] initWithFrame:CGRectMake(left*5.4, sign.top+sign.height*0.07, 0.55*self.view.width, sign.height*0.86)];
    tfMoney.placeholder = @"点击输入金额";
    tfMoney.delegate = self;
    tfMoney.textAlignment = NSTextAlignmentCenter;
    tfMoney.textColor = sign.textColor;
    tfMoney.font = SystemFontBy4(15.2);
    tfMoney.clearButtonMode = UITextFieldViewModeWhileEditing;
    tfMoney.keyboardType = UIKeyboardTypeNumberPad;
    [bankview addSubview:tfMoney];
    line = [[UIView alloc] initWithFrame:CGRectMake(tfMoney.left, tfMoney.bottom, tfMoney.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [bankview addSubview:line];
    bankview.height = line.bottom+widthTo4_7(8);
    
    line = [[UIView alloc] initWithFrame:CGRectMake(0, bankview.bottom, self.view.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [contentView addSubview:line];
    
    UILabel *notice = [[UILabel alloc] initWithFrame:CGRectMake(left, line.bottom, self.view.width-left*2, widthTo4_7(114))];
    notice.textColor = ColorHex(0xde3c35);
    notice.font = SystemFontBy4(11.);
    notice.numberOfLines = 0;
    [contentView addSubview:notice];
    notice.text = @"温馨提示：出款仅限整数递交，若填写的金额带有小数点，系统将会自动为您清除小数点保留整数递交出款单，多余小数点金额则会退回至您的账户。\n\n单笔最低提现100元，最高无上限。";
    
    UIButton *submit = [[UIButton alloc] initWithFrame:CGRectMake(left, notice.bottom, self.view.width-left*2, widthTo4_7(44))];
    submit.backgroundColor = ColorGreen;
    submit.layer.cornerRadius = widthTo4_7(4);
    submit.layer.masksToBounds = YES;
    [contentView addSubview:submit];
    [submit setTitle:@"下一步" forState:0];
    [submit setTitleColor:ColorHex(0xffffff) forState:0];
    submit.titleLabel.font = SystemFontBy4(14.2);
    [submit addTarget:self action:@selector(onSubmit) forControlEvents:UIControlEventTouchUpInside];
    
    contentView.height = submit.bottom+widthTo4_7(30);
    withdrawScroll.contentSize = CGSizeMake(contentView.width, contentView.height);
}

- (void)onSubmit {
    NSArray *banks = [beginData arrayForKey:@"aBankCards"];
    NSDictionary *dict = banks[currentIndex];
    NSString *_id = [dict stringForKey:@"id"];
    NSString *money = [tfMoney.text stringByReplacingOccurrencesOfString:@"," withString:@""];
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness withdrawConfirmForId:_id amount:money Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                WithdrawNextViewController *next = [[WithdrawNextViewController alloc] init];
                next.data = response;
                [self.navigationController pushViewController:next animated:YES];
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools alertWithTitle:str message:nil handle:nil cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求失败,请稍后再试."];
        }
    }];
}

- (void)onBankSelect {
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    WSDatePickerView *datepicker = [[WSDatePickerView alloc] initWithDateStyle:DateStyleShowBank data:banknameArr scrollToIndex:currentIndex CompleteBlock:^(NSInteger tag, BOOL cancel) {
        if (cancel) {
            NSLog(@"CANCEL.....");
        } else {
            currentIndex = tag;
            bankNameLal.text = (banknameArr.count>currentIndex)?(banknameArr[currentIndex]):(@"-");
        }
    }];
    
    datepicker.dateLabelColor = ColorHex(0xff5733);//年-月-日-时-分 颜色
    datepicker.datePickerColor = ColorHex(0x286be8);//滚轮日期颜色
    datepicker.doneButtonColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;//确定按钮的颜色
    [datepicker setHideBackgroundYearLabel:YES];
    [datepicker show];
}

- (void)onDama {
    hideDama = !hideDama;
    [self buildScroll];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString *value = [textField.text stringByReplacingCharactersInRange:range withString:string];
    value = [value stringByReplacingOccurrencesOfString:@"," withString:@""];
    textField.text = [value addMoneyDotNoFloat];
    return NO;
}
@end
