//
//  WithdrawNextViewController.m
//  CpNative
//
//  Created by david on 2019/3/14.
//  Copyright © 2019 david. All rights reserved.
//

#import "WithdrawNextViewController.h"

@interface WithdrawNextViewController ()

@end

@implementation WithdrawNextViewController {
    UITextField *tfFund;
    NSString *_id;
    NSString *amount;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    topbar.titleLabel.text = @"提款信息确认";
    
    NSDictionary *data = [_data dictionaryForKey:@"data"];
    NSDictionary *message = [data dictionaryForKey:@"aInputData"];
    NSDictionary *bankinfo = [data dictionaryForKey:@"aBankCard"];
    _id = [bankinfo stringForKey:@"id"];
    amount = [message stringForKey:@"amount"];
    
    
    CGFloat left = widthTo4_7(13);
    CGFloat left2 = 0.36*self.view.width;
    CGFloat height = widthTo4_7(40);
    UIFont *font = SystemFontBy4(12.6);
    UIFont *font2 = SystemFontBy4(13);
    UIColor *color = ColorHex(0x161616);
    CGFloat top = topbar.bottom + widthTo4_7(6);
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(left, top, 500, height*1.1)];
    label.font = font2;
    label.textColor = ColorHex(0xf79a00);
    label.text = @"⚠️请核对以下提款信息";
    [self.view addSubview:label];
    top = label.bottom;
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left, top, 100, height)];
    label.font = font;
    label.textColor = color;
    label.text = @"用户名:";
    [self.view addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left2, top, 400, height)];
    label.font = font;
    label.textColor = color;
    label.text = [Singleton shared].account;
    [self.view addSubview:label];
    top = label.bottom;
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left, top, 100, height)];
    label.font = font;
    label.textColor = color;
    label.text = @"可用提现余额:";
    [self.view addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left2, top, 400, height)];
    label.font = font;
    label.textColor = color;
    label.text = [[[Singleton shared].balance addMoneyDot] stringByAppendingString:@"元"];;
    [self.view addSubview:label];
    top = label.bottom;
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left, top, 100, height)];
    label.font = font;
    label.textColor = color;
    label.text = @"本次提现金额:";
    [self.view addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left2, top, 400, height)];
    label.font = font;
    label.textColor = color;
    label.text = [[[message stringForKey:@"amount"] addMoneyDotNoFloat] stringByAppendingString:@"元"];
    [self.view addSubview:label];
    top = label.bottom;
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left, top, 100, height)];
    label.font = font;
    label.textColor = color;
    label.text = @"开户银行:";
    [self.view addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left2, top, 400, height)];
    label.font = font;
    label.textColor = color;
    label.text = [bankinfo stringForKey:@"bank"];
    [self.view addSubview:label];
    top = label.bottom;
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left, top, 100, height)];
    label.font = font;
    label.textColor = color;
    label.text = @"开户行地址:";
    [self.view addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left2, top, 400, height)];
    label.font = font;
    label.textColor = color;
    label.text = [bankinfo stringForKey:@"branch"];
    [self.view addSubview:label];
    top = label.bottom;
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left, top, 100, height)];
    label.font = font;
    label.textColor = color;
    label.text = @"开户人:";
    [self.view addSubview:label];
    
    NSString *bbb = [bankinfo stringForKey:@"account_name"];
    if (bbb.length > 1) {
        bbb = [bbb substringFromIndex:bbb.length-1];
    } else {
        bbb = @"";
    }
    label = [[UILabel alloc] initWithFrame:CGRectMake(left2, top, 400, height)];
    label.font = font;
    label.textColor = color;
    label.text = [@"**" stringByAppendingString:bbb];
    [self.view addSubview:label];
    top = label.bottom;
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(left, top, 100, height)];
    label.font = font;
    label.textColor = color;
    label.text = @"提现银行卡号:";
    [self.view addSubview:label];
    
    bbb = [bankinfo stringForKey:@"account"];
    if (bbb.length > 4) {
        bbb = [bbb substringFromIndex:bbb.length-4];
    } else {
        bbb = @"";
    }
    label = [[UILabel alloc] initWithFrame:CGRectMake(left2, top, 400, height)];
    label.font = font;
    label.textColor = color;
    label.text = [@"**** **** **** " stringByAppendingString:bbb];
    [self.view addSubview:label];
    top = label.bottom;
    
    UILabel *notice = [[UILabel alloc] initWithFrame:CGRectMake(left, label.bottom+widthTo4_7(6), 400, widthTo4_7(30))];
    notice.font = SystemFontBy4(11.0);
    notice.text = @"为了确保您的资金安全,请输入资金密码以便确认您的身份:";
    notice.textColor = ColorHex(0xde3c35);
    [self.view addSubview:notice];
    
    UIView *vvv = [[UIView alloc] initWithFrame:CGRectMake(left, notice.bottom+widthTo4_7(3), self.view.width-left*2, widthTo4_7(50))];
    vvv.layer.borderColor = ColorHex(0xa0a0a0).CGColor;
    vvv.layer.borderWidth = widthTo4_7(1.0);
    vvv.layer.masksToBounds = YES;
    vvv.layer.cornerRadius = widthTo4_7(5);
    [self.view addSubview:vvv];
    
    tfFund = [[UITextField alloc] initWithFrame:vvv.bounds];
    tfFund.textColor = ColorHex(0x161616);
    tfFund.placeholder = @"点击输入资金密码";
    tfFund.font = SystemFontBy4(15.2);
    tfFund.textAlignment = NSTextAlignmentCenter;
    tfFund.secureTextEntry = YES;
    tfFund.clearButtonMode = UITextFieldViewModeWhileEditing;
    [vvv addSubview:tfFund];
    
    UIButton *submit = [[UIButton alloc] initWithFrame:CGRectMake(left, vvv.bottom+widthTo4_7(22), self.view.width-left*2, widthTo4_7(44))];
    submit.backgroundColor = ColorGreen;
    submit.layer.cornerRadius = widthTo4_7(4);
    submit.layer.masksToBounds = YES;
    [self.view addSubview:submit];
    [submit setTitle:@"确认提现" forState:0];
    [submit setTitleColor:ColorHex(0xffffff) forState:0];
    submit.titleLabel.font = SystemFontBy4(14.2);
    [submit addTarget:self action:@selector(onSubmit) forControlEvents:UIControlEventTouchUpInside];
}

- (void)onSubmit {
    if (!tfFund.text.length) {
        [Tools showText:@"请输入资金密码"];
        return;
    }
    
    [MBProgressHUD showHUDAddedTo:mainDelegate.window animated:NO];
    [NetworkBusiness withdrawSumitForId:_id amount:amount funPass:tfFund.text Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:mainDelegate.window animated:NO];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                [Tools alertWithTitle:@"提款申请已提交成功!" message:nil handle:^(UIAlertAction * _Nonnull action) {
                    [self.navigationController popToRootViewControllerAnimated:YES];
                } cancel:nil confirm:@"确定"];
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools alertWithTitle:str message:nil handle:^(UIAlertAction * _Nonnull action) {
                    [self.navigationController popViewControllerAnimated:YES];
                } cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求失败,请稍后再试."];
        }
    }];
    
    
}

@end
