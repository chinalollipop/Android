//
//  TeamChartViewController.m
//  CpNative
//
//  Created by david on 2019/2/15.
//  Copyright © 2019 david. All rights reserved.
//

#import "TeamChartViewController.h"

@interface TeamChartViewController ()

@end

@implementation TeamChartViewController {
    BasicScrollView *recordScroll;
    UILabel *beginDateLbl;
    UILabel *endDateLbl;
    UIView *xiangqingView;
    NSDictionary *data;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    topbar.titleLabel.text = @"团队报表";
    self.view.backgroundColor = ColorHex(0xeeeeee);
    
    recordScroll = [[BasicScrollView alloc] initWithFrame:CGRectMake(0, topbar.bottom, self.view.width, self.view.height-topbar.height)];
    [self.view addSubview:recordScroll];
    
    CGFloat wid = recordScroll.width/2;
    NSArray *titles = @[@"开始日期",@"截止日期",];
    for (int i = 0; i < titles.count; i++) {
        UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(wid*i, 0, wid, widthTo4_7(66))];
        btn.backgroundColor = ColorHex(0xffffff);
        btn.tag = i;
        [btn addTarget:self action:@selector(onDateOrTypeSelection:) forControlEvents:UIControlEventTouchUpInside];
        [recordScroll addSubview:btn];
        
        UILabel *lal = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, wid, widthTo4_7(38))];
        lal.text = titles[i];
        lal.textAlignment = NSTextAlignmentCenter;
        lal.font = SystemFontBy4(12.6);
        lal.textColor = ColorHex(0x333333);
        [btn addSubview:lal];
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, widthTo4_7(30), wid, widthTo4_7(30))];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = SystemFontBy4(12.6);
        label.textColor = ColorHex(0x333333);
        [btn addSubview:label];
        
        UILabel *sign = [[UILabel alloc] initWithFrame:CGRectMake(0.84*wid, widthTo4_7(30), 0.1*wid, widthTo4_7(30))];
        sign.font = FontForSize(14);
        sign.text = UpDown1;
        sign.textColor = ColorHex(0x555555);
        sign.textAlignment = NSTextAlignmentCenter;
        [btn addSubview:sign];
        
        if (i == 0) {
            beginDateLbl = label;
            beginDateLbl.text = [[NSDate date] stringWithFormat:DateFormat_record];
        }
        if (i == 1) {
            endDateLbl = label;
            endDateLbl.text = [[NSDate dateTomorrow] stringWithFormat:DateFormat_record];
        }
    }

    xiangqingView = [[UIView alloc] initWithFrame:CGRectMake(0, widthTo4_7(76), self.view.width, self.view.width*0.92)];
    xiangqingView.backgroundColor = ColorHex(0xffffff);
    [recordScroll addSubview:xiangqingView];
    [self updateXiangqingView];
    
    
    UIView *yingli = [[UIView alloc] initWithFrame:CGRectMake(0, xiangqingView.bottom+widthTo4_7(10), self.view.width, widthTo4_7(60)+0.02*self.view.width)];
    yingli.backgroundColor = ColorHex(0xffffff);
    [recordScroll addSubview:yingli];
    UIView *dot = [[UIView alloc] initWithFrame:CGRectMake(0.04*self.view.width, widthTo4_7(30), 0.02*self.view.width, 0.02*self.view.width)];
    dot.backgroundColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;
    dot.layer.cornerRadius = 0.5*dot.height;
    dot.layer.masksToBounds = YES;
    [yingli addSubview:dot];
    UILabel *label0 = [[UILabel alloc] initWithFrame:CGRectMake(0.1*self.view.width, 0, 0.86*self.view.width, yingli.height)];
    label0.text = @"净盈利 = 中奖金额+打和返款+投注返点+代理返点+活动奖励-投注金额。";
    label0.numberOfLines = 0;
    label0.font = SystemFontBy4(11.2);
    label0.textColor = ColorHex(0xff0000);
    [yingli addSubview:label0];
    
    recordScroll.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self request];
    }];
    [recordScroll.mj_header beginRefreshing];
}

- (void)updateXiangqingView {
    [xiangqingView removeAllSubviews];
    UIView *dot = [[UIView alloc] initWithFrame:CGRectMake(0.04*self.view.width, widthTo4_7(20), 0.02*self.view.width, 0.02*self.view.width)];
    dot.backgroundColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;
    dot.layer.cornerRadius = 0.5*dot.height;
    dot.layer.masksToBounds = YES;
    [xiangqingView addSubview:dot];
    UILabel *label0 = [[UILabel alloc] initWithFrame:CGRectMake(0.1*self.view.width, 0, 300, widthTo4_7(40)+0.02*self.view.width)];
    label0.text = @"团队详情";
    label0.font = SystemFontBy4(11.2);
    label0.textColor = ColorHex(0xff0000);
    [xiangqingView addSubview:label0];
    
    NSString *value0 = @"0.00";
    NSString *value1 = @"0.00";
    NSString *value2 = @"0.00";
    NSString *value3 = @"0.00";
    NSString *value4 = @"0.00";
    NSString *value5 = @"0.00";
    NSString *value6 = @"0.00";
    NSString *value7 = @"0.00";
    NSString *value8 = @"0.00";
    NSString *value9 = @"0.00";
    
    if (data) {
        if (_balance && _balance.length) {
            value0 = [_balance addMoneyDot];
        } else {
            value0 = [[Singleton shared].balance addMoneyDot];
        }
        
        NSString *total_deposit = [data stringForKey:@"total_deposit"];
        if (total_deposit.length) {
            value1 = [total_deposit addMoneyDot];
        }
        
        NSString *total_withdrawal = [data stringForKey:@"total_withdrawal"];
        if (total_withdrawal.length) {
            value2 = [total_withdrawal addMoneyDot];
        }
        
        NSString *total_turnover = [data stringForKey:@"total_turnover"];
        if (total_turnover.length) {
            value3 = [total_turnover addMoneyDot];
        }
        
        NSString *total_profit = [data stringForKey:@"total_profit"];
        if (total_profit.length) {
            value4 = [total_profit addMoneyDot];
        }
        
        NSString *total_prize = [data stringForKey:@"total_prize"];
        if (total_prize.length) {
            value5 = [total_prize addMoneyDot];
        }
    }
    
    NSArray *texts = @[@"余额",@"充值",@"提现",
                       value0,value1,value2,
                       @"投注金额",@"净盈利",@"中奖金额",
                       value3,value4,value5,
                       @"打和返款",@"代理返点",@"投注返点",
                       value6,value7,value8,
                       @"活动奖励",@"",@"",
                       value9,];
    CGFloat left = 0.1*self.view.width;
    CGFloat top = label0.bottom;
    CGFloat width = 0.8*self.view.width/3*1.2;
    CGFloat height = widthTo4_7(36);
    for (int i = 0; i < texts.count; i++) {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(left+width*(i%3), top+height*(i/3), width, height)];
        [xiangqingView addSubview:label];
        label.text = texts[i];
        if (i/3%2) {
            label.font = BoldSystemFontBy4(13.0);
            label.textColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;
            label.top -= widthTo4_7(6);//微调UI，更紧凑点
        } else {
            label.font = SystemFontBy4(13.0);
            label.textColor = ColorHex(0x161616);
        }
    }
}


- (void)onDateOrTypeSelection:(UIButton *)button {
    if (button.tag == 0) {
        [self showPickerWithTag:0 date:[NSDate date:beginDateLbl.text WithFormat:DateFormat_record]];
    }
    if (button.tag == 1) {
        [self showPickerWithTag:1 date:[NSDate date:endDateLbl.text WithFormat:DateFormat_record]];
    }
}


- (void)showPickerWithTag:(NSInteger)tag date:(NSDate *)date {
    __block __weak UILabel *wBegin = beginDateLbl;
    __block __weak UILabel *wEnd = endDateLbl;
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    WSDatePickerView *datepicker = [[WSDatePickerView alloc] initWithDateStyle:DateStyleShowYearMonthDay scrollToDate:date CompleteBlock:^(NSDate *selectDate,BOOL cancel) {
        if (!cancel) {
            NSString *dateString = [selectDate stringWithFormat:DateFormat_record];
            NSLog(@"选择的日期：%@",dateString);
            if (tag == 0) {
                wBegin.text = dateString;
            }
            if (tag == 1) {
                wEnd.text = dateString;
            }
            [self request];
        }
    }];
    datepicker.dateLabelColor = ColorHex(0xff5733);//年-月-日-时-分 颜色
    datepicker.datePickerColor = ColorHex(0x286be8);//滚轮日期颜色
    datepicker.doneButtonColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;//确定按钮的颜色
    [datepicker setHideBackgroundYearLabel:YES];
    [datepicker setOutOfRangeText:@"仅可查询半年内记录"];
    [datepicker setMinLimitDate:[Tools dateOfHalfYearAgo]];
    [datepicker setMaxLimitDate:[NSDate dateTomorrow]];
    [datepicker show];
}

- (void)request {
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness guanfangTeamSummaryAtBegin:beginDateLbl.text end:endDateLbl.text user_id:_user_id username:_username Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        [recordScroll.mj_header endRefreshing];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                data = [response dictionaryForKey:@"data"];
                [self updateXiangqingView];
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools showText:str];
            }
        } else {
            [Tools showText:@"请求失败,请稍后再试."];
        }
    }];
}
@end
