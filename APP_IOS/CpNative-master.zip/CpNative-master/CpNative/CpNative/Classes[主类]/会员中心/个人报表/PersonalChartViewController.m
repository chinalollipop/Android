//
//  GameRecordViewController.m
//  CpNative
//
//  Created by david on 2019/2/11.
//  Copyright © 2019 david. All rights reserved.
//

#import "PersonalChartViewController.h"

@interface PersonalChartViewController ()

@end

@implementation PersonalChartViewController {
    BasicScrollView *recordScroll;
    UIView *recordView;
    
    UILabel *beginDateLbl;
    UILabel *endDateLbl;
    
    UIView *titleView;
    NSInteger currentItemIndex;//当前选中的item
    
    NSInteger typeIndex;//游戏类型的索引
    
    NSDictionary *data;
    NSArray *widths;
    
    NSInteger currentPage;//当前第几页
    NSInteger totalCount;//当前条件下总共有多少条数据
    NSInteger pagesize;//每页请求多少条数据
    NSMutableArray *allRecords;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    topbar.titleLabel.text = @"个人报表";
    currentPage = 1;//初始化当前页码为第1页.
    pagesize = 20;//每页请求的数据条数
    
    recordScroll = [[BasicScrollView alloc] initWithFrame:CGRectMake(0, topbar.bottom, self.view.width, self.view.height-topbar.height)];
    [self.view addSubview:recordScroll];
    
    CGFloat wid = recordScroll.width/2;
    NSArray *titles = @[@"开始日期",@"截止日期",];
    for (int i = 0; i < titles.count; i++) {
        UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(wid*i, 0, wid, widthTo4_7(60))];
        btn.tag = i;
        [btn addTarget:self action:@selector(onDateOrTypeSelection:) forControlEvents:UIControlEventTouchUpInside];
        [recordScroll addSubview:btn];
        
        UILabel *lal = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, wid, widthTo4_7(38))];
        lal.text = titles[i];
        lal.textAlignment = NSTextAlignmentCenter;
        lal.font = SystemFontBy4(12.6);
        lal.textColor = ColorHex(0x333333);
        [btn addSubview:lal];
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, widthTo4_7(30), wid, widthTo4_7(30))];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = SystemFontBy4(12.6);
        label.textColor = ColorHex(0x333333);
        [btn addSubview:label];
        
        UILabel *sign = [[UILabel alloc] initWithFrame:CGRectMake(0.84*wid, widthTo4_7(30), 0.1*wid, widthTo4_7(30))];
        sign.font = FontForSize(14);
        sign.text = UpDown1;
        sign.textColor = ColorHex(0x555555);
        sign.textAlignment = NSTextAlignmentCenter;
        [btn addSubview:sign];
        
        if (i == 0) {
            beginDateLbl = label;
            beginDateLbl.text = [[NSDate date] stringWithFormat:DateFormat_record];
        }
        if (i == 1) {
            endDateLbl = label;
            endDateLbl.text = [[NSDate dateTomorrow] stringWithFormat:DateFormat_record];
        }
    }
    
    titleView = [[UIView alloc] initWithFrame:CGRectMake(0, widthTo4_7(66), recordScroll.width, widthTo4_7(44))];
    titleView.backgroundColor = ColorReset;
    [recordScroll addSubview:titleView];
    NSArray *names = @[@"日期",@"投注总额",@"中奖总额",@"游戏总盈亏",@"详情",];
    widths = @[@"0.23",@"0.21",@"0.215",@"0.235",@"0.11",];
    CGFloat be = 0;
    for (int i = 0; i < names.count; i++) {
        NSString *width = widths[i];
        UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(be, 0, width.floatValue*titleView.width, titleView.height)];
        [btn setTitle:names[i] forState:0];
        [titleView addSubview:btn];
        btn.tag = i;
        [btn setTitleColor:ColorHex(0xffffff) forState:0];
        btn.titleLabel.font = SystemFontBy4(12.6);
        be = btn.right;
    }
    
    recordView = [[UIView alloc] initWithFrame:CGRectMake(0, titleView.bottom, recordScroll.width, 100)];
    [recordScroll addSubview:recordView];
    
    recordScroll.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        currentPage = 1;
        [self requestIsRefresh:YES];
    }];
    
    recordScroll.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        ++currentPage;
        [self requestIsRefresh:NO];
    }];
    
    [recordScroll.mj_header beginRefreshing];
}

- (void)requestIsRefresh:(BOOL)isRefresh {
    
    if (!isRefresh) {
        if (allRecords.count >= totalCount) { //没有更多数据了
            [recordScroll.mj_footer endRefreshingWithNoMoreData];
            return;
        }
    }
    
    currentItemIndex = -1;//索引复位
    
    NSString *page = [NSString stringWithFormat:@"%li",(long)currentPage];
    NSString *sizeOfPage = [NSString stringWithFormat:@"%li",(long)pagesize];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness personalSummaryArBegin:beginDateLbl.text end:endDateLbl.text page:page pageSize:sizeOfPage Block:^(NSError *error, int code, id response)  {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        [recordScroll.mj_header endRefreshing];
        [recordScroll.mj_footer endRefreshing];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                data = [response dictionaryForKey:@"data"];
                NSArray *games = [data arrayForKey:@"user_profits"];
                totalCount = [data integerForKey:@"count"];
                
                if (!allRecords) {
                    allRecords = [[NSMutableArray alloc] init];
                }
                if (isRefresh) {
                    [allRecords removeAllObjects];
                }
                if (games.count) {
                    [allRecords addObjectsFromArray:games];
                }
                if (allRecords.count < totalCount) {
                    [recordScroll.mj_footer resetNoMoreData];//还有更多数据可以加载
                }
                
                [self updateView];
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools showText:str];
            }
        } else {
            [Tools showText:@"请求失败,请稍后再试."];
        }
        
        
    }];
}

- (void)onDateOrTypeSelection:(UIButton *)button {
    if (button.tag == 0) {
        [self showPickerWithTag:0 date:[NSDate date:beginDateLbl.text WithFormat:DateFormat_record]];
    }
    if (button.tag == 1) {
        [self showPickerWithTag:1 date:[NSDate date:endDateLbl.text WithFormat:DateFormat_record]];
    }
}



- (void)showPickerWithTag:(NSInteger)tag date:(NSDate *)date {
    __block __weak UILabel *wBegin = beginDateLbl;
    __block __weak UILabel *wEnd = endDateLbl;
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    WSDatePickerView *datepicker = [[WSDatePickerView alloc] initWithDateStyle:DateStyleShowYearMonthDay scrollToDate:date CompleteBlock:^(NSDate *selectDate,BOOL cancel) {
        if (!cancel) {
            NSString *dateString = [selectDate stringWithFormat:DateFormat_record];
            NSLog(@"选择的日期：%@",dateString);
            if (tag == 0) {
                wBegin.text = dateString;
            }
            if (tag == 1) {
                wEnd.text = dateString;
            }
            currentPage = 1;//页码重置为1
            [self requestIsRefresh:YES];
        }
    }];
    datepicker.dateLabelColor = ColorHex(0xff5733);//年-月-日-时-分 颜色
    datepicker.datePickerColor = ColorHex(0x286be8);//滚轮日期颜色
    datepicker.doneButtonColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;//确定按钮的颜色
    [datepicker setHideBackgroundYearLabel:YES];
    [datepicker setOutOfRangeText:@"仅可查询半年内记录"];
    [datepicker setMinLimitDate:[Tools dateOfHalfYearAgo]];
    [datepicker setMaxLimitDate:[NSDate dateTomorrow]];
    [datepicker show];
}

- (void)updateView {
    [recordView removeAllSubviews];
    
    
    if (!allRecords.count) {
        UILabel *no = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, recordScroll.width, widthTo4_7(80))];
        no.textAlignment = NSTextAlignmentCenter;
        no.text = No_Record_Text;
        no.font = SystemFontBy4(13.6);
        no.textColor = ColorHex(0x888888);
        [recordView addSubview:no];
        recordScroll.contentSize = CGSizeMake(recordScroll.width, recordScroll.height);
        return;
    }
    
    UIColor *color = ColorHex(0x161616);
    UIFont *font = SystemFontBy4(13.0);
    CGFloat offy = 0;
    CGFloat height = widthTo4_7(50);
    for (int i = 0; i < allRecords.count; i++) {
        NSDictionary *dict = allRecords[i];
        
        UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0, offy, recordView.width, height)];
        [button addTarget:self action:@selector(onXiangqing:) forControlEvents:UIControlEventTouchUpInside];
        button.tag = i;
        [recordView addSubview:button];
        
        NSString *width = widths[0];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width.floatValue*recordView.width, height)];
        label.textColor = color;
        label.numberOfLines = 0;
        label.font = font;
        label.textAlignment = NSTextAlignmentCenter;
        label.text = [dict stringForKey:@"date"];
        [button addSubview:label];
        
        width = widths[1];
        label = [[UILabel alloc] initWithFrame:CGRectMake(label.right, 0, width.floatValue*recordView.width, height)];
        label.textColor = color;
        label.numberOfLines = 0;
        label.font = font;
        label.textAlignment = NSTextAlignmentCenter;
        label.text = [[dict stringForKey:@"turnover"] addMoneyDot];
        [button addSubview:label];
        
        width = widths[2];
        label = [[UILabel alloc] initWithFrame:CGRectMake(label.right, 0, width.floatValue*recordView.width, height)];
        label.textColor = color;
        label.numberOfLines = 0;
        label.font = font;
        label.textAlignment = NSTextAlignmentCenter;
        label.text = [[dict stringForKey:@"prize"] addMoneyDot];
        [button addSubview:label];
        
        width = widths[3];
        label = [[UILabel alloc] initWithFrame:CGRectMake(label.right, 0, width.floatValue*recordView.width, height)];
        label.textColor = color;
        label.numberOfLines = 0;
        label.font = font;
        label.textAlignment = NSTextAlignmentCenter;
        label.text = [[dict stringForKey:@"profit"] addMoneyDot];
        [button addSubview:label];
        
        width = widths[4];
        label = [[UILabel alloc] initWithFrame:CGRectMake(label.right, 0, width.floatValue*recordView.width, height)];
        [button addSubview:label];
        
        UIImageView *arrow = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, widthTo4_7(16), widthTo4_7(16))];
        arrow.image = [UIImage imageNamed:@"ceright"];
        [label addSubview:arrow];
        arrow.center = CGPointMake(0.5*label.width, 0.5*label.height);
        
        offy = button.bottom;
        
        if (currentItemIndex == i) {
            [UIView animateWithDuration:0.08 animations:^{
                arrow.transform = CGAffineTransformMakeRotation(M_PI_2);
            }];
            
            NSString *value0 = [dict stringForKey:@"withdrawal"];
            NSString *value1 = [dict stringForKey:@"deposit"];
            NSString *value2 = [dict stringForKey:@"prize"];
            NSString *value3 = [dict stringForKey:@"commission"];
            NSString *value4 = [dict stringForKey:@"lose_commission"];
            
            offy = [self addDetailAt:offy value0:value0 value1:value1 value2:value2 value3:value3 value4:value4 color:color font:font height:button.height];
        }
        
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, offy, recordView.width, widthTo4_7(1.0))];
        line.backgroundColor = LineColor;
        [recordView addSubview:line];
        offy = line.bottom;
    }
    
    UIButton *totalBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, offy, recordView.width, height)];
    totalBtn.backgroundColor = ColorHex(0x7f7f7f);
    [totalBtn addTarget:self action:@selector(onTotal) forControlEvents:UIControlEventTouchUpInside];
    [recordView addSubview:totalBtn];
    
    NSDictionary *sub_total = [data dictionaryForKey:@"sub_total"];
    NSString *width = widths[0];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width.floatValue*recordView.width, totalBtn.height)];
    label.textColor = ColorHex(0xffffff);
    label.backgroundColor = ColorHex(0x699432);
    label.numberOfLines = 0;
    label.font = BoldSystemFontBy4(12.6);
    label.textAlignment = NSTextAlignmentCenter;
    label.text = @"总计";
    [totalBtn addSubview:label];
    
    width = widths[1];
    label = [[UILabel alloc] initWithFrame:CGRectMake(label.right, label.top, width.floatValue*recordView.width, totalBtn.height)];
    label.textColor = ColorHex(0xffffff);
    label.numberOfLines = 0;
    label.font = BoldSystemFontBy4(12.6);;
    label.textAlignment = NSTextAlignmentCenter;
    label.text = [[sub_total stringForKey:@"turnover"] addMoneyDot];
    [totalBtn addSubview:label];
    
    width = widths[2];
    label = [[UILabel alloc] initWithFrame:CGRectMake(label.right, label.top, width.floatValue*recordView.width, totalBtn.height)];
    label.textColor = ColorHex(0xffffff);
    label.numberOfLines = 0;
    label.font = BoldSystemFontBy4(12.6);;
    label.textAlignment = NSTextAlignmentCenter;
    label.text = [[sub_total stringForKey:@"prize"] addMoneyDot];
    [totalBtn addSubview:label];
    
    width = widths[3];
    label = [[UILabel alloc] initWithFrame:CGRectMake(label.right, label.top, width.floatValue*recordView.width, totalBtn.height)];
    label.textColor = ColorHex(0xffffff);
    label.numberOfLines = 0;
    label.font = BoldSystemFontBy4(12.6);;
    label.textAlignment = NSTextAlignmentCenter;
    label.text = [[sub_total stringForKey:@"profit"] addMoneyDot];
    [totalBtn addSubview:label];
    
    width = widths[4];
    label = [[UILabel alloc] initWithFrame:CGRectMake(label.right, label.top, width.floatValue*recordView.width, totalBtn.height)];
    label.backgroundColor = ColorHex(0x7f7f7f);
    [totalBtn addSubview:label];
    
    UIImageView *arrow = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, widthTo4_7(16), widthTo4_7(16))];
    arrow.image = [UIImage imageNamed:@"ceright"];
    [label addSubview:arrow];
    arrow.center = CGPointMake(0.5*label.width, 0.5*label.height);
    
    offy = totalBtn.bottom;
    if (currentItemIndex == 32222) {
        [UIView animateWithDuration:0.08 animations:^{
            arrow.transform = CGAffineTransformMakeRotation(M_PI_2);
        }];
        
        NSString *value0 = [sub_total stringForKey:@"withdrawal"];
        NSString *value1 = [sub_total stringForKey:@"deposit"];
        NSString *value2 = [sub_total stringForKey:@"prize"];
        NSString *value3 = [sub_total stringForKey:@"commission"];
        NSString *value4 = [sub_total stringForKey:@"lose_commission"];
        
        offy = [self addDetailAt:offy value0:value0 value1:value1 value2:value2 value3:value3 value4:value4 color:color font:font height:totalBtn.height];
    }
    recordView.height = offy;
    CGFloat sizeHeight = recordView.top + recordView.height;
    if (sizeHeight < recordScroll.height) {
        sizeHeight = recordScroll.height;
    }
    recordScroll.contentSize = CGSizeMake(recordView.width, sizeHeight);
    
}

- (CGFloat)addDetailAt:(CGFloat)offy value0:(NSString *)value0 value1:(NSString *)value1 value2:(NSString *)value2 value3:(NSString *)value3 value4:(NSString *)value4 color:(UIColor *)color font:(UIFont *)font height:(CGFloat)height {
    CGFloat left0 = widthTo4_7(13);
    CGFloat left1 = 0.26*self.view.width;
    CGFloat left2 = 0.5*self.view.width+widthTo4_7(13);
    CGFloat left3 = 0.76*self.view.width;
    
    UIView *kView = [[UIView alloc] initWithFrame:CGRectMake(0, offy, self.view.width, height)];
    kView.backgroundColor = ColorHex(0xf0f0f0);
    [recordView addSubview:kView];
    
    UILabel *aLabel = [[UILabel alloc] initWithFrame:CGRectMake(left0, 0, 300, kView.height)];
    aLabel.textColor = color;
    aLabel.font = font;
    aLabel.text = @"提款";
    [kView addSubview:aLabel];
    
    aLabel = [[UILabel alloc] initWithFrame:CGRectMake(left1, 0, 300, kView.height)];
    aLabel.textColor = color;
    aLabel.font = font;
    aLabel.text = [value0 addMoneyDot];
    [kView addSubview:aLabel];
    
    aLabel = [[UILabel alloc] initWithFrame:CGRectMake(left2, 0, 300, kView.height)];
    aLabel.textColor = color;
    aLabel.font = font;
    aLabel.text = @"充值";
    [kView addSubview:aLabel];
    
    aLabel = [[UILabel alloc] initWithFrame:CGRectMake(left3, 0, 300, kView.height)];
    aLabel.textColor = color;
    aLabel.font = font;
    aLabel.text = [value1 addMoneyDot];
    [kView addSubview:aLabel];
    
    offy = kView.bottom + widthTo4_7(0.8);
    
    kView = [[UIView alloc] initWithFrame:CGRectMake(0, offy, self.view.width, height)];
    kView.backgroundColor = ColorHex(0xf0f0f0);
    [recordView addSubview:kView];
    
    aLabel = [[UILabel alloc] initWithFrame:CGRectMake(left0, 0, 300, kView.height)];
    aLabel.textColor = color;
    aLabel.font = font;
    aLabel.text = @"中奖总额";
    [kView addSubview:aLabel];
    
    aLabel = [[UILabel alloc] initWithFrame:CGRectMake(left1, 0, 300, kView.height)];
    aLabel.textColor = color;
    aLabel.font = font;
    aLabel.text = [value2 addMoneyDot];
    [kView addSubview:aLabel];
    
    aLabel = [[UILabel alloc] initWithFrame:CGRectMake(left2, 0, 300, kView.height)];
    aLabel.textColor = color;
    aLabel.font = font;
    aLabel.text = @"代理返点";
    [kView addSubview:aLabel];
    
    aLabel = [[UILabel alloc] initWithFrame:CGRectMake(left3, 0, 300, kView.height)];
    aLabel.textColor = color;
    aLabel.font = font;
    aLabel.text = [value3 addMoneyDot];
    [kView addSubview:aLabel];
    
    offy = kView.bottom + widthTo4_7(0.8);
    
    kView = [[UIView alloc] initWithFrame:CGRectMake(0, offy, self.view.width, height)];
    kView.backgroundColor = ColorHex(0xf0f0f0);
    [recordView addSubview:kView];
    
    aLabel = [[UILabel alloc] initWithFrame:CGRectMake(left0, 0, 300, kView.height)];
    aLabel.textColor = color;
    aLabel.font = font;
    aLabel.text = @"投注返点";
    [kView addSubview:aLabel];
    
    aLabel = [[UILabel alloc] initWithFrame:CGRectMake(left1, 0, 300, kView.height)];
    aLabel.textColor = color;
    aLabel.font = font;
    aLabel.text = [value4 addMoneyDot];
    [kView addSubview:aLabel];
    
    offy = kView.bottom;
    return offy;
}


- (void)onXiangqing:(UIButton *)button {
    if (currentItemIndex == button.tag) {
        currentItemIndex = -1;
    } else {
        currentItemIndex = button.tag;
    }
    [self updateView];
}

- (void)onTotal {
    if (currentItemIndex == 32222) {
        currentItemIndex = -1;
    } else {
        currentItemIndex = 32222;
    }
    [self updateView];
}

@end
