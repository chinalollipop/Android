//
//  RegisterManageViewController.m
//  CpNative
//
//  Created by david on 2019/1/28.
//  Copyright © 2019 david. All rights reserved.
//

#import "RegisterManageViewController.h"
#import "ZJSwitch.h"

@interface RegisterManageViewController ()

@end

@implementation RegisterManageViewController {
    BasicScrollView *scrollview;
    IQPreviousNextView *iqView;
    
    CGFloat lineHeight;
    CGFloat beginLeft;
    UILabel *typeLabel;
    NSInteger selectedTypeIndex;
    
    UITextField *tfNichen;
    UITextField *tfAccount;
    UITextField *tfPass;
    UITextField *tfPass2;
    ZJSwitch *paySwitch;
    
    UIView *redBar;//红条
    CGRect redBarRect0;
    CGRect redBarRect1;
    
    //切换的2个视图
    UIView *switchView0;
    UIView *switchView1;
    NSInteger currentSwitch;
    
    UILabel *bounesLabel;//其它奖金组
    NSString *currentGroup;
    
    //数据
    NSArray *aAllPossibleAgentPrizeGroups;//其它奖金组，所有奖金组 (代理)
    NSMutableArray *otherGroupNamesAgent;//picker的名字数组 (代理)
    NSInteger selectedOtherBounesIndexAgent;//其它奖金组的picker的索引(选中了第几个) (代理)
    
    NSArray *aAllPossiblePrizeGroups;//其它奖金组 ，所有奖金组（会员）
    NSMutableArray *otherGroupNamesMember;//picker的名字数组 (会员)
    NSInteger selectedOtherBounesIndexMember;//其它奖金组的picker的索引(选中了第几个) （会员）
}

- (void)viewDidLoad {
    [super viewDidLoad];
    topbar.titleLabel.text = @"注册管理";
    
    scrollview = [[BasicScrollView alloc] initWithFrame:CGRectMake(0, topbar.height, self.view.width, self.view.height-topbar.height)];
    [self.view addSubview:scrollview];
    
    lineHeight = widthTo4_7(56);
    beginLeft = 0.31*self.view.width;
    CGFloat offY = 0;
    
    //用户类型
    [scrollview addSubview:[self typeLabelWithText:@"用户类型:" y:offY]];
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(beginLeft, offY, scrollview.width-beginLeft, lineHeight)];
    [btn addTarget:self action:@selector(onTypeSelect) forControlEvents:UIControlEventTouchUpInside];
    btn.backgroundColor = ColorHex(0xeaeaea);
    btn.layer.cornerRadius = 0.09*btn.height;
    btn.layer.masksToBounds = YES;
    [scrollview addSubview:btn];
    btn.top += widthTo4_7(6);
    btn.height -= widthTo4_7(12);
    btn.width -= widthTo4_7(6);
    typeLabel = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(10), 0, 100, btn.height)];
    typeLabel.font = SystemFontBy4(14.6);
    typeLabel.textColor = ColorHex(0x202020);
    typeLabel.text = @"代理";
    [btn addSubview:typeLabel];
    UILabel *draw1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, btn.height*1.0, btn.height)];
    draw1.font = FontForSize(17);
    draw1.text = Down_Arrow;
    draw1.textColor = ColorHex(0x161616);
    [btn addSubview:draw1];
    draw1.textAlignment = NSTextAlignmentCenter;
    draw1.right = btn.width;
    
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, lineHeight, scrollview.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [scrollview addSubview:line];
    offY = line.bottom;
    
    iqView = [[IQPreviousNextView alloc] initWithFrame:CGRectMake(0, offY, scrollview.width, lineHeight*4+4.0)];
    [scrollview addSubview:iqView];
    offY = iqView.bottom;
    
    //用户昵称
    [iqView addSubview:[self typeLabelWithText:@"用户昵称:" y:0]];
    tfNichen = [[UITextField alloc] initWithFrame:CGRectMake(beginLeft, 0, scrollview.width-beginLeft-widthTo4_7(5), lineHeight)];
    tfNichen.clearButtonMode = UITextFieldViewModeWhileEditing;
    tfNichen.textColor = ColorHex(0x202020);
    tfNichen.font = SystemFontBy4(14.6);
    tfNichen.placeholder = @"请输入昵称，2-16字符";
    [iqView addSubview:tfNichen];
    line = [[UIView alloc] initWithFrame:CGRectMake(0, lineHeight, scrollview.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [iqView addSubview:line];
    
    //登录账号
    [iqView addSubview:[self typeLabelWithText:@"登录账号:" y:line.bottom]];
    tfAccount = [[UITextField alloc] initWithFrame:CGRectMake(beginLeft, line.bottom, scrollview.width-beginLeft-widthTo4_7(5), lineHeight)];
    tfAccount.clearButtonMode = UITextFieldViewModeWhileEditing;
    tfAccount.textColor = ColorHex(0x202020);
    tfAccount.font = SystemFontBy4(14.6);
    tfAccount.placeholder = @"只能是数字和字母，6-16位";
    tfAccount.autocapitalizationType = UITextAutocapitalizationTypeNone;
    tfAccount.autocorrectionType = UITextAutocorrectionTypeNo;
    [iqView addSubview:tfAccount];
    line = [[UIView alloc] initWithFrame:CGRectMake(0, tfAccount.bottom, scrollview.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [iqView addSubview:line];
    
    //用户密码
    [iqView addSubview:[self typeLabelWithText:@"用户密码:" y:line.bottom]];
    tfPass = [[UITextField alloc] initWithFrame:CGRectMake(beginLeft, line.bottom, scrollview.width-beginLeft-widthTo4_7(5), lineHeight)];
    tfPass.clearButtonMode = UITextFieldViewModeWhileEditing;
    tfPass.textColor = ColorHex(0x202020);
    tfPass.font = SystemFontBy4(14.6);
    tfPass.placeholder = @"由数字和字母组成，6-16位";
    [iqView addSubview:tfPass];
    tfPass.secureTextEntry = YES;
    line = [[UIView alloc] initWithFrame:CGRectMake(0, tfPass.bottom, scrollview.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [iqView addSubview:line];
    
    //重复密码
    [iqView addSubview:[self typeLabelWithText:@"重复密码:" y:line.bottom]];
    tfPass2 = [[UITextField alloc] initWithFrame:CGRectMake(beginLeft, line.bottom, scrollview.width-beginLeft-widthTo4_7(5), lineHeight)];
    tfPass2.clearButtonMode = UITextFieldViewModeWhileEditing;
    tfPass2.textColor = ColorHex(0x202020);
    tfPass2.font = SystemFontBy4(14.6);
    tfPass2.placeholder = @"请再次输入密码";
    [iqView addSubview:tfPass2];
    tfPass2.secureTextEntry = YES;
    line = [[UIView alloc] initWithFrame:CGRectMake(0, tfPass2.bottom, scrollview.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [iqView addSubview:line];
    
    //出款通知
    [scrollview addSubview:[self typeLabelWithText:@"出款通知:" y:offY]];
    paySwitch = [[ZJSwitch alloc] initWithFrame:CGRectMake(0, 0, widthTo4_7(48), widthTo4_7(26))];
    [scrollview addSubview:paySwitch];
    paySwitch.center = CGPointMake(0.88*scrollview.width, offY+0.5*lineHeight);
    paySwitch.style = ZJSwitchStyleNoBorder;
    paySwitch.onTintColor = ColorHexWithAlpha(0x49df4d, 1.0);
    paySwitch.tintColor = ColorHexWithAlpha(0x000000, 0.35);
    paySwitch.thumbTintColorOff = ColorHex(0xffffff);
    paySwitch.thumbTintColorOn = ColorHex(0xffffff);
    [paySwitch setOn:YES];
    [paySwitch addTarget:self action:@selector(onSwitch:) forControlEvents:UIControlEventValueChanged];
    line = [[UIView alloc] initWithFrame:CGRectMake(0, offY+lineHeight, scrollview.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [scrollview addSubview:line];
    offY = line.bottom+widthTo4_7(1.0);
    
    UIView *bg = [[UIView alloc] initWithFrame:CGRectMake(0, offY, scrollview.width, lineHeight)];
    bg.backgroundColor = ColorHex(0xeaeaea);
    [scrollview addSubview:bg];
    UIButton *btn0 = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 0.5*bg.width, bg.height)];
    btn0.tag = 0;
    [btn0 setTitle:@"配额奖金组" forState:0];
    [btn0 setTitleColor:ColorHex(0xc9262e) forState:0];
    btn0.titleLabel.font = BoldSystemFontBy4(14.6);
    [btn0 addTarget:self action:@selector(onBonusButton:) forControlEvents:UIControlEventTouchUpInside];
    [bg addSubview:btn0];
    UIButton *btn1 = [[UIButton alloc] initWithFrame:CGRectMake(0.5*bg.width, 0, 0.5*bg.width, bg.height)];
    btn1.tag = 1;
    [btn1 setTitle:@"其它奖金组" forState:0];
    [btn1 setTitleColor:ColorHex(0xc9262e) forState:0];
    btn1.titleLabel.font = BoldSystemFontBy4(14.6);
    [btn1 addTarget:self action:@selector(onBonusButton:) forControlEvents:UIControlEventTouchUpInside];
    [bg addSubview:btn1];
    
    CGSize size = [btn0.titleLabel.text getContentSizeWithFont:btn0.titleLabel.font andWidth:20000 andHeight:20];
    redBarRect0 = CGRectMake((btn0.width-size.width)/2, 0.76*btn0.height, size.width, widthTo4_7(3.0));
    redBarRect1 = CGRectMake((btn1.width-size.width)/2+btn0.width, 0.76*btn0.height, size.width, widthTo4_7(3.0));
    redBar = [[UIView alloc] initWithFrame:redBarRect0];
    redBar.backgroundColor = ColorHex(0xc9262e);
    [bg addSubview:redBar];
    
    switchView0 = [[UIView alloc] initWithFrame:CGRectMake(0, bg.bottom, scrollview.width, 1)];
    [scrollview addSubview:switchView0];
    switchView1 = [[UIView alloc] initWithFrame:CGRectMake(0, bg.bottom, scrollview.width, 1)];
    [scrollview addSubview:switchView1];
    [self buildSwitchview0];
    [self buildSwitchview1];
    
    [self onBonusButton:btn0];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness registerManageBlock:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                NSDictionary *data = [response dictionaryForKey:@"data"];
                aAllPossibleAgentPrizeGroups = [data arrayForKey:@"aAllPossibleAgentPrizeGroups"];
                aAllPossiblePrizeGroups = [data arrayForKey:@"aAllPossiblePrizeGroups"];
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools alertWithTitle:str message:nil handle:^(UIAlertAction * _Nonnull action) {
                    [self.navigationController popViewControllerAnimated:YES];
                } cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求失败,请稍后再试."];
        }
    }];
    
}

- (void)buildSwitchview0 {
    UIView *bg = [[UIView alloc] initWithFrame:CGRectMake(0, 0, switchView0.width, widthTo4_7(44))];
    bg.backgroundColor = ColorReset;
    [switchView0 addSubview:bg];
    NSArray *titles = @[@"当前奖金",@"返点率",@"剩余配额",@"操作",];
    for (int i = 0; i < titles.count; i++) {
        UILabel *lab = [[UILabel alloc] initWithFrame:CGRectMake(bg.width/4*i, 0, bg.width/4, bg.height)];
        lab.text = titles[i];
        [bg addSubview:lab];
        lab.textAlignment = NSTextAlignmentCenter;
        lab.textColor = [UIColor whiteColor];
        lab.font = BoldSystemFontBy4(13.6);
        [bg addSubview:lab];
    }
    
    UIButton *registerBtn = [[UIButton alloc] initWithFrame:CGRectMake(0.15*switchView0.width, bg.bottom+widthTo4_7(30), 0.7*switchView0.width, widthTo4_7(44))];
    registerBtn.tag = 0;
    [registerBtn addTarget:self action:@selector(onRegiser:) forControlEvents:UIControlEventTouchUpInside];
    [registerBtn setTitle:@"注册账户" forState:0];
    [registerBtn setTitleColor:[UIColor whiteColor] forState:0];
    registerBtn.titleLabel.font = BoldSystemFontBy4(14.6);
    registerBtn.backgroundColor = ColorHex(0xc9262e);
    registerBtn.layer.cornerRadius = 0.07*registerBtn.height;
    registerBtn.layer.masksToBounds = YES;
    [switchView0 addSubview:registerBtn];
    switchView0.height = registerBtn.bottom + widthTo4_7(22);
}

- (void)buildSwitchview1 {
    [switchView1 addSubview:[self typeLabelWithText:@"设置奖金:" y:0]];
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(beginLeft, 0, scrollview.width-beginLeft, lineHeight)];
    [btn addTarget:self action:@selector(onOtherBonus) forControlEvents:UIControlEventTouchUpInside];
    btn.backgroundColor = ColorHex(0xeaeaea);
    btn.layer.cornerRadius = 0.09*btn.height;
    btn.layer.masksToBounds = YES;
    [switchView1 addSubview:btn];
    btn.top += widthTo4_7(6);
    btn.height -= widthTo4_7(12);
    btn.width -= widthTo4_7(6);
    bounesLabel = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(10), 0, 290, btn.height)];
    bounesLabel.font = SystemFontBy4(14.6);
    bounesLabel.textColor = ColorHex(0x202020);
    bounesLabel.text = @"选择其它奖金组";
    [btn addSubview:bounesLabel];
    UILabel *draw1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, btn.height*1.0, btn.height)];
    draw1.font = FontForSize(17);
    draw1.text = Down_Arrow;
    draw1.textColor = ColorHex(0x161616);
    [btn addSubview:draw1];
    draw1.textAlignment = NSTextAlignmentCenter;
    draw1.right = btn.width;
    
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, lineHeight, scrollview.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [switchView1 addSubview:line];
    
    UILabel *notice = [[UILabel alloc] initWithFrame:CGRectMake(0, line.bottom, switchView1.width, lineHeight)];
    notice.textAlignment = NSTextAlignmentCenter;
    notice.textColor = ColorHex(0xe79532);
    notice.font = SystemFontBy4(13);
    notice.text = @"奖金组一旦上调后则无法降低，请谨慎操作!";
    [switchView1 addSubview:notice];
    
    UIButton *registerBtn = [[UIButton alloc] initWithFrame:CGRectMake(0.15*switchView0.width, notice.bottom+widthTo4_7(10), 0.7*switchView0.width, widthTo4_7(44))];
    [registerBtn setTitle:@"注册账户" forState:0];
    registerBtn.tag = 1;
    [registerBtn addTarget:self action:@selector(onRegiser:) forControlEvents:UIControlEventTouchUpInside];
    [registerBtn setTitleColor:[UIColor whiteColor] forState:0];
    registerBtn.titleLabel.font = BoldSystemFontBy4(14.6);
    registerBtn.backgroundColor = ColorHex(0xc9262e);
    registerBtn.layer.cornerRadius = 0.07*registerBtn.height;
    registerBtn.layer.masksToBounds = YES;
    [switchView1 addSubview:registerBtn];
    switchView1.height = registerBtn.bottom + widthTo4_7(22);
}

- (void)onRegiser:(UIButton *)button {
    if (!tfNichen.text.length) {
        [Tools showText:@"请填写用户昵称"];
        return;
    }
    if (!tfAccount.text.length) {
        [Tools showText:@"请填写登录账户"];
        return;
    }
    if (!tfPass.text.length) {
        [Tools showText:@"请填写用户密码"];
        return;
    }
    if (!tfPass2.text.length) {
        [Tools showText:@"请再次输入用户密码"];
        return;
    }
    if (![tfPass.text isEqualToString:tfPass2.text]) {
        [Tools showText:@"重复密码与用户密码不一致"];
        return;
    }
    
    
    
    
    if (button.tag == 0) {//  TODO：配额奖金组
        [Tools showText:@"当前只能使用“其它奖金组”"];
    }
    
    if (button.tag == 1) {//  其它奖金组
        NSDictionary *dict;
        if (selectedTypeIndex == 0) {
            if (selectedOtherBounesIndexAgent == 0) {
                [Tools showText:@"请选择其它奖金组"];
                return;
            }
            dict = aAllPossibleAgentPrizeGroups[selectedOtherBounesIndexAgent-1];
        } else {
            if (selectedOtherBounesIndexMember == 0) {
                [Tools showText:@"请选择其它奖金组"];
                return;
            }
            dict = aAllPossiblePrizeGroups[selectedOtherBounesIndexMember-1];
        }
        
        NSString *name = [dict stringForKey:@"name"];
        
        NSString *is_agent = ((selectedTypeIndex==0)?(@"1"):(@"0"));
        NSString *prize_group_id = [dict stringForKey:@"id"];
        NSString *prize_group_type = [dict stringForKey:@"type"];
        NSString *agent_prize_set_quota = @"{}";
        NSString *username = tfAccount.text;
        NSString *password = tfPass.text;
        NSString *nickname = tfNichen.text;
        NSString *series_id = @"";
        NSString *lottery_id = @"";
        NSString *series_prize_group_json = [NSString stringWithFormat:@"{\"%@\":%@}",prize_group_type,name];
        NSString *fb_single = @"0.0";
        NSString *fb_all = @"0.0";
        
        UIView *bgview = [[UIView alloc] initWithFrame:self.view.frame];
        bgview.backgroundColor = ColorHexWithAlpha(0x000000, 0.5);
        [self.view addSubview:bgview];
        UIView *content = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.width, widthTo4_7(355))];
        content.backgroundColor = [UIColor whiteColor];
        [bgview addSubview:content];
        content.center = CGPointMake(0.5*bgview.width, 0.5*bgview.height);
        content.layer.cornerRadius = widthTo4_7(5);
        content.layer.masksToBounds = YES;
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, content.width, widthTo4_7(50))];
        label.font = SystemFontBy4(14.6);;
        label.textColor = ColorHex(0xf79a00);
        label.text = @"⚠️请核对开户信息";
        label.textAlignment = NSTextAlignmentCenter;
        [content addSubview:label];
        
        UIView *quota = [[UIView alloc] initWithFrame:CGRectMake(widthTo4_7(13), label.bottom, content.width-widthTo4_7(26), widthTo4_7(160))];
        quota.layer.borderColor = LineColor.CGColor;
        quota.layer.borderWidth = widthTo4_7(1.0);
        [content addSubview:quota];
        label = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(26), widthTo4_7(8), 100, widthTo4_7(36))];
        label.text = @"用户类型";
        label.textColor = ColorHex(0x161616);
        label.font = SystemFontBy4(14);
        [quota addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(0.5*quota.width, label.top, 200, widthTo4_7(36))];
        label.text = ((selectedTypeIndex==0)?(@"代理"):(@"会员"));
        label.textColor = ColorHex(0x161616);
        label.font = SystemFontBy4(14);
        [quota addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(26), label.bottom, 100, widthTo4_7(36))];
        label.text = @"登录账号";
        label.textColor = ColorHex(0x161616);
        label.font = SystemFontBy4(14);
        [quota addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(0.5*quota.width, label.top, 200, widthTo4_7(36))];
        label.text = username;
        label.textColor = ColorHex(0x161616);
        label.font = SystemFontBy4(14);
        [quota addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(26), label.bottom, 100, widthTo4_7(36))];
        label.text = @"登录密码";
        label.textColor = ColorHex(0x161616);
        label.font = SystemFontBy4(14);
        [quota addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(0.5*quota.width, label.top, 200, widthTo4_7(36))];
        label.text = password;
        label.textColor = ColorHex(0x161616);
        label.font = SystemFontBy4(14);
        [quota addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(26), label.bottom, 100, widthTo4_7(36))];
        label.text = @"用户昵称";
        label.textColor = ColorHex(0x161616);
        label.font = SystemFontBy4(14);
        [quota addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(0.5*quota.width, label.top, 200, widthTo4_7(36))];
        label.text = nickname;
        label.textColor = ColorHex(0x161616);
        label.font = SystemFontBy4(14);
        [quota addSubview:label];
        
        UIView *quota2 = [[UIView alloc] initWithFrame:CGRectMake(quota.left, quota.bottom + widthTo4_7(10), quota.width, widthTo4_7(70))];
        quota2.layer.borderColor = LineColor.CGColor;
        quota2.layer.borderWidth = widthTo4_7(1.0);
        [content addSubview:quota2];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, quota2.width, 0.65*quota2.height)];
        label.text = @"数字彩金组";
        label.textAlignment = NSTextAlignmentCenter;
        label.textColor = ColorHex(0x161616);
        label.font = SystemFontBy4(14);
        [quota2 addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0.35*quota2.height, quota2.width, 0.65*quota2.height)];
        label.text = currentGroup;
        label.textAlignment = NSTextAlignmentCenter;
        label.textColor = ColorHex(0x161616);
        label.font = SystemFontBy4(14);
        [quota2 addSubview:label];
        
        UIButton *submit = [[UIButton alloc] initWithFrame:CGRectMake(quota.left, quota2.bottom+widthTo4_7(10), (quota.width-widthTo4_7(12))/2, widthTo4_7(44))];
        [submit setTitle:@"开户" forState:0];
        [submit setTitleColor:ColorHex(0xffffff) forState:0];
        submit.titleLabel.font = SystemFontBy4(14.6);
        submit.backgroundColor = ColorGreen;
        submit.layer.cornerRadius = 0.1*submit.height;
        submit.layer.masksToBounds = YES;
        [content addSubview:submit];
        [submit handleCallBack:^(UIButton *button) {
            [MBProgressHUD showHUDAddedTo:mainDelegate.window animated:NO];
            [NetworkBusiness registerManageForAgent:is_agent prizeGroupId:prize_group_id prizeGroupType:prize_group_type agent_quota:agent_prize_set_quota name:username pass:password nick:nickname series_id:series_id lotteryId:lottery_id prizeGroupJson:series_prize_group_json fbSingle:fb_single fbAll:fb_all Block:^(NSError *error, int code, id response) {
                [MBProgressHUD hideHUDForView:mainDelegate.window animated:NO];
                
                /*判断是否重新登录*/
                if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
                    return;
                }
                
                if (code == 200) {
                    NSInteger err = [response integerForKey:@"errno"];
                    if (err == 0) {
                        [Tools alertWithTitle:@"注册成功!" message:@"" handle:^(UIAlertAction * _Nonnull action) {
                            [bgview removeFromSuperview];
                        } cancel:nil confirm:@"确定"];
                    } else {
                        NSString *str = [response stringForKey:@"error"];
                        if (!str.length) {
                            str = @"请求失败,请稍后再试。";
                        }
                        [Tools alertWithTitle:str message:nil handle:nil cancel:nil confirm:@"确定"];
                    }
                } else {
                    [Tools showText:@"请求失败,请稍后再试."];
                }
            }];
        } forEvent:UIControlEventTouchUpInside];
        
        UIButton *reset = [[UIButton alloc] initWithFrame:CGRectMake(submit.right+widthTo4_7(12), submit.top, submit.width, submit.height)];
        [reset setTitle:@"取消" forState:0];
        [reset setTitleColor:ColorHex(0xffffff) forState:0];
        reset.titleLabel.font = SystemFontBy4(14.6);
        reset.backgroundColor = ColorHex(0x444443);
        reset.layer.cornerRadius = 0.1*reset.height;
        reset.layer.masksToBounds = YES;
        [content addSubview:reset];
        [reset handleCallBack:^(UIButton *button) {
            [UIView animateWithDuration:0.2 animations:^{
                bgview.alpha = 0.f;
            } completion:^(BOOL finished) {
                [bgview removeFromSuperview];
            }];
        } forEvent:UIControlEventTouchUpInside];
        
        
        bgview.alpha = 0.f;
        [UIView animateWithDuration:0.2 animations:^{
            bgview.alpha = 1.f;
        }];
        
        
        
        
        
        
        
        
        
    }
}



- (void)onSwitch:(ZJSwitch *)control {
    NSLog(@"是否出款通知:%i",control.isOn);
}

/*选择用户类型*/
- (void)onTypeSelect {
    __block NSArray *types = @[@"代理",@"会员"];
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    WSDatePickerView *datepicker = [[WSDatePickerView alloc] initWithDateStyle:DateStyleShowBank data:types scrollToIndex:selectedTypeIndex CompleteBlock:^(NSInteger tag, BOOL cancel) {
        if (cancel) {
            NSLog(@"CANCEL.....");
        } else {
            selectedTypeIndex = tag;
            NSString *title = types[selectedTypeIndex];
            typeLabel.text = title;
            
            selectedOtherBounesIndexAgent = 0;
            selectedOtherBounesIndexMember = 0;
            bounesLabel.text = @"选择其它奖金组";
        }
    }];
    
    datepicker.dateLabelColor = ColorHex(0xff5733);//年-月-日-时-分 颜色
    datepicker.datePickerColor = ColorHex(0x286be8);//滚轮日期颜色
    datepicker.doneButtonColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;//确定按钮的颜色
    [datepicker setHideBackgroundYearLabel:YES];
    [datepicker show];
}


/*选择其它奖金组*/
- (void)onOtherBonus {
    NSArray *names;
    if (selectedTypeIndex == 0) {
        if (!otherGroupNamesAgent) {
            otherGroupNamesAgent = [[NSMutableArray alloc] init];
            [otherGroupNamesAgent addObject:@"选择其它奖金组"];
            
            for (int i = 0; i < aAllPossibleAgentPrizeGroups.count; i++) {
                NSDictionary *dict = aAllPossibleAgentPrizeGroups[i];
                CGFloat water = [dict floatForKey:@"water"];
                NSString *name = [dict stringForKey:@"name"];
                NSString *goup = [NSString stringWithFormat:@"%.2f%% ---- %@",(water*100),name];
                [otherGroupNamesAgent addObject:goup];
            }
        }
        names = otherGroupNamesAgent;
    } else {
        if (!otherGroupNamesMember) {
            otherGroupNamesMember = [[NSMutableArray alloc] init];
            [otherGroupNamesMember addObject:@"选择其它奖金组"];
            
            for (int i = 0; i < aAllPossiblePrizeGroups.count; i++) {
                NSDictionary *dict = aAllPossiblePrizeGroups[i];
                CGFloat water = [dict floatForKey:@"water"];
                NSString *name = [dict stringForKey:@"name"];
                NSString *goup = [NSString stringWithFormat:@"%.2f%% ---- %@",(water*100),name];
                [otherGroupNamesMember addObject:goup];
            }
        }
        names = otherGroupNamesMember;
    }

    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    WSDatePickerView *datepicker = [[WSDatePickerView alloc] initWithDateStyle:DateStyleShowBank data:names scrollToIndex:((selectedTypeIndex==0)?selectedOtherBounesIndexAgent:selectedOtherBounesIndexMember) CompleteBlock:^(NSInteger tag, BOOL cancel) {
        if (cancel) {
            NSLog(@"CANCEL.....");
        } else {
            if (selectedTypeIndex==0) {
                selectedOtherBounesIndexAgent = tag;
                currentGroup = otherGroupNamesAgent[selectedOtherBounesIndexAgent];
                bounesLabel.text = currentGroup;
            } else {
                selectedOtherBounesIndexMember = tag;
                NSString *title = otherGroupNamesMember[selectedOtherBounesIndexMember];
                bounesLabel.text = title;
            }
        }
    }];
    
    datepicker.dateLabelColor = ColorHex(0xff5733);//年-月-日-时-分 颜色
    datepicker.datePickerColor = ColorHex(0x286be8);//滚轮日期颜色
    datepicker.doneButtonColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;//确定按钮的颜色
    [datepicker setHideBackgroundYearLabel:YES];
    [datepicker show];
}

/*切换奖金组*/
- (void)onBonusButton:(UIButton *)button {
    currentSwitch = button.tag;
    if (button.tag == 0) {
        redBar.frame = redBarRect0;
        switchView0.hidden = NO;
        switchView1.hidden = YES;
        scrollview.contentSize = CGSizeMake(scrollview.width, switchView0.bottom);
    }
    if (button.tag == 1) {
        redBar.frame = redBarRect1;
        switchView0.hidden = YES;
        switchView1.hidden = NO;
        scrollview.contentSize = CGSizeMake(scrollview.width, switchView1.bottom);
    }
}

- (UILabel *)typeLabelWithText:(NSString *)text y:(CGFloat)y {
    UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(8), y, 120, lineHeight)];
    lbl.font = SystemFontBy4(14.6);
    lbl.textColor = ColorHex(0x202020);
    lbl.text = text;
    return lbl;
}


@end












