//
//  MessageBoxViewController.m
//  CpNative
//
//  Created by david on 2019/3/20.
//  Copyright © 2019 david. All rights reserved.
//

#import "MessageBoxViewController.h"
#import "MessageDetailViewController.h"

@interface MessageBoxViewController ()

@end

@implementation MessageBoxViewController {
    BasicScrollView *scrollM;
    UIView *contentView;
    NSArray *data;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    topbar.titleLabel.text = @"站内信";
    
    scrollM = [[BasicScrollView alloc] initWithFrame:CGRectMake(0, topbar.bottom, self.view.width, self.view.height-topbar.bottom)];
    [self.view addSubview:scrollM];
    
    contentView = [[UIView alloc] initWithFrame:scrollM.bounds];
    [scrollM addSubview:contentView];
    
    scrollM.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self requestList];
    }];
    [scrollM.mj_header beginRefreshing];
}

- (void)requestList {
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness messageInboxBlock:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        [scrollM.mj_header endRefreshing];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                NSDictionary *temp = [response dictionaryForKey:@"data"];
                data = [temp arrayForKey:@"list"];
                [self updateUI];
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools alertWithTitle:str message:nil handle:^(UIAlertAction * _Nonnull action) {
                    
                } cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求服务失败,请稍后再试."];
        }
    }];
}

- (void)updateUI {
    [contentView removeAllSubviews];
    
    if (!data.count) {
        UILabel *no = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, contentView.width, widthTo4_7(80))];
        no.textAlignment = NSTextAlignmentCenter;
        no.text = No_Record_Text;
        no.font = SystemFontBy4(13.6);
        no.textColor = ColorHex(0x888888);
        [contentView addSubview:no];
        scrollM.contentSize = CGSizeMake(contentView.width, scrollM.height);
        return;
    }
    
    CGFloat height = widthTo4_7(70);
    CGFloat gap = widthTo4_7(8);
    UIFont *font = SystemFontBy4(13.0);
    UIFont *fontt = SystemFontBy4(12.0);
    UIColor *color = ColorHex(0x222222);
    UIColor *colort = ColorHex(0x666666);
    UIImage *image = [UIImage imageNamed:@"logo"];
    CGFloat iw = image.size.width/image.size.height*(height-gap*2);
    CGFloat offy = widthTo4_7(6);
    for (int i = 0; i < data.count; i++) {
        NSDictionary *dict = data[i];
        
        UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0, offy, contentView.width, height)];
        [button addTarget:self action:@selector(onButton:) forControlEvents:UIControlEventTouchUpInside];
        [contentView addSubview:button];
        button.tag = i;
        button.backgroundColor = ColorHex(0xf5f5f5);
        
        UIImageView *imageview = [[UIImageView alloc] initWithFrame:CGRectMake(gap, gap, iw, height-gap*2)];
        imageview.image = image;
        [button addSubview:imageview];
        
        UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(imageview.right+gap*1.4, gap, 0.75*contentView.width-(imageview.right+gap*2), imageview.height)];
        title.font = font;
        title.textColor = color;
        title.text = [dict stringForKey:@"msg_title"];
        [button addSubview:title];
        title.numberOfLines = 0;
        
        NSString *time = [dict stringForKey:@"created_at"];
        time = [time stringByReplacingOccurrencesOfString:@" " withString:@"\n"];
        UILabel *tLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.75*contentView.width, gap, 0.25*contentView.width, imageview.height)];
        tLabel.text = time;
        tLabel.numberOfLines = 0;
        tLabel.font = fontt;
        tLabel.textColor = colort;
        tLabel.textAlignment = NSTextAlignmentCenter;
        [button addSubview:tLabel];
        
        offy = button.bottom + widthTo4_7(6);
    }
    
    CGFloat hhh = height*data.count;
    if (hhh < contentView.height) {
        hhh = contentView.height;
    }
    contentView.height = hhh;
    hhh = contentView.height + widthTo4_7(24);
    if (hhh < scrollM.height) {
        hhh = scrollM.height;
    }
    scrollM.contentSize = CGSizeMake(contentView.width, hhh);
}

- (void)onButton:(UIButton *)button {
    NSDictionary *dict = data[button.tag];
    NSString *_id = [dict stringForKey:@"id"];
    if (_id.length) {
        MessageDetailViewController *detail = [[MessageDetailViewController alloc] init];
        detail._id = _id;
        [self.navigationController pushViewController:detail animated:YES];
    }
    
    
}


@end
