//
//  MessageDetailViewController.m
//  CpNative
//
//  Created by david on 2019/3/20.
//  Copyright © 2019 david. All rights reserved.
//

#import "MessageDetailViewController.h"

@interface MessageDetailViewController ()<WKNavigationDelegate>

@end

@implementation MessageDetailViewController {
    BasicScrollView *scrollM;
    UIView *contentView;
    NSDictionary *data;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    topbar.titleLabel.text = @"消息详情";
    
    scrollM = [[BasicScrollView alloc] initWithFrame:CGRectMake(0, topbar.bottom, self.view.width, self.view.height-topbar.bottom)];
    [self.view addSubview:scrollM];
    
    contentView = [[UIView alloc] initWithFrame:scrollM.bounds];
    [scrollM addSubview:contentView];
    
    scrollM.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self requestList];
    }];
    [scrollM.mj_header beginRefreshing];
    
}

- (void)requestList {
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness messageInboxDetailForId:__id Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        [scrollM.mj_header endRefreshing];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                data = [response dictionaryForKey:@"data"];
                [self updateUI];
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools alertWithTitle:str message:nil handle:^(UIAlertAction * _Nonnull action) {
                    
                } cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求服务失败,请稍后再试."];
        }
    }];
    
    
    
}

- (void)updateUI {
    [contentView removeAllSubviews];
    
    if (!data || !data.allKeys.count) {
        UILabel *no = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, contentView.width, widthTo4_7(80))];
        no.textAlignment = NSTextAlignmentCenter;
        no.text = No_Record_Text;
        no.font = SystemFontBy4(13.6);
        no.textColor = ColorHex(0x888888);
        [contentView addSubview:no];
        scrollM.contentSize = CGSizeMake(contentView.width, scrollM.height);
        return;
    }
    
    NSString *title = [data stringForKey:@"msg_title"];
    NSString *time = [data stringForKey:@"created_at"];
    NSString *content = [data stringForKey:@"msg_content"];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(20), 0, self.view.width-widthTo4_7(40), widthTo4_7(80))];
    titleLabel.textColor = ColorHex(0x222222);
    titleLabel.font = SystemFontBy4(19);
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.numberOfLines = 0;
    titleLabel.text = title;
    [contentView addSubview:titleLabel];
    
    UILabel *timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, titleLabel.bottom, contentView.width, widthTo4_7(30))];
    timeLabel.textAlignment = NSTextAlignmentCenter;
    timeLabel.font = SystemFontBy4(12.6);
    timeLabel.textColor = ColorHex(0x666666);
    timeLabel.text = time;
    [contentView addSubview:timeLabel];
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(widthTo4_7(20), timeLabel.bottom, titleLabel.width, widthTo4_7(1.0))];
    view.backgroundColor = LineColor;
    [contentView addSubview:view];
    
    WKWebView *web = [[WKWebView alloc] initWithFrame:CGRectMake(view.left, view.bottom, view.width, contentView.height-view.bottom)];
    [contentView addSubview:web];
    web.navigationDelegate = self;
    [web loadHTMLString:content baseURL:nil];
    
    
}

#pragma mark WKNavigationDelegate
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    [ webView evaluateJavaScript:@"document.getElementsByTagName('body')[0].style.webkitTextSizeAdjust= '280%'" completionHandler:nil];
}
@end
