//
//  MemberCenterViewController.h
//  CpNative
//
//  Created by david on 2019/3/16.
//  Copyright © 2019 david. All rights reserved.
//

#import "BasicViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface MemberCenterViewController : BasicViewController

- (void)updateBalance;
- (void)setupUI;//构建UI
- (void)updateStates;//更新姓名和余额、是否现在代理等状态



@end

NS_ASSUME_NONNULL_END
