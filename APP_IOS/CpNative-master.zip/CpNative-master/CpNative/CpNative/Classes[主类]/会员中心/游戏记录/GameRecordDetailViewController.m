//
//  GameRecordDetailViewController.m
//  CpNative
//
//  Created by david on 2019/3/9.
//  Copyright © 2019 david. All rights reserved.
//

#import "GameRecordDetailViewController.h"

@interface GameRecordDetailViewController ()

@end

@implementation GameRecordDetailViewController {
    BasicScrollView *detailScroll;
    UIView *contentView;
    NSDictionary *data;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    topbar.titleLabel.text = @"注单详情";
    
    detailScroll = [[BasicScrollView alloc] initWithFrame:CGRectMake(0, topbar.bottom, self.view.width, self.view.height-topbar.bottom)];
    [self.view addSubview:detailScroll];
    detailScroll.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self request];
    }];
    contentView = [[UIView alloc] initWithFrame:detailScroll.bounds];
    [detailScroll addSubview:contentView];
    [detailScroll.mj_header beginRefreshing];
}

- (void)request {
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness getRecordDetailForId:__id Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        [detailScroll.mj_header endRefreshing];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                data = [response dictionaryForKey:@"data"];
                [self buidUI];
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools showText:str];
            }
        } else {
            [Tools showText:@"请求失败,请稍后再试."];
        }
    }];
}

- (void)buidUI {
    [contentView removeAllSubviews];
    NSArray *names = @[@"用户名:",@"注单编号:",@"游戏:",@"倍彩模式:",@"奖期:",@"投单时间:",@"注单奖金:",@"开奖内容:",@"玩法:",@"总金额:",@"动态返点:",@"订单状态:",@"投注内容:",@"可能中奖情况:",@"奖级名称:",@"号码:",@"倍数:",@"奖级:",@"奖金:",];
    
    CGFloat heig = widthTo4_7(58);
    UIColor *color = ColorHex(0x161616);
    UIFont *font = SystemFontBy4(13.0);
    UIFont *fontb = BoldSystemFontBy4(12.4);
    CGFloat left = widthTo4_7(10);
    CGFloat left2 = 0.3*self.view.width;
    CGFloat offy = 0;
    for (int i = 0; i < names.count; i++) {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(left, offy, 200, heig)];
        label.font = font;
        label.textColor = color;
        label.text = names[i];
        [contentView addSubview:label];
        
        UILabel *label0 = [[UILabel alloc] initWithFrame:CGRectMake(left2, label.top, self.view.width-left2-left, label.height)];
        label0.textColor = color;
        label0.font = fontb;
        label0.numberOfLines = 0;
        [contentView addSubview:label0];
        if (i == 0) {
            label0.text = [Singleton shared].account;
        }
        if (i == 1) {
            label0.text = [data stringForKey:@"serial_number"];
        }
        if (i == 2) {
            NSString *_id = [data stringForKey:@"lottery_id"];
            label0.text = [Tools nameOfId:_id isGF:YES];
        }
        if (i == 3) {
            NSString *bei = [data stringForKey:@"multiple"];
            NSString *zhu = [data stringForKey:@"single_count"];
            NSString *amount = [data stringForKey:@"amount"];
            NSString *yj = @"元";
            if (amount.floatValue/zhu.floatValue == 10) {
                yj = @"角";
            } else if (amount.floatValue/zhu.floatValue == 100) {
                yj = @"分";
            }
            label0.text = [NSString stringWithFormat:@"%@倍, %@注, 1%@",bei,zhu,yj];
        }
        if (i == 4) {
            label0.text = [data stringForKey:@"issue"];
        }
        if (i == 5) {
            label0.text = [data stringForKey:@"bought_at"];
        }
        if (i == 6) {
            NSString *priz = [data stringForKey:@"prize"];
            label0.textColor = ColorHex(0x6b9938);
            if (!priz.length) {
                label0.text = @"-";
            } else {
                label0.text = [priz addMoneyDot];
            }
        }
        if (i == 7) {
            label0.text = [data stringForKey:@"winning_number"];
            if (!label0.text.length) {
                label0.text = @"-";
            }
        }
        if (i == 8) {
            NSString *way = [data stringForKey:@"way"];
            if (!way || !way.length) {
                way = _way;
            }
            label0.text = way;
            if (!label0.text.length) {
                label0.text = @"-";
            }
        }
        if (i == 9) {
            label0.text = [[data stringForKey:@"amount"] addMoneyDot];
            label0.textColor = ColorHex(0xb23339);
        }
        if (i == 10) {
            label0.text = @"0";
        }
        if (i == 11) {
            NSArray *status = @[@"待开奖",@"已撤销",@"未中奖",@"已中奖",@"",@"",@"",];
            NSString *sta = [data stringForKey:@"status"];
            label0.text = status[sta.integerValue];
            if (sta.integerValue == 1 || sta.integerValue == 2) {
                label0.textColor = ColorHex(0x969494);
            } else if (sta.integerValue == 0) {
                label0.textColor = ColorHex(0x4478b5);
                UIButton *cedan = [[UIButton alloc] initWithFrame:CGRectMake(0.5*self.view.width, label.top, 0.1*self.view.width, label.height)];
                [contentView addSubview:cedan];
                label.userInteractionEnabled = YES;
                [cedan setTitle:@"撤单" forState:0];
                [cedan setTitleColor:ColorHex(0xb23339) forState:0];
                cedan.titleLabel.font = font;
                [cedan addTarget:self action:@selector(onCheDan) forControlEvents:UIControlEventTouchUpInside];
                
            } else if (sta.integerValue == 3) {
                label.textColor = ColorHex(0xd13125);
            }
        }
        if (i == 12) {
            NSString *bet = [data stringForKey:@"bet_number"];
            label0.text = bet;
            CGFloat size = [bet heightWithFont:label0.font constrainedToWidth:label0.width]+widthTo4_7(22);
            if (size > label0.height) {
                label0.height = size;
                label.height = size;
            }
        }
        if (i == 13) {
            [label0 removeFromSuperview];
            label.left = 0;
            label.width = self.view.width;
            label.textAlignment = NSTextAlignmentCenter;
            label.textColor = ColorHex(0xb23339);
        }
        if (i == 14) {
            NSString *way = [data stringForKey:@"way"];
            if (!way || !way.length) {
                way = _way;
            }
            label0.text = way;
        }
        if (i == 15) {
            NSString *bet = [data stringForKey:@"bet_number"];
            label0.text = bet;
            CGFloat size = [bet heightWithFont:label0.font constrainedToWidth:label0.width]+widthTo4_7(22);
            if (size > label0.height) {
                label0.height = size;
                label.height = size;
            }
        }
        if (i == 16) {
            label0.text = [data stringForKey:@"multiple"];
        }
        if (i == 17) {
            NSString *prize = [data stringForKey:@"prize"];
            label0.text = [NSString stringWithFormat:@"一等奖: %@元",prize];
        }
        if (i == 18) {
            label0.text = [data stringForKey:@"prize_group"];
        }
        
        
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, label.bottom, self.view.width, widthTo4_7(1.0))];
        line.backgroundColor = LineColor;
        [contentView addSubview:line];
        offy = line.bottom;
    }
    
    contentView.height = offy;
    detailScroll.contentSize = CGSizeMake(detailScroll.width, contentView.height);
}

- (void)onCheDan {
    [Tools alertWithTitle:@"确定撤单?" message:nil handle:^(UIAlertAction * _Nonnull action) {
        [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [NetworkBusiness cancelBetId:__id Block:^(NSError *error, int code, id response) {
            [MBProgressHUD hideHUDForView:self.view animated:NO];
            [detailScroll.mj_header endRefreshing];
            
            /*判断是否重新登录*/
            if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
                return;
            }
            
            if (code == 200) {
                NSInteger err = [response integerForKey:@"errno"];
                if (err == 0) {
                    [Tools alertWithTitle:@"撤单成功!" message:nil handle:^(UIAlertAction * _Nonnull action) {
                        [detailScroll.mj_header beginRefreshing];
                    } cancel:nil confirm:@"确定"];
                } else {
                    NSString *str = [response stringForKey:@"error"];
                    if (!str.length) {
                        str = @"请求失败,请稍后再试。";
                    }
                    [Tools showText:str];
                }
            } else {
                [Tools showText:@"请求失败,请稍后再试."];
            }
        }];
    } cancel:@"取消" confirm:@"撤单"];
}

@end
