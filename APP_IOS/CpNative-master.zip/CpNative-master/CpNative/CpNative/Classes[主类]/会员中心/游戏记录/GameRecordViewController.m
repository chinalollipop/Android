//
//  GameRecordViewController.m
//  CpNative
//
//  Created by david on 2019/2/11.
//  Copyright © 2019 david. All rights reserved.
//

#import "GameRecordViewController.h"
#import "GameRecordDetailViewController.h"

@interface GameRecordViewController ()

@end

@implementation GameRecordViewController {
    BasicScrollView *recordScroll;
    
    UILabel *beginDateLbl;//开始日期
    UILabel *endDateLbl;//接受日期
    UILabel *typeDateLbl;
    
    UIView *titleView;
    UIView *redBarView;//横杆
    NSInteger currentTitleTag;
    
    /*参数  重要！！！*/
    NSInteger typeIndex;//游戏类型的索引
    NSInteger currentPage;//当前第几页
    NSInteger totalCount;//当前条件下总共有多少条数据
    NSInteger pagesize;//每页请求多少条数据
    NSMutableArray *allRecords;//返回的数组
    NSMutableArray *array1;//未开奖
    NSMutableArray *array2;//中奖
    NSMutableArray *array3;//未中奖
    
    NSArray *gamesArray;
    
    NSMutableArray *gameNames;//所有的游戏名称
    
    UIView *recordView;//游戏记录
    EnlargeButton *gameTypeButton;//右上游戏类型按钮
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    topbar.titleLabel.text = @"游戏记录";
    currentPage = 1;//初始化当前页码为第1页.
    pagesize = 20;//每页请求的数据条数
    
    CGFloat gtWidth = widthTo4_7(55);
    CGFloat gtHeight = widthTo4_7(24.2);
    gameTypeButton = [[EnlargeButton alloc] initWithFrame:CGRectMake(topbar.width-(widthTo4_7(14)+gtWidth), (topbar.contentView.height-gtHeight)/2, gtWidth, gtHeight)];
    gameTypeButton.expandSpecs = widthTo4_7(10);
    [gameTypeButton setTitle:(_isXy?@"信用盘":@"官方盘") forState:0];
    [gameTypeButton setTitleColor:ColorHex(0xffffff) forState:0];
    gameTypeButton.titleLabel.font = SystemFontBy4(13.0);
    gameTypeButton.layer.borderColor = ColorHex(0xffffff).CGColor;
    gameTypeButton.layer.borderWidth = widthTo4_7(0.8);
    gameTypeButton.layer.cornerRadius = widthTo4_7(2.4);
    gameTypeButton.layer.masksToBounds = YES;
    [gameTypeButton addTarget:self action:@selector(onGameTypeButton:) forControlEvents:UIControlEventTouchUpInside];
    [topbar.contentView addSubview:gameTypeButton];
    
    recordScroll = [[BasicScrollView alloc] initWithFrame:CGRectMake(0, topbar.bottom, self.view.width, self.view.height-topbar.height)];
    [self.view addSubview:recordScroll];
    
    
    CGFloat wid = recordScroll.width/3;
    NSArray *titles = @[@"开始日期",@"截止日期",@"游戏类型",];
    for (int i = 0; i < titles.count; i++) {
        UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(wid*i, 0, wid, widthTo4_7(60))];
        btn.tag = i;
        [btn addTarget:self action:@selector(onDateOrTypeSelection:) forControlEvents:UIControlEventTouchUpInside];
        [recordScroll addSubview:btn];
        
        UILabel *lal = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, wid, widthTo4_7(38))];
        lal.text = titles[i];
        lal.textAlignment = NSTextAlignmentCenter;
        lal.font = SystemFontBy4(12.6);
        lal.textColor = ColorHex(0x333333);
        [btn addSubview:lal];
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, widthTo4_7(30), wid, widthTo4_7(30))];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = SystemFontBy4(12.6);
        label.textColor = ColorHex(0x333333);
        [btn addSubview:label];
        
        UILabel *sign = [[UILabel alloc] initWithFrame:CGRectMake(0.84*wid, widthTo4_7(30), 0.1*wid, widthTo4_7(30))];
        sign.font = FontForSize(14);
        sign.text = UpDown1;
        sign.textColor = ColorHex(0x555555);
        sign.textAlignment = NSTextAlignmentCenter;
        [btn addSubview:sign];
        
        if (i == 0) {
            beginDateLbl = label;
            beginDateLbl.text = [[NSDate date] stringWithFormat:DateFormat_record];
        }
        if (i == 1) {
            endDateLbl = label;
            endDateLbl.text = [[NSDate dateTomorrow] stringWithFormat:DateFormat_record];
        }
        if (i == 2) {
            typeDateLbl = label;
            [self makeGameNames];
            typeDateLbl.text = gameNames[0];
        }
    }

    titleView = [[UIView alloc] initWithFrame:CGRectMake(0, widthTo4_7(66), recordScroll.width, widthTo4_7(44))];
    titleView.backgroundColor = ColorReset;
    [recordScroll addSubview:titleView];
    NSArray *names = @[@"全部",@"未开奖",@"中奖",@"未中奖",];
    CGFloat width = recordScroll.width/names.count;
    for (int i = 0; i < names.count; i++) {
        UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(width*i, 0, width, titleView.height*0.95)];
        [btn setTitle:names[i] forState:0];
        [titleView addSubview:btn];
        btn.tag = i;
        [btn addTarget:self action:@selector(onTitleButton:) forControlEvents:UIControlEventTouchUpInside];
    }
    redBarView = [[UIView alloc] initWithFrame:CGRectMake(0, titleView.height-widthTo4_7(2.6), width, widthTo4_7(2.6))];
    redBarView.backgroundColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;
    [titleView addSubview:redBarView];
    [self shiftTitle];
    
    recordView = [[UIView alloc] initWithFrame:CGRectMake(0, titleView.bottom, recordScroll.width, recordScroll.height-titleView.bottom)];
    [recordScroll addSubview:recordView];
    
    recordScroll.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        currentPage = 1;//刷新，页码重置为1
        [self requestDataIsRefresh:YES];
    }];
    
    recordScroll.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        ++currentPage;//加载更多，页码+1
        [self requestDataIsRefresh:NO];
    }];
    
    [recordScroll.mj_header beginRefreshing];
}

- (void)onGameTypeButton:(UIButton *)button {
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    WSDatePickerView *datepicker = [[WSDatePickerView alloc] initWithDateStyle:DateStyleShowBank data:@[@"官方盘",@"信用盘",] scrollToIndex:(_isXy?1:0) CompleteBlock:^(NSInteger tag, BOOL cancel) {
        if (cancel) {
            NSLog(@"CANCEL.....");
        } else {
            _isXy = tag;
            [self makeGameNames];
            typeIndex = 0;
            NSString *name = gameNames[typeIndex];
            typeDateLbl.text = name;
            currentPage = 1;//页码重置为1
            [self requestDataIsRefresh:YES];
            [gameTypeButton setTitle:(_isXy?@"信用盘":@"官方盘") forState:0];
        }
    }];
    
    datepicker.dateLabelColor = ColorHex(0xff5733);//年-月-日-时-分 颜色
    datepicker.datePickerColor = ColorHex(0x286be8);//滚轮日期颜色
    datepicker.doneButtonColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;//确定按钮的颜色
    [datepicker setHideBackgroundYearLabel:YES];
    [datepicker show];
}

/*设置游戏的名字*/
- (void)makeGameNames {
    NSString *suffix = @"";
    if (_isXy) {
        gamesArray = [Singleton shared].gamesArrayXY;
        suffix = @"[信]";
    } else {
        gamesArray = [Singleton shared].gamesArrayGF;
        suffix = @"[官]";
    }
    if (!gameNames) {
        gameNames = [NSMutableArray array];
    }
    [gameNames removeAllObjects];
    [gameNames addObject:@"全部游戏"];
    for (NSDictionary *dict in gamesArray) {
        NSString *name = [[dict stringForKey:@"name"] stringByAppendingString:suffix];
        [gameNames addObject:name];
    }
}

- (void)requestDataIsRefresh:(BOOL)isRefresh {
    
    if (!isRefresh) {
        if (allRecords.count >= totalCount) { //没有更多数据了
            [recordScroll.mj_footer endRefreshingWithNoMoreData];
            return;
        }
    }
    
    NSString *_id = @"";
    if (typeIndex > 0) {
        NSDictionary *lottery = gamesArray[typeIndex-1];
        _id = [lottery stringForKey:@"lottery_id"];
    }
    
    NSString *page = [NSString stringWithFormat:@"%li",(long)currentPage];
    NSString *sizeOfPage = [NSString stringWithFormat:@"%li",(long)pagesize];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    
    if (_isXy) {
        [NetworkBusiness xyPersonalBetRecordsForId:_id start:beginDateLbl.text end:endDateLbl.text status:@"-1" page:page rows:sizeOfPage Block:^(NSError *error, int code, id response) {
            [self handleCallBack:error code:code response:response isrefresh:isRefresh];
        }];
    } else {
        [NetworkBusiness getRecordsForLotteryId:_id page:page pageSize:sizeOfPage begin_date:beginDateLbl.text end_date:endDateLbl.text Block:^(NSError *error, int code, id response) {
            [self handleCallBack:error code:code response:response isrefresh:isRefresh];
        }];
    }
}

- (void)handleCallBack:(NSError *)error code:(int)code response:(id)response isrefresh:(BOOL)isRefresh {
    [MBProgressHUD hideHUDForView:self.view animated:NO];
    [recordScroll.mj_header endRefreshing];
    [recordScroll.mj_footer endRefreshing];
    
    /*判断是否重新登录*/
    if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
        return;
    }
    
    if (code == 200) {
        NSInteger err = [response integerForKey:@"errno"];
        if (err == 0) {
            NSDictionary *data = [response dictionaryForKey:@"data"];
            NSString *arrayKey = @"";
            if (_isXy) {
                arrayKey = @"list";
            } else {
                arrayKey = @"projects";
            }
            NSArray *games = [data arrayForKey:arrayKey];
            totalCount = [data integerForKey:@"count"];
            if (!allRecords) {
                allRecords = [[NSMutableArray alloc] init];
            }
            if (isRefresh) {
                [allRecords removeAllObjects];
            }
            if (games.count) {
                [allRecords addObjectsFromArray:games];
            }
            if (allRecords.count < totalCount) {
                [recordScroll.mj_footer resetNoMoreData];//还有更多数据可以加载
            }
            [self buildRecordView];
        } else {
            NSString *str = [response stringForKey:@"error"];
            if (!str.length) {
                str = @"请求失败,请稍后再试。";
            }
            [Tools showText:str];
        }
    } else {
        [Tools showText:@"请求失败,请稍后再试."];
    }
}

- (void)buildRecordView {
    if (!array1) {
        array1 = [[NSMutableArray alloc] init];
        array2 = [[NSMutableArray alloc] init];
        array3 = [[NSMutableArray alloc] init];
    }
    [array1 removeAllObjects];
    [array2 removeAllObjects];
    [array3 removeAllObjects];
    
    for (int i = 0; i < allRecords.count; i++) {
        NSDictionary *record = allRecords[i];
        NSString *sta = [record stringForKey:@"status"];
        NSInteger statusIndex = sta.integerValue;
        if (statusIndex == 0) {
            [array1 addObject:record];
        }
        if (statusIndex == 3) {
            [array2 addObject:record];
        }
        if (statusIndex == 2) {
            [array3 addObject:record];
        }
    }
    
    [self buildRecords];
}

- (NSArray *)getData {
    if (currentTitleTag == 0) {
        return allRecords;
    } else if (currentTitleTag == 1) {
        return array1;
    } else if (currentTitleTag == 2) {
        return array2;
    } else if (currentTitleTag == 3) {
        return array3;
    }
    return nil;
}

- (void)buildRecords {
    [recordView removeAllSubviews];
    
    NSArray *recordDatas = [self getData];
    
    
    if (!recordDatas.count) {
        UILabel *no = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, recordScroll.width, widthTo4_7(80))];
        no.textAlignment = NSTextAlignmentCenter;
        no.text = No_Record_Text;
        no.font = SystemFontBy4(13.6);
        no.textColor = ColorHex(0x888888);
        [recordView addSubview:no];
        recordScroll.contentSize = CGSizeMake(recordScroll.width, recordScroll.height);
        return;
    }
    
    
    NSArray *status = @[@"待开奖",@"已撤销",@"未中奖",@"已中奖",@"",@"",@"",];
    CGFloat offY = 0;
    CGFloat lineHeig = widthTo4_7(28);
    CGFloat left = widthTo4_7(10);
    CGFloat left2 = 0.57*recordView.width;
    CGFloat left3 = 0.227*recordView.width;
    CGFloat left4 = 0.70*recordView.width;
    CGFloat top = left*1.5;
    UIFont *font = SystemFontBy4(13.0);
    UIFont *fontb = BoldSystemFontBy4(12.4);
    UIColor *color = ColorHex(0x161616);
    for (int i = 0; i < recordDatas.count; i++) {
        NSDictionary *record = recordDatas[i];
        UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0, offY, recordView.width, 1)];
        [recordView addSubview:button];
        button.tag = i;
        [button addTarget:self action:@selector(onRecordButton:) forControlEvents:UIControlEventTouchUpInside];
        
        NSString *lottId = [record stringForKey:(_isXy?@"type":@"lottery_id")];
        NSString *qi = [record stringForKey:(_isXy?@"actionNo":@"issue")];
        NSString *sta = [record stringForKey:@"status"];
        NSInteger statusIndex = sta.integerValue;
        
        NSString *lottName = [Tools nameOfId:lottId isGF:(!_isXy)];//彩种名字
        NSString *issue = [NSString stringWithFormat:@"%@期",qi];//期数
        NSString *time = [record stringForKey:(_isXy?@"actionTime":@"bought_at")];//购买时间
        NSString *wanfa = [record stringForKey:(_isXy?@"Groupname":@"way")];//玩法
        NSString *winNum = [record stringForKey:(_isXy?@"lotteryNo":@"winning_number")];//开奖号码
        NSString *bet = [record stringForKey:(_isXy?@"money":@"amount")];//投注金额
        NSString *stat = status[statusIndex];//状态
        NSString *bonus = [record stringForKey:(_isXy?@"bonus":@"prize")];//中奖金额
        NSString *user = [Singleton shared].account;//用户名
        NSString *no = [record stringForKey:(_isXy?@"wjorderId":@"serial_number")];//编号
        NSString *content = [record stringForKey:(_isXy?@"actionData":@"bet_number")];//投注内容
        if (!bonus || !bonus.length || bonus.floatValue <= 0) {
            if (statusIndex == 0 || statusIndex == 1) {
                bonus = @"-";
            } else if (statusIndex == 2) {
                bonus = @"0";
            } else if (statusIndex == 3) {
                bonus = @"";
            }
        }
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(left, top, 500, lineHeig)];
        label.text = lottName;
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig, 500, lineHeig)];
        label.text = issue;
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left2, top+lineHeig, 500, lineHeig)];
        label.text = time;
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig*2, 500, lineHeig)];
        label.text = @"游戏玩法:";
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left3, top+lineHeig*2, 500, lineHeig)];
        label.text = wanfa;
        label.textColor = color;
        label.font = fontb;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig*3, 500, lineHeig)];
        label.text = @"开奖号码:";
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        CGFloat leftH = label.height;
        label = [[UILabel alloc] initWithFrame:CGRectMake(left3, top+lineHeig*3, button.width-left3-left, lineHeig)];
        label.text = winNum;
        label.numberOfLines = 0;
        label.textColor = color;
        label.font = fontb;
        [label sizeToFit];
        [button addSubview:label];
        
        CGFloat offset = ((label.height/leftH)-1.0)*widthTo4_7(17.5);
        if (label.text.length < 2) {
            offset = 0;
        }
        label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig*4+offset, 500, lineHeig)];
        label.text = @"投注金额:";
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left3, top+lineHeig*4+offset, 500, lineHeig)];
        label.text = [bet addMoneyDot];
        label.textColor = ColorHex(0xb23339);
        label.font = fontb;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left2, top+lineHeig*4+offset, 500, lineHeig)];
        label.text = @"状态:";
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left4, top+lineHeig*4+offset, 500, lineHeig)];
        label.text = stat;
        label.font = fontb;
        [label sizeToFit];
        [button addSubview:label];
        if (sta.integerValue == 1 || sta.integerValue == 2) {
            label.textColor = ColorHex(0x969494);
        } else if (sta.integerValue == 0) {
            label.textColor = ColorHex(0x4478b5);
        } else if (sta.integerValue == 3) {
            label.textColor = ColorHex(0xd13125);
        }
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig*5+offset, 500, lineHeig)];
        label.text = @"中奖金额:";
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left3, top+lineHeig*5+offset, 500, lineHeig)];
        label.text = [bonus addMoneyDot];
        label.textColor = ColorHex(0x6b9938);
        label.font = fontb;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left2, top+lineHeig*5+offset, 500, lineHeig)];
        label.text = @"用户:";
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left4, top+lineHeig*5+offset, 500, lineHeig)];
        label.text = user;
        label.textColor = color;
        label.font = fontb;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig*6+offset, 500, lineHeig)];
        label.text = @"注单编号:";
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left3, top+lineHeig*6+offset, 500, lineHeig)];
        label.text = no;
        label.textColor = color;
        label.font = fontb;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left, top+lineHeig*7+offset, 500, lineHeig)];
        label.text = @"投注内容:";
        label.textColor = color;
        label.font = font;
        [label sizeToFit];
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(left3, top+lineHeig*7+offset, button.width-left3-left, 1000)];
        label.text = content;
        label.numberOfLines = 0;
        label.textColor = color;
        label.font = fontb;
        [label sizeToFit];
        [button addSubview:label];
        
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, label.bottom+top, button.width, widthTo4_7(1.2))];
        [button addSubview: line];
        line.backgroundColor = LineColor;
        
        button.height = line.bottom;
        offY = button.bottom;
    }
    recordView.height = offY;
    
    CGFloat contentH = recordScroll.height;
    if (recordView.bottom > contentH) {
        contentH = recordView.bottom;
    }
    recordScroll.contentSize = CGSizeMake(recordScroll.width, contentH);
}


- (void)onDateOrTypeSelection:(UIButton *)button {
    if (button.tag == 0) {
        [self showPickerWithTag:0 date:[NSDate date:beginDateLbl.text WithFormat:DateFormat_record]];
    }
    if (button.tag == 1) {
        [self showPickerWithTag:1 date:[NSDate date:endDateLbl.text WithFormat:DateFormat_record]];
    }
    if (button.tag == 2) {
        [self showPickForType];
    }
}



- (void)showPickerWithTag:(NSInteger)tag date:(NSDate *)date {
    __block __weak UILabel *wBegin = beginDateLbl;
    __block __weak UILabel *wEnd = endDateLbl;
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    WSDatePickerView *datepicker = [[WSDatePickerView alloc] initWithDateStyle:DateStyleShowYearMonthDay scrollToDate:date CompleteBlock:^(NSDate *selectDate,BOOL cancel) {
        if (!cancel) {
            NSString *dateString = [selectDate stringWithFormat:DateFormat_record];
            NSLog(@"选择的日期：%@",dateString);
            if (tag == 0) {
                wBegin.text = dateString;
            }
            if (tag == 1) {
                wEnd.text = dateString;
            }
            
            currentPage = 1;//页码重置为1
            [self requestDataIsRefresh:YES];
        }
    }];
    datepicker.dateLabelColor = ColorHex(0xff5733);//年-月-日-时-分 颜色
    datepicker.datePickerColor = ColorHex(0x286be8);//滚轮日期颜色
    datepicker.doneButtonColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;//确定按钮的颜色
    [datepicker setHideBackgroundYearLabel:YES];
    [datepicker setOutOfRangeText:@"仅可查询半年内记录"];
    [datepicker setMinLimitDate:[Tools dateOfHalfYearAgo]];
    [datepicker setMaxLimitDate:[NSDate dateTomorrow]];
    [datepicker show];
}

- (void)showPickForType {
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    WSDatePickerView *datepicker = [[WSDatePickerView alloc] initWithDateStyle:DateStyleShowBank data:gameNames scrollToIndex:typeIndex CompleteBlock:^(NSInteger tag, BOOL cancel) {
        if (cancel) {
            NSLog(@"CANCEL.....");
        } else {
            typeIndex = tag;
            NSString *name = gameNames[tag];
            typeDateLbl.text = name;
            currentPage = 1;//页码重置为1
            [self requestDataIsRefresh:YES];
        }
    }];
    
    datepicker.dateLabelColor = ColorHex(0xff5733);//年-月-日-时-分 颜色
    datepicker.datePickerColor = ColorHex(0x286be8);//滚轮日期颜色
    datepicker.doneButtonColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;//确定按钮的颜色
    [datepicker setHideBackgroundYearLabel:YES];
    [datepicker show];
}


/*点击进入详情*/
- (void)onRecordButton:(UIButton *)button {
    NSArray *arr = [self getData];
    if (!arr || !arr.count || (arr.count<=button.tag)) {
        return;
    }
    NSDictionary *dic = arr[button.tag];
    NSString *_id = [dic stringForKey:@"id"];
    NSString *way = [dic stringForKey:@"way"];
    
    if (_id.length > 0) {
        GameRecordDetailViewController *detail = [[GameRecordDetailViewController alloc] init];
        detail._id = _id;
        detail.way = way;
        [self.navigationController pushViewController:detail animated:YES];
    }
}


- (void)onTitleButton:(UIButton *)button {
    [self onTitleButtonTag:button.tag];
}

- (void)onTitleButtonTag:(NSInteger)tag {
    currentTitleTag = tag;
    [self buildRecords];
    [self shiftTitle];
}

- (void)shiftTitle {
    CGFloat wid = recordScroll.width/4;
    redBarView.left = wid*currentTitleTag;
    
    for (UIButton *btn in titleView.subviews) {
        if ([btn isKindOfClass:[UIButton class]]) {
            if (btn.tag == currentTitleTag) {
                [btn setTitleColor:COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT forState:0];
                btn.titleLabel.font = BoldSystemFontBy4(13.0);
            } else {
                [btn setTitleColor:ColorHex(0xffffff) forState:0];
                btn.titleLabel.font = SystemFontBy4(13.4);
            }
        }
    }
}


@end
