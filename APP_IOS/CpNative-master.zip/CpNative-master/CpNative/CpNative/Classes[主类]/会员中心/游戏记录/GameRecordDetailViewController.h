//
//  GameRecordDetailViewController.h
//  CpNative
//
//  Created by david on 2019/3/9.
//  Copyright © 2019 david. All rights reserved.
//

#import "BasicWithNaviBarViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface GameRecordDetailViewController : BasicWithNaviBarViewController

@property(nonatomic, copy) NSString *_id;
@property(nonatomic, copy) NSString *way;

@end

NS_ASSUME_NONNULL_END
