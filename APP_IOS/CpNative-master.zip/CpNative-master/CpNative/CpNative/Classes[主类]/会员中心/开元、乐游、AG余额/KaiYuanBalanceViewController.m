//
//  KaiYuanBalanceViewController.m
//  CpNative
//
//  Created by david on 2019/3/24.
//  Copyright © 2019 david. All rights reserved.
//

#import "KaiYuanBalanceViewController.h"

@interface KaiYuanBalanceViewController ()

@end

@implementation KaiYuanBalanceViewController {
    BasicScrollView *scrollQ;
    
    UILabel *allBalanceLbl;//总余额；
    UILabel *statusLbl;//查询状态
    UILabel *availbleBalance;//可转余额；
    UIButton *submit;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    topbar.titleLabel.text = @"开元棋牌余额";
    
    scrollQ = [[BasicScrollView alloc] initWithFrame:CGRectMake(0, topbar.bottom, self.view.width, self.view.height-topbar.height)];
    [self.view addSubview:scrollQ];
    
    UIView *blackBg = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.width, widthTo4_7(150))];
    blackBg.backgroundColor = ColorReset;
    [scrollQ addSubview:blackBg];
    
    UILabel *bar = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.view.width, widthTo4_7(40))];
    bar.textColor = ColorHex(0xffffff);
    bar.textAlignment = NSTextAlignmentCenter;
    bar.font = SystemFontBy4(13.0);
    bar.text = @"查询开元棋牌余额";
    [scrollQ addSubview:bar];
    
    UIView *allView = [[UIView alloc] initWithFrame:CGRectMake(0.07*scrollQ.width, bar.bottom, 0.86*scrollQ.width, widthTo4_7(64))];
    allView.backgroundColor = ColorHex(0xffffff);
    [scrollQ addSubview:allView];
    allView.layer.cornerRadius = 0.07*allView.height;
    allView.layer.masksToBounds = YES;
    
    UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 0.26*allView.width, allView.height)];
    lbl.textAlignment = NSTextAlignmentRight;
    lbl.text = @"总余额:";
    lbl.textColor = ColorHex(0x000000);
    lbl.font = SystemFontBy4(20);
    [allView addSubview:lbl];
    allBalanceLbl = [[UILabel alloc] initWithFrame:CGRectMake(lbl.right+widthTo4_7(5), 0, 200, allView.height)];
    allBalanceLbl.textColor = ColorHex(0xf18619);
    allBalanceLbl.font = lbl.font;
    allBalanceLbl.text = @"-";
    [allView addSubview:allBalanceLbl];
    
    lbl = [[UILabel alloc] initWithFrame:CGRectMake(0, allView.bottom, 0.5*blackBg.width, blackBg.height-allView.bottom)];
    lbl.textAlignment = NSTextAlignmentRight;
    lbl.text = @"查询状态:";
    lbl.font = SystemFontBy4(18);
    lbl.textColor = ColorHex(0xffffff);
    [blackBg addSubview:lbl];
    
    statusLbl = [[UILabel alloc] initWithFrame:CGRectMake(lbl.right+widthTo4_7(5), lbl.top, 150, lbl.height)];
    statusLbl.textColor = lbl.textColor;
    statusLbl.font = lbl.font;
    statusLbl.text = @"查询中...";
    [blackBg addSubview:statusLbl];
    
    UILabel *kezhuan = [[UILabel alloc] initWithFrame:CGRectMake(0, blackBg.bottom, 0.27*scrollQ.width, widthTo4_7(50))];
    kezhuan.textAlignment = NSTextAlignmentRight;
    kezhuan.font = SystemFontBy4(16);
    kezhuan.textColor = ColorHex(0x333333);
    kezhuan.text = @"可转余额:";
    [scrollQ addSubview:kezhuan];
    
    availbleBalance = [[UILabel alloc] initWithFrame:CGRectMake(kezhuan.right+widthTo4_7(5), kezhuan.top, 250, kezhuan.height)];
    availbleBalance.textColor = ColorHex(0x333333);
    availbleBalance.font = kezhuan.font;
    availbleBalance.text = @"-";
    [scrollQ addSubview:availbleBalance];
    
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, kezhuan.bottom, scrollQ.width, widthTo4_7(1.0))];
    line.backgroundColor = ColorHex(0xe5e5e5);
    [scrollQ addSubview:line];
    
    submit = [[UIButton alloc] initWithFrame:CGRectMake(0.12*scrollQ.width, line.bottom+widthTo4_7(36), 0.76*scrollQ.width, widthTo4_7(44))];
    submit.backgroundColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;
    submit.layer.cornerRadius = 0.5*submit.height;
    submit.layer.masksToBounds = YES;
    [submit setTitle:@"确定转换" forState:0];
    [submit setTitleColor:ColorHex(0xffffff) forState:0];
    submit.titleLabel.font = SystemFontBy4(15.6);
    [scrollQ addSubview:submit];
    [submit addTarget:self action:@selector(onTransfer) forControlEvents:UIControlEventTouchUpInside];
    
    scrollQ.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self requestBalance];
    }];
    [scrollQ.mj_header beginRefreshing];
}

- (void)requestBalance {
    
    allBalanceLbl.text = @"-";
    statusLbl.text = @"查询中...";
    availbleBalance.text = @"-";
    submit.enabled = NO;
    
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness kyBalanceBlock:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        [scrollQ.mj_header endRefreshing];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        statusLbl.text = @"查询失败！";
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                NSDictionary *data = [response dictionaryForKey:@"data"];
                NSString *text0 = [data stringForKey:@"sMsg"];
                NSString *text1 = [[data stringForKey:@"fTotalMoney"] addMoneyDot];
                NSString *text2 = [[data stringForKey:@"fFreeMoney"] addMoneyDot];
                
                allBalanceLbl.text = text1;
                statusLbl.text = text0;
                availbleBalance.text = text2;
                
                submit.enabled = YES;

            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools alertWithTitle:str message:nil handle:nil cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求服务失败,请稍后再试."];
        }
    }];
}



- (void)onTransfer {
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness kyBalanceToPlanformBlock:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        [scrollQ.mj_header endRefreshing];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                [Tools alertWithTitle:@"转入成功!" message:nil handle:^(UIAlertAction * _Nonnull action) {
                    [scrollQ.mj_header beginRefreshing];
                } cancel:nil confirm:@"确定"];
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools alertWithTitle:str message:nil handle:nil cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求服务失败,请稍后再试."];
        }
    }];
}
@end
