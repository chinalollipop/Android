//
//  BillSummaryViewController.m
//  CpNative
//
//  Created by david on 2019/3/15.
//  Copyright © 2019 david. All rights reserved.
//

#import "BillSummaryViewController.h"

@interface BillSummaryViewController ()

@end

@implementation BillSummaryViewController {
    
    UILabel *lblXiaoji;//小计
    UILabel *lblZongzhichu;//总支出
    UILabel *lblZongshouru;//总收入
    
    BasicScrollView *recordScroll;
    UIView *recordView;
    
    UILabel *beginDateLbl;
    UILabel *endDateLbl;
    
    UIView *titleView;
    NSInteger currentItemIndex;//当前选中的item
    
    NSInteger typeIndex;//游戏类型的索引
    
    NSDictionary *data;
    NSArray *widths;
    
    NSInteger currentPage;//当前第几页
    NSInteger totalCount;//当前条件下总共有多少条数据
    NSInteger pagesize;//每页请求多少条数据
    NSMutableArray *allRecords;
    NSString *totalIncome;//总收入
    NSString *totalSpence;//总支出
}

- (void)viewDidLoad {
    [super viewDidLoad];
    topbar.titleLabel.text = @"账单报表";
    currentPage = 1;//初始化当前页码为第1页.
    pagesize = 20;//每页请求的数据条数
    
    recordScroll = [[BasicScrollView alloc] initWithFrame:CGRectMake(0, topbar.bottom, self.view.width, self.view.height-topbar.height)];
    [self.view addSubview:recordScroll];
    
    CGFloat wid = recordScroll.width/2;
    NSArray *titles = @[@"开始日期",@"截止日期",];
    for (int i = 0; i < titles.count; i++) {
        UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(wid*i, 0, wid, widthTo4_7(60))];
        btn.tag = i;
        [btn addTarget:self action:@selector(onDateOrTypeSelection:) forControlEvents:UIControlEventTouchUpInside];
        [recordScroll addSubview:btn];
        
        UILabel *lal = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, wid, widthTo4_7(38))];
        lal.text = titles[i];
        lal.textAlignment = NSTextAlignmentCenter;
        lal.font = SystemFontBy4(12.6);
        lal.textColor = ColorHex(0x333333);
        [btn addSubview:lal];
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, widthTo4_7(30), wid, widthTo4_7(30))];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = SystemFontBy4(12.6);
        label.textColor = ColorHex(0x333333);
        [btn addSubview:label];
        
        UILabel *sign = [[UILabel alloc] initWithFrame:CGRectMake(0.84*wid, widthTo4_7(30), 0.1*wid, widthTo4_7(30))];
        sign.font = FontForSize(14);
        sign.text = UpDown1;
        sign.textColor = ColorHex(0x555555);
        sign.textAlignment = NSTextAlignmentCenter;
        [btn addSubview:sign];
        
        if (i == 0) {
            beginDateLbl = label;
            beginDateLbl.text = [[NSDate date] stringWithFormat:DateFormat_record];
        }
        if (i == 1) {
            endDateLbl = label;
            endDateLbl.text = [[NSDate dateTomorrow] stringWithFormat:DateFormat_record];
        }
    }
    
    titleView = [[UIView alloc] initWithFrame:CGRectMake(0, widthTo4_7(66), recordScroll.width, widthTo4_7(44))];
    titleView.backgroundColor = ColorReset;
    [recordScroll addSubview:titleView];
    
    lblXiaoji = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 0.26*titleView.width, titleView.height)];
    lblXiaoji.textAlignment = NSTextAlignmentCenter;
    lblXiaoji.textColor = ColorHex(0xffffff);
    lblXiaoji.font = SystemFontBy4(12.4);
    lblXiaoji.text = @"小计 0 笔";
    [titleView addSubview:lblXiaoji];
    
    lblZongzhichu = [[UILabel alloc] initWithFrame:CGRectMake(0.26*titleView.width, 0, 0.37*titleView.width, titleView.height)];
    lblZongzhichu.textAlignment = NSTextAlignmentCenter;
    lblZongzhichu.textColor = ColorHex(0xeecf4f);
    lblZongzhichu.font = SystemFontBy4(12.4);
    lblZongzhichu.text = @"总支出 0";
    [titleView addSubview:lblZongzhichu];
    
    lblZongshouru = [[UILabel alloc] initWithFrame:CGRectMake(0.63*titleView.width, 0, 0.37*titleView.width, titleView.height)];
    lblZongshouru.textAlignment = NSTextAlignmentCenter;
    lblZongshouru.textColor = ColorHex(0xeecf4f);
    lblZongshouru.font = SystemFontBy4(12.4);
    lblZongshouru.text = @"总收入 0";
    [titleView addSubview:lblZongshouru];
    
    recordView = [[UIView alloc] initWithFrame:CGRectMake(0, titleView.bottom, recordScroll.width, 100)];
    [recordScroll addSubview:recordView];
    
    recordScroll.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        currentPage = 1;
        [self requestIsRefresh:YES];
    }];
    
    recordScroll.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        ++currentPage;
        [self requestIsRefresh:NO];
    }];
    
    [recordScroll.mj_header beginRefreshing];
}

- (void)requestIsRefresh:(BOOL)isRefresh {
    
    if (!isRefresh) {
        if (allRecords.count >= totalCount) { //没有更多数据了
            [recordScroll.mj_footer endRefreshingWithNoMoreData];
            return;
        }
    }
    
    currentItemIndex = -1;//索引复位
    
    NSString *page = [NSString stringWithFormat:@"%li",(long)currentPage];
    NSString *sizeOfPage = [NSString stringWithFormat:@"%li",(long)pagesize];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness fundListAtBegin:beginDateLbl.text end:endDateLbl.text type:@"" page:page pageSize:sizeOfPage user_id:nil Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        [recordScroll.mj_header endRefreshing];
        [recordScroll.mj_footer endRefreshing];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                data = [response dictionaryForKey:@"data"];
                NSArray *games = [data arrayForKey:@"aTransactions"];
                totalCount = [data integerForKey:@"count"];
                totalIncome = [data stringForKey:@"bTotalRevenue"];
                totalSpence = [data stringForKey:@"bTotalExpenses"];
                
                if (!allRecords) {
                    allRecords = [[NSMutableArray alloc] init];
                }
                if (isRefresh) {
                    [allRecords removeAllObjects];
                }
                if (games.count) {
                    [allRecords addObjectsFromArray:games];
                }
                if (allRecords.count < totalCount) {
                    [recordScroll.mj_footer resetNoMoreData];//还有更多数据可以加载
                }
                
                [self updateView];
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools showText:str];
            }
        } else {
            [Tools showText:@"请求失败,请稍后再试."];
        }
    }];
    
}

- (void)onDateOrTypeSelection:(UIButton *)button {
    if (button.tag == 0) {
        [self showPickerWithTag:0 date:[NSDate date:beginDateLbl.text WithFormat:DateFormat_record]];
    }
    if (button.tag == 1) {
        [self showPickerWithTag:1 date:[NSDate date:endDateLbl.text WithFormat:DateFormat_record]];
    }
}



- (void)showPickerWithTag:(NSInteger)tag date:(NSDate *)date {
    __block __weak UILabel *wBegin = beginDateLbl;
    __block __weak UILabel *wEnd = endDateLbl;
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    WSDatePickerView *datepicker = [[WSDatePickerView alloc] initWithDateStyle:DateStyleShowYearMonthDay scrollToDate:date CompleteBlock:^(NSDate *selectDate,BOOL cancel) {
        if (!cancel) {
            NSString *dateString = [selectDate stringWithFormat:DateFormat_record];
            NSLog(@"选择的日期：%@",dateString);
            if (tag == 0) {
                wBegin.text = dateString;
            }
            if (tag == 1) {
                wEnd.text = dateString;
            }
            currentPage = 1;//页码重置为1
            [self requestIsRefresh:YES];
        }
    }];
    datepicker.dateLabelColor = ColorHex(0xff5733);//年-月-日-时-分 颜色
    datepicker.datePickerColor = ColorHex(0x286be8);//滚轮日期颜色
    datepicker.doneButtonColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;//确定按钮的颜色
    [datepicker setHideBackgroundYearLabel:YES];
    [datepicker setOutOfRangeText:@"仅可查询半年内记录"];
    [datepicker setMinLimitDate:[Tools dateOfHalfYearAgo]];
    [datepicker setMaxLimitDate:[NSDate dateTomorrow]];
    [datepicker show];
}

- (void)updateView {
    [recordView removeAllSubviews];
    
    if (!allRecords.count) {
        UILabel *no = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, recordScroll.width, widthTo4_7(80))];
        no.textAlignment = NSTextAlignmentCenter;
        no.text = No_Record_Text;
        no.font = SystemFontBy4(13.6);
        no.textColor = ColorHex(0x888888);
        [recordView addSubview:no];
        recordScroll.contentSize = CGSizeMake(recordScroll.width, recordScroll.height);
        return;
    }
    
    lblXiaoji.text = [NSString stringWithFormat:@"小计 %li 笔",allRecords.count];
    lblZongzhichu.text = [NSString stringWithFormat:@"总支出  %@",totalSpence];
    lblZongshouru.text = [NSString stringWithFormat:@"总收入  %@",totalIncome];
    
    UIColor *color = ColorHex(0x161616);
    UIFont *font = SystemFontBy4(12.4);
    UIFont *fontb = BoldSystemFontBy4(12.2);
    CGFloat offy = 0;
    CGFloat lineHeight = widthTo4_7(30);
    CGFloat gap = widthTo4_7(10);
    CGFloat height = (lineHeight*4+gap*2);
    for (int i = 0; i < allRecords.count; i++) {
        NSDictionary *dict = allRecords[i];
        
        UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0, offy, recordView.width, height)];
        button.tag = i;
        [recordView addSubview:button];
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(13), gap, 300, lineHeight)];
        label.text = @"用户";
        label.textColor = color;
        label.font = font;
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(0.14*button.width, gap, 300, lineHeight)];
        label.text = [Singleton shared].account;
        label.textColor = color;
        label.font = fontb;
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(0.55*button.width, gap, 300, lineHeight)];
        label.text = [dict stringForKey:@"created_at"];
        label.textColor = color;
        label.font = font;
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(13), gap+lineHeight, 300, lineHeight)];
        label.text = @"收入";
        label.textColor = color;
        label.font = font;
        [button addSubview:label];
        
        BOOL isincome = [dict boolForKey:@"is_income"];
        
        NSString *income = [dict stringForKey:@"amount"];
        if (!income.length) {
            income = @"-";
        } else if (isincome) {
            income = [@"+" stringByAppendingString: [income addMoneyDot]];
        } else {
            income = [@"-" stringByAppendingString: [income addMoneyDot]];
        }
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(0.14*button.width, gap+lineHeight, 300, lineHeight)];
        label.text = (isincome?(income):(@"-"));
        label.textColor = ColorHex(0xb23339);
        label.font = fontb;
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(0.55*button.width, gap+lineHeight, 300, lineHeight)];
        label.text = @"支出";
        label.textColor = color;
        label.font = font;
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(0.69*button.width-widthTo4_7(13), gap+lineHeight, 300, lineHeight)];
        label.text = (isincome?(@"-"):(income));
        label.textColor = ColorHex(0xd9a53a);
        label.font = fontb;
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(13), gap+lineHeight*2, 300, lineHeight)];
        label.text = @"账变类型";
        label.textColor = color;
        label.font = font;
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(0.23*button.width, gap+lineHeight*2, 300, lineHeight)];
        label.text = [dict stringForKey:@"description"];
        label.textColor = ColorHex(0x6b9938);;
        label.font = fontb;
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(0.55*button.width, gap+lineHeight*2, 300, lineHeight)];
        label.text = @"余额";
        label.textColor = color;
        label.font = font;
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(0.69*button.width-widthTo4_7(13), gap+lineHeight*2, 300, lineHeight)];
        label.text = [[dict stringForKey:@"ablance"] addMoneyDot];
        label.textColor = ColorHex(0xd9a53a);
        label.font = fontb;
        [button addSubview:label];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(13), gap+lineHeight*3, 300, lineHeight)];
        label.text = @"备注";
        label.textColor = color;
        label.font = font;
        [button addSubview:label];
        
        NSString *note = [dict stringForKey:@"note"];
        CGFloat wid = button.width-widthTo4_7(13)-0.14*button.width;
        CGFloat height = [note heightWithFont:font constrainedToWidth:wid];
        if ((height + widthTo4_7(16)) > lineHeight) {
            height = (height + widthTo4_7(16));
        } else {
            height = lineHeight;
        }
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(0.14*button.width, gap+lineHeight*3, wid, height)];
        label.text = note;
        label.textColor = color;
        label.font = font;
        label.numberOfLines = 0;
        [button addSubview:label];
        
        button.height = label.bottom+gap;
        offy = button.bottom;
        
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, offy, recordView.width, widthTo4_7(1.0))];
        line.backgroundColor = LineColor;
        [recordView addSubview:line];
        offy = line.bottom;
    }
    recordView.height = offy;
    recordScroll.contentSize = CGSizeMake(recordView.width, recordView.top+recordView.height);
    
}

- (CGFloat)addDetailAt:(CGFloat)offy value0:(NSString *)value0 value1:(NSString *)value1 value2:(NSString *)value2 value3:(NSString *)value3 value4:(NSString *)value4 color:(UIColor *)color font:(UIFont *)font height:(CGFloat)height {
    CGFloat left0 = widthTo4_7(13);
    CGFloat left1 = 0.23*self.view.width;
    CGFloat left2 = 0.5*self.view.width+widthTo4_7(13);
    CGFloat left3 = 0.73*self.view.width;
    
    UIView *kView = [[UIView alloc] initWithFrame:CGRectMake(0, offy, self.view.width, height)];
    kView.backgroundColor = ColorHex(0xf0f0f0);
    [recordView addSubview:kView];
    
    UILabel *aLabel = [[UILabel alloc] initWithFrame:CGRectMake(left0, 0, 300, kView.height)];
    aLabel.textColor = color;
    aLabel.font = font;
    aLabel.text = @"提款:";
    [kView addSubview:aLabel];
    
    aLabel = [[UILabel alloc] initWithFrame:CGRectMake(left1, 0, 300, kView.height)];
    aLabel.textColor = color;
    aLabel.font = font;
    aLabel.text = [value0 addMoneyDot];
    [kView addSubview:aLabel];
    
    aLabel = [[UILabel alloc] initWithFrame:CGRectMake(left2, 0, 300, kView.height)];
    aLabel.textColor = color;
    aLabel.font = font;
    aLabel.text = @"充值:";
    [kView addSubview:aLabel];
    
    aLabel = [[UILabel alloc] initWithFrame:CGRectMake(left3, 0, 300, kView.height)];
    aLabel.textColor = color;
    aLabel.font = font;
    aLabel.text = [value1 addMoneyDot];
    [kView addSubview:aLabel];
    
    offy = kView.bottom + widthTo4_7(0.8);
    
    kView = [[UIView alloc] initWithFrame:CGRectMake(0, offy, self.view.width, height)];
    kView.backgroundColor = ColorHex(0xf0f0f0);
    [recordView addSubview:kView];
    
    aLabel = [[UILabel alloc] initWithFrame:CGRectMake(left0, 0, 300, kView.height)];
    aLabel.textColor = color;
    aLabel.font = font;
    aLabel.text = @"中奖总额:";
    [kView addSubview:aLabel];
    
    aLabel = [[UILabel alloc] initWithFrame:CGRectMake(left1, 0, 300, kView.height)];
    aLabel.textColor = color;
    aLabel.font = font;
    aLabel.text = [value2 addMoneyDot];
    [kView addSubview:aLabel];
    
    aLabel = [[UILabel alloc] initWithFrame:CGRectMake(left2, 0, 300, kView.height)];
    aLabel.textColor = color;
    aLabel.font = font;
    aLabel.text = @"代理返点:";
    [kView addSubview:aLabel];
    
    aLabel = [[UILabel alloc] initWithFrame:CGRectMake(left3, 0, 300, kView.height)];
    aLabel.textColor = color;
    aLabel.font = font;
    aLabel.text = [value3 addMoneyDot];
    [kView addSubview:aLabel];
    
    offy = kView.bottom + widthTo4_7(0.8);
    
    kView = [[UIView alloc] initWithFrame:CGRectMake(0, offy, self.view.width, height)];
    kView.backgroundColor = ColorHex(0xf0f0f0);
    [recordView addSubview:kView];
    
    aLabel = [[UILabel alloc] initWithFrame:CGRectMake(left0, 0, 300, kView.height)];
    aLabel.textColor = color;
    aLabel.font = font;
    aLabel.text = @"投注返点:";
    [kView addSubview:aLabel];
    
    aLabel = [[UILabel alloc] initWithFrame:CGRectMake(left1, 0, 300, kView.height)];
    aLabel.textColor = color;
    aLabel.font = font;
    aLabel.text = [value4 addMoneyDot];
    [kView addSubview:aLabel];
    
    offy = kView.bottom;
    return offy;
}



@end
