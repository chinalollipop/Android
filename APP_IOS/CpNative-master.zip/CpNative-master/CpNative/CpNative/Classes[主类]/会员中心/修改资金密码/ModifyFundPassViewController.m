//
//  ModifyFundPassViewController.m
//  CpNative
//
//  Created by david on 2019/2/20.
//  Copyright © 2019 david. All rights reserved.
//

#import "ModifyFundPassViewController.h"
#import "BindCardViewController.h"
#import "UserDetailViewController.h"

@interface ModifyFundPassViewController ()

@end

@implementation ModifyFundPassViewController {
    bool exist;
    
    UITextField *tfOldPass;
    UITextField *tfNewPass;
    UITextField *tfNewPass2;
    
    UIButton *submit;
    UIButton *reset;
    UIView *trayView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    trayView = [[UIView alloc] initWithFrame:CGRectMake(0, topbar.bottom, self.view.width, self.view.height-topbar.bottom)];
    [self.view addSubview:trayView];
    
    exist = [[Singleton shared].loginDict boolForKey:@"fund_password_exist"];
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    [trayView removeAllSubviews];
    
    topbar.titleLabel.text = (exist?@"修改资金密码":@"设置资金密码");
    
    CGFloat gap = 0.04*self.view.width;
    CGFloat top = gap*1.5;
    CGFloat wid = self.view.width-gap*2;
    CGFloat heig = widthTo4_7(44);
    
    if (!exist) {
        UILabel *warn = [[UILabel alloc] initWithFrame:CGRectMake(gap, 0, wid, heig*1.33)];
        warn.text = @"⚠️为了您的资金安全，请先设置资金密码。";
        warn.textColor = ColorHex(0xf79a00);
        warn.font = SystemFontBy4(13.6);
        [trayView addSubview:warn];
        top = warn.bottom;
    } else {
        tfOldPass = [self holder:@"请输入旧资金密码" rect:CGRectMake(gap, top, wid, heig)];
        top = tfOldPass.bottom+gap;
    }
    
    tfNewPass = [self holder:(exist?@"请输入新资金密码":@"请输入资金密码") rect:CGRectMake(gap, top, wid, heig)];
    
    UILabel *notice = [[UILabel alloc] initWithFrame:CGRectMake(tfNewPass.left, tfNewPass.bottom, 300, widthTo4_7(20))];
    notice.text = @"(由字母和数字组成6-16个字符)";
    notice.font = SystemFontBy4(12.2);
    notice.textColor = ColorHex(0x363636);
    [trayView addSubview:notice];
    
    tfNewPass2 = [self holder:(exist?@"确认新资金密码":@"确认资金密码") rect:CGRectMake(gap, notice.bottom+gap, wid, heig)];
    
    submit = [[UIButton alloc] initWithFrame:CGRectMake(gap, tfNewPass2.bottom+gap*1.5, (self.view.width-gap*3)/2, heig)];
    [submit setTitle:(exist?@"修改":@"设置") forState:0];
    [submit setTitleColor:ColorHex(0xffffff) forState:0];
    submit.titleLabel.font = SystemFontBy4(15.6);
    submit.backgroundColor = ColorSubmit;
    submit.layer.cornerRadius = 0.1*heig;
    submit.layer.masksToBounds = YES;
    [submit addTarget:self action:@selector(onSubmit) forControlEvents:UIControlEventTouchUpInside];
    [trayView addSubview:submit];
    
    reset = [[UIButton alloc] initWithFrame:CGRectMake(submit.right+gap, tfNewPass2.bottom+gap*1.5, (self.view.width-gap*3)/2, heig)];
    [reset setTitle:@"重置" forState:0];
    [reset setTitleColor:ColorHex(0xffffff) forState:0];
    reset.titleLabel.font = SystemFontBy4(15.6);
    reset.backgroundColor = ColorReset;
    reset.layer.cornerRadius = 0.1*heig;
    reset.layer.masksToBounds = YES;
    [reset addTarget:self action:@selector(onReset) forControlEvents:UIControlEventTouchUpInside];
    [trayView addSubview:reset];
}

- (void)onSubmit {
    if (exist) {
        if (!tfOldPass.text.length) {
            [Tools showText:@"请输入旧资金密码"];
            return;
        }
        if (!tfNewPass.text.length) {
            [Tools showText:@"请输入新资金密码"];
            return;
        }
        if (!tfNewPass2.text.length) {
            [Tools showText:@"请再次输入新资金密码"];
            return;
        }
        if (![tfNewPass.text isEqualToString:tfNewPass2.text]) {
            [Tools showText:@"两次输入的新密码不一致"];
            return;
        }
        
        [[UIApplication sharedApplication].keyWindow endEditing:YES];
        [MBProgressHUD showHUDAddedTo:mainDelegate.window animated:NO];
        [NetworkBusiness modifyFundPassWithOld:tfOldPass.text newPass:tfNewPass.text Block:^(NSError *error, int code, id response) {
            [MBProgressHUD hideHUDForView:mainDelegate.window animated:NO];
            
            /*判断是否重新登录*/
            if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
                return;
            }
            
            if (code == 200) {
                if ([response integerForKey:@"errno"] == 0) {
                    [[Singleton shared].loginDict setBool:YES forKey:@"fund_password_exist"];
                    exist = YES;
                    [Tools alertWithTitle:@"资金密码修改成功!" message:nil handle:^(UIAlertAction * _Nonnull action) {
                        [self ok];
                    } cancel:nil confirm:@"确定"];
                } else {
                    NSString *str = [response stringForKey:@"error"];
                    [Tools alertWithTitle:str message:@"❌" handle:nil cancel:nil confirm:@"确定"];
                }
            }
        }];
    } else {
        if (!tfNewPass.text.length) {
            [Tools showText:@"请输入资金密码"];
            return;
        }
        if (!tfNewPass2.text.length) {
            [Tools showText:@"请再次输入资金密码"];
            return;
        }
        if (![tfNewPass.text isEqualToString:tfNewPass2.text]) {
            [Tools showText:@"两次输入的密码不一致"];
            return;
        }
        
        [[UIApplication sharedApplication].keyWindow endEditing:YES];
        [MBProgressHUD showHUDAddedTo:mainDelegate.window animated:NO];
        [NetworkBusiness setFundPasswordWithPass:tfNewPass.text Block:^(NSError *error, int code, id response) {
            [MBProgressHUD hideHUDForView:mainDelegate.window animated:NO];
            
            /*判断是否重新登录*/
            if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
                return;
            }
            
            if (code == 200) {
                if ([response integerForKey:@"errno"] == 0) {
                    [[Singleton shared].loginDict setBool:YES forKey:@"fund_password_exist"];
                    exist = YES;
                    [Tools alertWithTitle:@"资金密码设置成功!" message:nil handle:^(UIAlertAction * _Nonnull action) {
                        [self ok];
                    } cancel:nil confirm:@"确定"];
                } else {
                    NSString *str = [response stringForKey:@"error"];
                    [Tools alertWithTitle:str message:nil handle:nil cancel:nil confirm:@"确定"];
                }
            }
        }];
    }
}

- (void)ok {
    if (_isBindBankCard) {
        
        exist = ([[Singleton shared].loginDict stringForKey:@"name"].length > 1);
        if (exist) {
            BindCardViewController *bind = [[BindCardViewController alloc] init];
            [self.navigationController pushViewController:bind animated:YES];
        } else {
            UserDetailViewController *user = [[UserDetailViewController alloc] init];
            user.isBindBankCard = YES;
            [user setupShowWarn:YES];
            [self.navigationController pushViewController:user animated:YES];
        }
    } else {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)onReset {
    tfOldPass.text = @"";
    tfNewPass.text = @"";
    tfNewPass2.text = @"";
}


- (UITextField *)holder:(NSString *)holder rect:(CGRect)rect {
    UIFont *font = SystemFontBy4(13.6);
    UIColor *color = ColorHex(0x222222);
    CGColorRef borderColor = ColorHex(0x777777).CGColor;
    CGFloat borderWidth = widthTo4_7(1.0);
    CGFloat cornerRadius = 0.1*rect.size.height;
    UITextField *tf = [[UITextField alloc] initWithFrame:rect];
    tf.placeholder = holder;
    tf.textColor = color;
    tf.font = font;
    tf.layer.borderColor = borderColor;
    tf.layer.borderWidth = borderWidth;
    tf.layer.cornerRadius = cornerRadius;
    tf.layer.masksToBounds = YES;
    tf.secureTextEntry = YES;
    tf.clearButtonMode = UITextFieldViewModeWhileEditing;
    UIView *pad = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0.042*tf.width, tf.height)];
    tf.leftView = pad;
    tf.leftViewMode = UITextFieldViewModeAlways;
    [trayView addSubview:tf];
    return tf;
}
@end
