//
//  PayNextH5ViewController.h
//  CpNative
//
//  Created by david on 2019/4/15.
//  Copyright © 2019 david. All rights reserved.
//

#import "CFCBaseWKWebViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface PayNextH5ViewController : CFCBaseWKWebViewController

@end

NS_ASSUME_NONNULL_END
