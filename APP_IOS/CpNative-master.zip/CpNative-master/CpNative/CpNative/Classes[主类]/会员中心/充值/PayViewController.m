//
//  PayViewController.m
//  CpNative
//
//  Created by david on 2019/2/18.
//  Copyright © 2019 david. All rights reserved.
//

#import "PayViewController.h"
#import "PayNextViewController.h"
#import "PayKsczViewController.h"

@interface PayViewController ()<UITextFieldDelegate>

@end

@implementation PayViewController {
    BasicScrollView *scrollB;
    UIView *contentView;
    UILabel *balanceLbl;
    CGFloat left;
    UITextField *tfMoney;
    UIView *moneyInput;
    NSArray *titles;
    UIView *changingView;//根据点击的支付方式切换的视图
    NSInteger currentWay;//当前选中的支付方式
    NSInteger currentSubWay;//当前选中的支付方式子方式
    NSArray *keys;//支付方式定义的key
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = ColorHex(0xf0f0f0);
    
    topbar.titleLabel.text = @"充值";
    
    left = widthTo4_7(10);
    
    scrollB = [[BasicScrollView alloc] initWithFrame:CGRectMake(0, topbar.height, self.view.width, self.view.height-topbar.height)];
    [self.view addSubview:scrollB];
    
    contentView = [[UIView alloc] initWithFrame:scrollB.bounds];
    [scrollB addSubview:contentView];
    
    scrollB.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self requestPaymentWays];
    }];
    [scrollB.mj_header beginRefreshing];
}

/*请求支付方式*/
- (void)requestPaymentWays {
    currentSubWay = -1;
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness getPayBanksBlock:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        [scrollB.mj_header endRefreshing];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                _payways = [response dictionaryForKey:@"data"];
                if (!_payways) {
                    [Tools showText:[response stringForKey:@"error"]];
                }
                [self buidUI];
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools alertWithTitle:str message:nil handle:^(UIAlertAction * _Nonnull action) {
                    [self.navigationController popViewControllerAnimated:YES];
                } cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求失败,请稍后再试."];
        }
    }];
}

- (void)buidUI {
    [contentView removeAllSubviews];

    balanceLbl = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.view.width, widthTo4_7(48))];
    balanceLbl.textAlignment = NSTextAlignmentCenter;
    [contentView addSubview:balanceLbl];
    NSString *money = [[Singleton shared].balance addMoneyDot];
    NSString *text = [NSString stringWithFormat:@"我的余额: %@元",money];
    NSMutableAttributedString *mstr = [[NSMutableAttributedString alloc] initWithString:text];
    [mstr setFont:SystemFontBy4(14.2) inRange:NSMakeRange(0, text.length)];
    [mstr setAlignment:NSTextAlignmentCenter];
    [mstr setForegroundColor:ColorHex(0x262626) inRange:NSMakeRange(0, text.length)];
    [mstr setForegroundColor:COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT inRange:[text rangeOfString:money]];
    balanceLbl.attributedText = mstr;
    
    moneyInput = [[UIView alloc] initWithFrame:CGRectMake(0, balanceLbl.bottom, contentView.width, widthTo4_7(155))];
    moneyInput.backgroundColor = ColorHex(0xffffff);
    [contentView addSubview:moneyInput];
    
    UILabel *tt = [[UILabel alloc] initWithFrame:CGRectMake(left, 0, moneyInput.width, widthTo4_7(70))];
    tt.text = @"请输入充值金额:";
    tt.font = SystemFontBy4(13.6);
    tt.textColor = ColorHex(0x262626);
    [moneyInput addSubview:tt];
    
    titles = @[@"10",@"100",@"500",@"1000",@"3000",@"5000",@"10000",@"20000",];
    CGFloat wid = [tt.text widthWithFont:tt.font constrainedToHeight:30];
    wid = left+wid+widthTo4_7(10);
    tfMoney = [[UITextField alloc] initWithFrame:CGRectMake(wid, tt.top+widthTo4_7(17), moneyInput.width-wid-widthTo4_7(34), tt.height-widthTo4_7(34))];
    tfMoney.layer.borderColor = ColorHex(0x777777).CGColor;
    tfMoney.layer.borderWidth = widthTo4_7(1.0);
    tfMoney.layer.cornerRadius = widthTo4_7(2.6);
    tfMoney.layer.masksToBounds = YES;
    tfMoney.clearButtonMode = UITextFieldViewModeWhileEditing;
    tfMoney.font = tt.font;
    tfMoney.textColor = ColorHex(0x262626);
    tfMoney.text = titles[0];
    tfMoney.keyboardType = UIKeyboardTypeDecimalPad;
    tfMoney.delegate = self;
    [moneyInput addSubview:tfMoney];
    UIView *pad = [[UIView alloc] initWithFrame:CGRectMake(0, 0, widthTo4_7(10), tfMoney.height)];
    tfMoney.leftView = pad;
    tfMoney.leftViewMode = UITextFieldViewModeAlways;
    
    UILabel *yuan = [[UILabel alloc] initWithFrame:CGRectMake(tfMoney.right, tt.top, moneyInput.width-tfMoney.right-left, tt.height)];
    yuan.text = @"元";
    yuan.textAlignment = NSTextAlignmentRight;
    yuan.textColor = tt.textColor;
    yuan.font = tt.font;
    [moneyInput addSubview:yuan];
    
    CGFloat width = (moneyInput.width-left*5)/4;
    CGFloat height = width*0.37;
    for (int i = 0; i < titles.count; i++) {
        UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(left+(width+left)*(i%4), tt.height+(height+left)*(i/4), width, height)];
        btn.tag = i;
        btn.layer.borderWidth = widthTo4_7(1.0);
        btn.layer.cornerRadius = widthTo4_7(2.6);
        btn.layer.masksToBounds = YES;
        [btn setTitle:titles[i] forState:0];
        btn.titleLabel.font = SystemFontBy4(13.1);
        [moneyInput addSubview:btn];
        [btn addTarget:self action:@selector(onMoneyButton:) forControlEvents:UIControlEventTouchUpInside];
    }
    [self setButtonStatus:0];
    
    UILabel *fang = [[UILabel alloc] initWithFrame:CGRectMake(left, moneyInput.bottom, 300, widthTo4_7(40))];
    fang.text = @"请选择充值方式:";
    fang.textColor = tt.textColor;
    fang.font = tt.font;
    [contentView addSubview:fang];
    
    NSArray *defaultKeys = @[@"weixin",@"alipay",@"bank",@"yunshanfu",@"kscz",];
    NSArray *defaultNames = @[@"微信",@"支付宝",@"银行转账",@"云闪付",@"快速充值",];
    keys = _payways.allKeys;
    NSMutableArray *waytitles = [NSMutableArray array];
    for (int i = 0; i < keys.count; i++) {
        NSString *key = keys[i];
        NSInteger index = [defaultKeys indexOfObject:key];
        if (index >= 0  &&  index < defaultKeys.count) {
            [waytitles addObject:defaultNames[index]];
        }
    }
    
    CGFloat bw = contentView.width/waytitles.count;
    CGFloat bh = widthTo4_7(48);
    for (int i = 0; i < waytitles.count; i++) {
        PaymentWayButton *button = [[PaymentWayButton alloc] initWithFrame:CGRectMake(bw*i, fang.bottom, bw, bh)];
        [button addTarget:self action:@selector(onPaymentWayButton:) forControlEvents:UIControlEventTouchUpInside];
        [button setupWithTitle:waytitles[i]];
        [contentView addSubview:button];
        button.tag = i;
    }
    for (int i = 0; i < waytitles.count-1; i++) {
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(bw*(i+1), fang.bottom, widthTo4_7(1.0), bh)];
        line.backgroundColor = LineColor;
        [contentView addSubview:line];
    }
    
    changingView = [[UIView alloc] initWithFrame:CGRectMake(0, fang.bottom+bh, contentView.width, 1)];
    [contentView addSubview:changingView];
    
    currentWay = 0;
    [self setPaymentwayButtonStatus];
    [self updateChangingView];
}

- (void)updateChangingView {
    [changingView removeAllSubviews];
    NSString *key = keys[currentWay];
    NSArray *dataArr = [_payways arrayForKey:key];
    
    CGFloat itemHei = widthTo4_7(94);
    for (int i = 0; i < dataArr.count+1; i++) {
        UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0, itemHei*i, changingView.width, itemHei)];
        button.tag = i;
        [changingView addSubview:button];
        [button addTarget:self action:@selector(onPaywayButton:) forControlEvents:UIControlEventTouchUpInside];
        
        if (i > 0) {
            [Tools addBorderToLayer:button];
        }
        
        if (i < dataArr.count) {
            NSDictionary *dict = (dataArr[i]);
            NSString *title = [dict stringForKey:@"display_name"];
            NSString *subtitle =  [dict stringForKey:@"brief_description"];
            
            UILabel *titleLab = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(14), 0, 300, widthTo4_7(50))];
            titleLab.text = title;
            titleLab.textColor = ColorHex(0x262626);
            titleLab.font = SystemFontBy4(13.6);
            [button addSubview:titleLab];
            
            UILabel *sub = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(14), 0.32*itemHei, 300, 0.68*itemHei)];
            sub.text = subtitle;
            sub.textColor = ColorHex(0xee0000);
            sub.font = SystemFontBy4(13.2);
            sub.numberOfLines = 0;
            [button addSubview:sub];
            
            CGFloat size = widthTo4_7(21);
            UIImageView *imagev = [[UIImageView alloc] initWithFrame:CGRectMake(button.width-widthTo4_7(41), (titleLab.height-size)/2, size, size)];
            imagev.image = [UIImage imageNamed:@"quan"];
            [button addSubview:imagev];
            imagev.tag = 333;
        }
        
        if (i == dataArr.count) {
            button.userInteractionEnabled = NO;
            UIView *temp = [[UIView alloc] initWithFrame:button.frame];
            [button.superview addSubview:temp];
            UIButton *submit = [[UIButton alloc] initWithFrame:CGRectMake(widthTo4_7(10), widthTo4_7(15), button.width-widthTo4_7(20), widthTo4_7(42))];
            [submit setTitle:@"下一步" forState:0];
            [submit setTitleColor:ColorHex(0xffffff) forState:0];
            submit.backgroundColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;
            submit.layer.cornerRadius = widthTo4_7(5);
            submit.layer.masksToBounds = YES;
            submit.titleLabel.font = SystemFontBy4(13.6);
            [temp addSubview:submit];
            [submit addTarget:self action:@selector(onSubmit:) forControlEvents:UIControlEventTouchUpInside];
        }
    }
    changingView.height = itemHei*(dataArr.count+1);
    contentView.height = changingView.bottom;
    
    scrollB.contentSize = CGSizeMake(contentView.width, contentView.height);
    
    
    
}

- (void)onPaywayButton:(UIButton *)button {
    currentSubWay = button.tag;
    [self setPaySubWaySelected];
}

- (void)setPaySubWaySelected {
    for (UIButton *btn in changingView.subviews) {
        if ([btn isKindOfClass:[UIButton class]]) {
            UIImageView *vv = [btn viewWithTag:333];
            if ([vv isKindOfClass:[UIImageView class]]) {
                if (btn.tag == currentSubWay) {
                    vv.image = [UIImage imageNamed:@"gou"];
                    vv.frame = CGRectMake(btn.superview.width-widthTo4_7(43), (widthTo4_7(25))/2, widthTo4_7(25), widthTo4_7(25));
                } else {
                    vv.image = [UIImage imageNamed:@"quan"];
                    vv.frame = CGRectMake(btn.superview.width-widthTo4_7(41), (widthTo4_7(29))/2, widthTo4_7(21), widthTo4_7(21));
                }
            }
        }
    }
}

- (void)onSubmit:(UIButton *)button {
    NSLog(@"点击下一步:%li,,%li",currentWay,currentSubWay);
    
    if (currentSubWay < 0) {
        [Tools showText:@"请选择支付方式"];
        return;
    }
    
    if (tfMoney.text.intValue <= 0) {
        [Tools showText:@"请输入充值金额"];
        return;
    }
    
    NSString *key = keys[currentWay];
    NSArray  *thisArray = [_payways arrayForKey:key];
    NSDictionary *thisDict = thisArray[currentSubWay];
    
    if ([key isEqualToString:@"kscz"]) { //快速充值只是打开一个链接，则单独处理
        NSString *link = [thisDict stringForKey:@"link"];
        if (!link) {
            [Tools showText:@"请稍后再试"];
            return;
        }
        
        PayKsczViewController *kscz = [[PayKsczViewController alloc] init];
        kscz.htmlUrlString = link;
        [self.navigationController pushViewController:kscz animated:YES];
        
        return;
    }

    NSString *type = [thisDict stringForKey:@"type"];
    NSString *_id = [thisDict stringForKey:@"id"];
    
    [MBProgressHUD showHUDAddedTo:mainDelegate.window animated:NO];
    [NetworkBusiness veryfyForMode:type amount:tfMoney.text platform:_id Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:mainDelegate.window animated:NO];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                NSDictionary *data = [response dictionaryForKey:@"data"];
                PayNextViewController *next = [[PayNextViewController alloc] init];
                next.data = data;
                next.way = keys[currentWay];
                next.money = tfMoney.text;
                [self.navigationController pushViewController:next animated:YES];
            } else {
               [Tools showText:[response stringForKey:@"error"]];
            }
        } else {
            [Tools showText:@"请求失败,请稍后再试."];
        }
    }];
    
    
}


- (void)onPaymentWayButton:(UIButton *)button {
    currentWay = button.tag;
    currentSubWay = -1;
    [self setPaymentwayButtonStatus];
    [self updateChangingView];
}

- (void)setPaymentwayButtonStatus {
    for (PaymentWayButton *btn in contentView.subviews) {
        if ([btn isKindOfClass:[PaymentWayButton class]]) {
            if (btn.tag == currentWay) {
                btn.selected = YES;
            } else {
                btn.selected = NO;
            }
        }
    }
}

- (void)onMoneyButton:(UIButton *)btn {
    [self setButtonStatus:btn.tag];
    tfMoney.text = btn.titleLabel.text;
}

- (void)setButtonStatus:(NSInteger)tag {
    for (UIButton *btn in moneyInput.subviews) {
        if ([btn isKindOfClass:[UIButton class]]) {
            if (btn.tag == tag) {
                btn.layer.borderColor = ColorHex(0xff0000).CGColor;
                [btn setTitleColor:ColorHex(0xff0000) forState:0];
            } else {
                btn.layer.borderColor = ColorHex(0x808080).CGColor;
                [btn setTitleColor:ColorHex(0x343434) forState:0];
            }
        }
    }
}

- (BOOL)textFieldShouldClear:(UITextField *)textField {
    [self setButtonStatus:-1];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString *value = [textField.text stringByReplacingCharactersInRange:range withString:string];
    NSInteger *tag = -1;
    for (int i = 0; i < titles.count; i++) {
        NSString *str = titles[i];
        if (str.floatValue == value.floatValue) {
            tag = i;
            break;
        }
    }
    [self setButtonStatus:tag];
    return YES;
}
@end





@implementation PaymentWayButton {
    UIView *bar;
}

- (void)setupWithTitle:(NSString *)title {
    [self setTitle:title forState:0];
    self.backgroundColor = ColorHex(0xffffff);
    [self setTitleColor:ColorHex(0x262626) forState:0];
    self.titleEdgeInsets = UIEdgeInsetsMake(0, 0, self.height*0.07, 0);
    self.titleLabel.font = SystemFontBy4(13.6);
    
    bar = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.width, widthTo4_7(2.6))];
    bar.backgroundColor = ColorHex(0xee0000);
    [self addSubview:bar];
    bar.bottom = self.height;
}

- (void)setSelected:(BOOL)selected {
    if (selected) {
        bar.backgroundColor = ColorHex(0xee0000);
        [self setTitleColor:ColorHex(0xff0000) forState:0];
    } else {
        bar.backgroundColor = LineColor;
        [self setTitleColor:ColorHex(0x262626) forState:0];
    }
}





@end




