//
//  PayKsczViewController.h
//  CpNative
//
//  Created by david on 2019/4/14.
//  Copyright © 2019 david. All rights reserved.
//

#import "CFCBaseWKWebViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface PayKsczViewController : CFCBaseWKWebViewController

@end

NS_ASSUME_NONNULL_END
