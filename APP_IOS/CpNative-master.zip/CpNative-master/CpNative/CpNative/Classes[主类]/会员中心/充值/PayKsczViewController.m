//
//  PayKsczViewController.m
//  CpNative
//
//  Created by david on 2019/4/14.
//  Copyright © 2019 david. All rights reserved.
//

#import "PayKsczViewController.h"

@interface PayKsczViewController ()

@end

@implementation PayKsczViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

#pragma mark - WKWKNavigationDelegate
#pragma mark 加载的状态回调 - 开始加载网页
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation
{
    [super webView:webView didStartProvisionalNavigation:navigation];
    
    NSString *address = webView.URL.absoluteString;
    if ([address containsString:@"weixin://"] || [address hasPrefix:@"alipays://"] || [address hasPrefix:@"alipay://"]) {
        
        BOOL canOpen = [[UIApplication sharedApplication] canOpenURL:webView.URL];
        NSLog(@"是否可以跳转:%i",canOpen);
        [[UIApplication sharedApplication] openURL:webView.URL];
        
        return;
    }
    
}

@end
