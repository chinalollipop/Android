//
//  PayNextViewController.h
//  CpNative
//
//  Created by david on 2019/2/23.
//  Copyright © 2019 david. All rights reserved.
//

#import "BasicWithNaviBarViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface PayNextViewController : BasicWithNaviBarViewController

@property(nonatomic, strong) NSDictionary *data;
@property(nonatomic, copy) NSString *way;
@property(nonatomic, copy) NSString *money;


@end

NS_ASSUME_NONNULL_END
