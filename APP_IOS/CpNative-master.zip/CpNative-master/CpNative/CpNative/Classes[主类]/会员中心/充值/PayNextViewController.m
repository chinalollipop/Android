//
//  PayNextViewController.m
//  CpNative
//
//  Created by david on 2019/2/23.
//  Copyright © 2019 david. All rights reserved.
//

#import "PayNextViewController.h"
#import "PayNextH5ViewController.h"

@interface PayNextViewController ()<WKNavigationDelegate>

@end

@implementation PayNextViewController {
    UITextField *tfName;
    NSDictionary *dict;
    BOOL existDetail;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    topbar.titleLabel.text = @"提交订单";
    
    dict = [_data dictionaryForKey:@"aPlatform"];
    
    CGFloat borderwidth = widthTo4_7(1.2);
    UIColor *borderColor = ColorHex(0xc0c0c0);
    CGFloat left = widthTo4_7(12);
    UIView *upview = [[UIView alloc] initWithFrame:CGRectMake(left, topbar.bottom+left*0.8, self.view.width-left*2, 0.598*self.view.height)];
    upview.layer.borderColor = borderColor.CGColor;
    upview.layer.borderWidth = borderwidth;
    upview.layer.masksToBounds = YES;
    [self.view addSubview:upview];
    
    //图标
    CGFloat topHeight = widthTo4_7(46);//上方图标的高度
    UIImage *image = [UIImage imageNamed:_way];
    CGFloat imh = topHeight*0.62;
    CGFloat imw = image.size.width/image.size.height*imh;
    UIImageView *imageview = [[UIImageView alloc] initWithFrame:CGRectMake(left, (topHeight-imh)/2, imw, imh)];
    imageview.image = image;
    [upview addSubview:imageview];
    
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, topHeight, upview.width, borderwidth)];
    line.backgroundColor = borderColor;
    [upview addSubview:line];
    
    //姓名
    CGFloat leftHeig = upview.height - topHeight;
    CGFloat textHeight = 0.14*leftHeig;
    UILabel *xm = [[UILabel alloc] initWithFrame:CGRectMake(left, topHeight, 100, textHeight)];
    xm.text = @"充值方式:";
    xm.textColor = ColorHex(0x161616);
    xm.font = SystemFontBy4(13.);
    [upview addSubview:xm];
    UILabel *xingming = [[UILabel alloc] initWithFrame:CGRectMake(0.05*upview.width, topHeight, upview.width, xm.height)];
    xingming.textAlignment = NSTextAlignmentCenter;
    xingming.font = xm.font;
    xingming.textColor = xm.textColor;
    xingming.text = [dict stringForKey:@"display_name"];
    [upview addSubview:xingming];
    //复制按钮
    UIButton *copyBtn = [[UIButton alloc] initWithFrame:CGRectMake(upview.width-widthTo4_7(55), xm.top, widthTo4_7(55), xm.height)];
    [copyBtn setTitle:@"复制" forState:0];
    [copyBtn setTitleColor:[UIColor redColor] forState:0];
    copyBtn.titleLabel.font = xm.font;
    __block NSString *pasteText = xingming.text;
    [copyBtn handleCallBack:^(UIButton *button) {
        UIPasteboard*pasteboard = [UIPasteboard generalPasteboard];
        pasteboard.string = pasteText;
        [Tools showText:[NSString stringWithFormat:@"已复制\"%@\"",pasteText]];
    } forEvent:UIControlEventTouchUpInside];
    [upview addSubview:copyBtn];
    
    
    CGFloat wouldBottom = xingming.bottom;
    
    //插入汇款银行信息
    NSDictionary *bankInfo = [_data dictionaryForKey:@"aPaymentPlatformBankCard"];
    if (bankInfo) {
        NSString *bankString = [bankInfo stringForKey:@"bank"];
        NSString *ownerString = [bankInfo stringForKey:@"owner"];
        NSString *accountString = [bankInfo stringForKey:@"account_no"];
        NSString *branchString = [bankInfo stringForKey:@"branch"];
        if (accountString.length > 5) { //判断银行卡账号号码长度，可以进一步确认是否存在汇款信息
            
            textHeight *= 0.75;
            xm.height = xingming.height = copyBtn.height = textHeight;
            wouldBottom = xingming.bottom;
            textHeight *= 0.75;
            
            //收款银行
            UILabel *xm = [[UILabel alloc] initWithFrame:CGRectMake(left, wouldBottom*0.922, 100, textHeight)];
            xm.text = @"收款银行:";
            xm.textColor = ColorHex(0x161616);
            xm.font = SystemFontBy4(13.);
            [upview addSubview:xm];
            UILabel *xingming = [[UILabel alloc] initWithFrame:CGRectMake(0.05*upview.width, xm.top, upview.width, xm.height)];
            xingming.textAlignment = NSTextAlignmentCenter;
            xingming.font = xm.font;
            xingming.textColor = xm.textColor;
            xingming.text = bankString;
            [upview addSubview:xingming];
            //复制按钮
            UIButton *copyBtn = [[UIButton alloc] initWithFrame:CGRectMake(upview.width-widthTo4_7(55), xm.top, widthTo4_7(55), xm.height)];
            [copyBtn setTitle:@"复制" forState:0];
            [copyBtn setTitleColor:[UIColor redColor] forState:0];
            copyBtn.titleLabel.font = xm.font;
            __block NSString *pasteText = xingming.text;
            [copyBtn handleCallBack:^(UIButton *button) {
                UIPasteboard*pasteboard = [UIPasteboard generalPasteboard];
                pasteboard.string = pasteText;
                [Tools showText:[NSString stringWithFormat:@"已复制\"%@\"",pasteText]];
            } forEvent:UIControlEventTouchUpInside];
            [upview addSubview:copyBtn];
            wouldBottom = xingming.bottom;
            
            //收款账户
            xm = [[UILabel alloc] initWithFrame:CGRectMake(left, wouldBottom, 100, textHeight)];
            xm.text = @"收款账户:";
            xm.textColor = ColorHex(0x161616);
            xm.font = SystemFontBy4(13.);
            [upview addSubview:xm];
            xingming = [[UILabel alloc] initWithFrame:CGRectMake(0.05*upview.width, xm.top, upview.width, xm.height)];
            xingming.textAlignment = NSTextAlignmentCenter;
            xingming.font = xm.font;
            xingming.textColor = xm.textColor;
            xingming.text = ownerString;
            [upview addSubview:xingming];
            //复制按钮
            copyBtn = [[UIButton alloc] initWithFrame:CGRectMake(upview.width-widthTo4_7(55), xm.top, widthTo4_7(55), xm.height)];
            [copyBtn setTitle:@"复制" forState:0];
            [copyBtn setTitleColor:[UIColor redColor] forState:0];
            copyBtn.titleLabel.font = xm.font;
            __block NSString *pasteText1 = xingming.text;
            [copyBtn handleCallBack:^(UIButton *button) {
                UIPasteboard*pasteboard = [UIPasteboard generalPasteboard];
                pasteboard.string = pasteText1;
                [Tools showText:[NSString stringWithFormat:@"已复制\"%@\"",pasteText1]];
            } forEvent:UIControlEventTouchUpInside];
            [upview addSubview:copyBtn];
            wouldBottom = xingming.bottom;
            
            //收款账号
            xm = [[UILabel alloc] initWithFrame:CGRectMake(left, wouldBottom, 100, textHeight)];
            xm.text = @"收款账号:";
            xm.textColor = ColorHex(0x161616);
            xm.font = SystemFontBy4(13.);
            [upview addSubview:xm];
            xingming = [[UILabel alloc] initWithFrame:CGRectMake(0.05*upview.width, xm.top, upview.width, xm.height)];
            xingming.textAlignment = NSTextAlignmentCenter;
            xingming.font = xm.font;
            xingming.textColor = xm.textColor;
            xingming.text = accountString;
            [upview addSubview:xingming];
            //复制按钮
            copyBtn = [[UIButton alloc] initWithFrame:CGRectMake(upview.width-widthTo4_7(55), xm.top, widthTo4_7(55), xm.height)];
            [copyBtn setTitle:@"复制" forState:0];
            [copyBtn setTitleColor:[UIColor redColor] forState:0];
            copyBtn.titleLabel.font = xm.font;
            __block NSString *pasteText2 = xingming.text;
            [copyBtn handleCallBack:^(UIButton *button) {
                UIPasteboard*pasteboard = [UIPasteboard generalPasteboard];
                pasteboard.string = pasteText2;
                [Tools showText:[NSString stringWithFormat:@"已复制\"%@\"",pasteText2]];
            } forEvent:UIControlEventTouchUpInside];
            [upview addSubview:copyBtn];
            wouldBottom = xingming.bottom;
            
            //收款支行
            xm = [[UILabel alloc] initWithFrame:CGRectMake(left, wouldBottom, 100, textHeight)];
            xm.text = @"收款支行:";
            xm.textColor = ColorHex(0x161616);
            xm.font = SystemFontBy4(13.);
            [upview addSubview:xm];
            xingming = [[UILabel alloc] initWithFrame:CGRectMake(0.05*upview.width, xm.top, upview.width, xm.height)];
            xingming.textAlignment = NSTextAlignmentCenter;
            xingming.font = xm.font;
            xingming.textColor = xm.textColor;
            xingming.text = branchString;
            [upview addSubview:xingming];
            //复制按钮
            copyBtn = [[UIButton alloc] initWithFrame:CGRectMake(upview.width-widthTo4_7(55), xm.top, widthTo4_7(55), xm.height)];
            [copyBtn setTitle:@"复制" forState:0];
            [copyBtn setTitleColor:[UIColor redColor] forState:0];
            copyBtn.titleLabel.font = xm.font;
            __block NSString *pasteText3 = xingming.text;
            [copyBtn handleCallBack:^(UIButton *button) {
                UIPasteboard*pasteboard = [UIPasteboard generalPasteboard];
                pasteboard.string = pasteText3;
                [Tools showText:[NSString stringWithFormat:@"已复制\"%@\"",pasteText3]];
            } forEvent:UIControlEventTouchUpInside];
            [upview addSubview:copyBtn];
            wouldBottom = xingming.bottom;
            
        }
    }
    
    
    
    
    NSString *detail = [dict stringForKey:@"notice"];
    if (detail && detail.length) {
        existDetail = YES;
        detail = [Tools urlAddHost:detail isBare:NO prefix:@""];
        WKWebView *web = [[WKWebView alloc] initWithFrame:CGRectMake(left*0.5, wouldBottom, upview.width-left, upview.height-wouldBottom)];
        web.navigationDelegate = self;
        [web loadHTMLString:detail baseURL:nil];
        [upview addSubview:web];
    } else {
        existDetail = NO;
        upview.height = wouldBottom;
    }
    
    
    
    
    UIView *downview = [[UIView alloc] initWithFrame:CGRectMake(left, upview.bottom+left*2, upview.width, widthTo4_7(92))];
    downview.layer.borderWidth = borderwidth;
    downview.layer.borderColor = borderColor.CGColor;
    downview.layer.masksToBounds = YES;
    downview.layer.cornerRadius = widthTo4_7(4.0);
    [self.view addSubview:downview];
    
    UILabel *cunkuan = [[UILabel alloc] initWithFrame:CGRectMake(left*2.8, upview.bottom+left, widthTo4_7(89), left*2)];
    cunkuan.backgroundColor = [UIColor whiteColor];
    cunkuan.textAlignment = NSTextAlignmentCenter;
    cunkuan.text = @"存款信息";
    cunkuan.font = BoldSystemFontBy4(13.0);
    cunkuan.textColor = ColorHex(0xe73323);
    [self.view addSubview:cunkuan];
    
    UILabel *qian = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 0.35*downview.width, 0.6*downview.height)];
    qian.text = @"存款金额:";
    qian.textColor = ColorHex(0x161616);
    qian.font = SystemFontBy4(13.4);
    qian.textAlignment = NSTextAlignmentRight;
    [downview addSubview:qian];
    
    CGFloat txH = downview.height*0.3;
    UITextField *tfMoney = [[UITextField alloc] initWithFrame:CGRectMake(qian.right+widthTo4_7(12), (qian.height-txH)/2, 0.48*downview.width, txH)];
    tfMoney.textAlignment = NSTextAlignmentCenter;
    tfMoney.text = [NSString stringWithFormat:@"%@元",_money];
    tfMoney.font = SystemFontBy4(13.4);
    tfMoney.textColor = ColorHex(0x161616);
    [downview addSubview:tfMoney];
    tfMoney.userInteractionEnabled = NO;
    
    if (existDetail) {
        UILabel *ming = [[UILabel alloc] initWithFrame:CGRectMake(0, 0.4*downview.height, 0.35*downview.width, 0.6*downview.height)];
        ming.text = @"真实姓名:";
        ming.textColor = ColorHex(0x161616);
        ming.font = SystemFontBy4(13.4);
        ming.textAlignment = NSTextAlignmentRight;
        [downview addSubview:ming];
        
        tfName = [[UITextField alloc] initWithFrame:CGRectMake(qian.right+widthTo4_7(12), ming.top + (ming.height-txH)/2, 0.48*downview.width, txH)];
        tfName.textAlignment = NSTextAlignmentCenter;
        tfName.placeholder = @"请输入真实姓名";
        tfName.font = SystemFontBy4(13.4);
        tfName.textColor = ColorHex(0x161616);
        tfName.layer.borderColor = borderColor.CGColor;
        tfName.layer.borderWidth = widthTo4_7(1.0);
        tfName.layer.masksToBounds = YES;
        tfName.clearButtonMode = UITextFieldViewModeWhileEditing;
        [downview addSubview:tfName];
    } else {
        downview.height = tfMoney.bottom + widthTo4_7(10);
    }

    
    
    
    
    UIButton *submit = [[UIButton alloc] initWithFrame:CGRectMake(left, downview.bottom+left*1.7, downview.width, widthTo4_7(42))];
    submit.layer.cornerRadius = widthTo4_7(5);
    submit.layer.masksToBounds = YES;
    submit.backgroundColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;
    [submit setTitle:@"提交订单" forState:0];
    [submit setTitleColor:ColorHex(0xffffff) forState:0];
    submit.titleLabel.font = SystemFontBy4(13.6);
    [self.view addSubview:submit];
    [submit addTarget:self action:@selector(onSubmit) forControlEvents:UIControlEventTouchUpInside];
}

- (void)onSubmit {
    if (existDetail && (tfName.text.length < 1)) {
        [Tools showText:@"请输入真实姓名"];
        return;
    }
    
    //智融宝微信h5
    NSDictionary *aPlatform = [_data dictionaryForKey:@"aPlatform"];
    if ([aPlatform isKindOfClass:[NSDictionary class]]) {
        NSInteger pay_type = [aPlatform integerForKey:@"pay_type"];
        if (pay_type == 1) {
            NSString *payment_platform_id = [_data stringForKey:@"iPlatformId"];
            NSString *amount = _money;
            NSString *deposit_mode = [_data stringForKey:@"iDepositMode"];
            NSString *token = [[Singleton shared].loginDict stringForKey:@"token"];
            NSString *urlString = [NSString stringWithFormat:@"%@?payment_platform_id=%@&amount=%@&deposit_mode=%@&action=Payment&step=3&packet=Fund&terminal_id=2&token=%@",ApiFor(Api_Service),payment_platform_id,amount,deposit_mode,token];
            PayNextH5ViewController *h5 = [[PayNextH5ViewController alloc] init];
            h5.htmlUrlString = urlString;
            [self.navigationController pushViewController:h5 animated:YES];
            return;
        }
    }
    
    
    
    NSString *mode = [dict stringForKey:@"type"];
    NSString *_id = [dict stringForKey:@"id"];
    [MBProgressHUD showHUDAddedTo:mainDelegate.window animated:NO];
    [NetworkBusiness payWithMode:mode platform:_id amount:[_money stringByReplacingOccurrencesOfString:@"," withString:@""] payer_name:tfName.text  Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:mainDelegate.window animated:NO];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger errNum = [response integerForKey:@"errno"];
            NSString *descript = [response stringForKey:@"error"];
            if (errNum == 0) {
                NSDictionary *dict = [response dictionaryForKey:@"data"];
                if ([dict isKindOfClass:[NSDictionary class]]) {
                    NSString *sGotoUrl = [dict stringForKey:@"sGotoUrl"];
                    if (sGotoUrl.length) {  //H5充值
                        PayNextH5ViewController *h5 = [[PayNextH5ViewController alloc] init];
                        h5.htmlUrlString = sGotoUrl;
                        [self.navigationController pushViewController:h5 animated:YES];
                        
                        return;
                    }
                }
                
                if (!descript.length) {
                    descript = @"提交成功,请稍后检查余额。";
                }
                [Tools alertWithTitle:descript message:nil handle:^(UIAlertAction * _Nonnull action) {
                    [self.navigationController popViewControllerAnimated:YES];
                } cancel:nil confirm:@"确定"];
            } else {
                if (descript.length) {
                    [Tools alertWithTitle:descript message:nil handle:nil cancel:nil confirm:@"确定"];
                } else {
                    [Tools alertWithTitle:@"提交失败!" message:nil handle:nil cancel:nil confirm:@"确定"];
                }
            }
        } else {
            [Tools showText:@"请求服务失败,请稍后再试."];
        }
    }];
}

#pragma mark WKNavigationDelegate
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    [ webView evaluateJavaScript:@"document.getElementsByTagName('body')[0].style.webkitTextSizeAdjust= '300%'" completionHandler:nil];
}

@end
