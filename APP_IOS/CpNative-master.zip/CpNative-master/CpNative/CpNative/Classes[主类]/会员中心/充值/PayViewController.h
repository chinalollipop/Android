//
//  PayViewController.h
//  CpNative
//
//  Created by david on 2019/2/18.
//  Copyright © 2019 david. All rights reserved.
//

#import "BasicWithNaviBarViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface PaymentWayButton : UIButton

- (void)setupWithTitle:(NSString *)title;

@end







@interface PayViewController : BasicWithNaviBarViewController

@property(nonatomic, strong) NSDictionary *payways;


@end

NS_ASSUME_NONNULL_END
