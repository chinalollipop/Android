//
//  ModifyLoginPassViewController.h
//  CpNative
//
//  Created by david on 2019/2/20.
//  Copyright © 2019 david. All rights reserved.
//

#import "BasicWithNaviBarViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ModifyLoginPassViewController : BasicWithNaviBarViewController

@end

NS_ASSUME_NONNULL_END
