//
//  TGViewController.m
//  CpNative
//
//  Created by david on 2019/3/21.
//  Copyright © 2019 david. All rights reserved.
//

#import "TGViewController.h"
#import "TGOpenLinkViewController.h"

@interface TGViewController ()

@end

@implementation TGViewController {
    UIButton *button0;//链接开户
    UIButton *button1;//链接管理
    
    UIView *view0;//开户的视图
    BasicScrollView *view1;//管理的视图
    UIView *view1Contet;
    
    CGFloat lineHeight;
    CGFloat beginLeft;
    
    //渠道
    UILabel *qvDaoLabel;
    NSArray *qvDaos;
    NSInteger qvDaoIndex;
    
    //用户类型
    UILabel *userTypeLabel;
    NSArray *userTypes;
    NSInteger userTypeIndex;
    
    //有效期
    UILabel *validDayLabel;
    NSArray *validDays;
    NSInteger validDayIndex;
    
    //推广QQ
    UITextField *tfQQ;
    
    UILabel *prizeGroupLabel;
    NSMutableArray *prizeGroupsAgent;//奖金组 代理  显示
    NSMutableArray *prizeGroupsMember;//奖金组 会员  显示
    NSInteger prizeGroupIndex;
    
    NSArray *aAllPossibleAgentPrizeGroups;//其它奖金组，所有奖金组 (代理)
    NSArray *aAllPossiblePrizeGroups;//其它奖金组 ，所有奖金组（会员）
    
    NSArray *links;//已生成的链接
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    topbar.titleLabel.text = @"推广链接";
    
    CGFloat bwid = (self.view.width)/2;
    CGFloat height = widthTo4_7(50);
    button0 = [[UIButton alloc] initWithFrame:CGRectMake(0, topbar.bottom, bwid, height)];
    [button0 setTitleColor:COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT forState:UIControlStateSelected];
    [button0 setTitleColor:ColorHex(0x999999) forState:UIControlStateNormal];
    [button0 setTitle:@"链接开户" forState:UIControlStateNormal];
    [self.view addSubview:button0];
    [button0 addTarget:self action:@selector(onbutton0) forControlEvents:UIControlEventTouchUpInside];
    
    button1 = [[UIButton alloc] initWithFrame:CGRectMake(button0.right, topbar.bottom, bwid, height)];
    [button1 setTitleColor:COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT forState:UIControlStateSelected];
    [button1 setTitleColor:ColorHex(0x999999) forState:UIControlStateNormal];
    [button1 setTitle:@"链接管理" forState:UIControlStateNormal];
    [self.view addSubview:button1];
    [button1 addTarget:self action:@selector(onbutton1) forControlEvents:UIControlEventTouchUpInside];
    
    view0 = [[UIView alloc] initWithFrame:CGRectMake(0, button0.bottom, self.view.width, self.view.height-button0.bottom)];
    view0.backgroundColor = ColorHex(0xffffff);
    [self.view addSubview:view0];
    
    view1 = [[BasicScrollView alloc] initWithFrame:view0.frame];
    view1.backgroundColor = ColorHex(0xffffff);
    [self.view addSubview:view1];
    view1Contet = [[UIView alloc] initWithFrame:view1.bounds];
    [view1 addSubview:view1Contet];
    
    view1.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self requestList];
    }];
    
    [self buildView0];
    [self requestBase];
    [self onbutton0];
}

- (void)requestList {
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness registerLinkManagerBlock:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        [view1.mj_header endRefreshing];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                NSDictionary *data = [response dictionaryForKey:@"data"];
                links = [data arrayForKey:@"aRegisterLinks"];
                [self updateView1Content];
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools alertWithTitle:str message:nil handle:^(UIAlertAction * _Nonnull action) {
                    
                } cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求服务失败,请稍后再试."];
        }
    }];
}

- (void)updateView1Content {
    [view1Contet removeAllSubviews];
    
    CGFloat top = widthTo4_7(12);
    CGFloat h1 = widthTo4_7(70);
    CGFloat bheig = widthTo4_7(42);
    CGFloat height = top*2+h1+bheig*4;
    for (int i = 0; i < links.count; i++) {
        NSDictionary *link = links[i];
        
        NSString *status = [link stringForKey:@"status"];//是否开启
        BOOL isOpen = [[link stringForKey:@"status"] isEqualToString:@"开启"];
        
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, height*i, self.view.width, height)];
        [view1Contet addSubview:view];
        
        //推广渠道
        CGFloat left = 0.33*self.view.width;
        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(8), top, 120, h1)];
        lbl.font = SystemFontBy4(13.);
        lbl.textColor = ColorHex(0x333333);
        lbl.text = @"推广渠道链接:";
        [view addSubview:lbl];
        
        NSString *linkurl = [link stringForKey:@"url"];
        NSMutableAttributedString *mstr = [[NSMutableAttributedString alloc] initWithString:linkurl];
        [mstr setFont:SystemFontBy4(13.) inRange:NSMakeRange(0, linkurl.length)];
        [mstr setForegroundColor:(isOpen?ColorHex(0x001ff5):ColorHex(0x333333)) inRange:NSMakeRange(0, linkurl.length)];
        [mstr setUnderlineStyle:NSUnderlineStyleSingle color:(isOpen?ColorHex(0x001ff5):ColorHex(0x333333)) inRange:NSMakeRange(0, linkurl.length)];
        UIButton *LinkBtn = [[UIButton alloc] initWithFrame:CGRectMake(left, top, view.width-left-widthTo4_7(8), h1)];
        LinkBtn.titleLabel.numberOfLines = 0;
        LinkBtn.tag = i;
        [LinkBtn setAttributedTitle:mstr forState:0];
        [LinkBtn addTarget:self action:@selector(onLinkBtn:) forControlEvents:UIControlEventTouchUpInside];
        [view addSubview:LinkBtn];
        LinkBtn.userInteractionEnabled = isOpen;
        
        lbl = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(8), top+h1, 120, bheig)];
        lbl.font = SystemFontBy4(13.);
        lbl.textColor = ColorHex(0x333333);
        lbl.text = @"注册人数:";
        [view addSubview:lbl];
        
        NSString *renshu = [link stringForKey:@"renshu"];
        if (!renshu || renshu.length < 1) {
            renshu = @"0";
        }
        lbl = [[UILabel alloc] initWithFrame:CGRectMake(left, top+h1, 120, bheig)];
        lbl.font = SystemFontBy4(13.);
        lbl.textColor = ColorHex(0x333333);
        lbl.text = renshu;
        [view addSubview:lbl];
        
        lbl = [[UILabel alloc] initWithFrame:CGRectMake(0.6*view.width, top+h1, 120, bheig)];
        lbl.font = SystemFontBy4(13.);
        lbl.textColor = ColorHex(0x333333);
        lbl.text = @"开户类型:";
        [view addSubview:lbl];
        
        lbl = [[UILabel alloc] initWithFrame:CGRectMake(0.81*view.width, top+h1, 120, bheig)];
        lbl.font = SystemFontBy4(13.);
        lbl.textColor = ColorHex(0x333333);
        lbl.text = [link stringForKey:@"is_agent"];
        [view addSubview:lbl];
        
        lbl = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(8), top+h1+bheig, 120, bheig)];
        lbl.font = SystemFontBy4(13.);
        lbl.textColor = ColorHex(0x333333);
        lbl.text = @"状态:";
        [view addSubview:lbl];
        
        lbl = [[UILabel alloc] initWithFrame:CGRectMake(left, top+h1+bheig, 120, widthTo4_7(44))];
        lbl.font = SystemFontBy4(13.);
        lbl.textColor = ColorHex(0x333333);
        lbl.text = status;
        [view addSubview:lbl];
        
        lbl = [[UILabel alloc] initWithFrame:CGRectMake(0.6*view.width, top+h1+bheig, 120, bheig)];
        lbl.font = SystemFontBy4(13.);
        lbl.textColor = ColorHex(0x333333);
        lbl.text = @"有效期:";
        [view addSubview:lbl];
        
        NSString *days = [link stringForKey:@"valid_days"];
        lbl = [[UILabel alloc] initWithFrame:CGRectMake(0.81*view.width, top+h1+bheig, 120, bheig)];
        lbl.font = SystemFontBy4(13.);
        lbl.textColor = ColorHex(0x333333);
        if (days.integerValue == 0) {
            days = @"永久有效";
        } else {
            days = [days stringByAppendingString:@" 天"];
        }
        lbl.text = days;
        [view addSubview:lbl];
        
        lbl = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(8), top+h1+bheig*2, 120, bheig)];
        lbl.font = SystemFontBy4(13.);
        lbl.textColor = ColorHex(0x333333);
        lbl.text = @"生成时间:";
        [view addSubview:lbl];
        
        lbl = [[UILabel alloc] initWithFrame:CGRectMake(left, top+h1+bheig*2, 200, bheig)];
        lbl.font = SystemFontBy4(13.);
        lbl.textColor = ColorHex(0x333333);
        lbl.text = [link stringForKey:@"created_at"];
        [view addSubview:lbl];
        
        lbl = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(8), top+h1+bheig*3, 120, bheig)];
        lbl.font = SystemFontBy4(13.);
        lbl.textColor = ColorHex(0x333333);
        lbl.text = @"操作:";
        [view addSubview:lbl];
        
        CGFloat hhh = widthTo4_7(26);
        if (isOpen) {
            UIButton *copy = [[UIButton alloc] initWithFrame:CGRectMake(left, top+h1+bheig*3+(bheig-hhh)/2, widthTo4_7(52), hhh)];
            copy.backgroundColor = ColorGreen;
            copy.layer.cornerRadius = widthTo4_7(3.0);
            copy.layer.masksToBounds = YES;
            [copy setTitle:@"复制" forState:0];
            [copy setTitleColor:ColorHex(0xffffff) forState:0];
            copy.titleLabel.font = SystemFontBy4(12.8);
            [view addSubview:copy];
            copy.tag = i;
            [copy addTarget:self action:@selector(onCopy:) forControlEvents:UIControlEventTouchUpInside];
            
            UIButton *delete = [[UIButton alloc] initWithFrame:CGRectMake(copy.right+widthTo4_7(12), top+h1+bheig*3+(bheig-hhh)/2, widthTo4_7(52), hhh)];
            delete.backgroundColor = ColorReset;
            delete.layer.cornerRadius = widthTo4_7(3.0);
            delete.layer.masksToBounds = YES;
            [delete setTitle:@"删除" forState:0];
            [delete setTitleColor:ColorHex(0xffffff) forState:0];
            delete.titleLabel.font = SystemFontBy4(12.8);
            [view addSubview:delete];
            delete.tag = i;
            [delete addTarget:self action:@selector(onDelete:) forControlEvents:UIControlEventTouchUpInside];
        }
        
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, view.height-widthTo4_7(1.0), view.width, widthTo4_7(1.0))];
        line.backgroundColor = LineColor;
        [view addSubview:line];
    }
    
    view1Contet.height = height*links.count;
    view1.contentSize = CGSizeMake(view1Contet.width, view1Contet.height+widthTo4_7(24));
}

- (void)onDelete:(UIButton *)button {
    [Tools alertWithTitle:@"确定删除该推广链接" message:nil handle:^(UIAlertAction * _Nonnull action) {
        NSDictionary *dict = links[button.tag];
        NSString *_id = [dict stringForKey:@"id"];
        [MBProgressHUD showHUDAddedTo:mainDelegate.window animated:NO];
        [NetworkBusiness registerLinkDeleteForId:_id Block:^(NSError *error, int code, id response) {
            [MBProgressHUD hideHUDForView:mainDelegate.window animated:NO];
            
            /*判断是否重新登录*/
            if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
                return;
            }
            
            if (code == 200) {
                NSInteger err = [response integerForKey:@"errno"];
                if (err == 0) {
                    [Tools alertWithTitle:@"操作成功!" message:nil handle:^(UIAlertAction * _Nonnull action) {
                        [view1.mj_header beginRefreshing];
                    } cancel:nil confirm:@"确定"];
                } else {
                    NSString *str = [response stringForKey:@"error"];
                    if (!str.length) {
                        str = @"请求失败,请稍后再试。";
                    }
                    [Tools alertWithTitle:str message:nil handle:^(UIAlertAction * _Nonnull action) {
                        
                    } cancel:nil confirm:@"确定"];
                }
            } else {
                [Tools showText:@"请求服务失败,请稍后再试."];
            }
        }];
    } cancel:@"取消" confirm:@"删除"];
}

- (void)onCopy:(UIButton *)button {
    NSDictionary *dict = links[button.tag];
    NSString *url = [dict stringForKey:@"url"];
    UIPasteboard*pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string=url;
    [Tools alertWithTitle:[NSString stringWithFormat:@"已复制%@",url] message:nil handle:nil cancel:nil confirm:@"确定"];
}

- (void)onLinkBtn:(UIButton *)button {
    NSDictionary *dict = links[button.tag];
    TGOpenLinkViewController *open = [[TGOpenLinkViewController alloc] init];
    open.htmlUrlString = [dict stringForKey:@"url"];
    [self.navigationController pushViewController:open animated:YES];
}

- (void)requestBase {
    [MBProgressHUD  showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness registerLinkStep1Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                NSDictionary *data = [response dictionaryForKey:@"data"];
                aAllPossibleAgentPrizeGroups = [data arrayForKey:@"aAllPossibleAgentPrizeGroups"];
                aAllPossiblePrizeGroups = [data arrayForKey:@"aAllPossiblePrizeGroups"];
                
                if (!prizeGroupsAgent) {
                    prizeGroupsAgent = [[NSMutableArray alloc] init];
                    for (int i = 0; i < aAllPossibleAgentPrizeGroups.count; i++) {
                        NSDictionary *dict = aAllPossibleAgentPrizeGroups[i];
                        CGFloat water = [dict floatForKey:@"water"];
                        NSString *name = [dict stringForKey:@"name"];
                        NSString *goup = [NSString stringWithFormat:@"%.2f%% ---- %@",(water*100),name];
                        [prizeGroupsAgent addObject:goup];
                    }
                }
                
                if (!prizeGroupsMember) {
                    prizeGroupsMember = [[NSMutableArray alloc] init];
                    for (int i = 0; i < aAllPossiblePrizeGroups.count; i++) {
                        NSDictionary *dict = aAllPossiblePrizeGroups[i];
                        CGFloat water = [dict floatForKey:@"water"];
                        NSString *name = [dict stringForKey:@"name"];
                        NSString *goup = [NSString stringWithFormat:@"%.2f%% ---- %@",(water*100),name];
                        [prizeGroupsMember addObject:goup];
                    }
                }
                prizeGroupLabel.text = prizeGroupsMember[prizeGroupIndex];
                
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools alertWithTitle:str message:nil handle:^(UIAlertAction * _Nonnull action) {
                    
                } cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求服务失败,请稍后再试."];
        }
    }];
}

- (void)buildView0 {
    lineHeight = widthTo4_7(56);
    beginLeft = 0.31*self.view.width;
    CGFloat offY = 0;
    
    qvDaos = @[@"请选择",@"论坛",@"QQ群",];
    userTypes = @[@"会员",@"代理",];
    validDays = @[@"请选择",@"1天",@"7天",@"30天",@"90天",@"永久有效",];
    
    
    //推广渠道
    [view0 addSubview:[self typeLabelWithText:@"推广渠道:" y:offY]];
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(beginLeft, offY, view0.width-beginLeft, lineHeight)];
    [btn addTarget:self action:@selector(onSelection:) forControlEvents:UIControlEventTouchUpInside];
    btn.backgroundColor = ColorHex(0xeaeaea);
    btn.layer.cornerRadius = 0.09*btn.height;
    btn.layer.masksToBounds = YES;
    btn.tag = 0;
    [view0 addSubview:btn];
    btn.top += widthTo4_7(6);
    btn.height -= widthTo4_7(12);
    btn.width -= widthTo4_7(6);
    qvDaoLabel = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(10), 0, 100, btn.height)];
    qvDaoLabel.font = SystemFontBy4(14.6);
    qvDaoLabel.textColor = ColorHex(0x202020);
    qvDaoLabel.text = qvDaos[qvDaoIndex];
    [btn addSubview:qvDaoLabel];
    UILabel *draw1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, btn.height*1.0, btn.height)];
    draw1.font = FontForSize(17);
    draw1.text = Down_Arrow;
    draw1.textColor = ColorHex(0x161616);
    [btn addSubview:draw1];
    draw1.textAlignment = NSTextAlignmentCenter;
    draw1.right = btn.width;
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, lineHeight, view0.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [view0 addSubview:line];
    offY = line.bottom;
    
    //用户类型
    [view0 addSubview:[self typeLabelWithText:@"用户类型:" y:offY]];
    btn = [[UIButton alloc] initWithFrame:CGRectMake(beginLeft, offY, view0.width-beginLeft, lineHeight)];
    [btn addTarget:self action:@selector(onSelection:) forControlEvents:UIControlEventTouchUpInside];
    btn.backgroundColor = ColorHex(0xeaeaea);
    btn.layer.cornerRadius = 0.09*btn.height;
    btn.layer.masksToBounds = YES;
    btn.tag = 1;
    [view0 addSubview:btn];
    btn.top += widthTo4_7(6);
    btn.height -= widthTo4_7(12);
    btn.width -= widthTo4_7(6);
    userTypeLabel = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(10), 0, 100, btn.height)];
    userTypeLabel.font = SystemFontBy4(14.6);
    userTypeLabel.textColor = ColorHex(0x202020);
    userTypeLabel.text = userTypes[userTypeIndex];
    [btn addSubview:userTypeLabel];
    draw1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, btn.height*1.0, btn.height)];
    draw1.font = FontForSize(17);
    draw1.text = Down_Arrow;
    draw1.textColor = ColorHex(0x161616);
    [btn addSubview:draw1];
    draw1.textAlignment = NSTextAlignmentCenter;
    draw1.right = btn.width;

    line = [[UIView alloc] initWithFrame:CGRectMake(0, offY+lineHeight, view0.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [view0 addSubview:line];
    offY = line.bottom;

    //链接有效期
    [view0 addSubview:[self typeLabelWithText:@"链接有效期:" y:offY]];
    btn = [[UIButton alloc] initWithFrame:CGRectMake(beginLeft, offY, view0.width-beginLeft, lineHeight)];
    [btn addTarget:self action:@selector(onSelection:) forControlEvents:UIControlEventTouchUpInside];
    btn.backgroundColor = ColorHex(0xeaeaea);
    btn.layer.cornerRadius = 0.09*btn.height;
    btn.layer.masksToBounds = YES;
    btn.tag = 2;
    [view0 addSubview:btn];
    btn.top += widthTo4_7(6);
    btn.height -= widthTo4_7(12);
    btn.width -= widthTo4_7(6);
    validDayLabel = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(10), 0, 100, btn.height)];
    validDayLabel.font = SystemFontBy4(14.6);
    validDayLabel.textColor = ColorHex(0x202020);
    validDayLabel.text = validDays[validDayIndex];
    [btn addSubview:validDayLabel];
    draw1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, btn.height*1.0, btn.height)];
    draw1.font = FontForSize(17);
    draw1.text = Down_Arrow;
    draw1.textColor = ColorHex(0x161616);
    [btn addSubview:draw1];
    draw1.textAlignment = NSTextAlignmentCenter;
    draw1.right = btn.width;
    
    line = [[UIView alloc] initWithFrame:CGRectMake(0, offY+lineHeight, view0.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [view0 addSubview:line];
    offY = line.bottom;
    
    //推广QQ
    [view0 addSubview:[self typeLabelWithText:@"推广QQ:" y:offY]];
    tfQQ = [[UITextField alloc] initWithFrame:CGRectMake(beginLeft+widthTo4_7(10), offY, view0.width-beginLeft, lineHeight)];
    tfQQ.placeholder = @"请输入推广QQ";
    tfQQ.font = SystemFontBy4(14.6);
    tfQQ.textColor = ColorHex(0x202020);
    tfQQ.clearButtonMode = UITextFieldViewModeWhileEditing;
    [view0 addSubview:tfQQ];
    line = [[UIView alloc] initWithFrame:CGRectMake(0, tfQQ.bottom, view0.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [view0 addSubview:line];
    offY = line.bottom;
    
    //奖金组设定
    UILabel *sheding = [[UILabel alloc] initWithFrame:CGRectMake(0, offY, view0.width, lineHeight)];
    sheding.text = @"奖金组设定";
    sheding.textColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;
    sheding.font = SystemFontBy4(14);
    sheding.textAlignment = NSTextAlignmentCenter;
    [view0 addSubview:sheding];
    line = [[UIView alloc] initWithFrame:CGRectMake(0, sheding.bottom, view0.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [view0 addSubview:line];
    offY = line.bottom;
    
    //设置奖金
    [view0 addSubview:[self typeLabelWithText:@"设置奖金:" y:offY]];
    btn = [[UIButton alloc] initWithFrame:CGRectMake(beginLeft, offY, view0.width-beginLeft, lineHeight)];
    [btn addTarget:self action:@selector(onSelection:) forControlEvents:UIControlEventTouchUpInside];
    btn.backgroundColor = ColorHex(0xeaeaea);
    btn.layer.cornerRadius = 0.09*btn.height;
    btn.layer.masksToBounds = YES;
    btn.tag = 3;
    [view0 addSubview:btn];
    btn.top += widthTo4_7(6);
    btn.height -= widthTo4_7(12);
    btn.width -= widthTo4_7(6);
    prizeGroupLabel = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(10), 0, 220, btn.height)];
    prizeGroupLabel.font = SystemFontBy4(14.6);
    prizeGroupLabel.textColor = ColorHex(0x202020);
    prizeGroupLabel.text = @"----";
    [btn addSubview:prizeGroupLabel];
    draw1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, btn.height*1.0, btn.height)];
    draw1.font = FontForSize(17);
    draw1.text = Down_Arrow;
    draw1.textColor = ColorHex(0x161616);
    [btn addSubview:draw1];
    draw1.textAlignment = NSTextAlignmentCenter;
    draw1.right = btn.width;
    
    line = [[UIView alloc] initWithFrame:CGRectMake(0, offY+lineHeight, view0.width, widthTo4_7(1.0))];
    line.backgroundColor = LineColor;
    [view0 addSubview:line];
    offY = line.bottom;
    
    //奖金组设定
    sheding = [[UILabel alloc] initWithFrame:CGRectMake(0, offY, view0.width, lineHeight)];
    sheding.text = @"奖金组一旦上调后则无法降低，请谨慎操作";
    sheding.textColor = ColorSubmit;
    sheding.font = SystemFontBy4(12);
    sheding.textAlignment = NSTextAlignmentCenter;
    [view0 addSubview:sheding];

    
    UIButton *submit = [[UIButton alloc] initWithFrame:CGRectMake(widthTo4_7(10), sheding.bottom+widthTo4_7(10), self.view.width-widthTo4_7(20), widthTo4_7(44))];
    submit.backgroundColor = ColorGreen;
    submit.layer.cornerRadius = widthTo4_7(4);
    submit.layer.masksToBounds = YES;
    [view0 addSubview:submit];
    [submit setTitle:@"生成链接" forState:0];
    [submit setTitleColor:ColorHex(0xffffff) forState:0];
    submit.titleLabel.font = SystemFontBy4(14.2);
    [submit addTarget:self action:@selector(onCreate) forControlEvents:UIControlEventTouchUpInside];
}

- (void)onCreate {
    if (qvDaoIndex == 0) {
        [Tools showText:@"请选择推广渠道"];
        return;
    }
    if (validDayIndex == 0) {
        [Tools showText:@"请选择链接有效期"];
        return;
    }
    
    NSString *isAgent = @"";
    NSArray *group;
    if (userTypeIndex == 0) {
        isAgent = @"0";
        group = aAllPossiblePrizeGroups;
    } else {
        isAgent = @"1";
        group = aAllPossibleAgentPrizeGroups;
    }
    
    NSDictionary  *prize = group[prizeGroupIndex];
    NSString *prizeId = [prize stringForKey:@"id"];
    NSString *prizeType = [prize stringForKey:@"type"];
    NSString *quota = @"{}";
    NSString *name = [prize stringForKey:@"name"];
    
    
    NSString *validDays;
    if (validDayIndex == 1) {
        validDays = @"1";
    } else if (validDayIndex == 2) {
        validDays = @"7";
    } else if (validDayIndex == 3) {
        validDays = @"30";
    } else if (validDayIndex == 4) {
        validDays = @"90";
    } else if (validDayIndex == 5) {
        validDays = @"";
    }
    
    NSString *chanel = qvDaos[qvDaoIndex];
    
    NSString *qq = tfQQ.text;
    
    NSString *series_id = @"";
    
    NSString *lottery_id = @"";
    
    NSString *series_prize_group_json = [NSString stringWithFormat:@"{\"%@\":%@}",prizeType,name];
    
    NSString *fb_single = @"0.0";
    NSString *fb_all = @"0.0";
    
    [MBProgressHUD showHUDAddedTo:mainDelegate.window animated:NO];
    [NetworkBusiness registerLinkStep2ForIsAgent:isAgent prize_group_id:prizeId prizeGroupType:prizeType agent_prize_set_quota:quota valid_days:validDays channel:chanel agent_qq:qq seriesId:series_id lotteryId:lottery_id series_prize_group_json:series_prize_group_json fbsingle:fb_single fball:fb_all terminalId:nil Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:mainDelegate.window animated:NO];
        
        /*判断是否重新登录*/
        if ([Tools ifNeedReloginWithDict:response navigation:self.navigationController]) {
            return;
        }
        
        if (code == 200) {
            NSInteger err = [response integerForKey:@"errno"];
            if (err == 0) {
                [Tools alertWithTitle:@"生成链接成功!" message:nil handle:^(UIAlertAction * _Nonnull action) {
                    [self onbutton1];
                    [view1.mj_header beginRefreshing];
                } cancel:nil confirm:@"确定"];
            } else {
                NSString *str = [response stringForKey:@"error"];
                if (!str.length) {
                    str = @"请求失败,请稍后再试。";
                }
                [Tools alertWithTitle:str message:nil handle:nil cancel:nil confirm:@"确定"];
            }
        } else {
            [Tools showText:@"请求服务失败,请稍后再试."];
        }
    }];
    
}

- (void)onSelection:(UIButton *)button {
    NSInteger index = 0;
    NSArray *datas;
    if (button.tag == 0) {
        index = qvDaoIndex;
        datas = qvDaos;
    } else if (button.tag == 1) {
        index = userTypeIndex;
        datas = userTypes;
    } else if (button.tag == 2) {
        index = validDayIndex;
        datas = validDays;
    } else if (button.tag == 3) {
        index = prizeGroupIndex;
        if (userTypeIndex == 0) {
            datas = prizeGroupsMember;
        } else {
            datas = prizeGroupsAgent;
        }
    }
    
    
    
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    WSDatePickerView *datepicker = [[WSDatePickerView alloc] initWithDateStyle:DateStyleShowBank data:datas scrollToIndex:index CompleteBlock:^(NSInteger tag, BOOL cancel) {
        if (cancel) {
            NSLog(@"CANCEL.....");
        } else {
            if (button.tag == 0) {
                qvDaoIndex = tag;
                qvDaoLabel.text = qvDaos[qvDaoIndex];
            } else if (button.tag == 1) {
                userTypeIndex = tag;
                userTypeLabel.text = userTypes[userTypeIndex];
                prizeGroupIndex = 0;
                if (userTypeIndex == 0) {
                    prizeGroupLabel.text = prizeGroupsMember[prizeGroupIndex];
                } else {
                    prizeGroupLabel.text = prizeGroupsAgent[prizeGroupIndex];
                }
            } else if (button.tag == 2) {
                validDayIndex = tag;
                validDayLabel.text = validDays[validDayIndex];
            } else if (button.tag == 3) {
                prizeGroupIndex = tag;
                if (userTypeIndex == 0) {
                    prizeGroupLabel.text = prizeGroupsMember[prizeGroupIndex];
                } else {
                    prizeGroupLabel.text = prizeGroupsAgent[prizeGroupIndex];
                }
            }
        }
    }];
    
    datepicker.dateLabelColor = ColorHex(0xff5733);//年-月-日-时-分 颜色
    datepicker.datePickerColor = ColorHex(0x286be8);//滚轮日期颜色
    datepicker.doneButtonColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;//确定按钮的颜色
    [datepicker setHideBackgroundYearLabel:YES];
    [datepicker show];
}

- (void)onbutton0 {
    if (button0.selected) {
        return;
    }
    
    button0.selected = YES;
    button1.selected = NO;
    
    button1.backgroundColor = ColorReset;
    button0.backgroundColor = ColorHex(0xd5d5d5);
    
    button0.titleLabel.font = BoldSystemFontBy4(14.);
    button1.titleLabel.font = SystemFontBy4(14.);
    
    view0.hidden = NO;
    view1.hidden = YES;
}

- (void)onbutton1 {
    if (button1.selected) {
        return;
    }
    
    button0.selected = NO;
    button1.selected = YES;
    
    button0.backgroundColor = ColorReset;
    button1.backgroundColor = ColorHex(0xd5d5d5);
    
    button1.titleLabel.font = BoldSystemFontBy4(14.);
    button0.titleLabel.font = SystemFontBy4(14.);

    view1.hidden = NO;
    view0.hidden = YES;
    
    if (!links) {
        [view1.mj_header beginRefreshing];
    }
}


- (UILabel *)typeLabelWithText:(NSString *)text y:(CGFloat)y {
    UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(8), y, 120, lineHeight)];
    lbl.font = SystemFontBy4(14.6);
    lbl.textColor = ColorHex(0x202020);
    lbl.text = text;
    return lbl;
}
@end
