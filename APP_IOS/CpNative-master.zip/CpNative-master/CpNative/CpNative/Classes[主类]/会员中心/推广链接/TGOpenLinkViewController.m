//
//  TGOpenLinkViewController.m
//  CpNative
//
//  Created by david on 2019/3/28.
//  Copyright © 2019 david. All rights reserved.
//

#import "TGOpenLinkViewController.h"

@interface TGOpenLinkViewController ()

@end

@implementation TGOpenLinkViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
