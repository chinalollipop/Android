//
//  CouponViewController.m
//  CpNative
//
//  Created by david on 2019/3/16.
//  Copyright © 2019 david. All rights reserved.
//

#import "CouponViewController.h"
#import "CouponNextViewController.h"

@interface CouponViewController ()

@end

@implementation CouponViewController {
    BasicScrollView *_page2Scroll;
    NSMutableArray *buttonArray;
    CGFloat gap; //间隔 图片的间隔
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    gap = widthTo4_7(8);
    
    BOOL showReturn = NO;//是否显示返回按钮
    if (self.navigationController.viewControllers.lastObject == self) {
        showReturn = YES;
    }
    
    topbar.titleLabel.text = @"优惠活动";
    topbar.returnButton.hidden = (!showReturn);
    
    [self initPage2];
}

- (void)initPage2 {
    [_page2Scroll removeAllSubviews];
    [_page2Scroll removeFromSuperview];
    
    if (buttonArray) {
        [buttonArray removeAllObjects];
    }
    
    _page2Scroll = [[BasicScrollView alloc] initWithFrame:CGRectMake(0, topbar.bottom, self.view.width, self.view.height-topbar.height)];
    [self.view addSubview:_page2Scroll];
    CGFloat heigh = _page2Scroll.width*0.521;
    
    _page2Scroll.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        //获取优惠活动列表
        [_page2Scroll.mj_header beginRefreshing];
        [MBProgressHUD showHUDAddedTo:self.view animated:NO];
        [NetworkBusiness couponListBlock:^(NSError *error, int code, id response) {
            [_page2Scroll.mj_header endRefreshing];
            [MBProgressHUD hideHUDForView:self.view animated:NO];
            if (code == 200) {
                [Singleton shared].couponList = [response arrayForKey:@"data"];
                runBlockAfter(0.22, ^{
                    [self initPage2];
                });
            }
        }];
    }];
    
    CGFloat xoff = widthTo4_7((ScreenX?(0):(0)));
    
    NSArray *temp = [Singleton shared].couponList;
    if (!temp) {
        for (int i = 0; i < 4; i++) {
            UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0, xoff+heigh*i, _page2Scroll.width, heigh)];
            button.tag = i;
            [button addTarget:self action:@selector(onPage2CouponButton:) forControlEvents:UIControlEventTouchUpInside];
            NSString *imgstr = [NSString stringWithFormat:@"p3%i",i];
            UIImage *img = [UIImage imageNamed:imgstr];
            [button setBackgroundImage:img forState:0];
            [_page2Scroll addSubview:button];
            _page2Scroll.contentSize = CGSizeMake(_page2Scroll.width, button.bottom);
        }
    } else {
        heigh *= 0.44;
        
        if (!buttonArray) {
            buttonArray = [[NSMutableArray alloc] init];
        }
        
        for (int i = 0; i < temp.count; i++) {
            UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0, xoff+heigh*i+(gap*(i+1)), _page2Scroll.width, heigh)];
            __weak typeof(button) wb = button;
            [buttonArray addObject:wb];
            button.tag = i;
            [button addTarget:self action:@selector(onPage2CouponButton:) forControlEvents:UIControlEventTouchUpInside];
            
            NSDictionary *coupon = temp[i];
            NSString *urlstr = [coupon stringForKey:@"pic_url"];
            urlstr = [Tools urlAddHost:urlstr isBare:YES prefix:@""];
            NSURL *url = [NSURL URLWithString:urlstr];
            
            __weak typeof(self) ws = self;
            [button sd_setBackgroundImageWithURL:url forState:0 placeholderImage:[UIImage imageNamed:@"p33"] completed:^(UIImage * _Nullable image, NSError * _Nullable error, SDImageCacheType cacheType, NSURL * _Nullable imageURL) {
                [ws adjustImageHeights];
            }];
            [_page2Scroll addSubview:button];
            _page2Scroll.contentSize = CGSizeMake(_page2Scroll.width, button.bottom + widthTo4_7(24));
            
        }
    }
    
    if (_initRefresh) {
        _initRefresh = NO;
        [_page2Scroll.mj_header beginRefreshing];
    }
}

/*根据加载完毕的图片宽高，调整按钮高度*/
- (void)adjustImageHeights {
    if (!buttonArray.count) {
        return;
    }

    CGFloat offY = gap;
    for (int i = 0; i < buttonArray.count; i++) {
        UIButton *button = buttonArray[i];
        UIImage *image = button.currentBackgroundImage;
        CGFloat currentHeight = image.size.height/image.size.width*button.width;
        button.top = offY;
        button.height = currentHeight;
        offY = button.bottom + gap;
    }
    _page2Scroll.contentSize = CGSizeMake(_page2Scroll.width, offY + widthTo4_7(24));
}



- (void)forceRefresh {
    _initRefresh = NO;
    [_page2Scroll.mj_header beginRefreshing];
}

- (void)onPage2CouponButton:(UIButton *)button {
    
    if (![Singleton shared].couponList.count) {
        [_page2Scroll.mj_header beginRefreshing];
        return;
    }
    
    NSDictionary *coupon = [Singleton shared].couponList[button.tag];
    CouponNextViewController *couponVc = [[CouponNextViewController alloc] init];
    couponVc.coupon = coupon;
    [self.navigationController pushViewController:couponVc animated:YES];
}

@end
