//
//  CouponNextViewController.h
//  CpNative
//
//  Created by david on 2019/2/22.
//  Copyright © 2019 david. All rights reserved.
//

#import "BasicWithNaviBarViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CouponNextViewController : BasicWithNaviBarViewController

@property(nonatomic, strong) NSDictionary *coupon;
@property(nonatomic, strong) WKWebView *webView;

@end

NS_ASSUME_NONNULL_END
