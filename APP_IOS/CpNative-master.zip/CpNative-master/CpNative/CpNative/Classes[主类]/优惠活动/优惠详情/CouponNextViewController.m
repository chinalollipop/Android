//
//  CouponNextViewController.m
//  CpNative
//
//  Created by david on 2019/2/22.
//  Copyright © 2019 david. All rights reserved.
//

#import "CouponNextViewController.h"

@interface CouponNextViewController ()<WKNavigationDelegate>

@end

@implementation CouponNextViewController {
    UIActivityIndicatorView *indicator;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    topbar.titleLabel.text = [_coupon stringForKey:@"content"];
    
    _webView = [[WKWebView alloc] initWithFrame:CGRectMake(0, topbar.bottom, self.view.width, self.view.height-topbar.height)];
    [self.view addSubview:_webView];
    _webView.navigationDelegate  = self;
    NSString *urlstr = [_coupon stringForKey:@"redirect_url"];
    urlstr = [Tools urlAddHost:urlstr isBare:YES prefix:@""];
    
    NSURL *url = [NSURL URLWithString:urlstr];
    [_webView loadRequest:[NSURLRequest requestWithURL:url]];
    
    
    indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    [self.view addSubview:indicator];
    indicator.center = CGPointMake(0.5*self.view.width, 0.5*self.view.height);
    [indicator startAnimating];
    
}

- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(null_unspecified WKNavigation *)navigation {
    [indicator startAnimating];
}


- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error {
    [indicator stopAnimating];
}


- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation {
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    [indicator stopAnimating];
}

@end
