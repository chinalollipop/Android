//
//  CouponViewController.h
//  CpNative
//
//  Created by david on 2019/3/16.
//  Copyright © 2019 david. All rights reserved.
//

#import "BasicWithNaviBarViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CouponViewController : BasicWithNaviBarViewController

@property(nonatomic, assign) BOOL initRefresh;

- (void)forceRefresh;

@end

NS_ASSUME_NONNULL_END
