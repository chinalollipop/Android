//
//  Page3YilouView.h
//  CpNative
//
//  Created by david on 2019/2/27.
//  Copyright © 2019 david. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Page3YilouView : UIView

- (void)drawForData:(NSArray *)data width:(CGFloat)wid height:(CGFloat)heig color:(UIColor *)color font:(UIFont *)font vLines:(NSInteger)vLines;

@property(nonatomic, strong) NSMutableArray *showTimes;//出现次数
@property(nonatomic, strong) NSMutableArray *averageYilou;//平均遗漏
@property(nonatomic, strong) NSMutableArray *biggestYilou;//最大遗漏
@property(nonatomic, strong) NSMutableArray *biggestLianchu;//最大连出
@property(nonatomic, strong) NSMutableArray *lastYL;//最后的遗漏

@end

NS_ASSUME_NONNULL_END
