//
//  Page3YilouView.m
//  CpNative
//
//  Created by david on 2019/2/27.
//  Copyright © 2019 david. All rights reserved.
//

#import "Page3YilouView.h"

@implementation Page3YilouView

- (void)drawForData:(NSArray *)data width:(CGFloat)wid height:(CGFloat)heig color:(UIColor *)color font:(UIFont *)font vLines:(NSInteger)vLines {
    _showTimes = [[NSMutableArray alloc] init];
    _averageYilou = [[NSMutableArray alloc] init];
    _biggestYilou = [[NSMutableArray alloc] init];
    _biggestLianchu = [[NSMutableArray alloc] init];
    _lastYL = [[NSMutableArray alloc] init];
    
    for (int i = 0; i < vLines; i++) {
        int count = 0;//遗漏计数
        int ylTimes = 0;//遗漏次数、遗漏多少次
        int totalYL = 0;//遗漏的总数
        int biggestYL = 0;//最大的遗漏
        int showTime = 0;//出现的次数
        int lianchu = 0;//连出
        int biggestLianchu = 0;//最大连出
        int lastYL = 0;
        
        for (int j = 0; j < data.count; j++) {
            NSString *v = data[j];
            int value = v.intValue;
            if (value == i) {
                ++showTime;
                totalYL += count;
                ++lianchu;
                biggestLianchu = ((biggestLianchu>lianchu)?(biggestLianchu):(lianchu));
                count = 0;
            } else {
                ++count;
                if (count == 1) {
                    ++ylTimes;
                }
                if (j == (data.count-1)) {
                    totalYL += count;
                }
                lianchu = 0;
                UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(wid*i, heig*j, wid, heig)];
                label.textAlignment = NSTextAlignmentCenter;
                label.textColor = color;
                label.font = font;
                label.text = [NSString stringWithFormat:@"%i",count];
                [self addSubview:label];
            }
            biggestYL = ((biggestYL>count)?(biggestYL):(count));
            if (j == (data.count-1)) {
                lastYL = count;
            }
        }
        
        
        int averageYL = (int)(((float)totalYL)/ylTimes+0.5);//平均遗漏,四舍五入
//        NSLog(@"遗漏次数:%i,,总遗漏:%i,,最大遗漏:%i,,出现次数:%i,,连出:%i,,最大连出:%i",ylTimes,totalYL,biggestYL,showTime,lianchu,biggestLianchu);
        
        [_showTimes addObject:[NSString stringWithFormat:@"%i",showTime]];
        [_averageYilou addObject:[NSString stringWithFormat:@"%i",averageYL]];
        [_biggestYilou addObject:[NSString stringWithFormat:@"%i",biggestYL]];
        [_biggestLianchu addObject:[NSString stringWithFormat:@"%i",biggestLianchu]];
        [_lastYL addObject:[NSString stringWithFormat:@"%i",lastYL]];
    }
}

@end
