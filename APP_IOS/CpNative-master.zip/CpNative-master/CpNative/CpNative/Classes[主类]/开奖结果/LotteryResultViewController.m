//
//  LotteryResultViewController.m
//  CpNative
//
//  Created by david on 2019/3/8.
//  Copyright © 2019 david. All rights reserved.
//

#import "LotteryResultViewController.h"
#import "LotteryResultViewController_XY.h"
#import "BasicTableView.h"
#import "Page3ZoushiView.h"

@interface LotteryResultViewController ()<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic, assign) BOOL isXy;

@end

@implementation LotteryResultViewController {
    NSInteger page3AskingCount;//请求的开奖结果条数
    UILabel *page3GameLal;
    NSInteger page3SelectedGameIndex;//选中的游戏索引
    NSInteger page3MidScrollButtonIndex;//中间按钮的索引
    BasicTableView *page3Tabel;
    BasicScrollView *page3MidScroll;
    UIView *page3MidScrollRedBar;//中间的红条
    CGFloat cellH0;
    CGFloat cellH1;
    CGFloat cellH2;
    CGFloat cellH3;
    UIButton *page3TypeSelectButton;//开奖结果的选择彩种按钮
    UIButton *page3SettingButton;
    
    NSArray *page3Titles;
    BasicScrollView *page3ZoushiScroll;
    Page3ZoushiView *page3ZoushiView;
    ZJSwitch *page3switch0;
    ZJSwitch *page3switch1;
    ZJSwitch *page3switch2;
    ZJSwitch *page3switch3;
    
    NSMutableArray *lotteryNames;//彩种名字
    
    LotteryResultViewController_XY *resultXy;//信用盘开奖结果
    EnlargeButton *gameTypeButton;//切换按钮
}

- (void)refresh {
    if (page3Tabel.hidden) {
        [page3ZoushiScroll.mj_header beginRefreshing];
    } else {
        [page3Tabel.mj_header beginRefreshing];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    BOOL showReturn = NO;//是否显示返回按钮
    if (self.navigationController.viewControllers.lastObject == self) {
        showReturn = YES;
    }
    
    topbar.titleLabel.text = @"开奖结果";
    topbar.returnButton.hidden = (!showReturn);
    
    CGFloat gtWidth = widthTo4_7(55);
    CGFloat gtHeight = widthTo4_7(24.2);
    gameTypeButton = [[EnlargeButton alloc] initWithFrame:CGRectMake(topbar.width-(widthTo4_7(14)+gtWidth), (topbar.contentView.height-gtHeight)/2, gtWidth, gtHeight)];
    gameTypeButton.expandSpecs = widthTo4_7(10);
    [gameTypeButton setTitle:(_isXy?@"信用盘":@"官方盘") forState:0];
    [gameTypeButton setTitleColor:ColorHex(0xffffff) forState:0];
    gameTypeButton.titleLabel.font = SystemFontBy4(13.0);
    gameTypeButton.layer.borderColor = ColorHex(0xffffff).CGColor;
    gameTypeButton.layer.borderWidth = widthTo4_7(0.8);
    gameTypeButton.layer.cornerRadius = widthTo4_7(2.4);
    gameTypeButton.layer.masksToBounds = YES;
    [gameTypeButton addTarget:self action:@selector(onGameTypeButton:) forControlEvents:UIControlEventTouchUpInside];
    [topbar.contentView addSubview:gameTypeButton];
    
    lotteryNames = [NSMutableArray array];
    for (int i = 0; i < [Singleton shared].gamesArrayGF.count; i++) {
        NSDictionary *dict = [Singleton shared].gamesArrayGF[i];
        NSString *name = [dict stringForKey:@"name"];
        name = [name stringByAppendingString:@"[官]"];
        [lotteryNames safeAddObject:name];
        
        if (!_page3GameType && i == 0) { //没有传入游戏，则指定游戏为第一个游戏
            _page3GameType = [dict integerForKey:@"lottery_id"];
        }
        else //如果传过来已有指定游戏，则找出这个指定的游戏
        {
            NSInteger lottery_id = [dict integerForKey:@"lottery_id"];
            if (_page3GameType == lottery_id) {
                page3SelectedGameIndex = i;
            }
        }
    }
    
    page3TypeSelectButton = [[UIButton alloc] initWithFrame:CGRectMake(widthTo4_7(5), widthTo4_7(5)+topbar.bottom, self.view.width-widthTo4_7(55), widthTo4_7(39))];
    page3TypeSelectButton.layer.borderColor = ColorHex(0xd5d5d5).CGColor;
    page3TypeSelectButton.layer.borderWidth = widthTo4_7(1.0);
    page3TypeSelectButton.layer.cornerRadius = 0.1*page3TypeSelectButton.height;
    [page3TypeSelectButton addTarget:self action:@selector(onPage3GameSelect) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:page3TypeSelectButton];
    page3GameLal = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(10), 0, 250, page3TypeSelectButton.height)];
    page3GameLal.font = SystemFontBy4(14.);
    page3GameLal.textColor = ColorHex(0x202020);
    page3GameLal.text = lotteryNames[page3SelectedGameIndex];//默认值
    [page3TypeSelectButton addSubview:page3GameLal];
    UILabel *draw1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, page3TypeSelectButton.height*1.0, page3TypeSelectButton.height)];
    draw1.font = FontForSize(17);
    draw1.text = Down_Arrow;
    draw1.textColor = ColorHex(0x161616);
    [page3TypeSelectButton addSubview:draw1];
    draw1.textAlignment = NSTextAlignmentCenter;
    draw1.right = page3TypeSelectButton.width;
    draw1.tag = 4455;
    
    //设置按钮
    page3SettingButton = [[UIButton alloc] initWithFrame:CGRectMake(0.875*self.view.width, page3TypeSelectButton.top, 0.12*self.view.width, page3TypeSelectButton.height)];
    [page3SettingButton setTitle:Settings2 forState:0];
    page3SettingButton.titleLabel.font = FontForSize(26);
    [page3SettingButton setTitleColor:ColorHex(0x707070) forState:0];
    [self.view addSubview:page3SettingButton];
    [page3SettingButton addTarget:self action:@selector(onPage3Settings) forControlEvents:UIControlEventTouchUpInside];
    
    //中间的按钮
    page3MidScroll = [[BasicScrollView alloc] initWithFrame:CGRectMake(0, page3TypeSelectButton.bottom+widthTo4_7(5), self.view.width, widthTo4_7(47))];
    page3MidScroll.backgroundColor = ColorHex(0xececec);
    [self.view addSubview:page3MidScroll];
    
    //下方的Tableview
    cellH0 = widthTo4_7(120);
    cellH1 = widthTo4_7(120);
    cellH2 = widthTo4_7(90);
    cellH3 = widthTo4_7(130);
    page3Tabel = [[BasicTableView alloc] initWithFrame:CGRectMake(0, page3MidScroll.bottom, self.view.width, self.view.height-page3MidScroll.bottom)];
    [self.view addSubview:page3Tabel];
    page3Tabel.backgroundColor = [UIColor whiteColor];
    page3Tabel.allowsSelection = NO;
    page3Tabel.showsVerticalScrollIndicator = NO;
    page3Tabel.separatorStyle = UITableViewCellEditingStyleNone;
    page3Tabel.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self requestPage3LotteryResultsForId:_page3GameType isRefresh:YES];
    }];
    
    page3Tabel.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self requestPage3LotteryResultsForId:_page3GameType isRefresh:NO];
    }];
    
    //走势
    page3ZoushiScroll = [[BasicScrollView alloc] initWithFrame:page3Tabel.frame];
    [self.view addSubview:page3ZoushiScroll];
    page3ZoushiScroll.hidden = YES;
    //上拉、下拉
    page3ZoushiScroll.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self requestPage3LotteryResultsForId:_page3GameType isRefresh:YES];
    }];
    page3ZoushiScroll.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self requestPage3LotteryResultsForId:_page3GameType isRefresh:NO];
    }];
    
    //添加手势
    UISwipeGestureRecognizer *swipeLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(onPage3SwipeLeft)];
    swipeLeft.direction = UISwipeGestureRecognizerDirectionLeft;
    [self.view addGestureRecognizer:swipeLeft];
    UISwipeGestureRecognizer *swipeRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(onPage3SwipeRight)];
    swipeRight.direction = UISwipeGestureRecognizerDirectionRight;
    [self.view addGestureRecognizer:swipeRight];
    
    [self requestPage3LotteryResultsForId:_page3GameType isRefresh:YES];//请求数据
    
    [self updateSettingButtonHidden];
    
    resultXy = [[LotteryResultViewController_XY alloc] init];
    resultXy.isInHomePage = _isInHomePage;
    resultXy.gameType = GameType1BJPK10;
    resultXy.view.frame = self.view.bounds;
    [self.view addSubview:resultXy.view];
    [self.view bringSubviewToFront:topbar];
    resultXy.view.hidden = !_isXy;
    [self addChildViewController:resultXy];
}

- (void)onGameTypeButton:(UIButton *)button {
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    WSDatePickerView *datepicker = [[WSDatePickerView alloc] initWithDateStyle:DateStyleShowBank data:@[@"官方盘",@"信用盘",] scrollToIndex:(_isXy?1:0) CompleteBlock:^(NSInteger tag, BOOL cancel) {
        if (cancel) {
            NSLog(@"CANCEL.....");
        } else {
            
//            if (tag == 1) {
//                NSString *token = [[Singleton shared].loginDict stringForKey:@"token"];
//                if (!token || !token.length) {
//                    [Tools showText:@"请先登录"];
//                    return;
//                }
//            }
            
            _isXy = tag;
            [gameTypeButton setTitle:(_isXy?@"信用盘":@"官方盘") forState:0];
            resultXy.view.hidden = !_isXy;
            
            if (_isXy) {
                if (!resultXy.allDatas || !resultXy.allDatas.count) {
                }
                [resultXy onLeftRefresh];
            } else {
                [self refresh];
            }
        }
    }];
    
    datepicker.dateLabelColor = ColorHex(0xff5733);//年-月-日-时-分 颜色
    datepicker.datePickerColor = ColorHex(0x286be8);//滚轮日期颜色
    datepicker.doneButtonColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;//确定按钮的颜色
    [datepicker setHideBackgroundYearLabel:YES];
    [datepicker show];
}

- (void)onPage3SwipeLeft {
    [self onPage3MidButtonTag:page3MidScrollButtonIndex+1];
}

- (void)onPage3SwipeRight {
    [self onPage3MidButtonTag:page3MidScrollButtonIndex-1];
}

/*用户点击了中间按钮*/
- (void)onPage3MidButton:(UIButton *)button {
    NSLog(@"点击了走势按钮:%li",(long)button.tag);
    [self onPage3MidButtonTag:button.tag];
}

- (void)onPage3MidButtonTag:(NSInteger)tag {
    if (tag >= page3Titles.count ||
        tag < 0) {
        return;
    }
    if (page3MidScrollButtonIndex == tag) {
        return;
    }
    
    page3MidScrollButtonIndex = tag;
    [self updateSettingButtonHidden];
    page3MidScrollRedBar.left = page3MidScrollButtonIndex*page3MidScrollRedBar.width;
    [self updatePage3MidButtonStateWithTag:page3MidScrollButtonIndex];
    
    if (page3MidScrollButtonIndex == 0) { //开奖
        page3Tabel.hidden = NO;
        page3ZoushiScroll.hidden = YES;
    } else { //走势
        page3Tabel.hidden = YES;
        page3ZoushiScroll.hidden = NO;
        [self updatePage3ZoushiScrollview];
    }
}

- (void)updatePage3ZoushiScrollview {
    [page3ZoushiView removeFromSuperview];
    page3ZoushiView = nil;
    
    page3ZoushiScroll.height = page3Tabel.height;
    page3ZoushiView = [[Page3ZoushiView alloc] initWithFrame:page3ZoushiScroll.bounds];
    [page3ZoushiScroll addSubview:page3ZoushiView];
    [page3ZoushiView updateWithData:_lottResults index:page3MidScrollButtonIndex type:_page3GameType];
}

- (void)updatePage3MidButtonStateWithTag:(NSInteger)tag {
    for (UIButton *btn in page3MidScroll.subviews) {
        if (![btn isKindOfClass:[UIButton class]]) {
            continue;
        }
        if (btn.tag == tag) {
            btn.titleLabel.font = SystemFontBy4(13.6);
            [btn setTitleColor:ColorHex(0xee3333) forState:0];
            [Tools setView:btn toMiddleOfScroll:page3MidScroll];
        } else {
            btn.titleLabel.font = SystemFontBy4(13.0);
            [btn setTitleColor:ColorHex(0x202020 ) forState:0];
        }
    }
    if (tag == 0) {
        
    }
}

/*请求page3开奖结果*/
- (void)requestPage3LotteryResultsForId:(NSInteger)lottId isRefresh:(BOOL)isRefresh {
    if (isRefresh) {
        page3AskingCount = 0;
        [page3Tabel.mj_footer resetNoMoreData];
        [page3ZoushiScroll.mj_footer resetNoMoreData];
    }
    
    if (page3AskingCount > _lottResults.count) {//如果请求的数量， 比返回的数量大，说明没有更多数据了
        [page3Tabel.mj_footer endRefreshingWithNoMoreData];
        [page3ZoushiScroll.mj_footer endRefreshingWithNoMoreData];
        return;
    }
    
    
    NSString *lottoryId = [NSString stringWithFormat:@"%li",(long)lottId];
    page3AskingCount = (isRefresh?(20):(_lottResults.count+20));
    NSString *count = [NSString stringWithFormat:@"%li",(long)page3AskingCount];
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [NetworkBusiness getWinNumberList:lottoryId count:count Block:^(NSError *error, int code, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        [page3Tabel.mj_header endRefreshing];
        [page3Tabel.mj_footer endRefreshing];
        [page3ZoushiScroll.mj_header endRefreshing];
        [page3ZoushiScroll.mj_footer endRefreshing];
        if (code == 200) {
            self.lottResults = [response arrayForKey:@"data"];
            _page3GameType = lottId;
            [self updatePage3TableView];
            if (_lottResults.count < 1) {
                [Tools showText:@"暂无开奖数据"];
            }
            if (page3MidScrollButtonIndex > 0) { //更新走势视图
                [self updatePage3ZoushiScrollview];
                page3ZoushiScroll.hidden = NO;
                page3Tabel.hidden = YES;
            } else {
                page3ZoushiScroll.hidden = YES;
                page3Tabel.hidden = NO;
            }
            
            if (_initShowZoushi) {
                _initShowZoushi = NO;
                page3SettingButton.hidden = YES;
                [self onPage3MidButtonTag:1];
            }
            [self updateSettingButtonHidden];
        } else {
            [Tools showText:@"获取开奖结果失败"];
        }
    }];
}

- (void)onPage3GameSelect {
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    WSDatePickerView *datepicker = [[WSDatePickerView alloc] initWithDateStyle:DateStyleShowBank data:lotteryNames scrollToIndex:page3SelectedGameIndex CompleteBlock:^(NSInteger tag, BOOL cancel) {
        if (cancel) {
            NSLog(@"CANCEL.....");
        } else {
            page3SelectedGameIndex = tag;
            
            //彩种名称
            NSString *title = lotteryNames[page3SelectedGameIndex];
            page3GameLal.text = title;
            
            //彩种类型
            NSDictionary *dict = [Singleton shared].gamesArrayGF[page3SelectedGameIndex];
            _page3GameType = [dict integerForKey:@"lottery_id"];
            
            NSLog(@"page3从selectview选了了游戏:%li",(long)_page3GameType);
            page3MidScrollButtonIndex = 0;
            [self requestPage3LotteryResultsForId:_page3GameType isRefresh:YES];
        }
    }];
    
    datepicker.dateLabelColor = ColorHex(0xff5733);//年-月-日-时-分 颜色
    datepicker.datePickerColor = ColorHex(0x286be8);//滚轮日期颜色
    datepicker.doneButtonColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;//确定按钮的颜色
    [datepicker setHideBackgroundYearLabel:YES];
    [datepicker show];
}

/*更新设置按钮是否隐藏*/
- (void)updateSettingButtonHidden {
    BOOL shouldShow;
    if (_page3GameType == GameType1MarkSix ||
        _page3GameType == GameType0BJKL8 ||
        _page3GameType == GameType1JSMarkSix || (page3MidScrollButtonIndex == 0)) {
        //隐藏设置按钮
        shouldShow = NO;
    } else {
        //显示设置按钮
        shouldShow = YES;
    }
    
    CGFloat duration = 0.2f;
    if (shouldShow) {
        if (page3SettingButton.hidden) {
            page3SettingButton.hidden = NO;
            [UIView animateWithDuration:duration animations:^{
                page3SettingButton.left -= widthTo4_7(45);
                page3TypeSelectButton.width = self.view.width-widthTo4_7(55);
                UIView *arrow = [page3TypeSelectButton viewWithTag:4455];
                arrow.right = page3TypeSelectButton.width;
            }];
        }
    } else {
        if (!page3SettingButton.hidden) {
            [UIView animateWithDuration:duration animations:^{
                page3SettingButton.left += widthTo4_7(45);
                page3TypeSelectButton.width = self.view.width-widthTo4_7(10);
                UIView *arrow = [page3TypeSelectButton viewWithTag:4455];
                arrow.right = page3TypeSelectButton.width;
            } completion:^(BOOL finished) {
                page3SettingButton.hidden = YES;
                page3SettingButton.left = (0.875*self.view.width+widthTo4_7(45));//暂时先强制写死，解决设置按钮不显示问题
            }];
        }
        
    }
    
}


/*根据顶部选中的游戏，更新下方UI*/
- (void)updatePage3TableView {
    [page3MidScroll removeAllSubviews];
    if (_page3GameType == GameType0BJPK10 ||
        _page3GameType == GameType0BJPK105FC ||
        _page3GameType == GameType0GWPK10 ||
        _page3GameType == GameType0XYFT ||
        _page3GameType == GameType0XYFT2) {
        page3Tabel.top = page3MidScroll.bottom;
        page3Tabel.height = self.view.height - page3MidScroll.bottom;
        page3Titles = @[@"开奖",@"冠军走势",@"亚军走势",@"季军走势",@"第四走势",@"第五走势",@"第六走势",@"第七走势",@"第八走势",@"第九走势",@"第十走势",];
        
    }
    if (_page3GameType == GameType0CQSSC ||
        _page3GameType == GameType0XCQSSC ||
        _page3GameType == GameType0GD115 ||
        _page3GameType == GameType0Gwffc ||
        _page3GameType == GameType0GW115 ||
        _page3GameType == GameType0JSK3 ||
        _page3GameType == GameType0GW3FC ||
        _page3GameType == GameType0GWK3 ||
        _page3GameType == GameType0JSK33FC ||
        _page3GameType == GameType0JSK35FC ||
        _page3GameType == GameType0GW3D ||
        _page3GameType == GameType0GW5FC ||
        _page3GameType == GameType0GW115SFC ||
        _page3GameType == GameType0AHK3) {
        page3Tabel.top = page3MidScroll.bottom;
        page3Tabel.height = self.view.height - page3MidScroll.bottom;
        
        page3Titles = @[@"开奖",@"万位走势",@"千位走势",@"百位走势",@"十位走势",@"个位走势",];
        if (_page3GameType == GameType0JSK3 ||
            _page3GameType == GameType0GWK3 ||
            _page3GameType == GameType0JSK33FC ||
            _page3GameType == GameType0JSK35FC ||
            _page3GameType == GameType0GW3D ||
            _page3GameType == GameType0AHK3) {
            page3Titles = @[@"开奖",@"百位走势",@"十位走势",@"个位走势",];
        }
    }
    
    CGFloat wid = self.view.width/4;
    for (int i = 0; i < page3Titles.count; i++) {
        UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(wid*i, 0, wid, page3MidScroll.height)];
        button.tag = i;
        [button setTitle:page3Titles[i] forState:0];
        [page3MidScroll addSubview:button];
        [button addTarget:self action:@selector(onPage3MidButton:) forControlEvents:UIControlEventTouchUpInside];
    }
    page3MidScrollRedBar = [[UIView alloc] initWithFrame:CGRectMake(0, page3MidScroll.height-widthTo4_7(2.6), wid, widthTo4_7(2.6))];
    page3MidScrollRedBar.backgroundColor = ColorHex(0xee3333);
    [page3MidScroll addSubview:page3MidScrollRedBar];
    page3MidScroll.contentSize = CGSizeMake(wid*page3Titles.count, page3MidScroll.height);
    page3MidScroll.showsHorizontalScrollIndicator = NO;
    page3MidScrollRedBar.left = page3MidScrollButtonIndex*page3MidScrollRedBar.width;
    [page3MidScroll scrollRectToVisible:CGRectMake(page3MidScrollRedBar.left, 0, page3MidScrollRedBar.width, page3MidScroll.height) animated:YES];
    
    [self updatePage3MidButtonStateWithTag:page3MidScrollButtonIndex];
    
    if (_page3GameType == GameType1MarkSix ||
        _page3GameType == GameType0BJKL8) {
        page3Tabel.top = page3MidScroll.top;
        page3Tabel.height = self.view.height - page3MidScroll.top;
    }
    
    page3Tabel.delegate = self;
    page3Tabel.dataSource = self;
    [page3Tabel reloadData];
}

/*点击了page3的设置按钮*/
- (void)onPage3Settings {
    NSLog(@"点击了page3设置按钮");
    
    UIView *bg = [[UIView alloc] initWithFrame:mainDelegate.window.bounds];
    bg.backgroundColor = ColorHexWithAlpha(0x000000, 0.6);
    [mainDelegate.window addSubview:bg];
    
    UIView *content = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0.76*self.view.width, widthTo4_7(274))];
    content.layer.cornerRadius = widthTo4_7(5.8);
    content.backgroundColor = ColorHex(0xffffff);
    content.layer.masksToBounds = YES;
    content.center = self.view.center;
    [bg addSubview:content];
    UILabel *tlabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, content.width, widthTo4_7(42))];
    tlabel.backgroundColor = COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT;
    tlabel.textAlignment = NSTextAlignmentCenter;
    tlabel.text = @"走势图设置";
    tlabel.textColor = ColorHex(0xffffff);
    tlabel.font = BoldSystemFontBy4(14.6);
    [content addSubview:tlabel];
    
    CGFloat switchHeight = widthTo4_7(26);
    UILabel *lab0 = [[UILabel alloc] initWithFrame:CGRectMake(0, tlabel.bottom+10, widthTo4_7(92), widthTo4_7(40))];
    lab0.textAlignment = NSTextAlignmentRight;
    lab0.text = @"折线:";
    lab0.textColor = ColorHex(0x262626);
    lab0.font = SystemFontBy4(14.2);
    [content addSubview:lab0];
    page3switch0 = [[ZJSwitch alloc] initWithFrame:CGRectMake(content.width-widthTo4_7(70), lab0.top + (lab0.height-switchHeight)/2, widthTo4_7(48), switchHeight)];
    [content addSubview:page3switch0];
    page3switch0.style = ZJSwitchStyleNoBorder;
    page3switch0.onTintColor = ColorHexWithAlpha(0x11a211, 0.95);
    page3switch0.tintColor = ColorHexWithAlpha(0x000000, 0.5);
    page3switch0.thumbTintColorOff = ColorHex(0xffffff);
    page3switch0.thumbTintColorOn = ColorHex(0xffffff);
    [page3switch0 setOn:[Singleton shared].Page3ShowZX animated:NO];
    
    UILabel *lab1 = [[UILabel alloc] initWithFrame:CGRectMake(0, lab0.bottom, widthTo4_7(92), widthTo4_7(40))];
    lab1.textAlignment = NSTextAlignmentRight;
    lab1.text = @"遗漏:";
    lab1.textColor = ColorHex(0x262626);
    lab1.font = SystemFontBy4(14.2);
    [content addSubview:lab1];
    page3switch1 = [[ZJSwitch alloc] initWithFrame:CGRectMake(content.width-widthTo4_7(70), lab1.top + (lab1.height-switchHeight)/2, widthTo4_7(48), switchHeight)];
    [content addSubview:page3switch1];
    page3switch1.style = ZJSwitchStyleNoBorder;
    page3switch1.onTintColor = ColorHexWithAlpha(0x11a211, 0.95);
    page3switch1.tintColor = ColorHexWithAlpha(0x000000, 0.5);
    page3switch1.thumbTintColorOff = ColorHex(0xffffff);
    page3switch1.thumbTintColorOn = ColorHex(0xffffff);
    [page3switch1 setOn:[Singleton shared].Page3ShowYL animated:NO];
    
    UILabel *lab2 = [[UILabel alloc] initWithFrame:CGRectMake(0, lab1.bottom, widthTo4_7(92), widthTo4_7(40))];
    lab2.textAlignment = NSTextAlignmentRight;
    lab2.text = @"统计:";
    lab2.textColor = ColorHex(0x262626);
    lab2.font = SystemFontBy4(14.2);
    [content addSubview:lab2];
    page3switch2 = [[ZJSwitch alloc] initWithFrame:CGRectMake(content.width-widthTo4_7(70), lab2.top + (lab2.height-switchHeight)/2, widthTo4_7(48), switchHeight)];
    [content addSubview:page3switch2];
    page3switch2.style = ZJSwitchStyleNoBorder;
    page3switch2.onTintColor = ColorHexWithAlpha(0x11a211, 0.95);
    page3switch2.tintColor = ColorHexWithAlpha(0x000000, 0.5);
    page3switch2.thumbTintColorOff = ColorHex(0xffffff);
    page3switch2.thumbTintColorOn = ColorHex(0xffffff);
    [page3switch2 setOn:[Singleton shared].Page3ShowTJ animated:NO];
    
    UILabel *lab3 = [[UILabel alloc] initWithFrame:CGRectMake(0, lab2.bottom, widthTo4_7(92), widthTo4_7(40))];
    lab3.textAlignment = NSTextAlignmentRight;
    lab3.text = @"遗漏分层:";
    lab3.textColor = ColorHex(0x262626);
    lab3.font = SystemFontBy4(14.2);
    [content addSubview:lab3];
    page3switch3 = [[ZJSwitch alloc] initWithFrame:CGRectMake(content.width-widthTo4_7(70), lab3.top + (lab3.height-switchHeight)/2, widthTo4_7(48), switchHeight)];
    [content addSubview:page3switch3];
    page3switch3.style = ZJSwitchStyleNoBorder;
    page3switch3.onTintColor = ColorHexWithAlpha(0x11a211, 0.95);
    page3switch3.tintColor = ColorHexWithAlpha(0x000000, 0.5);
    page3switch3.thumbTintColorOff = ColorHex(0xffffff);
    page3switch3.thumbTintColorOn = ColorHex(0xffffff);
    [page3switch3 setOn:[Singleton shared].Page3ShowYLFC animated:NO];
    
    UIButton *ok = [[UIButton alloc] initWithFrame:CGRectMake(0, content.height-widthTo4_7(50), content.width, widthTo4_7(50))];
    [content addSubview:ok];
    [ok setTitle:@"确定" forState:0];
    [ok setTitleColor:COLOR_SYSTEM_MAIN_UI_THEME_DEFAULT forState:0];
    ok.titleLabel.font = SystemFontBy4(14.6);
    [content addSubview:ok];
    [ok handleCallBack:^(UIButton *button) {
        [Singleton shared].Page3ShowZX = page3switch0.isOn;
        [Singleton shared].Page3ShowYL = page3switch1.isOn;
        [Singleton shared].Page3ShowTJ = page3switch2.isOn;
        [Singleton shared].Page3ShowYLFC = page3switch3.isOn;
        
        
        [UIView animateWithDuration:0.12 animations:^{
            bg.alpha = 0.f;
            content.transform = CGAffineTransformMakeScale(0.8, 0.8);
        } completion:^(BOOL finished) {
            [bg removeFromSuperview];
            [content removeFromSuperview];
        }];
        
        
        [page3ZoushiView updateSettings];
    } forEvent:UIControlEventTouchUpInside];
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, content.height-widthTo4_7(50), content.width, widthTo4_7(0.8))];
    line.backgroundColor = ColorHex(0xbbbbbb);
    [content addSubview:line];
    
    bg.alpha = 0.f;
    [UIView animateWithDuration:0.2 animations:^{
        bg.alpha = 1.f;
    }];
}

#pragma mark UITableViewDelegate & UITableViewDataSource 代理方法
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    CGFloat page3TabelHeight = 0;
    if (_page3GameType == GameType0BJPK10 ||
        _page3GameType == GameType0BJPK105FC ||
        _page3GameType == GameType0GWPK10 ||
        _page3GameType == GameType0XYFT ||
        _page3GameType == GameType0XYFT2) {
        page3TabelHeight = cellH0;
    }
    if (_page3GameType == GameType0CQSSC ||
        _page3GameType == GameType0XCQSSC ||
        _page3GameType == GameType0GW3FC ||
        _page3GameType == GameType0GW5FC) {
        page3TabelHeight = cellH1;
    }
    if (_page3GameType == GameType1MarkSix ||
        _page3GameType == GameType0GD115 ||
        _page3GameType == GameType0Gwffc ||
        _page3GameType == GameType0GW115 ||
        _page3GameType == GameType0JSK3 ||
        _page3GameType == GameType0GWK3 ||
        _page3GameType == GameType0JSK33FC ||
        _page3GameType == GameType0JSK35FC ||
        _page3GameType == GameType0GW3D ||
        _page3GameType == GameType0GW115SFC) {
        page3TabelHeight = cellH2;
    }
    if (_page3GameType == GameType0BJKL8) {
        page3TabelHeight = cellH3;
    }
    if (indexPath.row == (_lottResults.count-1)) {
        page3TabelHeight += widthTo4_7(24);
    }
    
    return page3TabelHeight;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _lottResults.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell;
    UIColor *color0 = ColorHex(0x404040);
    if (_page3GameType == GameType0BJPK10 ||
        _page3GameType == GameType0BJPK105FC ||
        _page3GameType == GameType0GWPK10 ||
        _page3GameType == GameType0XYFT ||
        _page3GameType == GameType0XYFT2) {
        static NSString *page3TableIdentifier0 = @"page3TableIdentifier0";
        cell = [tableView dequeueReusableCellWithIdentifier:page3TableIdentifier0];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:page3TableIdentifier0];
            //第几期
            UILabel *qi = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(10), 0, 300, widthTo4_7(43))];
            qi.tag = 1000;
            qi.textColor = color0;
            qi.font = SystemFontBy4(12.1);
            [cell addSubview:qi];
            
            //时间戳
            UILabel *time = [[UILabel alloc] initWithFrame:CGRectMake(0, qi.top, self.view.width-widthTo4_7(10), qi.height)];
            time.textAlignment = NSTextAlignmentRight;
            time.font = qi.font;
            time.textColor = qi.textColor;
            time.tag = 1001;
            [cell addSubview:time];
            
            //号码
            CGFloat left = widthTo4_7(10);
            CGFloat gap = widthTo4_7(4.0);
            CGFloat size = (self.view.width-left*2-gap*9)/10;
            for (int i = 0; i < 10; i++) {
                UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(left+(size+gap)*i, widthTo4_7(40), size, size)];
                label.tag = 2000+i;
                label.font = BoldSystemFontBy4(14.2);
                label.textColor = ColorHex(0xffffff);
                label.layer.borderColor = ColorHex(0x777777).CGColor;
                label.layer.borderWidth = widthTo4_7(0.8);
                label.layer.cornerRadius = 0.13*size;
                label.layer.masksToBounds = YES;
                [cell addSubview:label];
                label.textAlignment = NSTextAlignmentCenter;
            }
            
            gap *= 2.4;
            size *= 0.84;
            left = (self.view.width-size*8-gap*7)/2;
            for (int k = 0; k < 8; k++) {
                UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(left+(size+gap)*k, 0.28*cellH0+size*1.72, size, size)];
                label.tag = 3000+k;
                label.font = SystemFontBy4(13.0);
                label.textColor = ColorHex(0x606060);
                label.layer.borderColor = ColorHex(0x606060).CGColor;
                label.layer.borderWidth = widthTo4_7(0.8);
                label.layer.cornerRadius = 0.13*size;
                label.layer.masksToBounds = YES;
                [cell addSubview:label];
                label.textAlignment = NSTextAlignmentCenter;
            }
            
            UIView *line = [[UIView alloc] initWithFrame:CGRectMake(widthTo4_7(10), cellH0-widthTo4_7(1.2), self.view.width-widthTo4_7(20), widthTo4_7(1.2))];
            line.backgroundColor = ColorHex(0xe2e2e2);
            [cell addSubview:line];
        }
        
        NSDictionary *result = _lottResults[indexPath.row];
        [self setIssueAndTimeForCell:cell result:result];
        NSString *win = [result stringForKey:@"wn_number"];
        NSArray *arr = [Tools arrayFormWn_number:win];
        
        for (int i = 0; i < arr.count; i++) {
            UILabel *label = [cell viewWithTag:2000+i];
            
            NSString *textstr = arr[i];
            
            //去掉前面的l0
            //                textstr = [NSString stringWithFormat:@"%i",textstr.intValue];
            
            //添加阴影
            NSShadow *shadow = [[NSShadow alloc] init];
            shadow.shadowBlurRadius = label.height*0.1;
            shadow.shadowOffset = CGSizeZero;
            shadow.shadowColor = ColorHex(0x000000);
            NSAttributedString *att = [[NSAttributedString alloc] initWithString:textstr attributes:@{NSShadowAttributeName:shadow}];
            label.attributedText = att;
            
            
            if (textstr.intValue == 1) {
                label.backgroundColor = ColorHex(0xf4ef4f);
            }
            if (textstr.intValue == 2) {
                label.backgroundColor = ColorHex(0x4591f7);
            }
            if (textstr.intValue == 3) {
                label.backgroundColor = ColorHex(0x4b4d52);
            }
            if (textstr.intValue == 4) {
                label.backgroundColor = ColorHex(0xeb7b30);
            }
            if (textstr.intValue == 5) {
                label.backgroundColor = ColorHex(0xa1fcfd);
            }
            if (textstr.intValue == 6) {
                label.backgroundColor = ColorHex(0x5341f3);
            }
            if (textstr.intValue == 7) {
                label.backgroundColor = ColorHex(0xe7e7e7);
            }
            if (textstr.intValue == 8) {
                label.backgroundColor = ColorHex(0xe73f25);
            }
            if (textstr.intValue == 9) {
                label.backgroundColor = ColorHex(0x681a0b);
            }
            if (textstr.intValue == 10) {
                label.backgroundColor = ColorHex(0x5fbf37);
            }
        }
        
        //龙虎
        NSMutableArray *mArr2 = [NSMutableArray array];
        NSString *val0 = (arr.count>0)?(arr[0]):(@"0");
        NSString *val1 = (arr.count>1)?(arr[1]):(@"0");
        NSString *val2 = (arr.count>2)?(arr[2]):(@"0");
        NSString *val3 = (arr.count>3)?(arr[3]):(@"0");
        NSString *val4 = (arr.count>4)?(arr[4]):(@"0");
        NSString *val5 = (arr.count>5)?(arr[5]):(@"0");
        NSString *val6 = (arr.count>6)?(arr[6]):(@"0");
        NSString *val7 = (arr.count>7)?(arr[7]):(@"0");
        NSString *val8 = (arr.count>8)?(arr[8]):(@"0");
        NSString *val9 = (arr.count>9)?(arr[9]):(@"0");
        int v0 = val0.intValue;
        int v1 = val1.intValue;
        int v2 = val2.intValue;
        int v3 = val3.intValue;
        int v4 = val4.intValue;
        int v5 = val5.intValue;
        int v6 = val6.intValue;
        int v7 = val7.intValue;
        int v8 = val8.intValue;
        int v9 = val9.intValue;
        int total = v0+v1+v2+v3+v4+v5+v6+v7+v8+v9;
        if (_page3GameType == GameType0BJPK10 ||
            _page3GameType == GameType0BJPK105FC ||
            _page3GameType == GameType0XYFT ||
            _page3GameType == GameType0XYFT2 ||
            _page3GameType == GameType0GWPK10) {//北京pk10、幸运飞艇、官网极速PK10
            int key0 = (v0+v1);
            [mArr2 addObject:[NSString stringWithFormat:@"%i",key0]];  //1
            NSString *daxiao = ((key0>11)?@"大":@"小");
            [mArr2 addObject:daxiao];                                  //2
            NSString *danshuang = ((key0%2==1)?@"单":@"双");
            [mArr2 addObject:danshuang];                               //3
            NSString *lh0 = ((v0>v9)?@"龙":@"虎");
            [mArr2 addObject:lh0];                                     //4
            NSString *lh1 = ((v1>v8)?@"龙":@"虎");
            [mArr2 addObject:lh1];                                     //5
            NSString *lh2 = ((v2>v7)?@"龙":@"虎");
            [mArr2 addObject:lh2];                                     //6
            NSString *lh3 = ((v3>v6)?@"龙":@"虎");
            [mArr2 addObject:lh3];                                     //7
            NSString *lh4 = ((v4>v5)?@"龙":@"虎");
            [mArr2 addObject:lh4];                                     //8
        } else if (_page3GameType == GameType0Gwffc) {              //group2  第2组
            [mArr2 addObject:[NSString stringWithFormat:@"%i",total]];  //1
            NSString *lh0 = ((total>=23)?@"大":@"小");                   //2
            [mArr2 addObject:lh0];
            NSString *lh1 = ((total%2==1)?@"单":@"双");                  //3
            [mArr2 addObject:lh1];
            if (v0>v4) {                                                //4
                [mArr2 addObject:@"龙"];
            } else if (v0==v4) {
                [mArr2 addObject:@"和"];
            } else {
                [mArr2 addObject:@"虎"];
            }
            
        } else if (_page3GameType == GameType0BJKL8) {        //group3  第3组
            [mArr2 addObject:[NSString stringWithFormat:@"%i",total]];  //1
            if (total>84) {                                             //2
                [mArr2 addObject:@"大"];
            } else if (total==84) {
                [mArr2 addObject:@"和"];
            } else {
                [mArr2 addObject:@"小"];
            }
            NSString *lh0 = ((total%2==1)?@"单":@"双");
            [mArr2 addObject:lh0];                                      //3
            NSString *lh1 = ((total%10>=5)?@"大":@"小");
            [mArr2 addObject:lh1];                                      //4
        } else if (_page3GameType == GameType0Gwffc) {                 //group4  第4组
            [mArr2 addObject:[NSString stringWithFormat:@"%i",total]];  //1
            if (total>30) {                                             //2
                [mArr2 addObject:@"大"];
            } else if (total==30) {
                [mArr2 addObject:@"和"];
            } else {
                [mArr2 addObject:@"小"];
            }
            NSString *lh0 = ((total%2==1)?@"单":@"双");
            [mArr2 addObject:lh0];                                      //3
            NSString *lh1 = ((total%10>=5)?@"大":@"小");
            [mArr2 addObject:lh1];                                      //4
            NSString *lh2 = ((v0>v4)?@"龙":@"虎");
            [mArr2 addObject:lh2];                                      //5
        } else if (_page3GameType == GameType0Gwffc) {          //group6  第6组
            [mArr2 addObject:[NSString stringWithFormat:@"%i",total]];  //1
            NSString *lh1 = ((total>=11)?@"大":@"小");                   //2
            [mArr2 addObject:lh1];
        } else if (_page3GameType == GameType0Gwffc) {       //group7  第7组
            
        } else if (_page3GameType == GameType0Gwffc) {                //group8  第8组
            [mArr2 addObject:[NSString stringWithFormat:@"%i",total]];  //1
            NSString *lh1 = ((total>13)?@"大":@"小");                   //2
            [mArr2 addObject:lh1];
            NSString *lh2 = ((total%2==1)?@"单":@"双");                  //3
            [mArr2 addObject:lh2];
        }
        
        for (int k = 0; k < mArr2.count; k++) {
            UILabel *label = [cell viewWithTag:3000+k];
            label.text = mArr2[k];
        }
    }
    if (_page3GameType == GameType0CQSSC ||
        _page3GameType == GameType0XCQSSC ||
        _page3GameType == GameType0GW3FC ||
        _page3GameType == GameType0GW5FC) {
        static NSString *page3TableIdentifier1 = @"page3TableIdentifier1";
        cell = [tableView dequeueReusableCellWithIdentifier:page3TableIdentifier1];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:page3TableIdentifier1];
            //第几期
            UILabel *qi = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(10), 0, 300, widthTo4_7(43))];
            qi.tag = 1000;
            qi.textColor = color0;
            qi.font = SystemFontBy4(12.1);
            [cell addSubview:qi];
            
            //时间戳
            UILabel *time = [[UILabel alloc] initWithFrame:CGRectMake(0, qi.top, self.view.width-widthTo4_7(10), qi.height)];
            time.textAlignment = NSTextAlignmentRight;
            time.font = qi.font;
            time.textColor = qi.textColor;
            time.tag = 1001;
            [cell addSubview:time];
            
            CGFloat top = widthTo4_7(42);
            CGFloat gap = widthTo4_7(4.2);
            CGFloat size = widthTo4_7(32);
            for (int i = 0; i < 5; i++) {
                UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(10)+(size+gap)*i, top, size, size)];
                label.textColor = ColorHex(0xffffff);
                label.textAlignment = NSTextAlignmentCenter;
                label.font = BoldSystemFontBy4(14.2);
                label.layer.cornerRadius = 0.5*label.height;
                label.layer.masksToBounds = YES;
                label.backgroundColor = ColorHex(0xc7343d);
                [cell addSubview:label];
                label.tag = 2000+i;
            }
            
            //总和大小单双
            UILabel *zonghe = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(10), widthTo4_7(80), 300, widthTo4_7(33))];
            zonghe.font = qi.font;
            zonghe.textColor = qi.textColor;
            zonghe.tag = 3000;
            [cell addSubview:zonghe];
            
            UIView *line = [[UIView alloc] initWithFrame:CGRectMake(widthTo4_7(10), cellH1-widthTo4_7(1.2), self.view.width-widthTo4_7(20), widthTo4_7(1.2))];
            line.backgroundColor = ColorHex(0xe2e2e2);
            [cell addSubview:line];
        }
        
        NSDictionary *result = _lottResults[indexPath.row];
        [self setIssueAndTimeForCell:cell result:result];
        NSString *win = [result stringForKey:@"wn_number"];
        NSArray *arr = [Tools arrayFormWn_number:win];
        
        int he = 0;
        for (int i = 0; i < arr.count; i++) {
            UILabel *label = [cell viewWithTag:2000+i];
            label.text = arr[i];
            he += label.text.intValue;
        }
        NSString *zongh = [NSString stringWithFormat:@"%i",he];
        NSString *daxiao = (he>=23?@"大":@"小");
        NSString *danshuang = ((he%2==1)?@"单":@"双");
        
        
        UILabel *zonghe = [cell viewWithTag:3000];
        zonghe.text = [NSString stringWithFormat:@"总和: %@       大小: %@       单双: %@",zongh,daxiao,danshuang];
        
    }
    if (_page3GameType == GameType1MarkSix ||
        _page3GameType == GameType0GD115 ||
        _page3GameType == GameType0Gwffc ||
        _page3GameType == GameType0GW115 ||
        _page3GameType == GameType0JSK3 ||
        _page3GameType == GameType0GWK3 ||
        _page3GameType == GameType0JSK33FC ||
        _page3GameType == GameType0JSK35FC ||
        _page3GameType == GameType0GW3D ||
        _page3GameType == GameType0GW115SFC ||
        _page3GameType == GameType0AHK3) {
        static NSString *page3TableIdentifier2 = @"page3TableIdentifier2";
        cell = [tableView dequeueReusableCellWithIdentifier:page3TableIdentifier2];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:page3TableIdentifier2];
            //第几期
            UILabel *qi = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(10), 0, 300, widthTo4_7(43))];
            qi.tag = 1000;
            qi.textColor = color0;
            qi.font = SystemFontBy4(12.1);
            [cell addSubview:qi];
            
            //时间戳
            UILabel *time = [[UILabel alloc] initWithFrame:CGRectMake(0, qi.top, self.view.width-widthTo4_7(10), qi.height)];
            time.textAlignment = NSTextAlignmentRight;
            time.font = qi.font;
            time.textColor = qi.textColor;
            time.tag = 1001;
            [cell addSubview:time];
            
            CGFloat top = widthTo4_7(42);
            CGFloat gap = widthTo4_7(4.2);
            CGFloat size = widthTo4_7(32);
            for (int i = 0; i < 5; i++) {
                UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(10)+(size+gap)*i, top, size, size)];
                label.textColor = ColorHex(0xffffff);
                label.textAlignment = NSTextAlignmentCenter;
                label.font = BoldSystemFontBy4(14.2);
                label.layer.cornerRadius = 0.5*label.height;
                label.layer.masksToBounds = YES;
                label.backgroundColor = ColorHex(0xc7343d);
                [cell addSubview:label];
                label.tag = 2000+i;
            }
            
            UIView *line = [[UIView alloc] initWithFrame:CGRectMake(widthTo4_7(10), cellH2-widthTo4_7(1.2), self.view.width-widthTo4_7(20), widthTo4_7(1.2))];
            line.backgroundColor = ColorHex(0xe2e2e2);
            [cell addSubview:line];
        }
        
        NSDictionary *result = _lottResults[indexPath.row];
        [self setIssueAndTimeForCell:cell result:result];
        NSString *win = [result stringForKey:@"wn_number"];
        NSArray *arr = [Tools arrayFormWn_number:win];
        
        for (int i = 0; i < 5; i++) {
            UILabel *label = [cell viewWithTag:2000+i];
            if (i < arr.count) {
                label.hidden = NO;
                label.text = arr[i];
            } else {
                label.hidden = YES;
            }
        }
    }
    
    if (_page3GameType == GameType0BJKL8) {
        static NSString *page3TableIdentifier3 = @"page3TableIdentifier3";
        cell = [tableView dequeueReusableCellWithIdentifier:page3TableIdentifier3];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:page3TableIdentifier3];
            //第几期
            UILabel *qi = [[UILabel alloc] initWithFrame:CGRectMake(widthTo4_7(10), 0, 300, widthTo4_7(43))];
            qi.tag = 1000;
            qi.textColor = color0;
            qi.font = SystemFontBy4(12.1);
            [cell addSubview:qi];
            
            //时间戳
            UILabel *time = [[UILabel alloc] initWithFrame:CGRectMake(0, qi.top, self.view.width-widthTo4_7(10), qi.height)];
            time.textAlignment = NSTextAlignmentRight;
            time.font = qi.font;
            time.textColor = qi.textColor;
            time.tag = 1001;
            [cell addSubview:time];
            
            CGFloat top = widthTo4_7(42);
            CGFloat size = widthTo4_7(32);
            CGFloat left = widthTo4_7(10);
            CGFloat gap = (self.view.width-left*2-size*10)/9;
            for (int i = 0; i < 20; i++) {
                UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(left+(size+gap)*(i%10), top + (size+gap*2.3)*(i/10), size, size)];
                label.textColor = ColorHex(0xffffff);
                label.textAlignment = NSTextAlignmentCenter;
                label.font = BoldSystemFontBy4(14.2);
                label.layer.cornerRadius = 0.5*label.height;
                label.layer.masksToBounds = YES;
                label.backgroundColor = ColorHex(0xc7343d);
                [cell addSubview:label];
                label.tag = 2000+i;
            }
            
            UIView *line = [[UIView alloc] initWithFrame:CGRectMake(widthTo4_7(10), cellH3-widthTo4_7(1.2), self.view.width-widthTo4_7(20), widthTo4_7(1.2))];
            line.backgroundColor = ColorHex(0xe2e2e2);
            [cell addSubview:line];
        }
        
        NSDictionary *result = _lottResults[indexPath.row];
        [self setIssueAndTimeForCell:cell result:result];
        NSString *win = [result stringForKey:@"wn_number"];
        NSArray *arr = [Tools arrayFormWn_number:win];
        
        for (int i = 0; i < 20; i++) {
            UILabel *label = [cell viewWithTag:2000+i];
            label.text = arr[i];
        }
    }
    
    /*防止crash*/
    if (!cell) {
        cell = [[UITableViewCell alloc] init];
    }
    
    return cell;
}

-  (void)setIssueAndTimeForCell:(UITableViewCell *)cell result:(NSDictionary *)result {
    NSString *qi = [result stringForKey:@"issue"];
    NSInteger timeQ = [result integerForKey:@"offical_time"];
    
    UILabel *issue = [cell viewWithTag:1000];//第几期
    issue.text = [NSString stringWithFormat:@"第%@期",qi];
    UILabel *time = [cell viewWithTag:1001];//时间戳
    NSDate *tDate = [NSDate dateWithTimeIntervalSince1970:timeQ];
    NSString *tDateStr = [tDate stringWithFormat:@"yyyy-MM-dd HH:mm:ss"];
    time.text = tDateStr;
}
@end
