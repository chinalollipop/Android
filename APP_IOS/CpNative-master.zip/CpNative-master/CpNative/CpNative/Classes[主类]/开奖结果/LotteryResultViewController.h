//
//  LotteryResultViewController.h
//  CpNative
//
//  Created by david on 2019/3/8.
//  Copyright © 2019 david. All rights reserved.
//

#import "BasicWithNaviBarViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface LotteryResultViewController : BasicWithNaviBarViewController

//彩种类型,push之前指定显示哪个彩种，在枚举GameType0中，不指定则显示返回的官方盘第1个彩种
@property(nonatomic, assign) NSInteger page3GameType;


@property(nonatomic, assign) BOOL initShowZoushi;//一开始就展示走势


@property(nonatomic, strong) NSArray *lottResults;//开奖结果数组

@property(nonatomic, assign) BOOL isInHomePage;

- (void)refresh;

@end

NS_ASSUME_NONNULL_END
