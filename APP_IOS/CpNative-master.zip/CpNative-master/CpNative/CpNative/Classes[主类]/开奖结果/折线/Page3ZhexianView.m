//
//  Page3ZhexianView.m
//  CpNative
//
//  Created by david on 2019/2/27.
//  Copyright © 2019 david. All rights reserved.
//

#import "Page3ZhexianView.h"

@implementation Page3ZhexianView {
    UIColor *drawColor;
    NSMutableArray *xs;//x轴
    NSMutableArray *ys;//y轴
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}

- (void)drawForData:(NSArray *)data width:(CGFloat)wid height:(CGFloat)heig color:(UIColor *)color {
    drawColor = color;
    
    /*计算x轴和y轴的坐标点*/
    xs = [[NSMutableArray alloc] init];
    ys = [[NSMutableArray alloc] init];
    for (int i = 0; i < data.count; i++) {
        NSString *index = data[i];
        CGFloat x = wid*(index.floatValue+0.5);
        CGFloat y = heig*(i+0.5);
        
        [xs addObject:[NSString stringWithFormat:@"%f",x]];
        [ys addObject:[NSString stringWithFormat:@"%f",y]];
    }
}


- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    for (int i = 0; i < xs.count; i++) {
        NSString *x = xs[i];
        NSString *y = ys[i];
        if (i == 0) {
            [path moveToPoint:CGPointMake(x.floatValue, y.floatValue)];
        } else {
            [path addLineToPoint:CGPointMake(x.floatValue, y.floatValue)];
        }
    }
    
    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
    shapeLayer.strokeColor = drawColor.CGColor;
    shapeLayer.fillColor = [UIColor clearColor].CGColor;
    shapeLayer.lineWidth = widthTo4_7(1.0);
    shapeLayer.path = path.CGPath;
    [self.layer addSublayer:shapeLayer];
}

@end
