//
//  Page3ZhexianView.h
//  CpNative
//
//  Created by david on 2019/2/27.
//  Copyright © 2019 david. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Page3ZhexianView : UIView

- (void)drawForData:(NSArray *)data width:(CGFloat)wid height:(CGFloat)heig color:(UIColor *)color;

@end

NS_ASSUME_NONNULL_END
