//
//  Page3ZoushiView.m
//  CpNative
//
//  Created by david on 2019/2/26.
//  Copyright © 2019 david. All rights reserved.
//

#import "Page3ZoushiView.h"

@implementation Page3ZoushiView {
    
    NSArray *realArray;
    
    UIColor *lineColor1;
    UIColor *lineColor2;
    UIColor *lineColor3;
    UIColor *lineColor4;
    UIColor *lineColor5;
    UIColor *lineColor6;
    
    CGFloat lineH;//行高
    NSInteger dataCount;//有多少条数据
    NSMutableArray *bingoes;//中奖号码，所有真正的号码
    UIView *tjCover;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.userInteractionEnabled = NO;
        self.layer.masksToBounds = YES;
        self.clipsToBounds = YES;
        lineColor1 = ColorHex(0xb237ac);
        lineColor2 = ColorHex(0x5173b2);
        lineColor3 = ColorHex(0x577e37);
        lineColor4 = ColorHex(0xa47d2c);
        lineColor5 = ColorHex(0xb82738);
        lineColor6 = ColorHex(0xe73323);
    }
    return self;
}

/*index是第几种颜色，type什么类型的彩种*/
- (void)updateWithData:(NSArray *)data index:(NSInteger)index type:(NSInteger)type {
    realArray = [[data reverseObjectEnumerator] allObjects];
    dataCount = realArray.count;
    UIColor *color0 = ColorHex(0x555555);//底部的文字颜色
    UIColor *color1 = ColorHex(0xececec);//奇数行数的颜色
    UIColor *color2 = ColorHex(0xe3f6f5);//遗漏分层的颜色
    UIColor *color4 = ColorHex(0xcccccc);//底部的线条颜色
    UIFont *bfont = BoldSystemFontBy4(11.6);//文字的字号
    UIFont *font = SystemFontBy4(11.6);//文字的字号
    UIColor *color3;//折线的颜色
    NSArray *numbers;//纵向的数字
    CGFloat leftWid = 0.22*self.width;//左侧期数的宽度
    lineH = (self.width-leftWid)/11.0;//行高
    CGFloat rightWid;//右边的宽度
    
    //重庆时时彩、官网分分彩、官网三分彩、官网极速3D、官网5分彩
    if (type == GameType0CQSSC ||
        type == GameType0XCQSSC ||
        type == GameType0Gwffc ||
        type == GameType0GW3FC ||
        type == GameType0GW3D ||
        type == GameType0GW5FC)
    {
        numbers = @[@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",];
    }
    
    //广东11选5、官网11选5、11选5三分彩
    else if (type == GameType0GD115 ||
        type == GameType0GW115 ||
        type == GameType0GW115SFC)
    {
        numbers = @[@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",];
    }
    
    //北京PK10
    else if (type == GameType0BJPK10 ||
             type == GameType0BJPK105FC ||
             type == GameType0GWPK10 ||
             type == GameType0XYFT ||
             type == GameType0XYFT2)
    {
        numbers = @[@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",];
    }
    
    //江苏快三、官网快三分分彩、安徽快三
    else if (type == GameType0JSK3 ||
             type == GameType0GWK3 ||
             type == GameType0JSK33FC ||
             type == GameType0JSK35FC ||
             type == GameType0AHK3)
    {
        numbers = @[@"1",@"2",@"3",@"4",@"5",@"6",];
    }
    
    //容错
    if (!numbers) {
        numbers = @[@"1"];
    }
    
    rightWid = (self.width-leftWid)/numbers.count;
    
    if (index == 1) {
        color3 = lineColor1;
    } else if (index == 2) {
        color3 = lineColor2;
    } else if (index == 3) {
        color3 = lineColor3;
    } else if (index == 4) {
        color3 = lineColor4;
    } else if (index == 5) {
        color3 = lineColor5;
    } else {
        color3 = lineColor6;
    }

    CALayer *hLine = [[CALayer alloc] init];
    hLine.frame = CGRectMake(0, 0, self.width, widthTo4_7(0.8));
    hLine.backgroundColor = color4.CGColor;
    [self.layer addSublayer:hLine];
    
    hLine = [[CALayer alloc] init];
    hLine.frame = CGRectMake(0, lineH, self.width, widthTo4_7(0.8));
    hLine.backgroundColor = color4.CGColor;
    [self.layer addSublayer:hLine];
    
    //中奖号码
    bingoes = [NSMutableArray array];
    for (int i = 0; i < realArray.count; i++) {
        NSDictionary *dict = realArray[i];
        NSString *win = [dict stringForKey:@"wn_number"];
        NSArray *wins = [Tools arrayFormWn_number:win];
        NSString *number = wins[index-1];
        int index = [Tools indexOfNum:number inNums:numbers];
        NSString *str = [NSString stringWithFormat:@"%i",index];
        [bingoes addObject:str];
    }
    

    CGFloat offY = 0;
    //第一行
    for (int i = 0; i < numbers.count+1; i++) {
        NSString *qishu = [NSString stringWithFormat:@"期数(%li)",(long)dataCount];
        NSString *text = (i==0?(qishu):(numbers[i-1]));
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake((rightWid*(i>0?i-1:0)+leftWid*(i>0?1:0)), 0, (i==0?leftWid:rightWid), lineH)];
        label.text = text;
        label.textAlignment = NSTextAlignmentCenter;
        label.font = bfont;
        label.textColor = color0;
        [self addSubview:label];
    }
    
    offY = lineH;
    for (int i = 0; i < (realArray.count+4); i++) {
        if (!(i%2)) {
            CALayer *layer = [[CALayer alloc] init];
            layer.backgroundColor = color1.CGColor;
            layer.frame = CGRectMake(0, lineH*2*(i/2)+offY, self.width, lineH);
            [self.layer addSublayer:layer];
        }
        
        if (i < realArray.count) {
            NSDictionary *dic = realArray[i];
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, lineH*(i+1), leftWid, lineH)];
            label.textAlignment = NSTextAlignmentCenter;
            label.textColor = color0;
            label.font = font;
            NSString *issue = [dic stringForKey:@"issue"];
            if ([issue containString:@"2019"] || [issue containString:@"2020"] || [issue containString:@"2021"]) {
                issue = [issue substringFromIndex:2];
            }
            label.text = issue;
            [self addSubview:label];
        }
    }
    
    //遗漏分层
    _ylfc = [[UIView alloc] initWithFrame:CGRectMake(leftWid, lineH, self.width-leftWid, lineH*realArray.count)];
    [self addSubview:_ylfc];
    
    hLine = [[CALayer alloc] init];
    hLine.frame = CGRectMake(0, lineH*(realArray.count+1)-widthTo4_7(0.8), self.width, widthTo4_7(0.8));
    hLine.backgroundColor = color4.CGColor;
    [self.layer addSublayer:hLine];
    
    hLine = [[CALayer alloc] init];
    hLine.frame = CGRectMake(0, lineH*(realArray.count+5)-widthTo4_7(0.8), self.width, widthTo4_7(0.8));
    hLine.backgroundColor = color4.CGColor;
    [self.layer addSublayer:hLine];
    
    //竖线
    for (int i = 0; i < numbers.count; i++) {
        CALayer *layer = [[CALayer alloc] init];
        layer.frame = CGRectMake(leftWid+rightWid*i, 0, widthTo4_7(0.8), lineH*(realArray.count+5));
        layer.backgroundColor = color4.CGColor;
        [self.layer addSublayer:layer];
    }
    
    //遗漏数字
    _yl = [[Page3YilouView alloc] initWithFrame:CGRectMake(leftWid, lineH, self.width-leftWid, lineH*realArray.count)];
    [_yl drawForData:bingoes width:rightWid height:lineH color:color0 font:font vLines:numbers.count];
    [self addSubview:_yl];
    
    //设置遗漏分层
    [self setYlfcWithWid:rightWid height:lineH color:color2];
    
    //折线
    _zx = [[Page3ZhexianView alloc] initWithFrame:CGRectMake(leftWid, lineH, self.width-leftWid, lineH*realArray.count)];
    [_zx drawForData:bingoes width:rightWid height:lineH color:color3];
    [self addSubview:_zx];
    
    //中奖号码
    for (int i = 0; i < bingoes.count; i++) {
        NSString *bingo = bingoes[i];
        NSString *text = numbers[bingo.integerValue];
        
        UILabel *numLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, lineH*0.84, lineH*0.84)];
        numLabel.text = text;
        numLabel.backgroundColor = color3;
        numLabel.layer.cornerRadius = numLabel.height*0.5;
        numLabel.layer.masksToBounds = YES;
        numLabel.textAlignment = NSTextAlignmentCenter;
        numLabel.font = BoldSystemFontBy4(12.);
        numLabel.textColor = [UIColor whiteColor];
        [self addSubview:numLabel];
        
        CGFloat x = leftWid + rightWid*(bingo.integerValue+0.5);
        numLabel.center = CGPointMake(x, lineH*(i+1.5));
    }
    
    //统计
    NSArray *texts = @[@"出现次数",@"平均遗漏",@"最大遗漏",@"最大连出",];
    NSArray *colors = @[ColorHex(0xb540af),ColorHex(0x4c5935),ColorHex(0x936848),ColorHex(0x396073),];
    for (int i = 0; i < texts.count; i++) {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, lineH*(dataCount+1+i), leftWid, lineH)];
        label.font = bfont;
        label.textAlignment = NSTextAlignmentCenter;
        label.textColor = colors[i];
        label.text = texts[i];
        [self addSubview:label];
        
        NSArray *arr;
        if (i == 0) {
            arr = _yl.showTimes;
        } else if (i == 1) {
            arr = _yl.averageYilou;
        } else if (i == 2) {
            arr = _yl.biggestYilou;
        } else if (i == 3) {
            arr = _yl.biggestLianchu;
        }
        
        for (int k = 0; k < arr.count; k++) {
            UILabel *valueLabel = [[UILabel alloc] initWithFrame:CGRectMake(leftWid+rightWid*k, label.top, rightWid, lineH)];
            valueLabel.text = arr[k];
            valueLabel.font = label.font;
            if (k < colors.count) {
                valueLabel.textColor = colors[k];
            } else {
                valueLabel.textColor = color0;
            }
            valueLabel.textAlignment = NSTextAlignmentCenter;
            [self addSubview:valueLabel];
        }
    }
    tjCover = [[UIView alloc] initWithFrame:CGRectMake(0, lineH*(dataCount+1)+widthTo4_7(0.6), self.width, widthTo4_7(24))];
    tjCover.backgroundColor = [UIColor whiteColor];
    [self addSubview:tjCover];
    
    [self updateSettings];
}

- (void)setYlfcWithWid:(CGFloat)wid height:(CGFloat)heig color:(UIColor *)color {
    for (int i = 0; i < _yl.lastYL.count; i++) {
        NSString *str = _yl.lastYL[i];
        int value = str.intValue;
        if (value > 0) {
            CGFloat top = heig*(dataCount-value);
            CALayer *layer = [[CALayer alloc] init];
            layer.frame = CGRectMake(wid*i, top, wid, _ylfc.height-top);
            layer.backgroundColor = color.CGColor;
            [_ylfc.layer addSublayer:layer];
        }
    }
}


/*当设置更新后调用*/
- (void)updateSettings {
    _zx.hidden = !([Singleton shared].Page3ShowZX);
    _yl.hidden = !([Singleton shared].Page3ShowYL);
    _ylfc.hidden = !([Singleton shared].Page3ShowYLFC);
    
    if ([Singleton shared].Page3ShowTJ) {
        self.height = lineH*(dataCount+5)+widthTo4_7(24);
        tjCover.hidden = YES;
    } else {
        self.height = lineH*(dataCount+1)+widthTo4_7(24);
        tjCover.hidden = NO;
    }
    
    BasicScrollView *scroll = (BasicScrollView *)self.superview;
    if ([scroll isKindOfClass:[BasicScrollView class]]) {
        self.top = 0;
        scroll.contentSize = CGSizeMake(self.width, self.height);
    }
}

@end
