//
//  Page3ZoushiView.h
//  CpNative
//
//  Created by david on 2019/2/26.
//  Copyright © 2019 david. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Page3ZhexianView.h"
#import "Page3YilouView.h"

NS_ASSUME_NONNULL_BEGIN

@interface Page3ZoushiView : UIView

@property(nonatomic, strong) UIView *ylfc;//遗漏分层
@property(nonatomic, strong) Page3YilouView *yl;//遗漏数字
@property(nonatomic, strong) Page3ZhexianView *zx;//折线
@property(nonatomic, strong) UIView *tj;//统计

/*index是第几种颜色，type什么类型的彩种*/
- (void)updateWithData:(NSArray *)data index:(NSInteger)index type:(NSInteger)type;

/*当设置更新后调用*/
- (void)updateSettings;



@end

NS_ASSUME_NONNULL_END
