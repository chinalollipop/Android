package com.hgapp.a6668.data;

public class SwPDHE {
    public String  ior_H_up;
    public String  ior_H_down;
}
