package com.hgapp.a6668.base;

/**
 * Created by Daniel on 2017/7/27.
 */

public interface IFinishView {
    public void finish();
}
