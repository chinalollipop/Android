package com.hgapp.a6668.data;

import com.google.gson.annotations.SerializedName;

public class CPJSFTResult {

    /**
     * 3317 : 2.19
     * 3318 : 1.78
     * 3319 : 1.78
     * 3320 : 2.19
     * 3301-3311 : 1.988
     * 3301-3312 : 1.988
     * 3301-3313 : 1.988
     * 3301-3314 : 1.988
     * 3301-3315 : 1.988
     * 3301-3316 : 1.988
     * 3301-1 : 9.88
     * 3301-2 : 9.88
     * 3301-3 : 9.88
     * 3301-4 : 9.88
     * 3301-5 : 9.88
     * 3301-6 : 9.88
     * 3301-7 : 9.88
     * 3301-8 : 9.88
     * 3301-9 : 9.88
     * 3301-10 : 9.88
     * 3302-3311 : 1.988
     * 3302-3312 : 1.988
     * 3302-3313 : 1.988
     * 3302-3314 : 1.988
     * 3302-3315 : 1.988
     * 3302-3316 : 1.988
     * 3302-1 : 9.88
     * 3302-2 : 9.88
     * 3302-3 : 9.88
     * 3302-4 : 9.88
     * 3302-5 : 9.88
     * 3302-6 : 9.88
     * 3302-7 : 9.88
     * 3302-8 : 9.88
     * 3302-9 : 9.88
     * 3302-10 : 9.88
     * 3303-3311 : 1.988
     * 3303-3312 : 1.988
     * 3303-3313 : 1.988
     * 3303-3314 : 1.988
     * 3303-3315 : 1.988
     * 3303-3316 : 1.988
     * 3303-1 : 9.88
     * 3303-2 : 9.88
     * 3303-3 : 9.88
     * 3303-4 : 9.88
     * 3303-5 : 9.88
     * 3303-6 : 9.88
     * 3303-7 : 9.88
     * 3303-8 : 9.88
     * 3303-9 : 9.88
     * 3303-10 : 9.88
     * 3304-3311 : 1.988
     * 3304-3312 : 1.988
     * 3304-3313 : 1.988
     * 3304-3314 : 1.988
     * 3304-3315 : 1.988
     * 3304-3316 : 1.988
     * 3304-1 : 9.88
     * 3304-2 : 9.88
     * 3304-3 : 9.88
     * 3304-4 : 9.88
     * 3304-5 : 9.88
     * 3304-6 : 9.88
     * 3304-7 : 9.88
     * 3304-8 : 9.88
     * 3304-9 : 9.88
     * 3304-10 : 9.88
     * 3305-3311 : 1.988
     * 3305-3312 : 1.988
     * 3305-3313 : 1.988
     * 3305-3314 : 1.988
     * 3305-3315 : 1.988
     * 3305-3316 : 1.988
     * 3305-1 : 9.88
     * 3305-2 : 9.88
     * 3305-3 : 9.88
     * 3305-4 : 9.88
     * 3305-5 : 9.88
     * 3305-6 : 9.88
     * 3305-7 : 9.88
     * 3305-8 : 9.88
     * 3305-9 : 9.88
     * 3305-10 : 9.88
     * 3306-3311 : 1.988
     * 3306-3312 : 1.988
     * 3306-3313 : 1.988
     * 3306-3314 : 1.988
     * 3306-1 : 9.88
     * 3306-2 : 9.88
     * 3306-3 : 9.88
     * 3306-4 : 9.88
     * 3306-5 : 9.88
     * 3306-6 : 9.88
     * 3306-7 : 9.88
     * 3306-8 : 9.88
     * 3306-9 : 9.88
     * 3306-10 : 9.88
     * 3307-3311 : 1.988
     * 3307-3312 : 1.988
     * 3307-3313 : 1.988
     * 3307-3314 : 1.988
     * 3307-1 : 9.88
     * 3307-2 : 9.88
     * 3307-3 : 9.88
     * 3307-4 : 9.88
     * 3307-5 : 9.88
     * 3307-6 : 9.88
     * 3307-7 : 9.88
     * 3307-8 : 9.88
     * 3307-9 : 9.88
     * 3307-10 : 9.88
     * 3308-3311 : 1.988
     * 3308-3312 : 1.988
     * 3308-3313 : 1.988
     * 3308-3314 : 1.988
     * 3308-1 : 9.88
     * 3308-2 : 9.88
     * 3308-3 : 9.88
     * 3308-4 : 9.88
     * 3308-5 : 9.88
     * 3308-6 : 9.88
     * 3308-7 : 9.88
     * 3308-8 : 9.88
     * 3308-9 : 9.88
     * 3308-10 : 9.88
     * 3309-3311 : 1.988
     * 3309-3312 : 1.988
     * 3309-3313 : 1.988
     * 3309-3314 : 1.988
     * 3309-1 : 9.88
     * 3309-2 : 9.88
     * 3309-3 : 9.88
     * 3309-4 : 9.88
     * 3309-5 : 9.88
     * 3309-6 : 9.88
     * 3309-7 : 9.88
     * 3309-8 : 9.88
     * 3309-9 : 9.88
     * 3309-10 : 9.88
     * 3310-3311 : 1.988
     * 3310-3312 : 1.988
     * 3310-3313 : 1.988
     * 3310-3314 : 1.988
     * 3310-1 : 9.88
     * 3310-2 : 9.88
     * 3310-3 : 9.88
     * 3310-4 : 9.88
     * 3310-5 : 9.88
     * 3310-6 : 9.88
     * 3310-7 : 9.88
     * 3310-8 : 9.88
     * 3310-9 : 9.88
     * 3310-10 : 9.88
     * 3321-3 : 42.5
     * 3321-4 : 42.5
     * 3321-5 : 21.5
     * 3321-6 : 21.5
     * 3321-7 : 14.5
     * 3321-8 : 14.5
     * 3321-9 : 10.5
     * 3321-10 : 10.5
     * 3321-11 : 8.5
     * 3321-12 : 10.5
     * 3321-13 : 10.5
     * 3321-14 : 14.5
     * 3321-15 : 14.5
     * 3321-16 : 21.5
     * 3321-17 : 21.5
     * 3321-18 : 42.5
     * 3321-19 : 42.5
     */

    @SerializedName("3317")
    private String data_3317;
    @SerializedName("3318")
    private String data_3318;
    @SerializedName("3319")
    private String data_3319;
    @SerializedName("3320")
    private String data_3320;
    @SerializedName("3301-3311")
    private String data_33013311;
    @SerializedName("3301-3312")
    private String data_33013312;
    @SerializedName("3301-3313")
    private String data_33013313;
    @SerializedName("3301-3314")
    private String data_33013314;
    @SerializedName("3301-3315")
    private String data_33013315;
    @SerializedName("3301-3316")
    private String data_33013316;
    @SerializedName("3301-1")
    private String data_33011;
    @SerializedName("3301-2")
    private String data_33012;
    @SerializedName("3301-3")
    private String data_33013;
    @SerializedName("3301-4")
    private String data_33014;
    @SerializedName("3301-5")
    private String data_33015;
    @SerializedName("3301-6")
    private String data_33016;
    @SerializedName("3301-7")
    private String data_33017;
    @SerializedName("3301-8")
    private String data_33018;
    @SerializedName("3301-9")
    private String data_33019;
    @SerializedName("3301-10")
    private String data_330110;
    @SerializedName("3302-3311")
    private String data_33023311;
    @SerializedName("3302-3312")
    private String data_33023312;
    @SerializedName("3302-3313")
    private String data_33023313;
    @SerializedName("3302-3314")
    private String data_33023314;
    @SerializedName("3302-3315")
    private String data_33023315;
    @SerializedName("3302-3316")
    private String data_33023316;
    @SerializedName("3302-1")
    private String data_33021;
    @SerializedName("3302-2")
    private String data_33022;
    @SerializedName("3302-3")
    private String data_33023;
    @SerializedName("3302-4")
    private String data_33024;
    @SerializedName("3302-5")
    private String data_33025;
    @SerializedName("3302-6")
    private String data_33026;
    @SerializedName("3302-7")
    private String data_33027;
    @SerializedName("3302-8")
    private String data_33028;
    @SerializedName("3302-9")
    private String data_33029;
    @SerializedName("3302-10")
    private String data_330210;
    @SerializedName("3303-3311")
    private String data_33033311;
    @SerializedName("3303-3312")
    private String data_33033312;
    @SerializedName("3303-3313")
    private String data_33033313;
    @SerializedName("3303-3314")
    private String data_33033314;
    @SerializedName("3303-3315")
    private String data_33033315;
    @SerializedName("3303-3316")
    private String data_33033316;
    @SerializedName("3303-1")
    private String data_33031;
    @SerializedName("3303-2")
    private String data_33032;
    @SerializedName("3303-3")
    private String data_33033;
    @SerializedName("3303-4")
    private String data_33034;
    @SerializedName("3303-5")
    private String data_33035;
    @SerializedName("3303-6")
    private String data_33036;
    @SerializedName("3303-7")
    private String data_33037;
    @SerializedName("3303-8")
    private String data_33038;
    @SerializedName("3303-9")
    private String data_33039;
    @SerializedName("3303-10")
    private String data_330310;
    @SerializedName("3304-3311")
    private String data_33043311;
    @SerializedName("3304-3312")
    private String data_33043312;
    @SerializedName("3304-3313")
    private String data_33043313;
    @SerializedName("3304-3314")
    private String data_33043314;
    @SerializedName("3304-3315")
    private String data_33043315;
    @SerializedName("3304-3316")
    private String data_33043316;
    @SerializedName("3304-1")
    private String data_33041;
    @SerializedName("3304-2")
    private String data_33042;
    @SerializedName("3304-3")
    private String data_33043;
    @SerializedName("3304-4")
    private String data_33044;
    @SerializedName("3304-5")
    private String data_33045;
    @SerializedName("3304-6")
    private String data_33046;
    @SerializedName("3304-7")
    private String data_33047;
    @SerializedName("3304-8")
    private String data_33048;
    @SerializedName("3304-9")
    private String data_33049;
    @SerializedName("3304-10")
    private String data_330410;
    @SerializedName("3305-3311")
    private String data_33053311;
    @SerializedName("3305-3312")
    private String data_33053312;
    @SerializedName("3305-3313")
    private String data_33053313;
    @SerializedName("3305-3314")
    private String data_33053314;
    @SerializedName("3305-3315")
    private String data_33053315;
    @SerializedName("3305-3316")
    private String data_33053316;
    @SerializedName("3305-1")
    private String data_33051;
    @SerializedName("3305-2")
    private String data_33052;
    @SerializedName("3305-3")
    private String data_33053;
    @SerializedName("3305-4")
    private String data_33054;
    @SerializedName("3305-5")
    private String data_33055;
    @SerializedName("3305-6")
    private String data_33056;
    @SerializedName("3305-7")
    private String data_33057;
    @SerializedName("3305-8")
    private String data_33058;
    @SerializedName("3305-9")
    private String data_33059;
    @SerializedName("3305-10")
    private String data_330510;
    @SerializedName("3306-3311")
    private String data_33063311;
    @SerializedName("3306-3312")
    private String data_33063312;
    @SerializedName("3306-3313")
    private String data_33063313;
    @SerializedName("3306-3314")
    private String data_33063314;
    @SerializedName("3306-1")
    private String data_33061;
    @SerializedName("3306-2")
    private String data_33062;
    @SerializedName("3306-3")
    private String data_33063;
    @SerializedName("3306-4")
    private String data_33064;
    @SerializedName("3306-5")
    private String data_33065;
    @SerializedName("3306-6")
    private String data_33066;
    @SerializedName("3306-7")
    private String data_33067;
    @SerializedName("3306-8")
    private String data_33068;
    @SerializedName("3306-9")
    private String data_33069;
    @SerializedName("3306-10")
    private String data_330610;
    @SerializedName("3307-3311")
    private String data_33073311;
    @SerializedName("3307-3312")
    private String data_33073312;
    @SerializedName("3307-3313")
    private String data_33073313;
    @SerializedName("3307-3314")
    private String data_33073314;
    @SerializedName("3307-1")
    private String data_33071;
    @SerializedName("3307-2")
    private String data_33072;
    @SerializedName("3307-3")
    private String data_33073;
    @SerializedName("3307-4")
    private String data_33074;
    @SerializedName("3307-5")
    private String data_33075;
    @SerializedName("3307-6")
    private String data_33076;
    @SerializedName("3307-7")
    private String data_33077;
    @SerializedName("3307-8")
    private String data_33078;
    @SerializedName("3307-9")
    private String data_33079;
    @SerializedName("3307-10")
    private String data_330710;
    @SerializedName("3308-3311")
    private String data_33083311;
    @SerializedName("3308-3312")
    private String data_33083312;
    @SerializedName("3308-3313")
    private String data_33083313;
    @SerializedName("3308-3314")
    private String data_33083314;
    @SerializedName("3308-1")
    private String data_33081;
    @SerializedName("3308-2")
    private String data_33082;
    @SerializedName("3308-3")
    private String data_33083;
    @SerializedName("3308-4")
    private String data_33084;
    @SerializedName("3308-5")
    private String data_33085;
    @SerializedName("3308-6")
    private String data_33086;
    @SerializedName("3308-7")
    private String data_33087;
    @SerializedName("3308-8")
    private String data_33088;
    @SerializedName("3308-9")
    private String data_33089;
    @SerializedName("3308-10")
    private String data_330810;
    @SerializedName("3309-3311")
    private String data_33093311;
    @SerializedName("3309-3312")
    private String data_33093312;
    @SerializedName("3309-3313")
    private String data_33093313;
    @SerializedName("3309-3314")
    private String data_33093314;
    @SerializedName("3309-1")
    private String data_33091;
    @SerializedName("3309-2")
    private String data_33092;
    @SerializedName("3309-3")
    private String data_33093;
    @SerializedName("3309-4")
    private String data_33094;
    @SerializedName("3309-5")
    private String data_33095;
    @SerializedName("3309-6")
    private String data_33096;
    @SerializedName("3309-7")
    private String data_33097;
    @SerializedName("3309-8")
    private String data_33098;
    @SerializedName("3309-9")
    private String data_33099;
    @SerializedName("3309-10")
    private String data_330910;
    @SerializedName("3310-3311")
    private String data_33103311;
    @SerializedName("3310-3312")
    private String data_33103312;
    @SerializedName("3310-3313")
    private String data_33103313;
    @SerializedName("3310-3314")
    private String data_33103314;
    @SerializedName("3310-1")
    private String data_33101;
    @SerializedName("3310-2")
    private String data_33102;
    @SerializedName("3310-3")
    private String data_33103;
    @SerializedName("3310-4")
    private String data_33104;
    @SerializedName("3310-5")
    private String data_33105;
    @SerializedName("3310-6")
    private String data_33106;
    @SerializedName("3310-7")
    private String data_33107;
    @SerializedName("3310-8")
    private String data_33108;
    @SerializedName("3310-9")
    private String data_33109;
    @SerializedName("3310-10")
    private String data_331010;
    @SerializedName("3321-3")
    private String data_33213;
    @SerializedName("3321-4")
    private String data_33214;
    @SerializedName("3321-5")
    private String data_33215;
    @SerializedName("3321-6")
    private String data_33216;
    @SerializedName("3321-7")
    private String data_33217;
    @SerializedName("3321-8")
    private String data_33218;
    @SerializedName("3321-9")
    private String data_33219;
    @SerializedName("3321-10")
    private String data_332110;
    @SerializedName("3321-11")
    private String data_332111;
    @SerializedName("3321-12")
    private String data_332112;
    @SerializedName("3321-13")
    private String data_332113;
    @SerializedName("3321-14")
    private String data_332114;
    @SerializedName("3321-15")
    private String data_332115;
    @SerializedName("3321-16")
    private String data_332116;
    @SerializedName("3321-17")
    private String data_332117;
    @SerializedName("3321-18")
    private String data_332118;
    @SerializedName("3321-19")
    private String data_332119;

    public String getdata_3317() {
        return data_3317;
    }

    public void setdata_3317(String data_3317) {
        this.data_3317 = data_3317;
    }

    public String getdata_3318() {
        return data_3318;
    }

    public void setdata_3318(String data_3318) {
        this.data_3318 = data_3318;
    }

    public String getdata_3319() {
        return data_3319;
    }

    public void setdata_3319(String data_3319) {
        this.data_3319 = data_3319;
    }

    public String getdata_3320() {
        return data_3320;
    }

    public void setdata_3320(String data_3320) {
        this.data_3320 = data_3320;
    }

    public String getdata_33013311() {
        return data_33013311;
    }

    public void setdata_33013311(String data_33013311) {
        this.data_33013311 = data_33013311;
    }

    public String getdata_33013312() {
        return data_33013312;
    }

    public void setdata_33013312(String data_33013312) {
        this.data_33013312 = data_33013312;
    }

    public String getdata_33013313() {
        return data_33013313;
    }

    public void setdata_33013313(String data_33013313) {
        this.data_33013313 = data_33013313;
    }

    public String getdata_33013314() {
        return data_33013314;
    }

    public void setdata_33013314(String data_33013314) {
        this.data_33013314 = data_33013314;
    }

    public String getdata_33013315() {
        return data_33013315;
    }

    public void setdata_33013315(String data_33013315) {
        this.data_33013315 = data_33013315;
    }

    public String getdata_33013316() {
        return data_33013316;
    }

    public void setdata_33013316(String data_33013316) {
        this.data_33013316 = data_33013316;
    }

    public String getdata_33011() {
        return data_33011;
    }

    public void setdata_33011(String data_33011) {
        this.data_33011 = data_33011;
    }

    public String getdata_33012() {
        return data_33012;
    }

    public void setdata_33012(String data_33012) {
        this.data_33012 = data_33012;
    }

    public String getdata_33013() {
        return data_33013;
    }

    public void setdata_33013(String data_33013) {
        this.data_33013 = data_33013;
    }

    public String getdata_33014() {
        return data_33014;
    }

    public void setdata_33014(String data_33014) {
        this.data_33014 = data_33014;
    }

    public String getdata_33015() {
        return data_33015;
    }

    public void setdata_33015(String data_33015) {
        this.data_33015 = data_33015;
    }

    public String getdata_33016() {
        return data_33016;
    }

    public void setdata_33016(String data_33016) {
        this.data_33016 = data_33016;
    }

    public String getdata_33017() {
        return data_33017;
    }

    public void setdata_33017(String data_33017) {
        this.data_33017 = data_33017;
    }

    public String getdata_33018() {
        return data_33018;
    }

    public void setdata_33018(String data_33018) {
        this.data_33018 = data_33018;
    }

    public String getdata_33019() {
        return data_33019;
    }

    public void setdata_33019(String data_33019) {
        this.data_33019 = data_33019;
    }

    public String getdata_330110() {
        return data_330110;
    }

    public void setdata_330110(String data_330110) {
        this.data_330110 = data_330110;
    }

    public String getdata_33023311() {
        return data_33023311;
    }

    public void setdata_33023311(String data_33023311) {
        this.data_33023311 = data_33023311;
    }

    public String getdata_33023312() {
        return data_33023312;
    }

    public void setdata_33023312(String data_33023312) {
        this.data_33023312 = data_33023312;
    }

    public String getdata_33023313() {
        return data_33023313;
    }

    public void setdata_33023313(String data_33023313) {
        this.data_33023313 = data_33023313;
    }

    public String getdata_33023314() {
        return data_33023314;
    }

    public void setdata_33023314(String data_33023314) {
        this.data_33023314 = data_33023314;
    }

    public String getdata_33023315() {
        return data_33023315;
    }

    public void setdata_33023315(String data_33023315) {
        this.data_33023315 = data_33023315;
    }

    public String getdata_33023316() {
        return data_33023316;
    }

    public void setdata_33023316(String data_33023316) {
        this.data_33023316 = data_33023316;
    }

    public String getdata_33021() {
        return data_33021;
    }

    public void setdata_33021(String data_33021) {
        this.data_33021 = data_33021;
    }

    public String getdata_33022() {
        return data_33022;
    }

    public void setdata_33022(String data_33022) {
        this.data_33022 = data_33022;
    }

    public String getdata_33023() {
        return data_33023;
    }

    public void setdata_33023(String data_33023) {
        this.data_33023 = data_33023;
    }

    public String getdata_33024() {
        return data_33024;
    }

    public void setdata_33024(String data_33024) {
        this.data_33024 = data_33024;
    }

    public String getdata_33025() {
        return data_33025;
    }

    public void setdata_33025(String data_33025) {
        this.data_33025 = data_33025;
    }

    public String getdata_33026() {
        return data_33026;
    }

    public void setdata_33026(String data_33026) {
        this.data_33026 = data_33026;
    }

    public String getdata_33027() {
        return data_33027;
    }

    public void setdata_33027(String data_33027) {
        this.data_33027 = data_33027;
    }

    public String getdata_33028() {
        return data_33028;
    }

    public void setdata_33028(String data_33028) {
        this.data_33028 = data_33028;
    }

    public String getdata_33029() {
        return data_33029;
    }

    public void setdata_33029(String data_33029) {
        this.data_33029 = data_33029;
    }

    public String getdata_330210() {
        return data_330210;
    }

    public void setdata_330210(String data_330210) {
        this.data_330210 = data_330210;
    }

    public String getdata_33033311() {
        return data_33033311;
    }

    public void setdata_33033311(String data_33033311) {
        this.data_33033311 = data_33033311;
    }

    public String getdata_33033312() {
        return data_33033312;
    }

    public void setdata_33033312(String data_33033312) {
        this.data_33033312 = data_33033312;
    }

    public String getdata_33033313() {
        return data_33033313;
    }

    public void setdata_33033313(String data_33033313) {
        this.data_33033313 = data_33033313;
    }

    public String getdata_33033314() {
        return data_33033314;
    }

    public void setdata_33033314(String data_33033314) {
        this.data_33033314 = data_33033314;
    }

    public String getdata_33033315() {
        return data_33033315;
    }

    public void setdata_33033315(String data_33033315) {
        this.data_33033315 = data_33033315;
    }

    public String getdata_33033316() {
        return data_33033316;
    }

    public void setdata_33033316(String data_33033316) {
        this.data_33033316 = data_33033316;
    }

    public String getdata_33031() {
        return data_33031;
    }

    public void setdata_33031(String data_33031) {
        this.data_33031 = data_33031;
    }

    public String getdata_33032() {
        return data_33032;
    }

    public void setdata_33032(String data_33032) {
        this.data_33032 = data_33032;
    }

    public String getdata_33033() {
        return data_33033;
    }

    public void setdata_33033(String data_33033) {
        this.data_33033 = data_33033;
    }

    public String getdata_33034() {
        return data_33034;
    }

    public void setdata_33034(String data_33034) {
        this.data_33034 = data_33034;
    }

    public String getdata_33035() {
        return data_33035;
    }

    public void setdata_33035(String data_33035) {
        this.data_33035 = data_33035;
    }

    public String getdata_33036() {
        return data_33036;
    }

    public void setdata_33036(String data_33036) {
        this.data_33036 = data_33036;
    }

    public String getdata_33037() {
        return data_33037;
    }

    public void setdata_33037(String data_33037) {
        this.data_33037 = data_33037;
    }

    public String getdata_33038() {
        return data_33038;
    }

    public void setdata_33038(String data_33038) {
        this.data_33038 = data_33038;
    }

    public String getdata_33039() {
        return data_33039;
    }

    public void setdata_33039(String data_33039) {
        this.data_33039 = data_33039;
    }

    public String getdata_330310() {
        return data_330310;
    }

    public void setdata_330310(String data_330310) {
        this.data_330310 = data_330310;
    }

    public String getdata_33043311() {
        return data_33043311;
    }

    public void setdata_33043311(String data_33043311) {
        this.data_33043311 = data_33043311;
    }

    public String getdata_33043312() {
        return data_33043312;
    }

    public void setdata_33043312(String data_33043312) {
        this.data_33043312 = data_33043312;
    }

    public String getdata_33043313() {
        return data_33043313;
    }

    public void setdata_33043313(String data_33043313) {
        this.data_33043313 = data_33043313;
    }

    public String getdata_33043314() {
        return data_33043314;
    }

    public void setdata_33043314(String data_33043314) {
        this.data_33043314 = data_33043314;
    }

    public String getdata_33043315() {
        return data_33043315;
    }

    public void setdata_33043315(String data_33043315) {
        this.data_33043315 = data_33043315;
    }

    public String getdata_33043316() {
        return data_33043316;
    }

    public void setdata_33043316(String data_33043316) {
        this.data_33043316 = data_33043316;
    }

    public String getdata_33041() {
        return data_33041;
    }

    public void setdata_33041(String data_33041) {
        this.data_33041 = data_33041;
    }

    public String getdata_33042() {
        return data_33042;
    }

    public void setdata_33042(String data_33042) {
        this.data_33042 = data_33042;
    }

    public String getdata_33043() {
        return data_33043;
    }

    public void setdata_33043(String data_33043) {
        this.data_33043 = data_33043;
    }

    public String getdata_33044() {
        return data_33044;
    }

    public void setdata_33044(String data_33044) {
        this.data_33044 = data_33044;
    }

    public String getdata_33045() {
        return data_33045;
    }

    public void setdata_33045(String data_33045) {
        this.data_33045 = data_33045;
    }

    public String getdata_33046() {
        return data_33046;
    }

    public void setdata_33046(String data_33046) {
        this.data_33046 = data_33046;
    }

    public String getdata_33047() {
        return data_33047;
    }

    public void setdata_33047(String data_33047) {
        this.data_33047 = data_33047;
    }

    public String getdata_33048() {
        return data_33048;
    }

    public void setdata_33048(String data_33048) {
        this.data_33048 = data_33048;
    }

    public String getdata_33049() {
        return data_33049;
    }

    public void setdata_33049(String data_33049) {
        this.data_33049 = data_33049;
    }

    public String getdata_330410() {
        return data_330410;
    }

    public void setdata_330410(String data_330410) {
        this.data_330410 = data_330410;
    }

    public String getdata_33053311() {
        return data_33053311;
    }

    public void setdata_33053311(String data_33053311) {
        this.data_33053311 = data_33053311;
    }

    public String getdata_33053312() {
        return data_33053312;
    }

    public void setdata_33053312(String data_33053312) {
        this.data_33053312 = data_33053312;
    }

    public String getdata_33053313() {
        return data_33053313;
    }

    public void setdata_33053313(String data_33053313) {
        this.data_33053313 = data_33053313;
    }

    public String getdata_33053314() {
        return data_33053314;
    }

    public void setdata_33053314(String data_33053314) {
        this.data_33053314 = data_33053314;
    }

    public String getdata_33053315() {
        return data_33053315;
    }

    public void setdata_33053315(String data_33053315) {
        this.data_33053315 = data_33053315;
    }

    public String getdata_33053316() {
        return data_33053316;
    }

    public void setdata_33053316(String data_33053316) {
        this.data_33053316 = data_33053316;
    }

    public String getdata_33051() {
        return data_33051;
    }

    public void setdata_33051(String data_33051) {
        this.data_33051 = data_33051;
    }

    public String getdata_33052() {
        return data_33052;
    }

    public void setdata_33052(String data_33052) {
        this.data_33052 = data_33052;
    }

    public String getdata_33053() {
        return data_33053;
    }

    public void setdata_33053(String data_33053) {
        this.data_33053 = data_33053;
    }

    public String getdata_33054() {
        return data_33054;
    }

    public void setdata_33054(String data_33054) {
        this.data_33054 = data_33054;
    }

    public String getdata_33055() {
        return data_33055;
    }

    public void setdata_33055(String data_33055) {
        this.data_33055 = data_33055;
    }

    public String getdata_33056() {
        return data_33056;
    }

    public void setdata_33056(String data_33056) {
        this.data_33056 = data_33056;
    }

    public String getdata_33057() {
        return data_33057;
    }

    public void setdata_33057(String data_33057) {
        this.data_33057 = data_33057;
    }

    public String getdata_33058() {
        return data_33058;
    }

    public void setdata_33058(String data_33058) {
        this.data_33058 = data_33058;
    }

    public String getdata_33059() {
        return data_33059;
    }

    public void setdata_33059(String data_33059) {
        this.data_33059 = data_33059;
    }

    public String getdata_330510() {
        return data_330510;
    }

    public void setdata_330510(String data_330510) {
        this.data_330510 = data_330510;
    }

    public String getdata_33063311() {
        return data_33063311;
    }

    public void setdata_33063311(String data_33063311) {
        this.data_33063311 = data_33063311;
    }

    public String getdata_33063312() {
        return data_33063312;
    }

    public void setdata_33063312(String data_33063312) {
        this.data_33063312 = data_33063312;
    }

    public String getdata_33063313() {
        return data_33063313;
    }

    public void setdata_33063313(String data_33063313) {
        this.data_33063313 = data_33063313;
    }

    public String getdata_33063314() {
        return data_33063314;
    }

    public void setdata_33063314(String data_33063314) {
        this.data_33063314 = data_33063314;
    }

    public String getdata_33061() {
        return data_33061;
    }

    public void setdata_33061(String data_33061) {
        this.data_33061 = data_33061;
    }

    public String getdata_33062() {
        return data_33062;
    }

    public void setdata_33062(String data_33062) {
        this.data_33062 = data_33062;
    }

    public String getdata_33063() {
        return data_33063;
    }

    public void setdata_33063(String data_33063) {
        this.data_33063 = data_33063;
    }

    public String getdata_33064() {
        return data_33064;
    }

    public void setdata_33064(String data_33064) {
        this.data_33064 = data_33064;
    }

    public String getdata_33065() {
        return data_33065;
    }

    public void setdata_33065(String data_33065) {
        this.data_33065 = data_33065;
    }

    public String getdata_33066() {
        return data_33066;
    }

    public void setdata_33066(String data_33066) {
        this.data_33066 = data_33066;
    }

    public String getdata_33067() {
        return data_33067;
    }

    public void setdata_33067(String data_33067) {
        this.data_33067 = data_33067;
    }

    public String getdata_33068() {
        return data_33068;
    }

    public void setdata_33068(String data_33068) {
        this.data_33068 = data_33068;
    }

    public String getdata_33069() {
        return data_33069;
    }

    public void setdata_33069(String data_33069) {
        this.data_33069 = data_33069;
    }

    public String getdata_330610() {
        return data_330610;
    }

    public void setdata_330610(String data_330610) {
        this.data_330610 = data_330610;
    }

    public String getdata_33073311() {
        return data_33073311;
    }

    public void setdata_33073311(String data_33073311) {
        this.data_33073311 = data_33073311;
    }

    public String getdata_33073312() {
        return data_33073312;
    }

    public void setdata_33073312(String data_33073312) {
        this.data_33073312 = data_33073312;
    }

    public String getdata_33073313() {
        return data_33073313;
    }

    public void setdata_33073313(String data_33073313) {
        this.data_33073313 = data_33073313;
    }

    public String getdata_33073314() {
        return data_33073314;
    }

    public void setdata_33073314(String data_33073314) {
        this.data_33073314 = data_33073314;
    }

    public String getdata_33071() {
        return data_33071;
    }

    public void setdata_33071(String data_33071) {
        this.data_33071 = data_33071;
    }

    public String getdata_33072() {
        return data_33072;
    }

    public void setdata_33072(String data_33072) {
        this.data_33072 = data_33072;
    }

    public String getdata_33073() {
        return data_33073;
    }

    public void setdata_33073(String data_33073) {
        this.data_33073 = data_33073;
    }

    public String getdata_33074() {
        return data_33074;
    }

    public void setdata_33074(String data_33074) {
        this.data_33074 = data_33074;
    }

    public String getdata_33075() {
        return data_33075;
    }

    public void setdata_33075(String data_33075) {
        this.data_33075 = data_33075;
    }

    public String getdata_33076() {
        return data_33076;
    }

    public void setdata_33076(String data_33076) {
        this.data_33076 = data_33076;
    }

    public String getdata_33077() {
        return data_33077;
    }

    public void setdata_33077(String data_33077) {
        this.data_33077 = data_33077;
    }

    public String getdata_33078() {
        return data_33078;
    }

    public void setdata_33078(String data_33078) {
        this.data_33078 = data_33078;
    }

    public String getdata_33079() {
        return data_33079;
    }

    public void setdata_33079(String data_33079) {
        this.data_33079 = data_33079;
    }

    public String getdata_330710() {
        return data_330710;
    }

    public void setdata_330710(String data_330710) {
        this.data_330710 = data_330710;
    }

    public String getdata_33083311() {
        return data_33083311;
    }

    public void setdata_33083311(String data_33083311) {
        this.data_33083311 = data_33083311;
    }

    public String getdata_33083312() {
        return data_33083312;
    }

    public void setdata_33083312(String data_33083312) {
        this.data_33083312 = data_33083312;
    }

    public String getdata_33083313() {
        return data_33083313;
    }

    public void setdata_33083313(String data_33083313) {
        this.data_33083313 = data_33083313;
    }

    public String getdata_33083314() {
        return data_33083314;
    }

    public void setdata_33083314(String data_33083314) {
        this.data_33083314 = data_33083314;
    }

    public String getdata_33081() {
        return data_33081;
    }

    public void setdata_33081(String data_33081) {
        this.data_33081 = data_33081;
    }

    public String getdata_33082() {
        return data_33082;
    }

    public void setdata_33082(String data_33082) {
        this.data_33082 = data_33082;
    }

    public String getdata_33083() {
        return data_33083;
    }

    public void setdata_33083(String data_33083) {
        this.data_33083 = data_33083;
    }

    public String getdata_33084() {
        return data_33084;
    }

    public void setdata_33084(String data_33084) {
        this.data_33084 = data_33084;
    }

    public String getdata_33085() {
        return data_33085;
    }

    public void setdata_33085(String data_33085) {
        this.data_33085 = data_33085;
    }

    public String getdata_33086() {
        return data_33086;
    }

    public void setdata_33086(String data_33086) {
        this.data_33086 = data_33086;
    }

    public String getdata_33087() {
        return data_33087;
    }

    public void setdata_33087(String data_33087) {
        this.data_33087 = data_33087;
    }

    public String getdata_33088() {
        return data_33088;
    }

    public void setdata_33088(String data_33088) {
        this.data_33088 = data_33088;
    }

    public String getdata_33089() {
        return data_33089;
    }

    public void setdata_33089(String data_33089) {
        this.data_33089 = data_33089;
    }

    public String getdata_330810() {
        return data_330810;
    }

    public void setdata_330810(String data_330810) {
        this.data_330810 = data_330810;
    }

    public String getdata_33093311() {
        return data_33093311;
    }

    public void setdata_33093311(String data_33093311) {
        this.data_33093311 = data_33093311;
    }

    public String getdata_33093312() {
        return data_33093312;
    }

    public void setdata_33093312(String data_33093312) {
        this.data_33093312 = data_33093312;
    }

    public String getdata_33093313() {
        return data_33093313;
    }

    public void setdata_33093313(String data_33093313) {
        this.data_33093313 = data_33093313;
    }

    public String getdata_33093314() {
        return data_33093314;
    }

    public void setdata_33093314(String data_33093314) {
        this.data_33093314 = data_33093314;
    }

    public String getdata_33091() {
        return data_33091;
    }

    public void setdata_33091(String data_33091) {
        this.data_33091 = data_33091;
    }

    public String getdata_33092() {
        return data_33092;
    }

    public void setdata_33092(String data_33092) {
        this.data_33092 = data_33092;
    }

    public String getdata_33093() {
        return data_33093;
    }

    public void setdata_33093(String data_33093) {
        this.data_33093 = data_33093;
    }

    public String getdata_33094() {
        return data_33094;
    }

    public void setdata_33094(String data_33094) {
        this.data_33094 = data_33094;
    }

    public String getdata_33095() {
        return data_33095;
    }

    public void setdata_33095(String data_33095) {
        this.data_33095 = data_33095;
    }

    public String getdata_33096() {
        return data_33096;
    }

    public void setdata_33096(String data_33096) {
        this.data_33096 = data_33096;
    }

    public String getdata_33097() {
        return data_33097;
    }

    public void setdata_33097(String data_33097) {
        this.data_33097 = data_33097;
    }

    public String getdata_33098() {
        return data_33098;
    }

    public void setdata_33098(String data_33098) {
        this.data_33098 = data_33098;
    }

    public String getdata_33099() {
        return data_33099;
    }

    public void setdata_33099(String data_33099) {
        this.data_33099 = data_33099;
    }

    public String getdata_330910() {
        return data_330910;
    }

    public void setdata_330910(String data_330910) {
        this.data_330910 = data_330910;
    }

    public String getdata_33103311() {
        return data_33103311;
    }

    public void setdata_33103311(String data_33103311) {
        this.data_33103311 = data_33103311;
    }

    public String getdata_33103312() {
        return data_33103312;
    }

    public void setdata_33103312(String data_33103312) {
        this.data_33103312 = data_33103312;
    }

    public String getdata_33103313() {
        return data_33103313;
    }

    public void setdata_33103313(String data_33103313) {
        this.data_33103313 = data_33103313;
    }

    public String getdata_33103314() {
        return data_33103314;
    }

    public void setdata_33103314(String data_33103314) {
        this.data_33103314 = data_33103314;
    }

    public String getdata_33101() {
        return data_33101;
    }

    public void setdata_33101(String data_33101) {
        this.data_33101 = data_33101;
    }

    public String getdata_33102() {
        return data_33102;
    }

    public void setdata_33102(String data_33102) {
        this.data_33102 = data_33102;
    }

    public String getdata_33103() {
        return data_33103;
    }

    public void setdata_33103(String data_33103) {
        this.data_33103 = data_33103;
    }

    public String getdata_33104() {
        return data_33104;
    }

    public void setdata_33104(String data_33104) {
        this.data_33104 = data_33104;
    }

    public String getdata_33105() {
        return data_33105;
    }

    public void setdata_33105(String data_33105) {
        this.data_33105 = data_33105;
    }

    public String getdata_33106() {
        return data_33106;
    }

    public void setdata_33106(String data_33106) {
        this.data_33106 = data_33106;
    }

    public String getdata_33107() {
        return data_33107;
    }

    public void setdata_33107(String data_33107) {
        this.data_33107 = data_33107;
    }

    public String getdata_33108() {
        return data_33108;
    }

    public void setdata_33108(String data_33108) {
        this.data_33108 = data_33108;
    }

    public String getdata_33109() {
        return data_33109;
    }

    public void setdata_33109(String data_33109) {
        this.data_33109 = data_33109;
    }

    public String getdata_331010() {
        return data_331010;
    }

    public void setdata_331010(String data_331010) {
        this.data_331010 = data_331010;
    }

    public String getdata_33213() {
        return data_33213;
    }

    public void setdata_33213(String data_33213) {
        this.data_33213 = data_33213;
    }

    public String getdata_33214() {
        return data_33214;
    }

    public void setdata_33214(String data_33214) {
        this.data_33214 = data_33214;
    }

    public String getdata_33215() {
        return data_33215;
    }

    public void setdata_33215(String data_33215) {
        this.data_33215 = data_33215;
    }

    public String getdata_33216() {
        return data_33216;
    }

    public void setdata_33216(String data_33216) {
        this.data_33216 = data_33216;
    }

    public String getdata_33217() {
        return data_33217;
    }

    public void setdata_33217(String data_33217) {
        this.data_33217 = data_33217;
    }

    public String getdata_33218() {
        return data_33218;
    }

    public void setdata_33218(String data_33218) {
        this.data_33218 = data_33218;
    }

    public String getdata_33219() {
        return data_33219;
    }

    public void setdata_33219(String data_33219) {
        this.data_33219 = data_33219;
    }

    public String getdata_332110() {
        return data_332110;
    }

    public void setdata_332110(String data_332110) {
        this.data_332110 = data_332110;
    }

    public String getdata_332111() {
        return data_332111;
    }

    public void setdata_332111(String data_332111) {
        this.data_332111 = data_332111;
    }

    public String getdata_332112() {
        return data_332112;
    }

    public void setdata_332112(String data_332112) {
        this.data_332112 = data_332112;
    }

    public String getdata_332113() {
        return data_332113;
    }

    public void setdata_332113(String data_332113) {
        this.data_332113 = data_332113;
    }

    public String getdata_332114() {
        return data_332114;
    }

    public void setdata_332114(String data_332114) {
        this.data_332114 = data_332114;
    }

    public String getdata_332115() {
        return data_332115;
    }

    public void setdata_332115(String data_332115) {
        this.data_332115 = data_332115;
    }

    public String getdata_332116() {
        return data_332116;
    }

    public void setdata_332116(String data_332116) {
        this.data_332116 = data_332116;
    }

    public String getdata_332117() {
        return data_332117;
    }

    public void setdata_332117(String data_332117) {
        this.data_332117 = data_332117;
    }

    public String getdata_332118() {
        return data_332118;
    }

    public void setdata_332118(String data_332118) {
        this.data_332118 = data_332118;
    }

    public String getdata_332119() {
        return data_332119;
    }

    public void setdata_332119(String data_332119) {
        this.data_332119 = data_332119;
    }
}
