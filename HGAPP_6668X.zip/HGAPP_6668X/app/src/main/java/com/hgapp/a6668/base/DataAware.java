package com.hgapp.a6668.base;

/**
 * Created by Daniel on 2017/4/21.
 */

public interface DataAware<F> {

    public void setData(F data1);
}
