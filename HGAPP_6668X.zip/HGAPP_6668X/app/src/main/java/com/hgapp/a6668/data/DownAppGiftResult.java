package com.hgapp.a6668.data;

public class DownAppGiftResult {
    /**
     * data_gold : 38
     */

    private int data_gold;

    public int getData_gold() {
        return data_gold;
    }

    public void setData_gold(int data_gold) {
        this.data_gold = data_gold;
    }
}
