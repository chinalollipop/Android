package com.hgapp.a6668.data;

public class CPLastResult {

    /**
     * gameId : 2
     * issue : 20181126-076
     * nums : 8,6,9,1,4
     */

    private int gameId;
    private String issue;
    private String nums;

    public int getGameId() {
        return gameId;
    }

    public void setGameId(int gameId) {
        this.gameId = gameId;
    }

    public String getIssue() {
        return issue;
    }

    public void setIssue(String issue) {
        this.issue = issue;
    }

    public String getNums() {
        return nums;
    }

    public void setNums(String nums) {
        this.nums = nums;
    }
}
