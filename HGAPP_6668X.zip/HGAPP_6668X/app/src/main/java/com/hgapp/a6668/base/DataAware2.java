package com.hgapp.a6668.base;

/**
 * Created by Daniel on 2017/5/18.
 */

public interface DataAware2<F,S> extends DataAware<F> {

    public void setData2(S data2);
}
