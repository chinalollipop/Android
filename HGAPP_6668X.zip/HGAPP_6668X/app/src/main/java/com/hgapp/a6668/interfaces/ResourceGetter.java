package com.hgapp.a6668.interfaces;

import android.support.annotation.StringRes;

/**
 * Created by Nereus on 2017/5/16.
 */

public interface ResourceGetter {
    public String getString(@StringRes int resid);
}
