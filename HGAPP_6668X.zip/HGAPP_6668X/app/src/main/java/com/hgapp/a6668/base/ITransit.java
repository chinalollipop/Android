package com.hgapp.a6668.base;

/**
 * Created by Daniel on 2017/5/31.
 */

public interface ITransit {

    public void transit(HGBaseFragment originFragment,HGBaseFragment destFragment);
}
