package com.hgapp.a6668.base;

import android.support.v4.app.FragmentManager;

import java.util.ArrayList;

import me.yokeyword.fragmentation.SupportFragment;

/**
 * Created by YoKeyword on 16/2/3.
 */
public class BaseFragment extends SupportFragment {
    /*private ArrayList<FragmentManager.FragmentLifecycleCallbacks> mFragmentLifecycleCallbacks;
    private LifecycleHelper mLifecycleHelper;
    public void registerFragmentLifecycleCallbacks(FragmentManager.FragmentLifecycleCallbacks callback) {
        synchronized (this) {
            if (mFragmentLifecycleCallbacks == null) {
                mFragmentLifecycleCallbacks = new ArrayList<>();
                mLifecycleHelper = new LifecycleHelper(mFragmentLifecycleCallbacks);
            }
            mFragmentLifecycleCallbacks.add(callback);
        }
    }

    public void unregisterFragmentLifecycleCallbacks(FragmentManager.FragmentLifecycleCallbacks callback) {
        synchronized (this) {
            if (mFragmentLifecycleCallbacks != null) {
                mFragmentLifecycleCallbacks.remove(callback);
            }
        }
    }*/

    @Override
    public void onSupportVisible() {
        super.onSupportVisible();
        onVisible();
    }

    public void  onVisible(){

    }
}
