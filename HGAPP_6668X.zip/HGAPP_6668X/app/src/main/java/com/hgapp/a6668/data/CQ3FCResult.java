package com.hgapp.a6668.data;

import com.google.gson.annotations.SerializedName;

public class CQ3FCResult {

    /**
     * 0 : 9.68
     * 1 : 9.68
     * 2 : 9.68
     * 3 : 9.68
     * 4 : 9.68
     * 5 : 9.68
     * 6 : 9.68
     * 7 : 9.68
     * 8 : 9.68
     * 9 : 9.68
     * 1205 : 1.968
     * 1206 : 1.968
     * 1207 : 1.968
     * 1208 : 1.968
     * 1209 : 1.968
     * 1210 : 1.968
     * 1211 : 1.968
     * 1212 : 1.968
     * 1213 : 1.968
     * 1214 : 1.968
     * 1215 : 9
     * 1216 : 75
     * 1217 : 14.5
     * 1218 : 3.3
     * 1219 : 2.5
     * 1220 : 3
     * 1221 : 75
     * 1222 : 14.5
     * 1223 : 3.3
     * 1224 : 2.5
     * 1225 : 3
     * 1226 : 75
     * 1227 : 14.5
     * 1228 : 3.3
     * 1229 : 2.5
     * 1230 : 3
     * 1200-0 : 9.68
     * 1200-1 : 9.68
     * 1200-2 : 9.68
     * 1200-3 : 9.68
     * 1200-4 : 9.68
     * 1200-5 : 9.68
     * 1200-6 : 9.68
     * 1200-7 : 9.68
     * 1200-8 : 9.68
     * 1200-9 : 9.68
     * 1201-0 : 9.68
     * 1201-1 : 9.68
     * 1201-2 : 9.68
     * 1201-3 : 9.68
     * 1201-4 : 9.68
     * 1201-5 : 9.68
     * 1201-6 : 9.68
     * 1201-7 : 9.68
     * 1201-8 : 9.68
     * 1201-9 : 9.68
     * 1202-0 : 9.68
     * 1202-1 : 9.68
     * 1202-2 : 9.68
     * 1202-3 : 9.68
     * 1202-4 : 9.68
     * 1202-5 : 9.68
     * 1202-6 : 9.68
     * 1202-7 : 9.68
     * 1202-8 : 9.68
     * 1202-9 : 9.68
     * 1203-0 : 9.68
     * 1203-1 : 9.68
     * 1203-2 : 9.68
     * 1203-3 : 9.68
     * 1203-4 : 9.68
     * 1203-5 : 9.68
     * 1203-6 : 9.68
     * 1203-7 : 9.68
     * 1203-8 : 9.68
     * 1203-9 : 9.68
     * 1204-0 : 9.68
     * 1204-1 : 9.68
     * 1204-2 : 9.68
     * 1204-3 : 9.68
     * 1204-4 : 9.68
     * 1204-5 : 9.68
     * 1204-6 : 9.68
     * 1204-7 : 9.68
     * 1204-8 : 9.68
     * 1204-9 : 9.68
     * 1-1205 : 1.968
     * 1-1206 : 1.968
     * 1-1207 : 1.968
     * 1-1208 : 1.968
     * 2-1205 : 1.968
     * 2-1206 : 1.968
     * 2-1207 : 1.968
     * 2-1208 : 1.968
     * 3-1205 : 1.968
     * 3-1206 : 1.968
     * 3-1207 : 1.968
     * 3-1208 : 1.968
     * 4-1205 : 1.968
     * 4-1206 : 1.968
     * 4-1207 : 1.968
     * 4-1208 : 1.968
     * 5-1205 : 1.968
     * 5-1206 : 1.968
     * 5-1207 : 1.968
     * 5-1208 : 1.968
     */

    @SerializedName("0")
    private String data0;
    @SerializedName("1")
    private String data1;
    @SerializedName("2")
    private String data2;
    @SerializedName("3")
    private String data3;
    @SerializedName("4")
    private String data4;
    @SerializedName("5")
    private String data5;
    @SerializedName("6")
    private String data6;
    @SerializedName("7")
    private String data7;
    @SerializedName("8")
    private String data8;
    @SerializedName("9")
    private String data9;
    @SerializedName("1205")
    private String data1205;
    @SerializedName("1206")
    private String data1206;
    @SerializedName("1207")
    private String data1207;
    @SerializedName("1208")
    private String data1208;
    @SerializedName("1209")
    private String data1209;
    @SerializedName("1210")
    private String data1210;
    @SerializedName("1211")
    private String data1211;
    @SerializedName("1212")
    private String data1212;
    @SerializedName("1213")
    private String data1213;
    @SerializedName("1214")
    private String data1214;
    @SerializedName("1215")
    private String data1215;
    @SerializedName("1216")
    private String data1216;
    @SerializedName("1217")
    private String data1217;
    @SerializedName("1218")
    private String data1218;
    @SerializedName("1219")
    private String data1219;
    @SerializedName("1220")
    private String data1220;
    @SerializedName("1221")
    private String data1221;
    @SerializedName("1222")
    private String data1222;
    @SerializedName("1223")
    private String data1223;
    @SerializedName("1224")
    private String data1224;
    @SerializedName("1225")
    private String data1225;
    @SerializedName("1226")
    private String data1226;
    @SerializedName("1227")
    private String data1227;
    @SerializedName("1228")
    private String data1228;
    @SerializedName("1229")
    private String data1229;
    @SerializedName("1230")
    private String data1230;
    @SerializedName("1200-0")
    private String data12000;
    @SerializedName("1200-1")
    private String data12001;
    @SerializedName("1200-2")
    private String data12002;
    @SerializedName("1200-3")
    private String data12003;
    @SerializedName("1200-4")
    private String data12004;
    @SerializedName("1200-5")
    private String data12005;
    @SerializedName("1200-6")
    private String data12006;
    @SerializedName("1200-7")
    private String data12007;
    @SerializedName("1200-8")
    private String data12008;
    @SerializedName("1200-9")
    private String data12009;
    @SerializedName("1201-0")
    private String data12010;
    @SerializedName("1201-1")
    private String data12011;
    @SerializedName("1201-2")
    private String data12012;
    @SerializedName("1201-3")
    private String data12013;
    @SerializedName("1201-4")
    private String data12014;
    @SerializedName("1201-5")
    private String data12015;
    @SerializedName("1201-6")
    private String data12016;
    @SerializedName("1201-7")
    private String data12017;
    @SerializedName("1201-8")
    private String data12018;
    @SerializedName("1201-9")
    private String data12019;
    @SerializedName("1202-0")
    private String data12020;
    @SerializedName("1202-1")
    private String data12021;
    @SerializedName("1202-2")
    private String data12022;
    @SerializedName("1202-3")
    private String data12023;
    @SerializedName("1202-4")
    private String data12024;
    @SerializedName("1202-5")
    private String data12025;
    @SerializedName("1202-6")
    private String data12026;
    @SerializedName("1202-7")
    private String data12027;
    @SerializedName("1202-8")
    private String data12028;
    @SerializedName("1202-9")
    private String data12029;
    @SerializedName("1203-0")
    private String data12030;
    @SerializedName("1203-1")
    private String data12031;
    @SerializedName("1203-2")
    private String data12032;
    @SerializedName("1203-3")
    private String data12033;
    @SerializedName("1203-4")
    private String data12034;
    @SerializedName("1203-5")
    private String data12035;
    @SerializedName("1203-6")
    private String data12036;
    @SerializedName("1203-7")
    private String data12037;
    @SerializedName("1203-8")
    private String data12038;
    @SerializedName("1203-9")
    private String data12039;
    @SerializedName("1204-0")
    private String data12040;
    @SerializedName("1204-1")
    private String data12041;
    @SerializedName("1204-2")
    private String data12042;
    @SerializedName("1204-3")
    private String data12043;
    @SerializedName("1204-4")
    private String data12044;
    @SerializedName("1204-5")
    private String data12045;
    @SerializedName("1204-6")
    private String data12046;
    @SerializedName("1204-7")
    private String data12047;
    @SerializedName("1204-8")
    private String data12048;
    @SerializedName("1204-9")
    private String data12049;
    @SerializedName("1-1205")
    private String data11205;
    @SerializedName("1-1206")
    private String data11206;
    @SerializedName("1-1207")
    private String data11207;
    @SerializedName("1-1208")
    private String data11208;
    @SerializedName("2-1205")
    private String data21205;
    @SerializedName("2-1206")
    private String data21206;
    @SerializedName("2-1207")
    private String data21207;
    @SerializedName("2-1208")
    private String data21208;
    @SerializedName("3-1205")
    private String data31205;
    @SerializedName("3-1206")
    private String data31206;
    @SerializedName("3-1207")
    private String data31207;
    @SerializedName("3-1208")
    private String data31208;
    @SerializedName("4-1205")
    private String data41205;
    @SerializedName("4-1206")
    private String data41206;
    @SerializedName("4-1207")
    private String data41207;
    @SerializedName("4-1208")
    private String data41208;
    @SerializedName("5-1205")
    private String data51205;
    @SerializedName("5-1206")
    private String data51206;
    @SerializedName("5-1207")
    private String data51207;
    @SerializedName("5-1208")
    private String data51208;

    public String getdata0() {
        return data0;
    }

    public void setdata0(String data0) {
        this.data0 = data0;
    }

    public String getdata1() {
        return data1;
    }

    public void setdata1(String data1) {
        this.data1 = data1;
    }

    public String getdata2() {
        return data2;
    }

    public void setdata2(String data2) {
        this.data2 = data2;
    }

    public String getdata3() {
        return data3;
    }

    public void setdata3(String data3) {
        this.data3 = data3;
    }

    public String getdata4() {
        return data4;
    }

    public void setdata4(String data4) {
        this.data4 = data4;
    }

    public String getdata5() {
        return data5;
    }

    public void setdata5(String data5) {
        this.data5 = data5;
    }

    public String getdata6() {
        return data6;
    }

    public void setdata6(String data6) {
        this.data6 = data6;
    }

    public String getdata7() {
        return data7;
    }

    public void setdata7(String data7) {
        this.data7 = data7;
    }

    public String getdata8() {
        return data8;
    }

    public void setdata8(String data8) {
        this.data8 = data8;
    }

    public String getdata9() {
        return data9;
    }

    public void setdata9(String data9) {
        this.data9 = data9;
    }

    public String getdata1205() {
        return data1205;
    }

    public void setdata1205(String data1205) {
        this.data1205 = data1205;
    }

    public String getdata1206() {
        return data1206;
    }

    public void setdata1206(String data1206) {
        this.data1206 = data1206;
    }

    public String getdata1207() {
        return data1207;
    }

    public void setdata1207(String data1207) {
        this.data1207 = data1207;
    }

    public String getdata1208() {
        return data1208;
    }

    public void setdata1208(String data1208) {
        this.data1208 = data1208;
    }

    public String getdata1209() {
        return data1209;
    }

    public void setdata1209(String data1209) {
        this.data1209 = data1209;
    }

    public String getdata1210() {
        return data1210;
    }

    public void setdata1210(String data1210) {
        this.data1210 = data1210;
    }

    public String getdata1211() {
        return data1211;
    }

    public void setdata1211(String data1211) {
        this.data1211 = data1211;
    }

    public String getdata1212() {
        return data1212;
    }

    public void setdata1212(String data1212) {
        this.data1212 = data1212;
    }

    public String getdata1213() {
        return data1213;
    }

    public void setdata1213(String data1213) {
        this.data1213 = data1213;
    }

    public String getdata1214() {
        return data1214;
    }

    public void setdata1214(String data1214) {
        this.data1214 = data1214;
    }

    public String getdata1215() {
        return data1215;
    }

    public void setdata1215(String data1215) {
        this.data1215 = data1215;
    }

    public String getdata1216() {
        return data1216;
    }

    public void setdata1216(String data1216) {
        this.data1216 = data1216;
    }

    public String getdata1217() {
        return data1217;
    }

    public void setdata1217(String data1217) {
        this.data1217 = data1217;
    }

    public String getdata1218() {
        return data1218;
    }

    public void setdata1218(String data1218) {
        this.data1218 = data1218;
    }

    public String getdata1219() {
        return data1219;
    }

    public void setdata1219(String data1219) {
        this.data1219 = data1219;
    }

    public String getdata1220() {
        return data1220;
    }

    public void setdata1220(String data1220) {
        this.data1220 = data1220;
    }

    public String getdata1221() {
        return data1221;
    }

    public void setdata1221(String data1221) {
        this.data1221 = data1221;
    }

    public String getdata1222() {
        return data1222;
    }

    public void setdata1222(String data1222) {
        this.data1222 = data1222;
    }

    public String getdata1223() {
        return data1223;
    }

    public void setdata1223(String data1223) {
        this.data1223 = data1223;
    }

    public String getdata1224() {
        return data1224;
    }

    public void setdata1224(String data1224) {
        this.data1224 = data1224;
    }

    public String getdata1225() {
        return data1225;
    }

    public void setdata1225(String data1225) {
        this.data1225 = data1225;
    }

    public String getdata1226() {
        return data1226;
    }

    public void setdata1226(String data1226) {
        this.data1226 = data1226;
    }

    public String getdata1227() {
        return data1227;
    }

    public void setdata1227(String data1227) {
        this.data1227 = data1227;
    }

    public String getdata1228() {
        return data1228;
    }

    public void setdata1228(String data1228) {
        this.data1228 = data1228;
    }

    public String getdata1229() {
        return data1229;
    }

    public void setdata1229(String data1229) {
        this.data1229 = data1229;
    }

    public String getdata1230() {
        return data1230;
    }

    public void setdata1230(String data1230) {
        this.data1230 = data1230;
    }

    public String getdata12000() {
        return data12000;
    }

    public void setdata12000(String data12000) {
        this.data12000 = data12000;
    }

    public String getdata12001() {
        return data12001;
    }

    public void setdata12001(String data12001) {
        this.data12001 = data12001;
    }

    public String getdata12002() {
        return data12002;
    }

    public void setdata12002(String data12002) {
        this.data12002 = data12002;
    }

    public String getdata12003() {
        return data12003;
    }

    public void setdata12003(String data12003) {
        this.data12003 = data12003;
    }

    public String getdata12004() {
        return data12004;
    }

    public void setdata12004(String data12004) {
        this.data12004 = data12004;
    }

    public String getdata12005() {
        return data12005;
    }

    public void setdata12005(String data12005) {
        this.data12005 = data12005;
    }

    public String getdata12006() {
        return data12006;
    }

    public void setdata12006(String data12006) {
        this.data12006 = data12006;
    }

    public String getdata12007() {
        return data12007;
    }

    public void setdata12007(String data12007) {
        this.data12007 = data12007;
    }

    public String getdata12008() {
        return data12008;
    }

    public void setdata12008(String data12008) {
        this.data12008 = data12008;
    }

    public String getdata12009() {
        return data12009;
    }

    public void setdata12009(String data12009) {
        this.data12009 = data12009;
    }

    public String getdata12010() {
        return data12010;
    }

    public void setdata12010(String data12010) {
        this.data12010 = data12010;
    }

    public String getdata12011() {
        return data12011;
    }

    public void setdata12011(String data12011) {
        this.data12011 = data12011;
    }

    public String getdata12012() {
        return data12012;
    }

    public void setdata12012(String data12012) {
        this.data12012 = data12012;
    }

    public String getdata12013() {
        return data12013;
    }

    public void setdata12013(String data12013) {
        this.data12013 = data12013;
    }

    public String getdata12014() {
        return data12014;
    }

    public void setdata12014(String data12014) {
        this.data12014 = data12014;
    }

    public String getdata12015() {
        return data12015;
    }

    public void setdata12015(String data12015) {
        this.data12015 = data12015;
    }

    public String getdata12016() {
        return data12016;
    }

    public void setdata12016(String data12016) {
        this.data12016 = data12016;
    }

    public String getdata12017() {
        return data12017;
    }

    public void setdata12017(String data12017) {
        this.data12017 = data12017;
    }

    public String getdata12018() {
        return data12018;
    }

    public void setdata12018(String data12018) {
        this.data12018 = data12018;
    }

    public String getdata12019() {
        return data12019;
    }

    public void setdata12019(String data12019) {
        this.data12019 = data12019;
    }

    public String getdata12020() {
        return data12020;
    }

    public void setdata12020(String data12020) {
        this.data12020 = data12020;
    }

    public String getdata12021() {
        return data12021;
    }

    public void setdata12021(String data12021) {
        this.data12021 = data12021;
    }

    public String getdata12022() {
        return data12022;
    }

    public void setdata12022(String data12022) {
        this.data12022 = data12022;
    }

    public String getdata12023() {
        return data12023;
    }

    public void setdata12023(String data12023) {
        this.data12023 = data12023;
    }

    public String getdata12024() {
        return data12024;
    }

    public void setdata12024(String data12024) {
        this.data12024 = data12024;
    }

    public String getdata12025() {
        return data12025;
    }

    public void setdata12025(String data12025) {
        this.data12025 = data12025;
    }

    public String getdata12026() {
        return data12026;
    }

    public void setdata12026(String data12026) {
        this.data12026 = data12026;
    }

    public String getdata12027() {
        return data12027;
    }

    public void setdata12027(String data12027) {
        this.data12027 = data12027;
    }

    public String getdata12028() {
        return data12028;
    }

    public void setdata12028(String data12028) {
        this.data12028 = data12028;
    }

    public String getdata12029() {
        return data12029;
    }

    public void setdata12029(String data12029) {
        this.data12029 = data12029;
    }

    public String getdata12030() {
        return data12030;
    }

    public void setdata12030(String data12030) {
        this.data12030 = data12030;
    }

    public String getdata12031() {
        return data12031;
    }

    public void setdata12031(String data12031) {
        this.data12031 = data12031;
    }

    public String getdata12032() {
        return data12032;
    }

    public void setdata12032(String data12032) {
        this.data12032 = data12032;
    }

    public String getdata12033() {
        return data12033;
    }

    public void setdata12033(String data12033) {
        this.data12033 = data12033;
    }

    public String getdata12034() {
        return data12034;
    }

    public void setdata12034(String data12034) {
        this.data12034 = data12034;
    }

    public String getdata12035() {
        return data12035;
    }

    public void setdata12035(String data12035) {
        this.data12035 = data12035;
    }

    public String getdata12036() {
        return data12036;
    }

    public void setdata12036(String data12036) {
        this.data12036 = data12036;
    }

    public String getdata12037() {
        return data12037;
    }

    public void setdata12037(String data12037) {
        this.data12037 = data12037;
    }

    public String getdata12038() {
        return data12038;
    }

    public void setdata12038(String data12038) {
        this.data12038 = data12038;
    }

    public String getdata12039() {
        return data12039;
    }

    public void setdata12039(String data12039) {
        this.data12039 = data12039;
    }

    public String getdata12040() {
        return data12040;
    }

    public void setdata12040(String data12040) {
        this.data12040 = data12040;
    }

    public String getdata12041() {
        return data12041;
    }

    public void setdata12041(String data12041) {
        this.data12041 = data12041;
    }

    public String getdata12042() {
        return data12042;
    }

    public void setdata12042(String data12042) {
        this.data12042 = data12042;
    }

    public String getdata12043() {
        return data12043;
    }

    public void setdata12043(String data12043) {
        this.data12043 = data12043;
    }

    public String getdata12044() {
        return data12044;
    }

    public void setdata12044(String data12044) {
        this.data12044 = data12044;
    }

    public String getdata12045() {
        return data12045;
    }

    public void setdata12045(String data12045) {
        this.data12045 = data12045;
    }

    public String getdata12046() {
        return data12046;
    }

    public void setdata12046(String data12046) {
        this.data12046 = data12046;
    }

    public String getdata12047() {
        return data12047;
    }

    public void setdata12047(String data12047) {
        this.data12047 = data12047;
    }

    public String getdata12048() {
        return data12048;
    }

    public void setdata12048(String data12048) {
        this.data12048 = data12048;
    }

    public String getdata12049() {
        return data12049;
    }

    public void setdata12049(String data12049) {
        this.data12049 = data12049;
    }

    public String getdata11205() {
        return data11205;
    }

    public void setdata11205(String data11205) {
        this.data11205 = data11205;
    }

    public String getdata11206() {
        return data11206;
    }

    public void setdata11206(String data11206) {
        this.data11206 = data11206;
    }

    public String getdata11207() {
        return data11207;
    }

    public void setdata11207(String data11207) {
        this.data11207 = data11207;
    }

    public String getdata11208() {
        return data11208;
    }

    public void setdata11208(String data11208) {
        this.data11208 = data11208;
    }

    public String getdata21205() {
        return data21205;
    }

    public void setdata21205(String data21205) {
        this.data21205 = data21205;
    }

    public String getdata21206() {
        return data21206;
    }

    public void setdata21206(String data21206) {
        this.data21206 = data21206;
    }

    public String getdata21207() {
        return data21207;
    }

    public void setdata21207(String data21207) {
        this.data21207 = data21207;
    }

    public String getdata21208() {
        return data21208;
    }

    public void setdata21208(String data21208) {
        this.data21208 = data21208;
    }

    public String getdata31205() {
        return data31205;
    }

    public void setdata31205(String data31205) {
        this.data31205 = data31205;
    }

    public String getdata31206() {
        return data31206;
    }

    public void setdata31206(String data31206) {
        this.data31206 = data31206;
    }

    public String getdata31207() {
        return data31207;
    }

    public void setdata31207(String data31207) {
        this.data31207 = data31207;
    }

    public String getdata31208() {
        return data31208;
    }

    public void setdata31208(String data31208) {
        this.data31208 = data31208;
    }

    public String getdata41205() {
        return data41205;
    }

    public void setdata41205(String data41205) {
        this.data41205 = data41205;
    }

    public String getdata41206() {
        return data41206;
    }

    public void setdata41206(String data41206) {
        this.data41206 = data41206;
    }

    public String getdata41207() {
        return data41207;
    }

    public void setdata41207(String data41207) {
        this.data41207 = data41207;
    }

    public String getdata41208() {
        return data41208;
    }

    public void setdata41208(String data41208) {
        this.data41208 = data41208;
    }

    public String getdata51205() {
        return data51205;
    }

    public void setdata51205(String data51205) {
        this.data51205 = data51205;
    }

    public String getdata51206() {
        return data51206;
    }

    public void setdata51206(String data51206) {
        this.data51206 = data51206;
    }

    public String getdata51207() {
        return data51207;
    }

    public void setdata51207(String data51207) {
        this.data51207 = data51207;
    }

    public String getdata51208() {
        return data51208;
    }

    public void setdata51208(String data51208) {
        this.data51208 = data51208;
    }
}
