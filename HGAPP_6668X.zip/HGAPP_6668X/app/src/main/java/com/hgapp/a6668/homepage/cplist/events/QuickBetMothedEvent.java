package com.hgapp.a6668.homepage.cplist.events;

public class QuickBetMothedEvent {
   public String sort;

    public QuickBetMothedEvent() {
    }
    public QuickBetMothedEvent(String sort) {
        this.sort = sort;
    }
}
