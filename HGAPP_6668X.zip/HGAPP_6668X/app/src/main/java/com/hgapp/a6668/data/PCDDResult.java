package com.hgapp.a6668.data;

import com.google.gson.annotations.SerializedName;

public class PCDDResult {
    /**
     * 5001 : 941
     * 5002 : 313
     * 5003 : 156
     * 5004 : 64
     * 5005 : 62
     * 5006 : 44
     * 5007 : 33
     * 5008 : 26
     * 5009 : 20.9
     * 5010 : 17.1
     * 5011 : 14.9
     * 5012 : 13.5
     * 5013 : 12.8
     * 5014 : 12.5
     * 5015 : 12.5
     * 5016 : 12.8
     * 5017 : 13.5
     * 5018 : 14.9
     * 5019 : 17.1
     * 5020 : 20.9
     * 5021 : 26
     * 5022 : 33
     * 5023 : 44
     * 5024 : 62
     * 5025 : 94
     * 5026 : 156
     * 5027 : 313
     * 5028 : 940
     * 5029 : 1.981
     * 5030 : 1.981
     * 5031 : 1.981
     * 5032 : 1.981
     * 5033 : 3.561
     * 5034 : 3.561
     * 5035 : 3.561
     * 5036 : 3.561
     * 5037 : 10
     * 5038 : 10
     * 5039 : 2.96
     * 5040 : 2.96
     * 5041 : 2.96
     * 5042 : 90
     */

    @SerializedName("5001")
    private String data_5001;
    @SerializedName("5002")
    private String data_5002;
    @SerializedName("5003")
    private String data_5003;
    @SerializedName("5004")
    private String data_5004;
    @SerializedName("5005")
    private String data_5005;
    @SerializedName("5006")
    private String data_5006;
    @SerializedName("5007")
    private String data_5007;
    @SerializedName("5008")
    private String data_5008;
    @SerializedName("5009")
    private String data_5009;
    @SerializedName("5010")
    private String data_5010;
    @SerializedName("5011")
    private String data_5011;
    @SerializedName("5012")
    private String data_5012;
    @SerializedName("5013")
    private String data_5013;
    @SerializedName("5014")
    private String data_5014;
    @SerializedName("5015")
    private String data_5015;
    @SerializedName("5016")
    private String data_5016;
    @SerializedName("5017")
    private String data_5017;
    @SerializedName("5018")
    private String data_5018;
    @SerializedName("5019")
    private String data_5019;
    @SerializedName("5020")
    private String data_5020;
    @SerializedName("5021")
    private String data_5021;
    @SerializedName("5022")
    private String data_5022;
    @SerializedName("5023")
    private String data_5023;
    @SerializedName("5024")
    private String data_5024;
    @SerializedName("5025")
    private String data_5025;
    @SerializedName("5026")
    private String data_5026;
    @SerializedName("5027")
    private String data_5027;
    @SerializedName("5028")
    private String data_5028;
    @SerializedName("5029")
    private String data_5029;
    @SerializedName("5030")
    private String data_5030;
    @SerializedName("5031")
    private String data_5031;
    @SerializedName("5032")
    private String data_5032;
    @SerializedName("5033")
    private String data_5033;
    @SerializedName("5034")
    private String data_5034;
    @SerializedName("5035")
    private String data_5035;
    @SerializedName("5036")
    private String data_5036;
    @SerializedName("5037")
    private String data_5037;
    @SerializedName("5038")
    private String data_5038;
    @SerializedName("5039")
    private String data_5039;
    @SerializedName("5040")
    private String data_5040;
    @SerializedName("5041")
    private String data_5041;
    @SerializedName("5042")
    private String data_5042;

    public String getData_5001() {
        return data_5001;
    }

    public void setData_5001(String data_5001) {
        this.data_5001 = data_5001;
    }

    public String getData_5002() {
        return data_5002;
    }

    public void setData_5002(String data_5002) {
        this.data_5002 = data_5002;
    }

    public String getData_5003() {
        return data_5003;
    }

    public void setData_5003(String data_5003) {
        this.data_5003 = data_5003;
    }

    public String getData_5004() {
        return data_5004;
    }

    public void setData_5004(String data_5004) {
        this.data_5004 = data_5004;
    }

    public String getData_5005() {
        return data_5005;
    }

    public void setData_5005(String data_5005) {
        this.data_5005 = data_5005;
    }

    public String getData_5006() {
        return data_5006;
    }

    public void setData_5006(String data_5006) {
        this.data_5006 = data_5006;
    }

    public String getData_5007() {
        return data_5007;
    }

    public void setData_5007(String data_5007) {
        this.data_5007 = data_5007;
    }

    public String getData_5008() {
        return data_5008;
    }

    public void setData_5008(String data_5008) {
        this.data_5008 = data_5008;
    }

    public String getData_5009() {
        return data_5009;
    }

    public void setData_5009(String data_5009) {
        this.data_5009 = data_5009;
    }

    public String getData_5010() {
        return data_5010;
    }

    public void setData_5010(String data_5010) {
        this.data_5010 = data_5010;
    }

    public String getData_5011() {
        return data_5011;
    }

    public void setData_5011(String data_5011) {
        this.data_5011 = data_5011;
    }

    public String getData_5012() {
        return data_5012;
    }

    public void setData_5012(String data_5012) {
        this.data_5012 = data_5012;
    }

    public String getData_5013() {
        return data_5013;
    }

    public void setData_5013(String data_5013) {
        this.data_5013 = data_5013;
    }

    public String getData_5014() {
        return data_5014;
    }

    public void setData_5014(String data_5014) {
        this.data_5014 = data_5014;
    }

    public String getData_5015() {
        return data_5015;
    }

    public void setData_5015(String data_5015) {
        this.data_5015 = data_5015;
    }

    public String getData_5016() {
        return data_5016;
    }

    public void setData_5016(String data_5016) {
        this.data_5016 = data_5016;
    }

    public String getData_5017() {
        return data_5017;
    }

    public void setData_5017(String data_5017) {
        this.data_5017 = data_5017;
    }

    public String getData_5018() {
        return data_5018;
    }

    public void setData_5018(String data_5018) {
        this.data_5018 = data_5018;
    }

    public String getData_5019() {
        return data_5019;
    }

    public void setData_5019(String data_5019) {
        this.data_5019 = data_5019;
    }

    public String getData_5020() {
        return data_5020;
    }

    public void setData_5020(String data_5020) {
        this.data_5020 = data_5020;
    }

    public String getData_5021() {
        return data_5021;
    }

    public void setData_5021(String data_5021) {
        this.data_5021 = data_5021;
    }

    public String getData_5022() {
        return data_5022;
    }

    public void setData_5022(String data_5022) {
        this.data_5022 = data_5022;
    }

    public String getData_5023() {
        return data_5023;
    }

    public void setData_5023(String data_5023) {
        this.data_5023 = data_5023;
    }

    public String getData_5024() {
        return data_5024;
    }

    public void setData_5024(String data_5024) {
        this.data_5024 = data_5024;
    }

    public String getData_5025() {
        return data_5025;
    }

    public void setData_5025(String data_5025) {
        this.data_5025 = data_5025;
    }

    public String getData_5026() {
        return data_5026;
    }

    public void setData_5026(String data_5026) {
        this.data_5026 = data_5026;
    }

    public String getData_5027() {
        return data_5027;
    }

    public void setData_5027(String data_5027) {
        this.data_5027 = data_5027;
    }

    public String getData_5028() {
        return data_5028;
    }

    public void setData_5028(String data_5028) {
        this.data_5028 = data_5028;
    }

    public String getData_5029() {
        return data_5029;
    }

    public void setData_5029(String data_5029) {
        this.data_5029 = data_5029;
    }

    public String getData_5030() {
        return data_5030;
    }

    public void setData_5030(String data_5030) {
        this.data_5030 = data_5030;
    }

    public String getData_5031() {
        return data_5031;
    }

    public void setData_5031(String data_5031) {
        this.data_5031 = data_5031;
    }

    public String getData_5032() {
        return data_5032;
    }

    public void setData_5032(String data_5032) {
        this.data_5032 = data_5032;
    }

    public String getData_5033() {
        return data_5033;
    }

    public void setData_5033(String data_5033) {
        this.data_5033 = data_5033;
    }

    public String getData_5034() {
        return data_5034;
    }

    public void setData_5034(String data_5034) {
        this.data_5034 = data_5034;
    }

    public String getData_5035() {
        return data_5035;
    }

    public void setData_5035(String data_5035) {
        this.data_5035 = data_5035;
    }

    public String getData_5036() {
        return data_5036;
    }

    public void setData_5036(String data_5036) {
        this.data_5036 = data_5036;
    }

    public String getData_5037() {
        return data_5037;
    }

    public void setData_5037(String data_5037) {
        this.data_5037 = data_5037;
    }

    public String getData_5038() {
        return data_5038;
    }

    public void setData_5038(String data_5038) {
        this.data_5038 = data_5038;
    }

    public String getData_5039() {
        return data_5039;
    }

    public void setData_5039(String data_5039) {
        this.data_5039 = data_5039;
    }

    public String getData_5040() {
        return data_5040;
    }

    public void setData_5040(String data_5040) {
        this.data_5040 = data_5040;
    }

    public String getData_5041() {
        return data_5041;
    }

    public void setData_5041(String data_5041) {
        this.data_5041 = data_5041;
    }

    public String getData_5042() {
        return data_5042;
    }

    public void setData_5042(String data_5042) {
        this.data_5042 = data_5042;
    }

    @Override
    public String toString() {
        return "PCDDResult{" +
                "data_5001='" + data_5001 + '\'' +
                ", data_5002='" + data_5002 + '\'' +
                ", data_5003='" + data_5003 + '\'' +
                ", data_5004='" + data_5004 + '\'' +
                ", data_5005='" + data_5005 + '\'' +
                ", data_5006='" + data_5006 + '\'' +
                ", data_5007='" + data_5007 + '\'' +
                ", data_5008='" + data_5008 + '\'' +
                ", data_5009='" + data_5009 + '\'' +
                ", data_5010='" + data_5010 + '\'' +
                ", data_5011='" + data_5011 + '\'' +
                ", data_5012='" + data_5012 + '\'' +
                ", data_5013='" + data_5013 + '\'' +
                ", data_5014='" + data_5014 + '\'' +
                ", data_5015='" + data_5015 + '\'' +
                ", data_5016='" + data_5016 + '\'' +
                ", data_5017='" + data_5017 + '\'' +
                ", data_5018='" + data_5018 + '\'' +
                ", data_5019='" + data_5019 + '\'' +
                ", data_5020='" + data_5020 + '\'' +
                ", data_5021='" + data_5021 + '\'' +
                ", data_5022='" + data_5022 + '\'' +
                ", data_5023='" + data_5023 + '\'' +
                ", data_5024='" + data_5024 + '\'' +
                ", data_5025='" + data_5025 + '\'' +
                ", data_5026='" + data_5026 + '\'' +
                ", data_5027='" + data_5027 + '\'' +
                ", data_5028='" + data_5028 + '\'' +
                ", data_5029='" + data_5029 + '\'' +
                ", data_5030='" + data_5030 + '\'' +
                ", data_5031='" + data_5031 + '\'' +
                ", data_5032='" + data_5032 + '\'' +
                ", data_5033='" + data_5033 + '\'' +
                ", data_5034='" + data_5034 + '\'' +
                ", data_5035='" + data_5035 + '\'' +
                ", data_5036='" + data_5036 + '\'' +
                ", data_5037='" + data_5037 + '\'' +
                ", data_5038='" + data_5038 + '\'' +
                ", data_5039='" + data_5039 + '\'' +
                ", data_5040='" + data_5040 + '\'' +
                ", data_5041='" + data_5041 + '\'' +
                ", data_5042='" + data_5042 + '\'' +
                '}';
    }
}
