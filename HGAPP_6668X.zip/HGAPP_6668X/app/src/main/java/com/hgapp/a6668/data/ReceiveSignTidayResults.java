package com.hgapp.a6668.data;

public class ReceiveSignTidayResults {

    /**
     * balance_hg : 13689.07
     * data_gold : 25
     */

    private double balance_hg;
    private String data_gold;

    public double getBalance_hg() {
        return balance_hg;
    }

    public void setBalance_hg(double balance_hg) {
        this.balance_hg = balance_hg;
    }

    public String getData_gold() {
        return data_gold;
    }

    public void setData_gold(String data_gold) {
        this.data_gold = data_gold;
    }
}
