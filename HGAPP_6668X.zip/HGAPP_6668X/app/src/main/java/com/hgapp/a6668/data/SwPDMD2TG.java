package com.hgapp.a6668.data;

public class SwPDMD2TG {
    public String  ior_H_up;
    public String  ior_H_down;
    public String  order_method;
    public String  rtype;
    public String  wtype;
}
