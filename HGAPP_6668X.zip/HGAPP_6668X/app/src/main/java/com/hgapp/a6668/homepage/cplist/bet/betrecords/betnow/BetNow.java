package com.hgapp.a6668.homepage.cplist.bet.betrecords.betnow;


public class BetNow {
    String name;
    String id;
    String num;
    String moeny;
}
