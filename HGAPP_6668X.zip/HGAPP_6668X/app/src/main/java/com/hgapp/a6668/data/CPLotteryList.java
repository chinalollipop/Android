package com.hgapp.a6668.data;

import java.util.List;

public class CPLotteryList {
    List<CPLotteryListResult> data;

    public List<CPLotteryListResult> getData() {
        return data;
    }

    public void setData(List<CPLotteryListResult> data) {
        this.data = data;
    }
}
