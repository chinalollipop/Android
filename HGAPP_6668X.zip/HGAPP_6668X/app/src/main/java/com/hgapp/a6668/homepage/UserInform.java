package com.hgapp.a6668.homepage;

public class UserInform {
    public String agent;
    public String id;
    public String ida;
    public String name;
    public String pwd;
    public String key;
    public String flag;
    public String apptip;

}
