package com.hgapp.a6668.base;

/**
 * Created by Daniel on 2017/4/17.
 * MVP的Presenter层父接口
 */

public interface IPresenter {

    public void start();
    public void destroy();
}
