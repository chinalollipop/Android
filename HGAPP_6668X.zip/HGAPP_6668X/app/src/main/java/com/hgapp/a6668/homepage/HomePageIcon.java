package com.hgapp.a6668.homepage;

public class HomePageIcon {
    private String iconName;
    private int iconId;
    private int id;
    private String iconNameTitle;

    public HomePageIcon(String iconName, int iconId) {
        this.iconName = iconName;
        this.iconId = iconId;
    }
    public HomePageIcon(String iconName, int iconId,int id) {
        this.iconName = iconName;
        this.iconId = iconId;
        this.id = id;
    }

    public HomePageIcon(String iconName, int iconId, int id, String iconNameTitle) {
        this.iconName = iconName;
        this.iconId = iconId;
        this.id = id;
        this.iconNameTitle = iconNameTitle;
    }

    public String getIconName() {
        return iconName;
    }

    public void setIconName(String iconName) {
        this.iconName = iconName;
    }

    public int getIconId() {
        return iconId;
    }

    public void setIconId(int iconId) {
        this.iconId = iconId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIconNameTitle() {
        return iconNameTitle;
    }

    public void setIconNameTitle(String iconNameTitle) {
        this.iconNameTitle = iconNameTitle;
    }
}
