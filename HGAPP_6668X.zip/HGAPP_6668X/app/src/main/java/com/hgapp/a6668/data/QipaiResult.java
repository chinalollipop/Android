package com.hgapp.a6668.data;

public class QipaiResult {

    /**
     * code : 0
     * url : https://kyh5.ky206.com/index.html?account=70240_daniel50080&token=eyJkYXRhIjoiNzAyNDBfZGFuaWVsNTAwODAiLCJjcmVhdGVkIjoxNTM3Njg2MjgzLCJleHAiOjE1MH0=.wFv/hkPF/jfxi9fy90DsImHjKoQ/GgI3sLKRjnXaNno=&lang=zh-CN
     */

    private int code;
    private String url;
    private String message;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
