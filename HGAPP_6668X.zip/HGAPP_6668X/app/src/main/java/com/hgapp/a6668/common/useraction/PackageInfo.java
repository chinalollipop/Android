package com.hgapp.a6668.common.useraction;

/**
 * Created by Nereus on 2017/5/31.
 * 这个包是留着以后做统计用的，留一手。将来好办事
 */

public class PackageInfo {
}
