package com.hgapp.a6668.homepage;

public class UserMoneyEvent {
    public String money;

    public UserMoneyEvent(String money) {
        this.money = money;
    }
}
