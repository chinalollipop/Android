package com.hgapp.a6668.interfaces;

/**
 * Created by Nereus on 2017/7/25.
 */

public interface IBackPressedSupport {

    public boolean backPressedHandled();
}
