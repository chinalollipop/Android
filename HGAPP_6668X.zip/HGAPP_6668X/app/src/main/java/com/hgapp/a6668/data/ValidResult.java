package com.hgapp.a6668.data;

public class ValidResult {
    /**
     * valid_money : 1200
     * last_times : 1
     */

    private int valid_money;
    private int last_times;

    public int getValid_money() {
        return valid_money;
    }

    public void setValid_money(int valid_money) {
        this.valid_money = valid_money;
    }

    public int getLast_times() {
        return last_times;
    }

    public void setLast_times(int last_times) {
        this.last_times = last_times;
    }
}
