package com.hgapp.a6668.interfaces;

import android.os.Bundle;

/**
 * Created by Nereus on 2017/5/25.
 */

public interface IOnSetResult {

  public void onSetResult(int requestCode, int resultCode, Bundle data);
}
