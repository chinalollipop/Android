package com.hgapp.a6668.depositpage;

public class DepositEvent {
    private int id;
    public DepositEvent(int id){
        this.id = id;
    }
}
