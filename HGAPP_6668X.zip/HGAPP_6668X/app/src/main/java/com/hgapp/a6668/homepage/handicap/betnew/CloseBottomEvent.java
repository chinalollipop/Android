package com.hgapp.a6668.homepage.handicap.betnew;

public class CloseBottomEvent {
}
