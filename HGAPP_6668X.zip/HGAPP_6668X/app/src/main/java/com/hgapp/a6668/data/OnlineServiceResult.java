package com.hgapp.a6668.data;

public class OnlineServiceResult {
    /**
     * onlineserver : https://static.meiqia.com/dist/standalone.html?_=t&eid=106062
     * webname : HG0088.PH
     * website : hg0088.ph
     * telephone : 0063-9296208888
     */

    private String onlineserver;
    private String webname;
    private String website;
    private String telephone;

    public String getOnlineserver() {
        return onlineserver;
    }

    public void setOnlineserver(String onlineserver) {
        this.onlineserver = onlineserver;
    }

    public String getWebname() {
        return webname;
    }

    public void setWebname(String webname) {
        this.webname = webname;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }
}
