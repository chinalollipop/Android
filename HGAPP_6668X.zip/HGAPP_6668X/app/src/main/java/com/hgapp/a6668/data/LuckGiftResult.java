package com.hgapp.a6668.data;

public class LuckGiftResult {
    /**
     * valid_money : 1200
     * last_times : 1
     * data_gold : 8
     */

    private int valid_money;
    private int last_times;
    private String data_gold;

    public int getValid_money() {
        return valid_money;
    }

    public void setValid_money(int valid_money) {
        this.valid_money = valid_money;
    }

    public int getLast_times() {
        return last_times;
    }

    public void setLast_times(int last_times) {
        this.last_times = last_times;
    }

    public String getData_gold() {
        return data_gold;
    }

    public void setData_gold(String data_gold) {
        this.data_gold = data_gold;
    }
}
