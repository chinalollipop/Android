package com.hgapp.a6668.base;

/**
 * Created by Daniel on 2017/4/17.
 * MVP中的视图层父接口
 */

public interface IMessageView {

    public void showMessage(String message);
}
