package com.hgapp.a6668.data;

public class WithdrawResult {

    /**
     * UserName : lincoin06
     * Bank_Name : 江苏省农村信用社联合社
     * Bank_Account : 1234123412341234
     * Bank_Address : 江苏
     */

    private String UserName;
    private String Bank_Name;
    private String Bank_Account;
    private String Bank_Address;

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String UserName) {
        this.UserName = UserName;
    }

    public String getBank_Name() {
        return Bank_Name;
    }

    public void setBank_Name(String Bank_Name) {
        this.Bank_Name = Bank_Name;
    }

    public String getBank_Account() {
        return Bank_Account;
    }

    public void setBank_Account(String Bank_Account) {
        this.Bank_Account = Bank_Account;
    }

    public String getBank_Address() {
        return Bank_Address;
    }

    public void setBank_Address(String Bank_Address) {
        this.Bank_Address = Bank_Address;
    }
}
