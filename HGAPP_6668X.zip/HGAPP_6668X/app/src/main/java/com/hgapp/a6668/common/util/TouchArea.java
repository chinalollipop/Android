package com.hgapp.a6668.common.util;

import android.view.View;

/**
 * Created by Nereus on 2017/10/7.
 */

public class TouchArea {


     public void expandTouchArea(View view)
     {
         /*Rect rect = new Rect();
         view.getHitRect(rect);
         final int ADD=200;
         rect.left+=ADD;
         rect.top+=ADD;
         rect.right+=ADD;
         rect.bottom+=ADD;
         TouchDelegate touchDelegate = new TouchDelegate(rect,view);
         if(view.getParent() instanceof View)
         {
             View parentView = (View)view.getParent();
             parentView.setTouchDelegate(touchDelegate);
         }*/
     }
}
