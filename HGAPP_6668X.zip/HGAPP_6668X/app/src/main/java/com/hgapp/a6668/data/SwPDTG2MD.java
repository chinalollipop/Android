package com.hgapp.a6668.data;

public class SwPDTG2MD {
    public String  ior_C_up;
    public String  ior_C_down;
}
