package com.hgapp.a6668.homepage.cplist.events;

public class CPOrderSuccessEvent {
}
