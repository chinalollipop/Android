package com.hgapp.a6668.common.widgets.tablayout;

public interface OnTabSelectListener {
    void onTabSelect(int position);
    void onTabReselect(int position);
}