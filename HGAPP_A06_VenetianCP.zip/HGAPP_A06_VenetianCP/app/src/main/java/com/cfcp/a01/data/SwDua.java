package com.cfcp.a01.data;

public class SwDua {
    public String ior_DUA_Name;
    public String ior_DUA_da_Name;
    public String ior_DUA_xiao_Name;
    public String ior_DUA_da;
    public String ior_DUA_xiao;
    public String order_method;
    public String rtype_o;//DUAHO   DUBHO   C D
    public String rtype_u;//DUAHU DUBHU
    public String wtype;//DUA DUB DUC DUD

}
