package com.cfcp.a01.homepage.handicap.leaguedetail;

public class CalosEvent {
}
