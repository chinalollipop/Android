package com.cfcp.a01.data;

public class CheckAgLiveResult {

    /**
     * is_registered : “1”
     */

    private String is_registered;

    public String getIs_registered() {
        return is_registered;
    }

    public void setIs_registered(String is_registered) {
        this.is_registered = is_registered;
    }
}

