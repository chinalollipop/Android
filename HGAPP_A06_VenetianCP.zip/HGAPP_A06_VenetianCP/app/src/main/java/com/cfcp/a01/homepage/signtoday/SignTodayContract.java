package com.cfcp.a01.homepage.signtoday;


import com.cfcp.a01.base.IMessageView;
import com.cfcp.a01.base.IPresenter;
import com.cfcp.a01.base.IView;
import com.cfcp.a01.data.ReceiveSignTidayResults;
import com.cfcp.a01.data.SignTodayResults;

public interface SignTodayContract {

    public interface Presenter extends IPresenter
    {
        public void postSignTodayCheck(String appRefer, String action);
        public void postSignTodaySign(String appRefer, String action);
        public void postSignTodayReceive(String appRefer, String action);
    }
    public interface View extends IView<Presenter>, IMessageView
    {
        public void postSignTodayCheckResult(SignTodayResults signTodayResults);
        public void postSignTodayReceiveResult(ReceiveSignTidayResults receiveSignTidayResults);
    }

}
