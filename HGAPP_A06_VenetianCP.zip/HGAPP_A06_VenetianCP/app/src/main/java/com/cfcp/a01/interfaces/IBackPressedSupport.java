package com.cfcp.a01.interfaces;

/**
 * Created by Nereus on 2017/7/25.
 */

public interface IBackPressedSupport {

    public boolean backPressedHandled();
}
