package com.cfcp.a01.data;

public class Sportcenter {

    /**
     * url : https://m.tyzx6688.com/sports/login_ok_api.php?sitemid=reena668&channel=60888&agent=ddm423&key=1c9065e183496bab602c3ed1eea0903e&sig=bc781d91066e4aa47151c54b8669b90b
     * gameUrl : https://m.tyzx6688.com
     */

    private String url;
    private String gameUrl;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getGameUrl() {
        return gameUrl;
    }

    public void setGameUrl(String gameUrl) {
        this.gameUrl = gameUrl;
    }
}
