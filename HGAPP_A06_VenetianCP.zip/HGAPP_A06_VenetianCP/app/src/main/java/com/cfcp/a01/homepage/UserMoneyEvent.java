package com.cfcp.a01.homepage;

public class UserMoneyEvent {
    public String money;

    public UserMoneyEvent(String money) {
        this.money = money;
    }
}
