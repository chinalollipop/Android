package com.cfcp.a01.base;

import android.os.Bundle;

/**
 * Created by Daniel on 2017/5/25.
 */

public interface ISetResultView {

    public void setResult(int resultcode,Bundle bundle);
}
