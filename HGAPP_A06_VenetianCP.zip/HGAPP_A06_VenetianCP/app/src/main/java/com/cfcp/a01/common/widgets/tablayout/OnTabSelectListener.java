package com.cfcp.a01.common.widgets.tablayout;

public interface OnTabSelectListener {
    void onTabSelect(int position);
    void onTabReselect(int position);
}