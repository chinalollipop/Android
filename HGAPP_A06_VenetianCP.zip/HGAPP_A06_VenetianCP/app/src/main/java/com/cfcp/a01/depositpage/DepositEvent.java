package com.cfcp.a01.depositpage;

public class DepositEvent {
    private int id;
    public DepositEvent(int id){
        this.id = id;
    }
}
