package com.cfcp.a01.data;

import com.google.gson.annotations.SerializedName;

public class CPBJSCResult {

    /**
     * 3017 : 2.19
     * 3018 : 1.78
     * 3019 : 1.78
     * 3020 : 2.19
     * 3001-3011 : 1.988
     * 3001-3012 : 1.988
     * 3001-3013 : 1.988
     * 3001-3014 : 1.988
     * 3001-3015 : 1.988
     * 3001-3016 : 1.988
     * 3001-1 : 9.88
     * 3001-2 : 9.88
     * 3001-3 : 9.88
     * 3001-4 : 9.88
     * 3001-5 : 9.88
     * 3001-6 : 9.88
     * 3001-7 : 9.88
     * 3001-8 : 9.88
     * 3001-9 : 9.88
     * 3001-10 : 9.88
     * 3002-3011 : 1.988
     * 3002-3012 : 1.988
     * 3002-3013 : 1.988
     * 3002-3014 : 1.988
     * 3002-3015 : 1.988
     * 3002-3016 : 1.988
     * 3002-1 : 9.88
     * 3002-2 : 9.88
     * 3002-3 : 9.88
     * 3002-4 : 9.88
     * 3002-5 : 9.88
     * 3002-6 : 9.88
     * 3002-7 : 9.88
     * 3002-8 : 9.88
     * 3002-9 : 9.88
     * 3002-10 : 9.88
     * 3003-3011 : 1.988
     * 3003-3012 : 1.988
     * 3003-3013 : 1.988
     * 3003-3014 : 1.988
     * 3003-3015 : 1.988
     * 3003-3016 : 1.988
     * 3003-1 : 9.88
     * 3003-2 : 9.88
     * 3003-3 : 9.88
     * 3003-4 : 9.88
     * 3003-5 : 9.88
     * 3003-6 : 9.88
     * 3003-7 : 9.88
     * 3003-8 : 9.88
     * 3003-9 : 9.88
     * 3003-10 : 9.88
     * 3004-3011 : 1.988
     * 3004-3012 : 1.988
     * 3004-3013 : 1.988
     * 3004-3014 : 1.988
     * 3004-3015 : 1.988
     * 3004-3016 : 1.988
     * 3004-1 : 9.88
     * 3004-2 : 9.88
     * 3004-3 : 9.88
     * 3004-4 : 9.88
     * 3004-5 : 9.88
     * 3004-6 : 9.88
     * 3004-7 : 9.88
     * 3004-8 : 9.88
     * 3004-9 : 9.88
     * 3004-10 : 9.88
     * 3005-3011 : 1.988
     * 3005-3012 : 1.988
     * 3005-3013 : 1.988
     * 3005-3014 : 1.988
     * 3005-3015 : 1.988
     * 3005-3016 : 1.988
     * 3005-1 : 9.88
     * 3005-2 : 9.88
     * 3005-3 : 9.88
     * 3005-4 : 9.88
     * 3005-5 : 9.88
     * 3005-6 : 9.88
     * 3005-7 : 9.88
     * 3005-8 : 9.88
     * 3005-9 : 9.88
     * 3005-10 : 9.88
     * 3006-3011 : 1.988
     * 3006-3012 : 1.988
     * 3006-3013 : 1.988
     * 3006-3014 : 1.988
     * 3006-1 : 9.88
     * 3006-2 : 9.88
     * 3006-3 : 9.88
     * 3006-4 : 9.88
     * 3006-5 : 9.88
     * 3006-6 : 9.88
     * 3006-7 : 9.88
     * 3006-8 : 9.88
     * 3006-9 : 9.88
     * 3006-10 : 9.88
     * 3007-3011 : 1.988
     * 3007-3012 : 1.988
     * 3007-3013 : 1.988
     * 3007-3014 : 1.988
     * 3007-1 : 9.88
     * 3007-2 : 9.88
     * 3007-3 : 9.88
     * 3007-4 : 9.88
     * 3007-5 : 9.88
     * 3007-6 : 9.88
     * 3007-7 : 9.88
     * 3007-8 : 9.88
     * 3007-9 : 9.88
     * 3007-10 : 9.88
     * 3008-3011 : 1.988
     * 3008-3012 : 1.988
     * 3008-3013 : 1.988
     * 3008-3014 : 1.988
     * 3008-1 : 9.88
     * 3008-2 : 9.88
     * 3008-3 : 9.88
     * 3008-4 : 9.88
     * 3008-5 : 9.88
     * 3008-6 : 9.88
     * 3008-7 : 9.88
     * 3008-8 : 9.88
     * 3008-9 : 9.88
     * 3008-10 : 9.88
     * 3009-3011 : 1.988
     * 3009-3012 : 1.988
     * 3009-3013 : 1.988
     * 3009-3014 : 1.988
     * 3009-1 : 9.88
     * 3009-2 : 9.88
     * 3009-3 : 9.88
     * 3009-4 : 9.88
     * 3009-5 : 9.88
     * 3009-6 : 9.88
     * 3009-7 : 9.88
     * 3009-8 : 9.88
     * 3009-9 : 9.88
     * 3009-10 : 9.88
     * 3010-3011 : 1.988
     * 3010-3012 : 1.988
     * 3010-3013 : 1.988
     * 3010-3014 : 1.988
     * 3010-1 : 9.88
     * 3010-2 : 9.88
     * 3010-3 : 9.88
     * 3010-4 : 9.88
     * 3010-5 : 9.88
     * 3010-6 : 9.88
     * 3010-7 : 9.88
     * 3010-8 : 9.88
     * 3010-9 : 9.88
     * 3010-10 : 9.88
     * 3021-3 : 42.5
     * 3021-4 : 42.5
     * 3021-5 : 21.5
     * 3021-6 : 21.5
     * 3021-7 : 14.5
     * 3021-8 : 14.5
     * 3021-9 : 10.5
     * 3021-10 : 10.5
     * 3021-11 : 8.5
     * 3021-12 : 10.5
     * 3021-13 : 10.5
     * 3021-14 : 14.5
     * 3021-15 : 14.5
     * 3021-16 : 21.5
     * 3021-17 : 21.5
     * 3021-18 : 42.5
     * 3021-19 : 42.5
     */

    @SerializedName("3017")
    private String data_3017;
    @SerializedName("3018")
    private String data_3018;
    @SerializedName("3019")
    private String data_3019;
    @SerializedName("3020")
    private String data_3020;
    @SerializedName("3001-3011")
    private String data_30013011;
    @SerializedName("3001-3012")
    private String data_30013012;
    @SerializedName("3001-3013")
    private String data_30013013;
    @SerializedName("3001-3014")
    private String data_30013014;
    @SerializedName("3001-3015")
    private String data_30013015;
    @SerializedName("3001-3016")
    private String data_30013016;
    @SerializedName("3001-1")
    private String data_30011;
    @SerializedName("3001-2")
    private String data_30012;
    @SerializedName("3001-3")
    private String data_30013;
    @SerializedName("3001-4")
    private String data_30014;
    @SerializedName("3001-5")
    private String data_30015;
    @SerializedName("3001-6")
    private String data_30016;
    @SerializedName("3001-7")
    private String data_30017;
    @SerializedName("3001-8")
    private String data_30018;
    @SerializedName("3001-9")
    private String data_30019;
    @SerializedName("3001-10")
    private String data_300110;
    @SerializedName("3002-3011")
    private String data_30023011;
    @SerializedName("3002-3012")
    private String data_30023012;
    @SerializedName("3002-3013")
    private String data_30023013;
    @SerializedName("3002-3014")
    private String data_30023014;
    @SerializedName("3002-3015")
    private String data_30023015;
    @SerializedName("3002-3016")
    private String data_30023016;
    @SerializedName("3002-1")
    private String data_30021;
    @SerializedName("3002-2")
    private String data_30022;
    @SerializedName("3002-3")
    private String data_30023;
    @SerializedName("3002-4")
    private String data_30024;
    @SerializedName("3002-5")
    private String data_30025;
    @SerializedName("3002-6")
    private String data_30026;
    @SerializedName("3002-7")
    private String data_30027;
    @SerializedName("3002-8")
    private String data_30028;
    @SerializedName("3002-9")
    private String data_30029;
    @SerializedName("3002-10")
    private String data_300210;
    @SerializedName("3003-3011")
    private String data_30033011;
    @SerializedName("3003-3012")
    private String data_30033012;
    @SerializedName("3003-3013")
    private String data_30033013;
    @SerializedName("3003-3014")
    private String data_30033014;
    @SerializedName("3003-3015")
    private String data_30033015;
    @SerializedName("3003-3016")
    private String data_30033016;
    @SerializedName("3003-1")
    private String data_30031;
    @SerializedName("3003-2")
    private String data_30032;
    @SerializedName("3003-3")
    private String data_30033;
    @SerializedName("3003-4")
    private String data_30034;
    @SerializedName("3003-5")
    private String data_30035;
    @SerializedName("3003-6")
    private String data_30036;
    @SerializedName("3003-7")
    private String data_30037;
    @SerializedName("3003-8")
    private String data_30038;
    @SerializedName("3003-9")
    private String data_30039;
    @SerializedName("3003-10")
    private String data_300310;
    @SerializedName("3004-3011")
    private String data_30043011;
    @SerializedName("3004-3012")
    private String data_30043012;
    @SerializedName("3004-3013")
    private String data_30043013;
    @SerializedName("3004-3014")
    private String data_30043014;
    @SerializedName("3004-3015")
    private String data_30043015;
    @SerializedName("3004-3016")
    private String data_30043016;
    @SerializedName("3004-1")
    private String data_30041;
    @SerializedName("3004-2")
    private String data_30042;
    @SerializedName("3004-3")
    private String data_30043;
    @SerializedName("3004-4")
    private String data_30044;
    @SerializedName("3004-5")
    private String data_30045;
    @SerializedName("3004-6")
    private String data_30046;
    @SerializedName("3004-7")
    private String data_30047;
    @SerializedName("3004-8")
    private String data_30048;
    @SerializedName("3004-9")
    private String data_30049;
    @SerializedName("3004-10")
    private String data_300410;
    @SerializedName("3005-3011")
    private String data_30053011;
    @SerializedName("3005-3012")
    private String data_30053012;
    @SerializedName("3005-3013")
    private String data_30053013;
    @SerializedName("3005-3014")
    private String data_30053014;
    @SerializedName("3005-3015")
    private String data_30053015;
    @SerializedName("3005-3016")
    private String data_30053016;
    @SerializedName("3005-1")
    private String data_30051;
    @SerializedName("3005-2")
    private String data_30052;
    @SerializedName("3005-3")
    private String data_30053;
    @SerializedName("3005-4")
    private String data_30054;
    @SerializedName("3005-5")
    private String data_30055;
    @SerializedName("3005-6")
    private String data_30056;
    @SerializedName("3005-7")
    private String data_30057;
    @SerializedName("3005-8")
    private String data_30058;
    @SerializedName("3005-9")
    private String data_30059;
    @SerializedName("3005-10")
    private String data_300510;
    @SerializedName("3006-3011")
    private String data_30063011;
    @SerializedName("3006-3012")
    private String data_30063012;
    @SerializedName("3006-3013")
    private String data_30063013;
    @SerializedName("3006-3014")
    private String data_30063014;
    @SerializedName("3006-1")
    private String data_30061;
    @SerializedName("3006-2")
    private String data_30062;
    @SerializedName("3006-3")
    private String data_30063;
    @SerializedName("3006-4")
    private String data_30064;
    @SerializedName("3006-5")
    private String data_30065;
    @SerializedName("3006-6")
    private String data_30066;
    @SerializedName("3006-7")
    private String data_30067;
    @SerializedName("3006-8")
    private String data_30068;
    @SerializedName("3006-9")
    private String data_30069;
    @SerializedName("3006-10")
    private String data_300610;
    @SerializedName("3007-3011")
    private String data_30073011;
    @SerializedName("3007-3012")
    private String data_30073012;
    @SerializedName("3007-3013")
    private String data_30073013;
    @SerializedName("3007-3014")
    private String data_30073014;
    @SerializedName("3007-1")
    private String data_30071;
    @SerializedName("3007-2")
    private String data_30072;
    @SerializedName("3007-3")
    private String data_30073;
    @SerializedName("3007-4")
    private String data_30074;
    @SerializedName("3007-5")
    private String data_30075;
    @SerializedName("3007-6")
    private String data_30076;
    @SerializedName("3007-7")
    private String data_30077;
    @SerializedName("3007-8")
    private String data_30078;
    @SerializedName("3007-9")
    private String data_30079;
    @SerializedName("3007-10")
    private String data_300710;
    @SerializedName("3008-3011")
    private String data_30083011;
    @SerializedName("3008-3012")
    private String data_30083012;
    @SerializedName("3008-3013")
    private String data_30083013;
    @SerializedName("3008-3014")
    private String data_30083014;
    @SerializedName("3008-1")
    private String data_30081;
    @SerializedName("3008-2")
    private String data_30082;
    @SerializedName("3008-3")
    private String data_30083;
    @SerializedName("3008-4")
    private String data_30084;
    @SerializedName("3008-5")
    private String data_30085;
    @SerializedName("3008-6")
    private String data_30086;
    @SerializedName("3008-7")
    private String data_30087;
    @SerializedName("3008-8")
    private String data_30088;
    @SerializedName("3008-9")
    private String data_30089;
    @SerializedName("3008-10")
    private String data_300810;
    @SerializedName("3009-3011")
    private String data_30093011;
    @SerializedName("3009-3012")
    private String data_30093012;
    @SerializedName("3009-3013")
    private String data_30093013;
    @SerializedName("3009-3014")
    private String data_30093014;
    @SerializedName("3009-1")
    private String data_30091;
    @SerializedName("3009-2")
    private String data_30092;
    @SerializedName("3009-3")
    private String data_30093;
    @SerializedName("3009-4")
    private String data_30094;
    @SerializedName("3009-5")
    private String data_30095;
    @SerializedName("3009-6")
    private String data_30096;
    @SerializedName("3009-7")
    private String data_30097;
    @SerializedName("3009-8")
    private String data_30098;
    @SerializedName("3009-9")
    private String data_30099;
    @SerializedName("3009-10")
    private String data_300910;
    @SerializedName("3010-3011")
    private String data_30103011;
    @SerializedName("3010-3012")
    private String data_30103012;
    @SerializedName("3010-3013")
    private String data_30103013;
    @SerializedName("3010-3014")
    private String data_30103014;
    @SerializedName("3010-1")
    private String data_30101;
    @SerializedName("3010-2")
    private String data_30102;
    @SerializedName("3010-3")
    private String data_30103;
    @SerializedName("3010-4")
    private String data_30104;
    @SerializedName("3010-5")
    private String data_30105;
    @SerializedName("3010-6")
    private String data_30106;
    @SerializedName("3010-7")
    private String data_30107;
    @SerializedName("3010-8")
    private String data_30108;
    @SerializedName("3010-9")
    private String data_30109;
    @SerializedName("3010-10")
    private String data_301010;
    @SerializedName("3021-3")
    private String data_30213;
    @SerializedName("3021-4")
    private String data_30214;
    @SerializedName("3021-5")
    private String data_30215;
    @SerializedName("3021-6")
    private String data_30216;
    @SerializedName("3021-7")
    private String data_30217;
    @SerializedName("3021-8")
    private String data_30218;
    @SerializedName("3021-9")
    private String data_30219;
    @SerializedName("3021-10")
    private String data_302110;
    @SerializedName("3021-11")
    private String data_302111;
    @SerializedName("3021-12")
    private String data_302112;
    @SerializedName("3021-13")
    private String data_302113;
    @SerializedName("3021-14")
    private String data_302114;
    @SerializedName("3021-15")
    private String data_302115;
    @SerializedName("3021-16")
    private String data_302116;
    @SerializedName("3021-17")
    private String data_302117;
    @SerializedName("3021-18")
    private String data_302118;
    @SerializedName("3021-19")
    private String data_302119;

    public String getdata_3017() {
        return data_3017;
    }

    public void setdata_3017(String data_3017) {
        this.data_3017 = data_3017;
    }

    public String getdata_3018() {
        return data_3018;
    }

    public void setdata_3018(String data_3018) {
        this.data_3018 = data_3018;
    }

    public String getdata_3019() {
        return data_3019;
    }

    public void setdata_3019(String data_3019) {
        this.data_3019 = data_3019;
    }

    public String getdata_3020() {
        return data_3020;
    }

    public void setdata_3020(String data_3020) {
        this.data_3020 = data_3020;
    }

    public String getdata_30013011() {
        return data_30013011;
    }

    public void setdata_30013011(String data_30013011) {
        this.data_30013011 = data_30013011;
    }

    public String getdata_30013012() {
        return data_30013012;
    }

    public void setdata_30013012(String data_30013012) {
        this.data_30013012 = data_30013012;
    }

    public String getdata_30013013() {
        return data_30013013;
    }

    public void setdata_30013013(String data_30013013) {
        this.data_30013013 = data_30013013;
    }

    public String getdata_30013014() {
        return data_30013014;
    }

    public void setdata_30013014(String data_30013014) {
        this.data_30013014 = data_30013014;
    }

    public String getdata_30013015() {
        return data_30013015;
    }

    public void setdata_30013015(String data_30013015) {
        this.data_30013015 = data_30013015;
    }

    public String getdata_30013016() {
        return data_30013016;
    }

    public void setdata_30013016(String data_30013016) {
        this.data_30013016 = data_30013016;
    }

    public String getdata_30011() {
        return data_30011;
    }

    public void setdata_30011(String data_30011) {
        this.data_30011 = data_30011;
    }

    public String getdata_30012() {
        return data_30012;
    }

    public void setdata_30012(String data_30012) {
        this.data_30012 = data_30012;
    }

    public String getdata_30013() {
        return data_30013;
    }

    public void setdata_30013(String data_30013) {
        this.data_30013 = data_30013;
    }

    public String getdata_30014() {
        return data_30014;
    }

    public void setdata_30014(String data_30014) {
        this.data_30014 = data_30014;
    }

    public String getdata_30015() {
        return data_30015;
    }

    public void setdata_30015(String data_30015) {
        this.data_30015 = data_30015;
    }

    public String getdata_30016() {
        return data_30016;
    }

    public void setdata_30016(String data_30016) {
        this.data_30016 = data_30016;
    }

    public String getdata_30017() {
        return data_30017;
    }

    public void setdata_30017(String data_30017) {
        this.data_30017 = data_30017;
    }

    public String getdata_30018() {
        return data_30018;
    }

    public void setdata_30018(String data_30018) {
        this.data_30018 = data_30018;
    }

    public String getdata_30019() {
        return data_30019;
    }

    public void setdata_30019(String data_30019) {
        this.data_30019 = data_30019;
    }

    public String getdata_300110() {
        return data_300110;
    }

    public void setdata_300110(String data_300110) {
        this.data_300110 = data_300110;
    }

    public String getdata_30023011() {
        return data_30023011;
    }

    public void setdata_30023011(String data_30023011) {
        this.data_30023011 = data_30023011;
    }

    public String getdata_30023012() {
        return data_30023012;
    }

    public void setdata_30023012(String data_30023012) {
        this.data_30023012 = data_30023012;
    }

    public String getdata_30023013() {
        return data_30023013;
    }

    public void setdata_30023013(String data_30023013) {
        this.data_30023013 = data_30023013;
    }

    public String getdata_30023014() {
        return data_30023014;
    }

    public void setdata_30023014(String data_30023014) {
        this.data_30023014 = data_30023014;
    }

    public String getdata_30023015() {
        return data_30023015;
    }

    public void setdata_30023015(String data_30023015) {
        this.data_30023015 = data_30023015;
    }

    public String getdata_30023016() {
        return data_30023016;
    }

    public void setdata_30023016(String data_30023016) {
        this.data_30023016 = data_30023016;
    }

    public String getdata_30021() {
        return data_30021;
    }

    public void setdata_30021(String data_30021) {
        this.data_30021 = data_30021;
    }

    public String getdata_30022() {
        return data_30022;
    }

    public void setdata_30022(String data_30022) {
        this.data_30022 = data_30022;
    }

    public String getdata_30023() {
        return data_30023;
    }

    public void setdata_30023(String data_30023) {
        this.data_30023 = data_30023;
    }

    public String getdata_30024() {
        return data_30024;
    }

    public void setdata_30024(String data_30024) {
        this.data_30024 = data_30024;
    }

    public String getdata_30025() {
        return data_30025;
    }

    public void setdata_30025(String data_30025) {
        this.data_30025 = data_30025;
    }

    public String getdata_30026() {
        return data_30026;
    }

    public void setdata_30026(String data_30026) {
        this.data_30026 = data_30026;
    }

    public String getdata_30027() {
        return data_30027;
    }

    public void setdata_30027(String data_30027) {
        this.data_30027 = data_30027;
    }

    public String getdata_30028() {
        return data_30028;
    }

    public void setdata_30028(String data_30028) {
        this.data_30028 = data_30028;
    }

    public String getdata_30029() {
        return data_30029;
    }

    public void setdata_30029(String data_30029) {
        this.data_30029 = data_30029;
    }

    public String getdata_300210() {
        return data_300210;
    }

    public void setdata_300210(String data_300210) {
        this.data_300210 = data_300210;
    }

    public String getdata_30033011() {
        return data_30033011;
    }

    public void setdata_30033011(String data_30033011) {
        this.data_30033011 = data_30033011;
    }

    public String getdata_30033012() {
        return data_30033012;
    }

    public void setdata_30033012(String data_30033012) {
        this.data_30033012 = data_30033012;
    }

    public String getdata_30033013() {
        return data_30033013;
    }

    public void setdata_30033013(String data_30033013) {
        this.data_30033013 = data_30033013;
    }

    public String getdata_30033014() {
        return data_30033014;
    }

    public void setdata_30033014(String data_30033014) {
        this.data_30033014 = data_30033014;
    }

    public String getdata_30033015() {
        return data_30033015;
    }

    public void setdata_30033015(String data_30033015) {
        this.data_30033015 = data_30033015;
    }

    public String getdata_30033016() {
        return data_30033016;
    }

    public void setdata_30033016(String data_30033016) {
        this.data_30033016 = data_30033016;
    }

    public String getdata_30031() {
        return data_30031;
    }

    public void setdata_30031(String data_30031) {
        this.data_30031 = data_30031;
    }

    public String getdata_30032() {
        return data_30032;
    }

    public void setdata_30032(String data_30032) {
        this.data_30032 = data_30032;
    }

    public String getdata_30033() {
        return data_30033;
    }

    public void setdata_30033(String data_30033) {
        this.data_30033 = data_30033;
    }

    public String getdata_30034() {
        return data_30034;
    }

    public void setdata_30034(String data_30034) {
        this.data_30034 = data_30034;
    }

    public String getdata_30035() {
        return data_30035;
    }

    public void setdata_30035(String data_30035) {
        this.data_30035 = data_30035;
    }

    public String getdata_30036() {
        return data_30036;
    }

    public void setdata_30036(String data_30036) {
        this.data_30036 = data_30036;
    }

    public String getdata_30037() {
        return data_30037;
    }

    public void setdata_30037(String data_30037) {
        this.data_30037 = data_30037;
    }

    public String getdata_30038() {
        return data_30038;
    }

    public void setdata_30038(String data_30038) {
        this.data_30038 = data_30038;
    }

    public String getdata_30039() {
        return data_30039;
    }

    public void setdata_30039(String data_30039) {
        this.data_30039 = data_30039;
    }

    public String getdata_300310() {
        return data_300310;
    }

    public void setdata_300310(String data_300310) {
        this.data_300310 = data_300310;
    }

    public String getdata_30043011() {
        return data_30043011;
    }

    public void setdata_30043011(String data_30043011) {
        this.data_30043011 = data_30043011;
    }

    public String getdata_30043012() {
        return data_30043012;
    }

    public void setdata_30043012(String data_30043012) {
        this.data_30043012 = data_30043012;
    }

    public String getdata_30043013() {
        return data_30043013;
    }

    public void setdata_30043013(String data_30043013) {
        this.data_30043013 = data_30043013;
    }

    public String getdata_30043014() {
        return data_30043014;
    }

    public void setdata_30043014(String data_30043014) {
        this.data_30043014 = data_30043014;
    }

    public String getdata_30043015() {
        return data_30043015;
    }

    public void setdata_30043015(String data_30043015) {
        this.data_30043015 = data_30043015;
    }

    public String getdata_30043016() {
        return data_30043016;
    }

    public void setdata_30043016(String data_30043016) {
        this.data_30043016 = data_30043016;
    }

    public String getdata_30041() {
        return data_30041;
    }

    public void setdata_30041(String data_30041) {
        this.data_30041 = data_30041;
    }

    public String getdata_30042() {
        return data_30042;
    }

    public void setdata_30042(String data_30042) {
        this.data_30042 = data_30042;
    }

    public String getdata_30043() {
        return data_30043;
    }

    public void setdata_30043(String data_30043) {
        this.data_30043 = data_30043;
    }

    public String getdata_30044() {
        return data_30044;
    }

    public void setdata_30044(String data_30044) {
        this.data_30044 = data_30044;
    }

    public String getdata_30045() {
        return data_30045;
    }

    public void setdata_30045(String data_30045) {
        this.data_30045 = data_30045;
    }

    public String getdata_30046() {
        return data_30046;
    }

    public void setdata_30046(String data_30046) {
        this.data_30046 = data_30046;
    }

    public String getdata_30047() {
        return data_30047;
    }

    public void setdata_30047(String data_30047) {
        this.data_30047 = data_30047;
    }

    public String getdata_30048() {
        return data_30048;
    }

    public void setdata_30048(String data_30048) {
        this.data_30048 = data_30048;
    }

    public String getdata_30049() {
        return data_30049;
    }

    public void setdata_30049(String data_30049) {
        this.data_30049 = data_30049;
    }

    public String getdata_300410() {
        return data_300410;
    }

    public void setdata_300410(String data_300410) {
        this.data_300410 = data_300410;
    }

    public String getdata_30053011() {
        return data_30053011;
    }

    public void setdata_30053011(String data_30053011) {
        this.data_30053011 = data_30053011;
    }

    public String getdata_30053012() {
        return data_30053012;
    }

    public void setdata_30053012(String data_30053012) {
        this.data_30053012 = data_30053012;
    }

    public String getdata_30053013() {
        return data_30053013;
    }

    public void setdata_30053013(String data_30053013) {
        this.data_30053013 = data_30053013;
    }

    public String getdata_30053014() {
        return data_30053014;
    }

    public void setdata_30053014(String data_30053014) {
        this.data_30053014 = data_30053014;
    }

    public String getdata_30053015() {
        return data_30053015;
    }

    public void setdata_30053015(String data_30053015) {
        this.data_30053015 = data_30053015;
    }

    public String getdata_30053016() {
        return data_30053016;
    }

    public void setdata_30053016(String data_30053016) {
        this.data_30053016 = data_30053016;
    }

    public String getdata_30051() {
        return data_30051;
    }

    public void setdata_30051(String data_30051) {
        this.data_30051 = data_30051;
    }

    public String getdata_30052() {
        return data_30052;
    }

    public void setdata_30052(String data_30052) {
        this.data_30052 = data_30052;
    }

    public String getdata_30053() {
        return data_30053;
    }

    public void setdata_30053(String data_30053) {
        this.data_30053 = data_30053;
    }

    public String getdata_30054() {
        return data_30054;
    }

    public void setdata_30054(String data_30054) {
        this.data_30054 = data_30054;
    }

    public String getdata_30055() {
        return data_30055;
    }

    public void setdata_30055(String data_30055) {
        this.data_30055 = data_30055;
    }

    public String getdata_30056() {
        return data_30056;
    }

    public void setdata_30056(String data_30056) {
        this.data_30056 = data_30056;
    }

    public String getdata_30057() {
        return data_30057;
    }

    public void setdata_30057(String data_30057) {
        this.data_30057 = data_30057;
    }

    public String getdata_30058() {
        return data_30058;
    }

    public void setdata_30058(String data_30058) {
        this.data_30058 = data_30058;
    }

    public String getdata_30059() {
        return data_30059;
    }

    public void setdata_30059(String data_30059) {
        this.data_30059 = data_30059;
    }

    public String getdata_300510() {
        return data_300510;
    }

    public void setdata_300510(String data_300510) {
        this.data_300510 = data_300510;
    }

    public String getdata_30063011() {
        return data_30063011;
    }

    public void setdata_30063011(String data_30063011) {
        this.data_30063011 = data_30063011;
    }

    public String getdata_30063012() {
        return data_30063012;
    }

    public void setdata_30063012(String data_30063012) {
        this.data_30063012 = data_30063012;
    }

    public String getdata_30063013() {
        return data_30063013;
    }

    public void setdata_30063013(String data_30063013) {
        this.data_30063013 = data_30063013;
    }

    public String getdata_30063014() {
        return data_30063014;
    }

    public void setdata_30063014(String data_30063014) {
        this.data_30063014 = data_30063014;
    }

    public String getdata_30061() {
        return data_30061;
    }

    public void setdata_30061(String data_30061) {
        this.data_30061 = data_30061;
    }

    public String getdata_30062() {
        return data_30062;
    }

    public void setdata_30062(String data_30062) {
        this.data_30062 = data_30062;
    }

    public String getdata_30063() {
        return data_30063;
    }

    public void setdata_30063(String data_30063) {
        this.data_30063 = data_30063;
    }

    public String getdata_30064() {
        return data_30064;
    }

    public void setdata_30064(String data_30064) {
        this.data_30064 = data_30064;
    }

    public String getdata_30065() {
        return data_30065;
    }

    public void setdata_30065(String data_30065) {
        this.data_30065 = data_30065;
    }

    public String getdata_30066() {
        return data_30066;
    }

    public void setdata_30066(String data_30066) {
        this.data_30066 = data_30066;
    }

    public String getdata_30067() {
        return data_30067;
    }

    public void setdata_30067(String data_30067) {
        this.data_30067 = data_30067;
    }

    public String getdata_30068() {
        return data_30068;
    }

    public void setdata_30068(String data_30068) {
        this.data_30068 = data_30068;
    }

    public String getdata_30069() {
        return data_30069;
    }

    public void setdata_30069(String data_30069) {
        this.data_30069 = data_30069;
    }

    public String getdata_300610() {
        return data_300610;
    }

    public void setdata_300610(String data_300610) {
        this.data_300610 = data_300610;
    }

    public String getdata_30073011() {
        return data_30073011;
    }

    public void setdata_30073011(String data_30073011) {
        this.data_30073011 = data_30073011;
    }

    public String getdata_30073012() {
        return data_30073012;
    }

    public void setdata_30073012(String data_30073012) {
        this.data_30073012 = data_30073012;
    }

    public String getdata_30073013() {
        return data_30073013;
    }

    public void setdata_30073013(String data_30073013) {
        this.data_30073013 = data_30073013;
    }

    public String getdata_30073014() {
        return data_30073014;
    }

    public void setdata_30073014(String data_30073014) {
        this.data_30073014 = data_30073014;
    }

    public String getdata_30071() {
        return data_30071;
    }

    public void setdata_30071(String data_30071) {
        this.data_30071 = data_30071;
    }

    public String getdata_30072() {
        return data_30072;
    }

    public void setdata_30072(String data_30072) {
        this.data_30072 = data_30072;
    }

    public String getdata_30073() {
        return data_30073;
    }

    public void setdata_30073(String data_30073) {
        this.data_30073 = data_30073;
    }

    public String getdata_30074() {
        return data_30074;
    }

    public void setdata_30074(String data_30074) {
        this.data_30074 = data_30074;
    }

    public String getdata_30075() {
        return data_30075;
    }

    public void setdata_30075(String data_30075) {
        this.data_30075 = data_30075;
    }

    public String getdata_30076() {
        return data_30076;
    }

    public void setdata_30076(String data_30076) {
        this.data_30076 = data_30076;
    }

    public String getdata_30077() {
        return data_30077;
    }

    public void setdata_30077(String data_30077) {
        this.data_30077 = data_30077;
    }

    public String getdata_30078() {
        return data_30078;
    }

    public void setdata_30078(String data_30078) {
        this.data_30078 = data_30078;
    }

    public String getdata_30079() {
        return data_30079;
    }

    public void setdata_30079(String data_30079) {
        this.data_30079 = data_30079;
    }

    public String getdata_300710() {
        return data_300710;
    }

    public void setdata_300710(String data_300710) {
        this.data_300710 = data_300710;
    }

    public String getdata_30083011() {
        return data_30083011;
    }

    public void setdata_30083011(String data_30083011) {
        this.data_30083011 = data_30083011;
    }

    public String getdata_30083012() {
        return data_30083012;
    }

    public void setdata_30083012(String data_30083012) {
        this.data_30083012 = data_30083012;
    }

    public String getdata_30083013() {
        return data_30083013;
    }

    public void setdata_30083013(String data_30083013) {
        this.data_30083013 = data_30083013;
    }

    public String getdata_30083014() {
        return data_30083014;
    }

    public void setdata_30083014(String data_30083014) {
        this.data_30083014 = data_30083014;
    }

    public String getdata_30081() {
        return data_30081;
    }

    public void setdata_30081(String data_30081) {
        this.data_30081 = data_30081;
    }

    public String getdata_30082() {
        return data_30082;
    }

    public void setdata_30082(String data_30082) {
        this.data_30082 = data_30082;
    }

    public String getdata_30083() {
        return data_30083;
    }

    public void setdata_30083(String data_30083) {
        this.data_30083 = data_30083;
    }

    public String getdata_30084() {
        return data_30084;
    }

    public void setdata_30084(String data_30084) {
        this.data_30084 = data_30084;
    }

    public String getdata_30085() {
        return data_30085;
    }

    public void setdata_30085(String data_30085) {
        this.data_30085 = data_30085;
    }

    public String getdata_30086() {
        return data_30086;
    }

    public void setdata_30086(String data_30086) {
        this.data_30086 = data_30086;
    }

    public String getdata_30087() {
        return data_30087;
    }

    public void setdata_30087(String data_30087) {
        this.data_30087 = data_30087;
    }

    public String getdata_30088() {
        return data_30088;
    }

    public void setdata_30088(String data_30088) {
        this.data_30088 = data_30088;
    }

    public String getdata_30089() {
        return data_30089;
    }

    public void setdata_30089(String data_30089) {
        this.data_30089 = data_30089;
    }

    public String getdata_300810() {
        return data_300810;
    }

    public void setdata_300810(String data_300810) {
        this.data_300810 = data_300810;
    }

    public String getdata_30093011() {
        return data_30093011;
    }

    public void setdata_30093011(String data_30093011) {
        this.data_30093011 = data_30093011;
    }

    public String getdata_30093012() {
        return data_30093012;
    }

    public void setdata_30093012(String data_30093012) {
        this.data_30093012 = data_30093012;
    }

    public String getdata_30093013() {
        return data_30093013;
    }

    public void setdata_30093013(String data_30093013) {
        this.data_30093013 = data_30093013;
    }

    public String getdata_30093014() {
        return data_30093014;
    }

    public void setdata_30093014(String data_30093014) {
        this.data_30093014 = data_30093014;
    }

    public String getdata_30091() {
        return data_30091;
    }

    public void setdata_30091(String data_30091) {
        this.data_30091 = data_30091;
    }

    public String getdata_30092() {
        return data_30092;
    }

    public void setdata_30092(String data_30092) {
        this.data_30092 = data_30092;
    }

    public String getdata_30093() {
        return data_30093;
    }

    public void setdata_30093(String data_30093) {
        this.data_30093 = data_30093;
    }

    public String getdata_30094() {
        return data_30094;
    }

    public void setdata_30094(String data_30094) {
        this.data_30094 = data_30094;
    }

    public String getdata_30095() {
        return data_30095;
    }

    public void setdata_30095(String data_30095) {
        this.data_30095 = data_30095;
    }

    public String getdata_30096() {
        return data_30096;
    }

    public void setdata_30096(String data_30096) {
        this.data_30096 = data_30096;
    }

    public String getdata_30097() {
        return data_30097;
    }

    public void setdata_30097(String data_30097) {
        this.data_30097 = data_30097;
    }

    public String getdata_30098() {
        return data_30098;
    }

    public void setdata_30098(String data_30098) {
        this.data_30098 = data_30098;
    }

    public String getdata_30099() {
        return data_30099;
    }

    public void setdata_30099(String data_30099) {
        this.data_30099 = data_30099;
    }

    public String getdata_300910() {
        return data_300910;
    }

    public void setdata_300910(String data_300910) {
        this.data_300910 = data_300910;
    }

    public String getdata_30103011() {
        return data_30103011;
    }

    public void setdata_30103011(String data_30103011) {
        this.data_30103011 = data_30103011;
    }

    public String getdata_30103012() {
        return data_30103012;
    }

    public void setdata_30103012(String data_30103012) {
        this.data_30103012 = data_30103012;
    }

    public String getdata_30103013() {
        return data_30103013;
    }

    public void setdata_30103013(String data_30103013) {
        this.data_30103013 = data_30103013;
    }

    public String getdata_30103014() {
        return data_30103014;
    }

    public void setdata_30103014(String data_30103014) {
        this.data_30103014 = data_30103014;
    }

    public String getdata_30101() {
        return data_30101;
    }

    public void setdata_30101(String data_30101) {
        this.data_30101 = data_30101;
    }

    public String getdata_30102() {
        return data_30102;
    }

    public void setdata_30102(String data_30102) {
        this.data_30102 = data_30102;
    }

    public String getdata_30103() {
        return data_30103;
    }

    public void setdata_30103(String data_30103) {
        this.data_30103 = data_30103;
    }

    public String getdata_30104() {
        return data_30104;
    }

    public void setdata_30104(String data_30104) {
        this.data_30104 = data_30104;
    }

    public String getdata_30105() {
        return data_30105;
    }

    public void setdata_30105(String data_30105) {
        this.data_30105 = data_30105;
    }

    public String getdata_30106() {
        return data_30106;
    }

    public void setdata_30106(String data_30106) {
        this.data_30106 = data_30106;
    }

    public String getdata_30107() {
        return data_30107;
    }

    public void setdata_30107(String data_30107) {
        this.data_30107 = data_30107;
    }

    public String getdata_30108() {
        return data_30108;
    }

    public void setdata_30108(String data_30108) {
        this.data_30108 = data_30108;
    }

    public String getdata_30109() {
        return data_30109;
    }

    public void setdata_30109(String data_30109) {
        this.data_30109 = data_30109;
    }

    public String getdata_301010() {
        return data_301010;
    }

    public void setdata_301010(String data_301010) {
        this.data_301010 = data_301010;
    }

    public String getdata_30213() {
        return data_30213;
    }

    public void setdata_30213(String data_30213) {
        this.data_30213 = data_30213;
    }

    public String getdata_30214() {
        return data_30214;
    }

    public void setdata_30214(String data_30214) {
        this.data_30214 = data_30214;
    }

    public String getdata_30215() {
        return data_30215;
    }

    public void setdata_30215(String data_30215) {
        this.data_30215 = data_30215;
    }

    public String getdata_30216() {
        return data_30216;
    }

    public void setdata_30216(String data_30216) {
        this.data_30216 = data_30216;
    }

    public String getdata_30217() {
        return data_30217;
    }

    public void setdata_30217(String data_30217) {
        this.data_30217 = data_30217;
    }

    public String getdata_30218() {
        return data_30218;
    }

    public void setdata_30218(String data_30218) {
        this.data_30218 = data_30218;
    }

    public String getdata_30219() {
        return data_30219;
    }

    public void setdata_30219(String data_30219) {
        this.data_30219 = data_30219;
    }

    public String getdata_302110() {
        return data_302110;
    }

    public void setdata_302110(String data_302110) {
        this.data_302110 = data_302110;
    }

    public String getdata_302111() {
        return data_302111;
    }

    public void setdata_302111(String data_302111) {
        this.data_302111 = data_302111;
    }

    public String getdata_302112() {
        return data_302112;
    }

    public void setdata_302112(String data_302112) {
        this.data_302112 = data_302112;
    }

    public String getdata_302113() {
        return data_302113;
    }

    public void setdata_302113(String data_302113) {
        this.data_302113 = data_302113;
    }

    public String getdata_302114() {
        return data_302114;
    }

    public void setdata_302114(String data_302114) {
        this.data_302114 = data_302114;
    }

    public String getdata_302115() {
        return data_302115;
    }

    public void setdata_302115(String data_302115) {
        this.data_302115 = data_302115;
    }

    public String getdata_302116() {
        return data_302116;
    }

    public void setdata_302116(String data_302116) {
        this.data_302116 = data_302116;
    }

    public String getdata_302117() {
        return data_302117;
    }

    public void setdata_302117(String data_302117) {
        this.data_302117 = data_302117;
    }

    public String getdata_302118() {
        return data_302118;
    }

    public void setdata_302118(String data_302118) {
        this.data_302118 = data_302118;
    }

    public String getdata_302119() {
        return data_302119;
    }

    public void setdata_302119(String data_302119) {
        this.data_302119 = data_302119;
    }

    @Override
    public String toString() {
        return "CPBJSCResult2{" +
                "data_3017='" + data_3017 + '\'' +
                ", data_3018='" + data_3018 + '\'' +
                ", data_3019='" + data_3019 + '\'' +
                ", data_3020='" + data_3020 + '\'' +
                ", data_30013011='" + data_30013011 + '\'' +
                ", data_30013012='" + data_30013012 + '\'' +
                ", data_30013013='" + data_30013013 + '\'' +
                ", data_30013014='" + data_30013014 + '\'' +
                ", data_30013015='" + data_30013015 + '\'' +
                ", data_30013016='" + data_30013016 + '\'' +
                ", data_30011='" + data_30011 + '\'' +
                ", data_30012='" + data_30012 + '\'' +
                ", data_30013='" + data_30013 + '\'' +
                ", data_30014='" + data_30014 + '\'' +
                ", data_30015='" + data_30015 + '\'' +
                ", data_30016='" + data_30016 + '\'' +
                ", data_30017='" + data_30017 + '\'' +
                ", data_30018='" + data_30018 + '\'' +
                ", data_30019='" + data_30019 + '\'' +
                ", data_300110='" + data_300110 + '\'' +
                ", data_30023011='" + data_30023011 + '\'' +
                ", data_30023012='" + data_30023012 + '\'' +
                ", data_30023013='" + data_30023013 + '\'' +
                ", data_30023014='" + data_30023014 + '\'' +
                ", data_30023015='" + data_30023015 + '\'' +
                ", data_30023016='" + data_30023016 + '\'' +
                ", data_30021='" + data_30021 + '\'' +
                ", data_30022='" + data_30022 + '\'' +
                ", data_30023='" + data_30023 + '\'' +
                ", data_30024='" + data_30024 + '\'' +
                ", data_30025='" + data_30025 + '\'' +
                ", data_30026='" + data_30026 + '\'' +
                ", data_30027='" + data_30027 + '\'' +
                ", data_30028='" + data_30028 + '\'' +
                ", data_30029='" + data_30029 + '\'' +
                ", data_300210='" + data_300210 + '\'' +
                ", data_30033011='" + data_30033011 + '\'' +
                ", data_30033012='" + data_30033012 + '\'' +
                ", data_30033013='" + data_30033013 + '\'' +
                ", data_30033014='" + data_30033014 + '\'' +
                ", data_30033015='" + data_30033015 + '\'' +
                ", data_30033016='" + data_30033016 + '\'' +
                ", data_30031='" + data_30031 + '\'' +
                ", data_30032='" + data_30032 + '\'' +
                ", data_30033='" + data_30033 + '\'' +
                ", data_30034='" + data_30034 + '\'' +
                ", data_30035='" + data_30035 + '\'' +
                ", data_30036='" + data_30036 + '\'' +
                ", data_30037='" + data_30037 + '\'' +
                ", data_30038='" + data_30038 + '\'' +
                ", data_30039='" + data_30039 + '\'' +
                ", data_300310='" + data_300310 + '\'' +
                ", data_30043011='" + data_30043011 + '\'' +
                ", data_30043012='" + data_30043012 + '\'' +
                ", data_30043013='" + data_30043013 + '\'' +
                ", data_30043014='" + data_30043014 + '\'' +
                ", data_30043015='" + data_30043015 + '\'' +
                ", data_30043016='" + data_30043016 + '\'' +
                ", data_30041='" + data_30041 + '\'' +
                ", data_30042='" + data_30042 + '\'' +
                ", data_30043='" + data_30043 + '\'' +
                ", data_30044='" + data_30044 + '\'' +
                ", data_30045='" + data_30045 + '\'' +
                ", data_30046='" + data_30046 + '\'' +
                ", data_30047='" + data_30047 + '\'' +
                ", data_30048='" + data_30048 + '\'' +
                ", data_30049='" + data_30049 + '\'' +
                ", data_300410='" + data_300410 + '\'' +
                ", data_30053011='" + data_30053011 + '\'' +
                ", data_30053012='" + data_30053012 + '\'' +
                ", data_30053013='" + data_30053013 + '\'' +
                ", data_30053014='" + data_30053014 + '\'' +
                ", data_30053015='" + data_30053015 + '\'' +
                ", data_30053016='" + data_30053016 + '\'' +
                ", data_30051='" + data_30051 + '\'' +
                ", data_30052='" + data_30052 + '\'' +
                ", data_30053='" + data_30053 + '\'' +
                ", data_30054='" + data_30054 + '\'' +
                ", data_30055='" + data_30055 + '\'' +
                ", data_30056='" + data_30056 + '\'' +
                ", data_30057='" + data_30057 + '\'' +
                ", data_30058='" + data_30058 + '\'' +
                ", data_30059='" + data_30059 + '\'' +
                ", data_300510='" + data_300510 + '\'' +
                ", data_30063011='" + data_30063011 + '\'' +
                ", data_30063012='" + data_30063012 + '\'' +
                ", data_30063013='" + data_30063013 + '\'' +
                ", data_30063014='" + data_30063014 + '\'' +
                ", data_30061='" + data_30061 + '\'' +
                ", data_30062='" + data_30062 + '\'' +
                ", data_30063='" + data_30063 + '\'' +
                ", data_30064='" + data_30064 + '\'' +
                ", data_30065='" + data_30065 + '\'' +
                ", data_30066='" + data_30066 + '\'' +
                ", data_30067='" + data_30067 + '\'' +
                ", data_30068='" + data_30068 + '\'' +
                ", data_30069='" + data_30069 + '\'' +
                ", data_300610='" + data_300610 + '\'' +
                ", data_30073011='" + data_30073011 + '\'' +
                ", data_30073012='" + data_30073012 + '\'' +
                ", data_30073013='" + data_30073013 + '\'' +
                ", data_30073014='" + data_30073014 + '\'' +
                ", data_30071='" + data_30071 + '\'' +
                ", data_30072='" + data_30072 + '\'' +
                ", data_30073='" + data_30073 + '\'' +
                ", data_30074='" + data_30074 + '\'' +
                ", data_30075='" + data_30075 + '\'' +
                ", data_30076='" + data_30076 + '\'' +
                ", data_30077='" + data_30077 + '\'' +
                ", data_30078='" + data_30078 + '\'' +
                ", data_30079='" + data_30079 + '\'' +
                ", data_300710='" + data_300710 + '\'' +
                ", data_30083011='" + data_30083011 + '\'' +
                ", data_30083012='" + data_30083012 + '\'' +
                ", data_30083013='" + data_30083013 + '\'' +
                ", data_30083014='" + data_30083014 + '\'' +
                ", data_30081='" + data_30081 + '\'' +
                ", data_30082='" + data_30082 + '\'' +
                ", data_30083='" + data_30083 + '\'' +
                ", data_30084='" + data_30084 + '\'' +
                ", data_30085='" + data_30085 + '\'' +
                ", data_30086='" + data_30086 + '\'' +
                ", data_30087='" + data_30087 + '\'' +
                ", data_30088='" + data_30088 + '\'' +
                ", data_30089='" + data_30089 + '\'' +
                ", data_300810='" + data_300810 + '\'' +
                ", data_30093011='" + data_30093011 + '\'' +
                ", data_30093012='" + data_30093012 + '\'' +
                ", data_30093013='" + data_30093013 + '\'' +
                ", data_30093014='" + data_30093014 + '\'' +
                ", data_30091='" + data_30091 + '\'' +
                ", data_30092='" + data_30092 + '\'' +
                ", data_30093='" + data_30093 + '\'' +
                ", data_30094='" + data_30094 + '\'' +
                ", data_30095='" + data_30095 + '\'' +
                ", data_30096='" + data_30096 + '\'' +
                ", data_30097='" + data_30097 + '\'' +
                ", data_30098='" + data_30098 + '\'' +
                ", data_30099='" + data_30099 + '\'' +
                ", data_300910='" + data_300910 + '\'' +
                ", data_30103011='" + data_30103011 + '\'' +
                ", data_30103012='" + data_30103012 + '\'' +
                ", data_30103013='" + data_30103013 + '\'' +
                ", data_30103014='" + data_30103014 + '\'' +
                ", data_30101='" + data_30101 + '\'' +
                ", data_30102='" + data_30102 + '\'' +
                ", data_30103='" + data_30103 + '\'' +
                ", data_30104='" + data_30104 + '\'' +
                ", data_30105='" + data_30105 + '\'' +
                ", data_30106='" + data_30106 + '\'' +
                ", data_30107='" + data_30107 + '\'' +
                ", data_30108='" + data_30108 + '\'' +
                ", data_30109='" + data_30109 + '\'' +
                ", data_301010='" + data_301010 + '\'' +
                ", data_30213='" + data_30213 + '\'' +
                ", data_30214='" + data_30214 + '\'' +
                ", data_30215='" + data_30215 + '\'' +
                ", data_30216='" + data_30216 + '\'' +
                ", data_30217='" + data_30217 + '\'' +
                ", data_30218='" + data_30218 + '\'' +
                ", data_30219='" + data_30219 + '\'' +
                ", data_302110='" + data_302110 + '\'' +
                ", data_302111='" + data_302111 + '\'' +
                ", data_302112='" + data_302112 + '\'' +
                ", data_302113='" + data_302113 + '\'' +
                ", data_302114='" + data_302114 + '\'' +
                ", data_302115='" + data_302115 + '\'' +
                ", data_302116='" + data_302116 + '\'' +
                ", data_302117='" + data_302117 + '\'' +
                ", data_302118='" + data_302118 + '\'' +
                ", data_302119='" + data_302119 + '\'' +
                '}';
    }
}
