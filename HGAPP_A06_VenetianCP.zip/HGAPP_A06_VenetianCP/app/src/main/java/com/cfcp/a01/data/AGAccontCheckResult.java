package com.cfcp.a01.data;

public class AGAccontCheckResult {
    /**
     * is_registered : 1
     */

    private int is_registered;

    public int getIs_registered() {
        return is_registered;
    }

    public void setIs_registered(int is_registered) {
        this.is_registered = is_registered;
    }
}
