package com.cfcp.a01.data;

public class SwPDHE {
    public String  ior_H_up;
    public String  ior_H_down;
}
