package com.cfcp.a01.base;

/**
 * Created by Daniel on 2017/5/31.
 */

public interface ITransit {

    public void transit(HGBaseFragment originFragment,HGBaseFragment destFragment);
}
