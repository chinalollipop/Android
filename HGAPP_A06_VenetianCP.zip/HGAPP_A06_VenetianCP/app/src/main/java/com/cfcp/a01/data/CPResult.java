package com.cfcp.a01.data;

public class CPResult {

    /**
     * third_cpUrl : http://52070887.com/auth/signin
     * params : MWg4K3FWdVo3NisxMmFPZ1BuclB3SUFpeVVqbDkxVUIyOHplYmdpRDUrN1hjOGpxNGRFNW53PT0=
     * thirdLotteryId : gmcp
     */

    private String third_cpUrl;
    private String params;
    private String thirdLotteryId;

    public String getThird_cpUrl() {
        return third_cpUrl;
    }

    public void setThird_cpUrl(String third_cpUrl) {
        this.third_cpUrl = third_cpUrl;
    }

    public String getParams() {
        return params;
    }

    public void setParams(String params) {
        this.params = params;
    }

    public String getThirdLotteryId() {
        return thirdLotteryId;
    }

    public void setThirdLotteryId(String thirdLotteryId) {
        this.thirdLotteryId = thirdLotteryId;
    }
}
