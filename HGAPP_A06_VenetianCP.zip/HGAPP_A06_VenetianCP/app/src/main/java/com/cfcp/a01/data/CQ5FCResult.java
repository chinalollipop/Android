package com.cfcp.a01.data;

import com.google.gson.annotations.SerializedName;

public class CQ5FCResult {

    /**
     * 0 : 9.68
     * 1 : 9.68
     * 2 : 9.68
     * 3 : 9.68
     * 4 : 9.68
     * 5 : 9.68
     * 6 : 9.68
     * 7 : 9.68
     * 8 : 9.68
     * 9 : 9.68
     * 1305 : 1.968
     * 1306 : 1.968
     * 1307 : 1.968
     * 1308 : 1.968
     * 1309 : 1.968
     * 1310 : 1.968
     * 1311 : 1.968
     * 1312 : 1.968
     * 1313 : 1.968
     * 1314 : 1.968
     * 1315 : 9
     * 1316 : 75
     * 1317 : 14.5
     * 1318 : 3.3
     * 1319 : 2.5
     * 1320 : 3
     * 1321 : 75
     * 1322 : 14.5
     * 1323 : 3.3
     * 1324 : 2.5
     * 1325 : 3
     * 1326 : 75
     * 1327 : 14.5
     * 1328 : 3.3
     * 1329 : 2.5
     * 1330 : 3
     * 1300-0 : 9.68
     * 1300-1 : 9.68
     * 1300-2 : 9.68
     * 1300-3 : 9.68
     * 1300-4 : 9.68
     * 1300-5 : 9.68
     * 1300-6 : 9.68
     * 1300-7 : 9.68
     * 1300-8 : 9.68
     * 1300-9 : 9.68
     * 1301-0 : 9.68
     * 1301-1 : 9.68
     * 1301-2 : 9.68
     * 1301-3 : 9.68
     * 1301-4 : 9.68
     * 1301-5 : 9.68
     * 1301-6 : 9.68
     * 1301-7 : 9.68
     * 1301-8 : 9.68
     * 1301-9 : 9.68
     * 1302-0 : 9.68
     * 1302-1 : 9.68
     * 1302-2 : 9.68
     * 1302-3 : 9.68
     * 1302-4 : 9.68
     * 1302-5 : 9.68
     * 1302-6 : 9.68
     * 1302-7 : 9.68
     * 1302-8 : 9.68
     * 1302-9 : 9.68
     * 1303-0 : 9.68
     * 1303-1 : 9.68
     * 1303-2 : 9.68
     * 1303-3 : 9.68
     * 1303-4 : 9.68
     * 1303-5 : 9.68
     * 1303-6 : 9.68
     * 1303-7 : 9.68
     * 1303-8 : 9.68
     * 1303-9 : 9.68
     * 1304-0 : 9.68
     * 1304-1 : 9.68
     * 1304-2 : 9.68
     * 1304-3 : 9.68
     * 1304-4 : 9.68
     * 1304-5 : 9.68
     * 1304-6 : 9.68
     * 1304-7 : 9.68
     * 1304-8 : 9.68
     * 1304-9 : 9.68
     * 1-1305 : 1.968
     * 1-1306 : 1.968
     * 1-1307 : 1.968
     * 1-1308 : 1.968
     * 2-1305 : 1.968
     * 2-1306 : 1.968
     * 2-1307 : 1.968
     * 2-1308 : 1.968
     * 3-1305 : 1.968
     * 3-1306 : 1.968
     * 3-1307 : 1.968
     * 3-1308 : 1.968
     * 4-1305 : 1.968
     * 4-1306 : 1.968
     * 4-1307 : 1.968
     * 4-1308 : 1.968
     * 5-1305 : 1.968
     * 5-1306 : 1.968
     * 5-1307 : 1.968
     * 5-1308 : 1.968
     */

    @SerializedName("0")
    private String data0;
    @SerializedName("1")
    private String data1;
    @SerializedName("2")
    private String data2;
    @SerializedName("3")
    private String data3;
    @SerializedName("4")
    private String data4;
    @SerializedName("5")
    private String data5;
    @SerializedName("6")
    private String data6;
    @SerializedName("7")
    private String data7;
    @SerializedName("8")
    private String data8;
    @SerializedName("9")
    private String data9;
    @SerializedName("1305")
    private String data1305;
    @SerializedName("1306")
    private String data1306;
    @SerializedName("1307")
    private String data1307;
    @SerializedName("1308")
    private String data1308;
    @SerializedName("1309")
    private String data1309;
    @SerializedName("1310")
    private String data1310;
    @SerializedName("1311")
    private String data1311;
    @SerializedName("1312")
    private String data1312;
    @SerializedName("1313")
    private String data1313;
    @SerializedName("1314")
    private String data1314;
    @SerializedName("1315")
    private String data1315;
    @SerializedName("1316")
    private String data1316;
    @SerializedName("1317")
    private String data1317;
    @SerializedName("1318")
    private String data1318;
    @SerializedName("1319")
    private String data1319;
    @SerializedName("1320")
    private String data1320;
    @SerializedName("1321")
    private String data1321;
    @SerializedName("1322")
    private String data1322;
    @SerializedName("1323")
    private String data1323;
    @SerializedName("1324")
    private String data1324;
    @SerializedName("1325")
    private String data1325;
    @SerializedName("1326")
    private String data1326;
    @SerializedName("1327")
    private String data1327;
    @SerializedName("1328")
    private String data1328;
    @SerializedName("1329")
    private String data1329;
    @SerializedName("1330")
    private String data1330;
    @SerializedName("1300-0")
    private String data13000;
    @SerializedName("1300-1")
    private String data13001;
    @SerializedName("1300-2")
    private String data13002;
    @SerializedName("1300-3")
    private String data13003;
    @SerializedName("1300-4")
    private String data13004;
    @SerializedName("1300-5")
    private String data13005;
    @SerializedName("1300-6")
    private String data13006;
    @SerializedName("1300-7")
    private String data13007;
    @SerializedName("1300-8")
    private String data13008;
    @SerializedName("1300-9")
    private String data13009;
    @SerializedName("1301-0")
    private String data13010;
    @SerializedName("1301-1")
    private String data13011;
    @SerializedName("1301-2")
    private String data13012;
    @SerializedName("1301-3")
    private String data13013;
    @SerializedName("1301-4")
    private String data13014;
    @SerializedName("1301-5")
    private String data13015;
    @SerializedName("1301-6")
    private String data13016;
    @SerializedName("1301-7")
    private String data13017;
    @SerializedName("1301-8")
    private String data13018;
    @SerializedName("1301-9")
    private String data13019;
    @SerializedName("1302-0")
    private String data13020;
    @SerializedName("1302-1")
    private String data13021;
    @SerializedName("1302-2")
    private String data13022;
    @SerializedName("1302-3")
    private String data13023;
    @SerializedName("1302-4")
    private String data13024;
    @SerializedName("1302-5")
    private String data13025;
    @SerializedName("1302-6")
    private String data13026;
    @SerializedName("1302-7")
    private String data13027;
    @SerializedName("1302-8")
    private String data13028;
    @SerializedName("1302-9")
    private String data13029;
    @SerializedName("1303-0")
    private String data13030;
    @SerializedName("1303-1")
    private String data13031;
    @SerializedName("1303-2")
    private String data13032;
    @SerializedName("1303-3")
    private String data13033;
    @SerializedName("1303-4")
    private String data13034;
    @SerializedName("1303-5")
    private String data13035;
    @SerializedName("1303-6")
    private String data13036;
    @SerializedName("1303-7")
    private String data13037;
    @SerializedName("1303-8")
    private String data13038;
    @SerializedName("1303-9")
    private String data13039;
    @SerializedName("1304-0")
    private String data13040;
    @SerializedName("1304-1")
    private String data13041;
    @SerializedName("1304-2")
    private String data13042;
    @SerializedName("1304-3")
    private String data13043;
    @SerializedName("1304-4")
    private String data13044;
    @SerializedName("1304-5")
    private String data13045;
    @SerializedName("1304-6")
    private String data13046;
    @SerializedName("1304-7")
    private String data13047;
    @SerializedName("1304-8")
    private String data13048;
    @SerializedName("1304-9")
    private String data13049;
    @SerializedName("1-1305")
    private String data11305;
    @SerializedName("1-1306")
    private String data11306;
    @SerializedName("1-1307")
    private String data11307;
    @SerializedName("1-1308")
    private String data11308;
    @SerializedName("2-1305")
    private String data21305;
    @SerializedName("2-1306")
    private String data21306;
    @SerializedName("2-1307")
    private String data21307;
    @SerializedName("2-1308")
    private String data21308;
    @SerializedName("3-1305")
    private String data31305;
    @SerializedName("3-1306")
    private String data31306;
    @SerializedName("3-1307")
    private String data31307;
    @SerializedName("3-1308")
    private String data31308;
    @SerializedName("4-1305")
    private String data41305;
    @SerializedName("4-1306")
    private String data41306;
    @SerializedName("4-1307")
    private String data41307;
    @SerializedName("4-1308")
    private String data41308;
    @SerializedName("5-1305")
    private String data51305;
    @SerializedName("5-1306")
    private String data51306;
    @SerializedName("5-1307")
    private String data51307;
    @SerializedName("5-1308")
    private String data51308;

    public String getdata0() {
        return data0;
    }

    public void setdata0(String data0) {
        this.data0 = data0;
    }

    public String getdata1() {
        return data1;
    }

    public void setdata1(String data1) {
        this.data1 = data1;
    }

    public String getdata2() {
        return data2;
    }

    public void setdata2(String data2) {
        this.data2 = data2;
    }

    public String getdata3() {
        return data3;
    }

    public void setdata3(String data3) {
        this.data3 = data3;
    }

    public String getdata4() {
        return data4;
    }

    public void setdata4(String data4) {
        this.data4 = data4;
    }

    public String getdata5() {
        return data5;
    }

    public void setdata5(String data5) {
        this.data5 = data5;
    }

    public String getdata6() {
        return data6;
    }

    public void setdata6(String data6) {
        this.data6 = data6;
    }

    public String getdata7() {
        return data7;
    }

    public void setdata7(String data7) {
        this.data7 = data7;
    }

    public String getdata8() {
        return data8;
    }

    public void setdata8(String data8) {
        this.data8 = data8;
    }

    public String getdata9() {
        return data9;
    }

    public void setdata9(String data9) {
        this.data9 = data9;
    }

    public String getdata1305() {
        return data1305;
    }

    public void setdata1305(String data1305) {
        this.data1305 = data1305;
    }

    public String getdata1306() {
        return data1306;
    }

    public void setdata1306(String data1306) {
        this.data1306 = data1306;
    }

    public String getdata1307() {
        return data1307;
    }

    public void setdata1307(String data1307) {
        this.data1307 = data1307;
    }

    public String getdata1308() {
        return data1308;
    }

    public void setdata1308(String data1308) {
        this.data1308 = data1308;
    }

    public String getdata1309() {
        return data1309;
    }

    public void setdata1309(String data1309) {
        this.data1309 = data1309;
    }

    public String getdata1310() {
        return data1310;
    }

    public void setdata1310(String data1310) {
        this.data1310 = data1310;
    }

    public String getdata1311() {
        return data1311;
    }

    public void setdata1311(String data1311) {
        this.data1311 = data1311;
    }

    public String getdata1312() {
        return data1312;
    }

    public void setdata1312(String data1312) {
        this.data1312 = data1312;
    }

    public String getdata1313() {
        return data1313;
    }

    public void setdata1313(String data1313) {
        this.data1313 = data1313;
    }

    public String getdata1314() {
        return data1314;
    }

    public void setdata1314(String data1314) {
        this.data1314 = data1314;
    }

    public String getdata1315() {
        return data1315;
    }

    public void setdata1315(String data1315) {
        this.data1315 = data1315;
    }

    public String getdata1316() {
        return data1316;
    }

    public void setdata1316(String data1316) {
        this.data1316 = data1316;
    }

    public String getdata1317() {
        return data1317;
    }

    public void setdata1317(String data1317) {
        this.data1317 = data1317;
    }

    public String getdata1318() {
        return data1318;
    }

    public void setdata1318(String data1318) {
        this.data1318 = data1318;
    }

    public String getdata1319() {
        return data1319;
    }

    public void setdata1319(String data1319) {
        this.data1319 = data1319;
    }

    public String getdata1320() {
        return data1320;
    }

    public void setdata1320(String data1320) {
        this.data1320 = data1320;
    }

    public String getdata1321() {
        return data1321;
    }

    public void setdata1321(String data1321) {
        this.data1321 = data1321;
    }

    public String getdata1322() {
        return data1322;
    }

    public void setdata1322(String data1322) {
        this.data1322 = data1322;
    }

    public String getdata1323() {
        return data1323;
    }

    public void setdata1323(String data1323) {
        this.data1323 = data1323;
    }

    public String getdata1324() {
        return data1324;
    }

    public void setdata1324(String data1324) {
        this.data1324 = data1324;
    }

    public String getdata1325() {
        return data1325;
    }

    public void setdata1325(String data1325) {
        this.data1325 = data1325;
    }

    public String getdata1326() {
        return data1326;
    }

    public void setdata1326(String data1326) {
        this.data1326 = data1326;
    }

    public String getdata1327() {
        return data1327;
    }

    public void setdata1327(String data1327) {
        this.data1327 = data1327;
    }

    public String getdata1328() {
        return data1328;
    }

    public void setdata1328(String data1328) {
        this.data1328 = data1328;
    }

    public String getdata1329() {
        return data1329;
    }

    public void setdata1329(String data1329) {
        this.data1329 = data1329;
    }

    public String getdata1330() {
        return data1330;
    }

    public void setdata1330(String data1330) {
        this.data1330 = data1330;
    }

    public String getdata13000() {
        return data13000;
    }

    public void setdata13000(String data13000) {
        this.data13000 = data13000;
    }

    public String getdata13001() {
        return data13001;
    }

    public void setdata13001(String data13001) {
        this.data13001 = data13001;
    }

    public String getdata13002() {
        return data13002;
    }

    public void setdata13002(String data13002) {
        this.data13002 = data13002;
    }

    public String getdata13003() {
        return data13003;
    }

    public void setdata13003(String data13003) {
        this.data13003 = data13003;
    }

    public String getdata13004() {
        return data13004;
    }

    public void setdata13004(String data13004) {
        this.data13004 = data13004;
    }

    public String getdata13005() {
        return data13005;
    }

    public void setdata13005(String data13005) {
        this.data13005 = data13005;
    }

    public String getdata13006() {
        return data13006;
    }

    public void setdata13006(String data13006) {
        this.data13006 = data13006;
    }

    public String getdata13007() {
        return data13007;
    }

    public void setdata13007(String data13007) {
        this.data13007 = data13007;
    }

    public String getdata13008() {
        return data13008;
    }

    public void setdata13008(String data13008) {
        this.data13008 = data13008;
    }

    public String getdata13009() {
        return data13009;
    }

    public void setdata13009(String data13009) {
        this.data13009 = data13009;
    }

    public String getdata13010() {
        return data13010;
    }

    public void setdata13010(String data13010) {
        this.data13010 = data13010;
    }

    public String getdata13011() {
        return data13011;
    }

    public void setdata13011(String data13011) {
        this.data13011 = data13011;
    }

    public String getdata13012() {
        return data13012;
    }

    public void setdata13012(String data13012) {
        this.data13012 = data13012;
    }

    public String getdata13013() {
        return data13013;
    }

    public void setdata13013(String data13013) {
        this.data13013 = data13013;
    }

    public String getdata13014() {
        return data13014;
    }

    public void setdata13014(String data13014) {
        this.data13014 = data13014;
    }

    public String getdata13015() {
        return data13015;
    }

    public void setdata13015(String data13015) {
        this.data13015 = data13015;
    }

    public String getdata13016() {
        return data13016;
    }

    public void setdata13016(String data13016) {
        this.data13016 = data13016;
    }

    public String getdata13017() {
        return data13017;
    }

    public void setdata13017(String data13017) {
        this.data13017 = data13017;
    }

    public String getdata13018() {
        return data13018;
    }

    public void setdata13018(String data13018) {
        this.data13018 = data13018;
    }

    public String getdata13019() {
        return data13019;
    }

    public void setdata13019(String data13019) {
        this.data13019 = data13019;
    }

    public String getdata13020() {
        return data13020;
    }

    public void setdata13020(String data13020) {
        this.data13020 = data13020;
    }

    public String getdata13021() {
        return data13021;
    }

    public void setdata13021(String data13021) {
        this.data13021 = data13021;
    }

    public String getdata13022() {
        return data13022;
    }

    public void setdata13022(String data13022) {
        this.data13022 = data13022;
    }

    public String getdata13023() {
        return data13023;
    }

    public void setdata13023(String data13023) {
        this.data13023 = data13023;
    }

    public String getdata13024() {
        return data13024;
    }

    public void setdata13024(String data13024) {
        this.data13024 = data13024;
    }

    public String getdata13025() {
        return data13025;
    }

    public void setdata13025(String data13025) {
        this.data13025 = data13025;
    }

    public String getdata13026() {
        return data13026;
    }

    public void setdata13026(String data13026) {
        this.data13026 = data13026;
    }

    public String getdata13027() {
        return data13027;
    }

    public void setdata13027(String data13027) {
        this.data13027 = data13027;
    }

    public String getdata13028() {
        return data13028;
    }

    public void setdata13028(String data13028) {
        this.data13028 = data13028;
    }

    public String getdata13029() {
        return data13029;
    }

    public void setdata13029(String data13029) {
        this.data13029 = data13029;
    }

    public String getdata13030() {
        return data13030;
    }

    public void setdata13030(String data13030) {
        this.data13030 = data13030;
    }

    public String getdata13031() {
        return data13031;
    }

    public void setdata13031(String data13031) {
        this.data13031 = data13031;
    }

    public String getdata13032() {
        return data13032;
    }

    public void setdata13032(String data13032) {
        this.data13032 = data13032;
    }

    public String getdata13033() {
        return data13033;
    }

    public void setdata13033(String data13033) {
        this.data13033 = data13033;
    }

    public String getdata13034() {
        return data13034;
    }

    public void setdata13034(String data13034) {
        this.data13034 = data13034;
    }

    public String getdata13035() {
        return data13035;
    }

    public void setdata13035(String data13035) {
        this.data13035 = data13035;
    }

    public String getdata13036() {
        return data13036;
    }

    public void setdata13036(String data13036) {
        this.data13036 = data13036;
    }

    public String getdata13037() {
        return data13037;
    }

    public void setdata13037(String data13037) {
        this.data13037 = data13037;
    }

    public String getdata13038() {
        return data13038;
    }

    public void setdata13038(String data13038) {
        this.data13038 = data13038;
    }

    public String getdata13039() {
        return data13039;
    }

    public void setdata13039(String data13039) {
        this.data13039 = data13039;
    }

    public String getdata13040() {
        return data13040;
    }

    public void setdata13040(String data13040) {
        this.data13040 = data13040;
    }

    public String getdata13041() {
        return data13041;
    }

    public void setdata13041(String data13041) {
        this.data13041 = data13041;
    }

    public String getdata13042() {
        return data13042;
    }

    public void setdata13042(String data13042) {
        this.data13042 = data13042;
    }

    public String getdata13043() {
        return data13043;
    }

    public void setdata13043(String data13043) {
        this.data13043 = data13043;
    }

    public String getdata13044() {
        return data13044;
    }

    public void setdata13044(String data13044) {
        this.data13044 = data13044;
    }

    public String getdata13045() {
        return data13045;
    }

    public void setdata13045(String data13045) {
        this.data13045 = data13045;
    }

    public String getdata13046() {
        return data13046;
    }

    public void setdata13046(String data13046) {
        this.data13046 = data13046;
    }

    public String getdata13047() {
        return data13047;
    }

    public void setdata13047(String data13047) {
        this.data13047 = data13047;
    }

    public String getdata13048() {
        return data13048;
    }

    public void setdata13048(String data13048) {
        this.data13048 = data13048;
    }

    public String getdata13049() {
        return data13049;
    }

    public void setdata13049(String data13049) {
        this.data13049 = data13049;
    }

    public String getdata11305() {
        return data11305;
    }

    public void setdata11305(String data11305) {
        this.data11305 = data11305;
    }

    public String getdata11306() {
        return data11306;
    }

    public void setdata11306(String data11306) {
        this.data11306 = data11306;
    }

    public String getdata11307() {
        return data11307;
    }

    public void setdata11307(String data11307) {
        this.data11307 = data11307;
    }

    public String getdata11308() {
        return data11308;
    }

    public void setdata11308(String data11308) {
        this.data11308 = data11308;
    }

    public String getdata21305() {
        return data21305;
    }

    public void setdata21305(String data21305) {
        this.data21305 = data21305;
    }

    public String getdata21306() {
        return data21306;
    }

    public void setdata21306(String data21306) {
        this.data21306 = data21306;
    }

    public String getdata21307() {
        return data21307;
    }

    public void setdata21307(String data21307) {
        this.data21307 = data21307;
    }

    public String getdata21308() {
        return data21308;
    }

    public void setdata21308(String data21308) {
        this.data21308 = data21308;
    }

    public String getdata31305() {
        return data31305;
    }

    public void setdata31305(String data31305) {
        this.data31305 = data31305;
    }

    public String getdata31306() {
        return data31306;
    }

    public void setdata31306(String data31306) {
        this.data31306 = data31306;
    }

    public String getdata31307() {
        return data31307;
    }

    public void setdata31307(String data31307) {
        this.data31307 = data31307;
    }

    public String getdata31308() {
        return data31308;
    }

    public void setdata31308(String data31308) {
        this.data31308 = data31308;
    }

    public String getdata41305() {
        return data41305;
    }

    public void setdata41305(String data41305) {
        this.data41305 = data41305;
    }

    public String getdata41306() {
        return data41306;
    }

    public void setdata41306(String data41306) {
        this.data41306 = data41306;
    }

    public String getdata41307() {
        return data41307;
    }

    public void setdata41307(String data41307) {
        this.data41307 = data41307;
    }

    public String getdata41308() {
        return data41308;
    }

    public void setdata41308(String data41308) {
        this.data41308 = data41308;
    }

    public String getdata51305() {
        return data51305;
    }

    public void setdata51305(String data51305) {
        this.data51305 = data51305;
    }

    public String getdata51306() {
        return data51306;
    }

    public void setdata51306(String data51306) {
        this.data51306 = data51306;
    }

    public String getdata51307() {
        return data51307;
    }

    public void setdata51307(String data51307) {
        this.data51307 = data51307;
    }

    public String getdata51308() {
        return data51308;
    }

    public void setdata51308(String data51308) {
        this.data51308 = data51308;
    }
}
