package com.cfcp.a01.base;

/**
 * Created by Daniel on 2017/4/21.
 */

public interface DataAware<F> {

    public void setData(F data1);
}
